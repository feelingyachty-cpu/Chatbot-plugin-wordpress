<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fleet Spreadsheet Import — bulk-create/update yachts from a WooCommerce-style
 * product export (.xlsx or .csv), such as a migration dump from another
 * platform. This is a DIFFERENT format from the plugin's own round-trip CSV
 * (Checkout & Integrations → Export/Import CSV, see FY_Fleet_REST::csv_columns())
 * — that one uses this plugin's own column headers; this one reads the
 * generic WooCommerce importer headers (ID, Type, SKU, Name, Regular price,
 * Attribute N name/value(s), Meta: Location, Meta: Latitude, Meta: Longitude,
 * Images, …) plus any "N Hour Price" columns.
 *
 * Every row becomes (or updates) a yacht via the same FY_Fleet_REST::apply()
 * path the REST API and the plugin's own CSV importer use, so Woo product
 * sync, defaults and validation all run identically. Photos in the Images
 * column are downloaded into the Media Library and become the yacht's
 * gallery (first photo = featured image) via FY_Fleet_Woo::import_gallery_images().
 */
class FY_Fleet_Import {

	/**
	 * Seconds of photo-downloading one AJAX request may spend before it
	 * stops and hands a resume cursor back to the browser. Deliberately
	 * well under the usual 30s/60s PHP limit so a slow external image host
	 * can never push a single request into a gateway timeout.
	 */
	const IMAGE_TIME_BUDGET = 12;

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ), 20 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		// Full-page-POST handlers: the no-JS fallback. Large fleets (many
		// rows and/or many photos) should go through the AJAX batch path
		// below instead — one request processing everything can exceed the
		// host's PHP time limit and come back as a 502.
		add_action( 'admin_post_fy_import_spreadsheet', array( __CLASS__, 'handle_import' ) );
		add_action( 'admin_post_fy_import_bundled_spreadsheet', array( __CLASS__, 'handle_bundled_import' ) );
		// AJAX batch path: a handful of rows per request, looped from the
		// browser with a progress bar, so nothing ever runs long enough to
		// hit a server timeout regardless of fleet size.
		add_action( 'wp_ajax_fy_import_prepare_upload', array( __CLASS__, 'ajax_prepare_upload' ) );
		add_action( 'wp_ajax_fy_import_batch', array( __CLASS__, 'ajax_batch' ) );
	}

	public static function enqueue() {
		if ( ! isset( $_GET['page'] ) || 'fy-fleet-import' !== $_GET['page'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- page id only, no data processed
			return;
		}
		wp_enqueue_script( 'fy-fleet-import', FY_FLEET_URL . 'assets/import.js', array( 'jquery' ), FY_FLEET_VERSION, true );
		wp_localize_script(
			'fy-fleet-import',
			'fyImport',
			array(
				'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
				'nonce'         => wp_create_nonce( 'fy_import_batch' ),
				'visualizerUrl' => admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-visualizer' ),
			)
		);
	}

	/** True when includes/data/fleet-import.csv ships with this install. */
	private static function has_bundled_file() {
		return file_exists( FY_FLEET_DIR . 'includes/data/fleet-import.csv' );
	}

	public static function add_menu() {
		add_submenu_page(
			'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE,
			__( 'Import Fleet Spreadsheet', 'fy-fleet' ),
			__( 'Import Spreadsheet', 'fy-fleet' ),
			'manage_options',
			'fy-fleet-import',
			array( __CLASS__, 'render_page' )
		);
	}

	public static function render_page() {
		?>
		<div class="wrap">
			<h1><?php esc_html_e( '📥 Import Fleet Spreadsheet', 'fy-fleet' ); ?></h1>
			<p style="max-width:820px"><?php esc_html_e( 'Upload a WooCommerce-style product export (.xlsx or .csv) — e.g. a migration file from another booking platform. Each row becomes a yacht: name, price, size, capacity, description, categories, marina location, and every photo in the Images column (downloaded into the Media Library and set as that yacht\'s gallery, first photo = featured image).', 'fy-fleet' ); ?></p>

			<?php if ( isset( $_GET['fy_import_result'] ) ) : ?>
				<?php
				$created = isset( $_GET['created'] ) ? intval( $_GET['created'] ) : 0;
				$updated = isset( $_GET['updated'] ) ? intval( $_GET['updated'] ) : 0;
				$skipped = isset( $_GET['skipped'] ) ? intval( $_GET['skipped'] ) : 0;
				?>
				<?php if ( 'ok' === $_GET['fy_import_result'] ) : ?>
					<div class="notice notice-success"><p>
						<?php
						printf(
							/* translators: 1: created count 2: updated count 3: skipped count */
							esc_html__( 'Import complete: %1$d yacht(s) created, %2$d updated, %3$d row(s) skipped.', 'fy-fleet' ),
							$created,
							$updated,
							$skipped
						);
						?>
						<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-visualizer' ) ); ?>"><?php esc_html_e( 'Open the Fleet Visualizer', 'fy-fleet' ); ?></a>
					</p></div>
				<?php else : ?>
					<div class="notice notice-error"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['fy_import_result'] ) ) ); ?></p></div>
				<?php endif; ?>
			<?php endif; ?>

			<?php if ( self::has_bundled_file() ) : ?>
				<h2><?php esc_html_e( '⚡ Bundled spreadsheet', 'fy-fleet' ); ?></h2>
				<p class="description" style="max-width:820px"><?php esc_html_e( 'This plugin install ships with a fleet spreadsheet already built in — nothing to upload. Pick a city and go.', 'fy-fleet' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="fy-import-bundled-form" style="margin-top:12px;padding:14px 18px;border:1px solid #E6EAF3;border-radius:10px;background:#F8FAFF;max-width:820px">
					<input type="hidden" name="action" value="fy_import_bundled_spreadsheet">
					<?php wp_nonce_field( 'fy_import_bundled_spreadsheet' ); ?>
					<table class="form-table">
						<?php self::render_shared_fields(); ?>
					</table>
					<?php submit_button( __( 'Import Bundled Spreadsheet', 'fy-fleet' ), 'primary' ); ?>
				</form>
				<h2 style="margin-top:28px"><?php esc_html_e( 'Or upload a different spreadsheet', 'fy-fleet' ); ?></h2>
			<?php endif; ?>

			<h2><?php esc_html_e( 'Expected columns', 'fy-fleet' ); ?></h2>
			<p class="description" style="max-width:820px">
				<?php esc_html_e( 'Column names are matched by header text, case-insensitive — extra columns are ignored and missing ones are simply left blank. Recognized columns:', 'fy-fleet' ); ?>
			</p>
			<ul style="max-width:820px;list-style:disc;margin-left:22px">
				<li><code>Name</code>, <code>SKU</code>, <code>Published</code>, <code>Short description</code>, <code>Description</code></li>
				<li><code>Regular price</code> (the per-hour rate) and any <code>3/4/5/6/7/8 Hour Price</code> columns</li>
				<li><code>Categories</code> (imported as search tags, e.g. boat type/brand — NOT the city, see below), <code>Images</code> (comma-separated URLs)</li>
				<li><code>Attribute N name</code> / <code>Attribute N value(s)</code> — recognizes <em>Capacity (guests)</em>, <em>Length (ft)</em>, <em>Year</em>, <em>Captain Included</em>, <em>Brand</em></li>
				<li><code>Meta: Model</code>, <code>Meta: Rating</code>, <code>Meta: Owner</code>, <code>Meta: Source Listing ID</code></li>
				<li><code>Meta: Location</code>, <code>Meta: Latitude</code>, <code>Meta: Longitude</code> — becomes the yacht's marina + embedded Google map</li>
			</ul>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data" id="fy-import-upload-form" style="margin-top:16px">
				<input type="hidden" name="action" value="fy_import_spreadsheet">
				<?php wp_nonce_field( 'fy_import_spreadsheet' ); ?>
				<table class="form-table">
					<tr>
						<th><label for="fy_spreadsheet_file"><?php esc_html_e( 'Spreadsheet file', 'fy-fleet' ); ?></label></th>
						<td><input type="file" id="fy_spreadsheet_file" name="fy_spreadsheet_file" accept=".xlsx,.csv" required></td>
					</tr>
					<?php self::render_shared_fields(); ?>
				</table>
				<p class="description"><?php esc_html_e( 'A full backup of the fleet is taken automatically before the import runs, and can be restored from the Import/Export API page.', 'fy-fleet' ); ?></p>
				<?php submit_button( __( 'Import Spreadsheet', 'fy-fleet' ) ); ?>
			</form>
		</div>
		<?php
	}

	/** City picker + match-by options + photos checkbox — shared by both forms. */
	private static function render_shared_fields() {
		?>
		<tr>
			<th><?php esc_html_e( 'City / fleet widget', 'fy-fleet' ); ?></th>
			<td>
				<?php
				$cities = get_terms( array( 'taxonomy' => 'fy_yacht_cat', 'hide_empty' => false ) );
				$cities = is_wp_error( $cities ) ? array() : $cities;
				?>
				<select name="fy_import_city">
					<option value="__new__"><?php esc_html_e( '＋ Create a new city (recommended — keeps this fleet separate)', 'fy-fleet' ); ?></option>
					<?php foreach ( $cities as $city_term ) : ?>
						<option value="<?php echo esc_attr( $city_term->term_id ); ?>"><?php echo esc_html( $city_term->name ); ?> (<?php echo (int) $city_term->count; ?>)</option>
					<?php endforeach; ?>
				</select>
				<br><br>
				<label><?php esc_html_e( 'New city name', 'fy-fleet' ); ?></label><br>
				<input type="text" name="fy_import_city_name" class="regular-text" placeholder="<?php esc_attr_e( 'e.g. New Fleet', 'fy-fleet' ); ?>">
				<p class="description"><?php esc_html_e( 'Every yacht in this import is assigned to ONE city term, which gets its own grid page automatically (e.g. /yacht-category/new-fleet/) and never appears on your existing Miami/Panama pages unless you pick one of those above. Ignored if you pick an existing city from the dropdown.', 'fy-fleet' ); ?></p>
			</td>
		</tr>
		<tr>
			<th><?php esc_html_e( 'Match existing yachts by', 'fy-fleet' ); ?></th>
			<td>
				<label><input type="checkbox" name="fy_match_sku" value="1" checked> <?php esc_html_e( 'SKU (recommended — re-running this import updates the same yachts instead of duplicating them)', 'fy-fleet' ); ?></label><br>
				<label><input type="checkbox" name="fy_match_title" value="1" checked> <?php esc_html_e( 'Yacht name, if no SKU match is found', 'fy-fleet' ); ?></label>
			</td>
		</tr>
		<tr>
			<th><?php esc_html_e( 'Photos', 'fy-fleet' ); ?></th>
			<td><label><input type="checkbox" name="fy_import_images" value="1" checked> <?php esc_html_e( 'Download every photo in the Images column into the Media Library (skips URLs already imported on a re-run)', 'fy-fleet' ); ?></label></td>
		</tr>
		<?php
	}

	/* ------------------------------------------------------------------
	 * Upload handler
	 * ---------------------------------------------------------------- */

	public static function handle_import() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		check_admin_referer( 'fy_import_spreadsheet' );

		if ( empty( $_FILES['fy_spreadsheet_file']['tmp_name'] ) || ! is_uploaded_file( $_FILES['fy_spreadsheet_file']['tmp_name'] ) ) {
			self::redirect_error( __( 'No file uploaded.', 'fy-fleet' ) );
		}

		$name = isset( $_FILES['fy_spreadsheet_file']['name'] ) ? sanitize_file_name( wp_unslash( $_FILES['fy_spreadsheet_file']['name'] ) ) : '';
		$tmp  = sanitize_text_field( $_FILES['fy_spreadsheet_file']['tmp_name'] ); // phpcs:ignore -- tmp upload path
		$ext  = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );

		if ( 'xlsx' === $ext ) {
			$rows = self::read_xlsx( $tmp );
		} elseif ( 'csv' === $ext ) {
			$rows = self::read_csv( $tmp );
		} else {
			self::redirect_error( __( 'Unsupported file type — upload a .xlsx or .csv file.', 'fy-fleet' ) );
			return;
		}

		if ( is_wp_error( $rows ) ) {
			self::redirect_error( $rows->get_error_message() );
			return;
		}
		if ( empty( $rows ) || count( $rows ) < 2 ) {
			self::redirect_error( __( 'That file has no data rows.', 'fy-fleet' ) );
			return;
		}

		$city_term_id = self::resolve_city_term();
		if ( is_wp_error( $city_term_id ) ) {
			self::redirect_error( $city_term_id->get_error_message() );
			return;
		}

		$counts = self::run_import(
			$rows,
			$city_term_id,
			! empty( $_POST['fy_match_sku'] ),
			! empty( $_POST['fy_match_title'] ),
			! empty( $_POST['fy_import_images'] )
		);
		if ( is_wp_error( $counts ) ) {
			self::redirect_error( $counts->get_error_message() );
			return;
		}

		self::redirect_ok( $counts );
	}

	/**
	 * Import the fleet spreadsheet shipped inside the plugin itself
	 * (includes/data/fleet-import.csv) — no file to upload, just pick a
	 * city and go.
	 */
	public static function handle_bundled_import() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		check_admin_referer( 'fy_import_bundled_spreadsheet' );

		$path = FY_FLEET_DIR . 'includes/data/fleet-import.csv';
		if ( ! file_exists( $path ) ) {
			self::redirect_error( __( 'The bundled fleet spreadsheet was not found in this plugin install.', 'fy-fleet' ) );
			return;
		}

		$rows = self::read_csv( $path );
		if ( is_wp_error( $rows ) ) {
			self::redirect_error( $rows->get_error_message() );
			return;
		}
		if ( empty( $rows ) || count( $rows ) < 2 ) {
			self::redirect_error( __( 'That file has no data rows.', 'fy-fleet' ) );
			return;
		}

		$city_term_id = self::resolve_city_term();
		if ( is_wp_error( $city_term_id ) ) {
			self::redirect_error( $city_term_id->get_error_message() );
			return;
		}

		$counts = self::run_import(
			$rows,
			$city_term_id,
			! empty( $_POST['fy_match_sku'] ),
			! empty( $_POST['fy_match_title'] ),
			! empty( $_POST['fy_import_images'] )
		);
		if ( is_wp_error( $counts ) ) {
			self::redirect_error( $counts->get_error_message() );
			return;
		}

		self::redirect_ok( $counts );
	}

	/* ------------------------------------------------------------------
	 * AJAX batch import — small chunks per request, driven by assets/import.js
	 * ---------------------------------------------------------------- */

	/** Where an AJAX-uploaded spreadsheet is held between batch requests. */
	private static function temp_upload_dir() {
		$upload_dir = wp_upload_dir();
		return trailingslashit( $upload_dir['basedir'] ) . 'fy-import-tmp';
	}

	/**
	 * Step 1 of the AJAX flow for an uploaded file: save it once to a temp
	 * location and hand the browser back a token, so every batch request
	 * after this one just references the file instead of re-uploading it.
	 */
	public static function ajax_prepare_upload() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'fy-fleet' ) ), 403 );
		}
		check_ajax_referer( 'fy_import_batch', 'nonce' );

		if ( empty( $_FILES['file']['tmp_name'] ) || ! is_uploaded_file( $_FILES['file']['tmp_name'] ) ) {
			wp_send_json_error( array( 'message' => __( 'No file uploaded.', 'fy-fleet' ) ) );
		}

		$name = isset( $_FILES['file']['name'] ) ? sanitize_file_name( wp_unslash( $_FILES['file']['name'] ) ) : '';
		$ext  = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
		if ( ! in_array( $ext, array( 'xlsx', 'csv' ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'Unsupported file type — upload a .xlsx or .csv file.', 'fy-fleet' ) ) );
		}

		$dir = self::temp_upload_dir();
		if ( ! file_exists( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		if ( ! file_exists( $dir . '/index.html' ) ) {
			@file_put_contents( $dir . '/index.html', '' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- best-effort directory listing guard
		}

		$token = wp_generate_password( 24, false, false );
		$dest  = $dir . '/' . $token . '.' . $ext;
		if ( ! move_uploaded_file( $_FILES['file']['tmp_name'], $dest ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_move_uploaded_file -- tmp upload
			wp_send_json_error( array( 'message' => __( 'Could not save the uploaded file.', 'fy-fleet' ) ) );
		}

		$rows = ( 'xlsx' === $ext ) ? self::read_xlsx( $dest ) : self::read_csv( $dest );
		if ( is_wp_error( $rows ) ) {
			wp_delete_file( $dest );
			wp_send_json_error( array( 'message' => $rows->get_error_message() ) );
		}
		if ( empty( $rows ) || count( $rows ) < 2 ) {
			wp_delete_file( $dest );
			wp_send_json_error( array( 'message' => __( 'That file has no data rows.', 'fy-fleet' ) ) );
		}
		if ( ! isset( self::map_headers( $rows[0] )['Name'] ) ) {
			wp_delete_file( $dest );
			wp_send_json_error( array( 'message' => __( 'A "Name" column is required and was not found.', 'fy-fleet' ) ) );
		}

		wp_send_json_success(
			array(
				'token' => $token,
				'ext'   => $ext,
				'total' => count( $rows ) - 1,
			)
		);
	}

	/**
	 * Step 2 (repeated): process a handful of rows from either the bundled
	 * spreadsheet or a previously-uploaded one. The browser calls this in a
	 * loop, advancing `offset` each time, until `done` comes back true.
	 */
	public static function ajax_batch() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'fy-fleet' ) ), 403 );
		}
		check_ajax_referer( 'fy_import_batch', 'nonce' );

		$source     = isset( $_POST['source'] ) ? sanitize_key( wp_unslash( $_POST['source'] ) ) : '';
		$offset     = isset( $_POST['offset'] ) ? max( 0, intval( $_POST['offset'] ) ) : 0;
		$img_offset = isset( $_POST['img_offset'] ) ? max( 0, intval( $_POST['img_offset'] ) ) : 0;
		$do_images  = ! empty( $_POST['do_images'] );
		// Photos are the slow part — one yacht at a time when downloading
		// images (and that yacht's photos are themselves chunked by a time
		// budget); metadata-only rows are cheap, so a bigger batch is fine.
		$batch_size = $do_images ? 1 : 10;

		$path = '';
		if ( 'bundled' === $source ) {
			$path = FY_FLEET_DIR . 'includes/data/fleet-import.csv';
			if ( ! file_exists( $path ) ) {
				wp_send_json_error( array( 'message' => __( 'The bundled fleet spreadsheet was not found in this plugin install.', 'fy-fleet' ) ) );
			}
			$rows = self::read_csv( $path );
		} elseif ( 'uploaded' === $source ) {
			$token = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
			$ext   = isset( $_POST['ext'] ) ? sanitize_key( wp_unslash( $_POST['ext'] ) ) : '';
			if ( ! preg_match( '/^[A-Za-z0-9]{10,40}$/', $token ) || ! in_array( $ext, array( 'xlsx', 'csv' ), true ) ) {
				wp_send_json_error( array( 'message' => __( 'Invalid upload reference — please start over.', 'fy-fleet' ) ) );
			}
			$path = self::temp_upload_dir() . '/' . $token . '.' . $ext;
			if ( ! file_exists( $path ) ) {
				wp_send_json_error( array( 'message' => __( 'Uploaded file not found — please start over.', 'fy-fleet' ) ) );
			}
			$rows = ( 'xlsx' === $ext ) ? self::read_xlsx( $path ) : self::read_csv( $path );
		} else {
			wp_send_json_error( array( 'message' => __( 'Unknown import source.', 'fy-fleet' ) ) );
		}

		if ( is_wp_error( $rows ) ) {
			wp_send_json_error( array( 'message' => $rows->get_error_message() ) );
		}
		if ( empty( $rows ) || count( $rows ) < 2 ) {
			wp_send_json_error( array( 'message' => __( 'That file has no data rows.', 'fy-fleet' ) ) );
		}

		$header = array_shift( $rows );
		$map    = self::map_headers( $header );
		if ( ! isset( $map['Name'] ) ) {
			wp_send_json_error( array( 'message' => __( 'A "Name" column is required and was not found.', 'fy-fleet' ) ) );
		}

		$total = count( $rows );

		// The city is resolved ONCE, on the very first batch, and the
		// resulting term ID is handed back for the browser to reuse on
		// every later batch — so "create a new city" only ever creates it once.
		$city_term_id = isset( $_POST['city_term_id'] ) ? intval( $_POST['city_term_id'] ) : 0;
		if ( ! $city_term_id && 0 === $offset ) {
			$choice   = isset( $_POST['city_choice'] ) ? sanitize_text_field( wp_unslash( $_POST['city_choice'] ) ) : '__new__';
			$name     = isset( $_POST['city_name'] ) ? sanitize_text_field( wp_unslash( $_POST['city_name'] ) ) : '';
			$resolved = self::resolve_city_term_from( $choice, $name );
			if ( is_wp_error( $resolved ) ) {
				wp_send_json_error( array( 'message' => $resolved->get_error_message() ) );
			}
			$city_term_id = $resolved;
		}

		if ( 0 === $offset && 0 === $img_offset && class_exists( 'FY_Fleet_REST' ) ) {
			FY_Fleet_REST::create_backup( 'pre-spreadsheet-import' );
		}

		$match_sku   = ! empty( $_POST['match_sku'] );
		$match_title = ! empty( $_POST['match_title'] );

		$created = 0;
		$updated = 0;
		$skipped = 0;

		if ( $do_images ) {
			// ---- Photo mode: ONE yacht per request, and that yacht's photo
			// list is itself resumable. A 145-photo yacht would otherwise mean
			// 145 external downloads inside a single request, which is what
			// blows the host's PHP timeout (surfacing as a 502).
			if ( $offset >= $total ) {
				$processed = $total;
				$done      = true;
			} else {
				$row  = $rows[ $offset ];
				$cell = function ( $label ) use ( $row, $map ) {
					return isset( $map[ $label ], $row[ $map[ $label ] ] ) ? trim( (string) $row[ $map[ $label ] ] ) : '';
				};
				$title = self::clean_yacht_name( $cell( 'Name' ) );

				$yacht_id       = isset( $_POST['row_yacht_id'] ) ? intval( $_POST['row_yacht_id'] ) : 0;
				$row_finished   = false;
				$next_img_offset = 0;

				if ( '' === $title ) {
					$skipped++;
					$row_finished = true;
				} else {
					try {
						// Create/update the yacht on the row's FIRST request
						// only; later chunks just keep feeding it photos.
						if ( 0 === $img_offset || ! $yacht_id ) {
							$yacht_id = (int) self::process_one_row( $cell, $map, $row, false, $match_sku, $match_title, $city_term_id, $title, $created, $updated, $skipped );
						}

						if ( ! $yacht_id ) {
							$row_finished = true;
						} else {
							$image_urls = self::split_urls( $cell( 'Images' ) );
							if ( empty( $image_urls ) || ! class_exists( 'FY_Fleet_Woo' ) ) {
								$row_finished = true;
							} else {
								$result          = FY_Fleet_Woo::import_gallery_images( $yacht_id, $image_urls, $img_offset, self::IMAGE_TIME_BUDGET );
								$row_finished    = ! empty( $result['done'] );
								$next_img_offset = (int) $result['next_offset'];
							}
						}
					} catch ( \Throwable $e ) {
						$skipped++;
						$row_finished = true;
						if ( class_exists( 'FY_Fleet_Log' ) ) {
							FY_Fleet_Log::add( 'import.row_failed', sprintf( 'Import row "%s" failed: %s', $title, $e->getMessage() ) );
						}
					}
				}

				if ( $row_finished ) {
					$offset++;
					$img_offset = 0;
					$yacht_id   = 0;
				} else {
					$img_offset = $next_img_offset;
				}
				$processed = min( $offset, $total );
				$done      = $offset >= $total;
			}
		} else {
			// ---- Metadata-only mode: photos are skipped entirely, so rows
			// are cheap and can go several at a time.
			$slice  = array_slice( $rows, $offset, $batch_size );
			$counts = self::process_rows( $slice, $map, $city_term_id, $match_sku, $match_title, false );

			$created   = $counts['created'];
			$updated   = $counts['updated'];
			$skipped   = $counts['skipped'];
			$offset    = min( $offset + count( $slice ), $total );
			$processed = $offset;
			$done      = $processed >= $total || empty( $slice );
			$yacht_id  = 0;
		}

		if ( $done ) {
			if ( class_exists( 'FY_Fleet_Log' ) ) {
				FY_Fleet_Log::add( 'import.spreadsheet', sprintf( 'Spreadsheet import (%s, batched): finished', $source ) );
			}
			if ( 'uploaded' === $source && $path && file_exists( $path ) ) {
				wp_delete_file( $path );
			}
		}

		wp_send_json_success(
			array(
				'processed'    => $processed,
				'total'        => $total,
				'created'      => $created,
				'updated'      => $updated,
				'skipped'      => $skipped,
				'done'         => $done,
				'city_term_id' => $city_term_id,
				// Cursor the browser echoes back so the next request resumes
				// exactly where this one stopped — including mid-photo-list.
				'offset'       => $offset,
				'img_offset'   => $img_offset,
				'row_yacht_id' => isset( $yacht_id ) ? (int) $yacht_id : 0,
			)
		);
	}

	/**
	 * Shared row-processing loop used by both the upload and the bundled
	 * import — everything after "we have a parsed 2-D array of rows" is
	 * identical regardless of where those rows came from.
	 *
	 * @return array{created:int,updated:int,skipped:int}|WP_Error
	 */
	private static function run_import( $rows, $city_term_id, $match_sku, $match_title, $do_images ) {
		if ( empty( $rows ) || count( $rows ) < 2 ) {
			return new WP_Error( 'fy_no_rows', __( 'That file has no data rows.', 'fy-fleet' ) );
		}

		$header = array_shift( $rows );
		$map    = self::map_headers( $header );
		if ( ! isset( $map['Name'] ) ) {
			return new WP_Error( 'fy_no_name_column', __( 'A "Name" column is required and was not found.', 'fy-fleet' ) );
		}

		if ( class_exists( 'FY_Fleet_REST' ) ) {
			FY_Fleet_REST::create_backup( 'pre-spreadsheet-import' );
		}

		$counts = self::process_rows( $rows, $map, $city_term_id, $match_sku, $match_title, $do_images );

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'import.spreadsheet', sprintf( 'Spreadsheet import: %d created, %d updated, %d skipped', $counts['created'], $counts['updated'], $counts['skipped'] ) );
		}

		return $counts;
	}

	/**
	 * Create/update yachts for a set of already-mapped data rows (no header
	 * row, no backup, no logging) — the reusable core also called per-batch
	 * by the AJAX importer, which processes a handful of rows per request
	 * instead of the whole file in one shot (large fleets with photos can
	 * easily exceed a host's PHP time limit in a single request).
	 *
	 * @return array{created:int,updated:int,skipped:int}
	 */
	private static function process_rows( $rows, $map, $city_term_id, $match_sku, $match_title, $do_images ) {
		$created = 0;
		$updated = 0;
		$skipped = 0;

		foreach ( $rows as $row ) {
			$cell = function ( $label ) use ( $row, $map ) {
				return isset( $map[ $label ], $row[ $map[ $label ] ] ) ? trim( (string) $row[ $map[ $label ] ] ) : '';
			};

			$title = self::clean_yacht_name( $cell( 'Name' ) );
			if ( '' === $title ) {
				$skipped++;
				continue;
			}

			// One bad row (a malformed cell, an unexpected error anywhere in
			// yacht creation, product sync, or gallery import) must not take
			// down the whole batch — every request from here on is wrapped
			// so a single failure becomes a skipped row instead of a fatal
			// error that breaks the AJAX response for every row after it.
			try {
				self::process_one_row( $cell, $map, $row, $do_images, $match_sku, $match_title, $city_term_id, $title, $created, $updated, $skipped );
			} catch ( \Throwable $e ) {
				$skipped++;
				if ( class_exists( 'FY_Fleet_Log' ) ) {
					FY_Fleet_Log::add( 'import.row_failed', sprintf( 'Import row "%s" failed: %s', $title, $e->getMessage() ) );
				}
			}
		}

		return array( 'created' => $created, 'updated' => $updated, 'skipped' => $skipped );
	}

	/**
	 * One data row → one created/updated yacht.
	 *
	 * Broken out so process_rows() can wrap it in a try/catch per row, and so
	 * the AJAX batch importer can create the yacht WITHOUT its photos
	 * ($do_images = false) and then pull those in resumable chunks.
	 *
	 * @return int The yacht ID, or 0 when the row could not be imported.
	 */
	private static function process_one_row( $cell, $map, $row, $do_images, $match_sku, $match_title, $city_term_id, $title, &$created, &$updated, &$skipped ) {
			$params = self::row_to_params( $cell, $map, $row, $do_images );

			$target = 0;
			$sku    = isset( $params['sku'] ) ? $params['sku'] : '';
			if ( $match_sku && '' !== $sku ) {
				$existing = get_posts(
					array(
						'post_type'      => FY_Fleet_CPT::POST_TYPE,
						'post_status'    => 'any',
						'posts_per_page' => 1,
						'fields'         => 'ids',
						'meta_key'       => '_fy_sku',
						'meta_value'     => $sku,
					)
				);
				if ( $existing ) {
					$target = (int) $existing[0];
				}
			}
			if ( ! $target && $match_title ) {
				$existing = get_posts(
					array(
						'post_type'      => FY_Fleet_CPT::POST_TYPE,
						'post_status'    => 'any',
						'title'          => $title,
						'posts_per_page' => 1,
						'fields'         => 'ids',
					)
				);
				if ( $existing ) {
					$target = (int) $existing[0];
				}
			}

			$request = new WP_REST_Request( 'POST' );
			foreach ( $params as $key => $value ) {
				$request->set_param( $key, $value );
			}

			if ( $target ) {
				$request['id'] = $target;
				$result        = FY_Fleet_REST::update_yacht( $request );
				$yacht_id      = ( ! is_wp_error( $result ) ) ? $target : 0;
			} else {
				$result   = FY_Fleet_REST::create_yacht( $request );
				$data     = ( ! is_wp_error( $result ) ) ? $result->get_data() : null;
				$yacht_id = ( is_array( $data ) && ! empty( $data['id'] ) ) ? intval( $data['id'] ) : 0;
			}

			if ( ! $yacht_id ) {
				$skipped++;
				return 0;
			}
			$target ? $updated++ : $created++;

			// Force this yacht onto the chosen city term — set explicitly
			// (not merely as a fallback default), so it always lands in the
			// dedicated fleet picked on the import screen, never mixed into
			// whatever city an existing matched yacht already belonged to.
			if ( $city_term_id ) {
				wp_set_object_terms( $yacht_id, array( $city_term_id ), 'fy_yacht_cat', false );
			}

			if ( $do_images && class_exists( 'FY_Fleet_Woo' ) ) {
				$image_urls = self::split_urls( $cell( 'Images' ) );
				if ( ! empty( $image_urls ) ) {
					FY_Fleet_Woo::import_gallery_images( $yacht_id, $image_urls );
				}
			}

			return $yacht_id;
	}

	private static function redirect_ok( $counts ) {
		wp_safe_redirect(
			add_query_arg(
				array(
					'post_type'        => FY_Fleet_CPT::POST_TYPE,
					'page'             => 'fy-fleet-import',
					'fy_import_result' => 'ok',
					'created'          => $counts['created'],
					'updated'          => $counts['updated'],
					'skipped'          => $counts['skipped'],
				),
				admin_url( 'edit.php' )
			)
		);
		exit;
	}

	/**
	 * Resolve the city (fy_yacht_cat term) this whole import lands in — an
	 * existing term picked from the dropdown, or a brand-new one created
	 * from the typed name. Every yacht in the run gets exactly this term,
	 * so the import is fully isolated from any existing city/fleet.
	 *
	 * @return int|WP_Error Term ID, 0 if the taxonomy doesn't exist, or a WP_Error.
	 */
	private static function resolve_city_term() {
		$choice = isset( $_POST['fy_import_city'] ) ? sanitize_text_field( wp_unslash( $_POST['fy_import_city'] ) ) : '__new__';
		$name   = isset( $_POST['fy_import_city_name'] ) ? sanitize_text_field( wp_unslash( $_POST['fy_import_city_name'] ) ) : '';
		return self::resolve_city_term_from( $choice, $name );
	}

	/**
	 * Resolve the city (fy_yacht_cat term) an import lands in — an existing
	 * term ID (as a string), or "__new__" plus a name to create one. Every
	 * yacht in the run gets exactly this term, so the import is fully
	 * isolated from any existing city/fleet.
	 *
	 * @return int|WP_Error Term ID, 0 if the taxonomy doesn't exist, or a WP_Error.
	 */
	private static function resolve_city_term_from( $choice, $name ) {
		if ( ! taxonomy_exists( 'fy_yacht_cat' ) ) {
			return 0;
		}

		if ( '__new__' !== $choice ) {
			$term_id = intval( $choice );
			$term    = $term_id ? get_term( $term_id, 'fy_yacht_cat' ) : null;
			if ( $term && ! is_wp_error( $term ) ) {
				return (int) $term->term_id;
			}
			return new WP_Error( 'fy_bad_city', __( 'The selected city could not be found — pick another, or create a new one.', 'fy-fleet' ) );
		}

		if ( '' === $name ) {
			return new WP_Error( 'fy_no_city_name', __( 'Type a name for the new city, or pick an existing one from the dropdown.', 'fy-fleet' ) );
		}

		$slug     = sanitize_title( $name );
		$existing = get_term_by( 'slug', $slug, 'fy_yacht_cat' );
		if ( $existing && ! is_wp_error( $existing ) ) {
			return (int) $existing->term_id;
		}

		$created = wp_insert_term( $name, 'fy_yacht_cat', array( 'slug' => $slug ) );
		if ( is_wp_error( $created ) ) {
			return $created;
		}
		// A new city gets its own URL namespace (see FY_Fleet_Woo::add_pretty_url_rewrite())
		// — that only takes effect once rewrite rules are rebuilt.
		update_option( 'fy_fleet_flush_needed', '1' );
		return (int) $created['term_id'];
	}

	private static function redirect_error( $message ) {
		wp_safe_redirect(
			add_query_arg(
				array(
					'post_type'        => FY_Fleet_CPT::POST_TYPE,
					'page'             => 'fy-fleet-import',
					'fy_import_result' => rawurlencode( $message ),
				),
				admin_url( 'edit.php' )
			)
		);
		exit;
	}

	/* ------------------------------------------------------------------
	 * Row → REST params
	 * ---------------------------------------------------------------- */

	private static function split_urls( $raw ) {
		if ( '' === trim( (string) $raw ) ) {
			return array();
		}
		$urls = array_map( 'trim', explode( ',', (string) $raw ) );
		return array_values( array_filter( $urls ) );
	}

	/**
	 * Attribute N name/value pairs → a lowercased label => value lookup,
	 * e.g. {"capacity (guests)":"13","length (ft)":"60","year":"2006", …}.
	 */
	private static function attribute_lookup( $map, $row ) {
		$out = array();
		for ( $i = 1; $i <= 6; $i++ ) {
			$name_col  = 'Attribute ' . $i . ' name';
			$value_col = 'Attribute ' . $i . ' value(s)';
			if ( ! isset( $map[ $name_col ], $map[ $value_col ] ) ) {
				continue;
			}
			$label = isset( $row[ $map[ $name_col ] ] ) ? trim( (string) $row[ $map[ $name_col ] ] ) : '';
			$value = isset( $row[ $map[ $value_col ] ] ) ? trim( (string) $row[ $map[ $value_col ] ] ) : '';
			if ( '' === $label ) {
				continue;
			}
			$out[ strtolower( $label ) ] = $value;
		}
		return $out;
	}

	/**
	 * Yacht names in Title Case — first letter of each word capitalised, the
	 * rest lowercase. Source listings are a mix of "ZEUS", "sale vita" and
	 * "Happy Place"; the fleet grid reads far better when they all match.
	 */
	public static function title_case( $name ) {
		$name = trim( preg_replace( '/\s+/', ' ', (string) $name ) );
		if ( '' === $name ) {
			return '';
		}

		$name = function_exists( 'mb_convert_case' )
			? mb_convert_case( $name, MB_CASE_TITLE, 'UTF-8' )
			: ucwords( strtolower( $name ) );

		// Roman numerals are common in boat names ("Millennium II", "Sweet
		// Caroline II") and plain title-casing turns them into "Ii", which
		// just reads as a typo. Only multi-letter numerals are restored —
		// a lone "I", "V" or "X" is far more likely to be an initial.
		$name = preg_replace_callback(
			'/\b(ii|iii|iv|vi|vii|viii|ix|xi|xii)\b/i',
			function ( $m ) {
				return strtoupper( $m[1] );
			},
			$name
		);

		return $name;
	}

	/**
	 * A description written from THIS yacht's own specifications.
	 *
	 * The source sheet reuses the same paragraph across dozens of listings
	 * (one blurb appears 44 times), which reads as filler and gives search
	 * engines 44 identical pages. This builds a genuinely per-yacht
	 * paragraph out of the facts we actually hold — builder, model, year,
	 * length, capacity, captain, departure area, boat type and the charter
	 * lengths offered.
	 *
	 * Sentence variants are chosen from a hash of the yacht's own name, so
	 * two yachts with identical specs still read differently, while the SAME
	 * yacht produces the SAME text on every re-import (no churn).
	 *
	 * @param array $facts name, brand, model, year, size, capacity, captain, type, area, hours[]
	 */
	public static function build_description( $facts ) {
		$facts = wp_parse_args(
			$facts,
			array(
				'name'     => '',
				'brand'    => '',
				'model'    => '',
				'year'     => 0,
				'size'     => 0,
				'capacity' => 0,
				'captain'  => false,
				'type'     => '',
				'area'     => '',
				'hours'    => array(),
				'price'    => 0,
			)
		);

		$name = $facts['name'];
		if ( '' === $name ) {
			return '';
		}

		// Stable per-yacht "randomness": the same yacht always produces the
		// same text (so re-imports don't churn), while different yachts land
		// on different variants. An explicit by-reference counter rather
		// than a static, so the sequence provably restarts for every yacht.
		$seed = crc32( strtolower( $name ) );
		$call = 0;
		$pick = function ( $options ) use ( $seed, &$call ) {
			$call++;
			return $options[ ( $seed + ( $call * 7 ) ) % count( $options ) ];
		};

		// "a 52 ft 2019 Azimut Flybridge" — assembled from whatever exists.
		$spec_bits = array();
		if ( $facts['size'] > 0 ) {
			$spec_bits[] = (int) $facts['size'] . ' ft';
		}
		if ( $facts['year'] > 0 ) {
			$spec_bits[] = (int) $facts['year'];
		}
		// Brand and model are often the same word in the source data
		// ("Catamaran" / "Catamaran") — say it once.
		$brand = trim( $facts['brand'] );
		$model = trim( $facts['model'] );
		if ( '' !== $model && 0 === strcasecmp( $brand, $model ) ) {
			$model = '';
		}
		// And drop a model that merely repeats the brand ("Leopard" + "Leopard 440").
		if ( '' !== $brand && '' !== $model && 0 === stripos( $model, $brand ) ) {
			$brand = '';
		}
		$maker = trim( $brand . ' ' . $model );
		if ( '' !== $maker ) {
			$spec_bits[] = $maker;
		}
		$spec_phrase = implode( ' ', $spec_bits );

		// What to call it, from the source "type" (Catamaran, Megayacht…).
		$type_word = 'yacht';
		$type_low  = strtolower( $facts['type'] );
		if ( false !== strpos( $type_low, 'catamaran' ) ) {
			$type_word = 'catamaran';
		} elseif ( false !== strpos( $type_low, 'mega' ) ) {
			$type_word = 'megayacht';
		} elseif ( false !== strpos( $type_low, 'speed' ) || false !== strpos( $type_low, 'sport' ) ) {
			$type_word = 'sport boat';
		} elseif ( false !== strpos( $type_low, 'pontoon' ) || false !== strpos( $type_low, 'ponton' ) ) {
			$type_word = 'pontoon';
		} elseif ( false !== strpos( $type_low, 'wake' ) ) {
			$type_word = 'wake boat';
		} elseif ( false !== strpos( $type_low, 'pink' ) ) {
			$type_word = 'pink yacht';
		}

		// When the make/model already says "catamaran", don't say it twice
		// ("a 44 ft Leopard 440 Power Catamaran catamaran").
		if ( '' !== $spec_phrase && false !== stripos( $spec_phrase, $type_word ) ) {
			$type_word = '';
		}

		$sentences = array();

		// 1. Opening — introduces the boat and its specs.
		if ( '' !== $spec_phrase ) {
			$described = trim( $spec_phrase . ( '' !== $type_word ? ' ' . $type_word : '' ) );
			$openers   = array(
				sprintf( 'Step aboard %s, a %s.', $name, $described ),
				sprintf( '%s is a %s, ready for your day on Biscayne Bay.', $name, $described ),
				sprintf( 'Charter %s — a %s.', $name, $described ),
				sprintf( 'Meet %s, a %s built for Miami water.', $name, $described ),
			);
		} else {
			$openers = array(
				sprintf( 'Step aboard %s for a private day on Biscayne Bay.', $name ),
				sprintf( '%s is ready for your day on the water.', $name ),
			);
		}
		$sentences[] = $pick( $openers );

		// 2. Capacity, and the captain when one is included.
		if ( $facts['capacity'] > 0 ) {
			$cap_lines = array(
				sprintf( 'There is comfortable room for up to %d guests.', $facts['capacity'] ),
				sprintf( 'Bring up to %d guests along for the day.', $facts['capacity'] ),
				sprintf( 'She hosts parties of up to %d.', $facts['capacity'] ),
			);
			$line = $pick( $cap_lines );
			if ( $facts['captain'] ) {
				$line = rtrim( $line, '.' ) . ', with a professional captain included so you can simply relax and enjoy the ride.';
			}
			$sentences[] = $line;
		} elseif ( $facts['captain'] ) {
			$sentences[] = 'A professional captain is included, so you can simply relax and enjoy the ride.';
		}

		// 3. Where it leaves from and what you'll see.
		$views = array(
			'the Miami skyline, Brickell high-rises and the Star Island mansions',
			'downtown Miami, Star Island and the turquoise water off Biscayne Bay',
			'the skyline, Star Island and Miami Beach from the water',
		);
		if ( '' !== $facts['area'] ) {
			$sentences[] = sprintf( 'Departing from %s, you will cruise past %s.', $facts['area'], $pick( $views ) );
		} else {
			$sentences[] = sprintf( 'You will cruise past %s.', $pick( $views ) );
		}

		// 4. What she's good for — varied so 180 yachts don't share a line.
		$size = (float) $facts['size'];
		if ( $size >= 70 ) {
			$occasions = array(
				'With this much deck to spread out on, she suits big celebrations, corporate days out and milestone birthdays.',
				'There is room here for a serious party — corporate charters, birthdays and bachelorette weekends all work well.',
				'A boat this size turns a birthday or company outing into something people talk about afterwards.',
			);
		} elseif ( $size >= 45 ) {
			$occasions = array(
				'A comfortable size for birthdays, bachelorette parties and family days on the water.',
				'She strikes the balance most groups want — roomy enough for a party, easy enough for a relaxed family day.',
				'Popular for birthdays, anniversaries and long lazy afternoons at the sandbar.',
			);
		} elseif ( $size > 0 ) {
			$occasions = array(
				'An easy, affordable way to get a small group onto the water for the afternoon.',
				'Ideal for couples, small families and anyone who wants a private day out without the big-yacht price.',
				'Great for a first charter, a birthday for a few friends, or a quiet afternoon cruising.',
			);
		} else {
			$occasions = array(
				'A private day on the water, arranged around whatever you have planned.',
			);
		}
		$sentences[] = $pick( $occasions );

		// 5. Charter lengths actually offered on this yacht, plus the rate.
		$hours = array_values( array_filter( array_map( 'intval', (array) $facts['hours'] ) ) );
		if ( ! empty( $hours ) ) {
			sort( $hours );
			$min  = reset( $hours );
			$max  = end( $hours );
			$span = ( $min !== $max )
				? sprintf( 'Charters run from %d to %d hours', $min, $max )
				: sprintf( 'Charters run %d hours', $min );

			if ( $facts['price'] > 0 ) {
				$sentences[] = sprintf( '%s, from $%s per hour.', $span, number_format( (float) $facts['price'] ) );
			} else {
				$sentences[] = $span . '.';
			}
		}

		return implode( ' ', $sentences );
	}

	/**
	 * Yacht name, cleaned for display: the length is stripped out and the
	 * result title-cased.
	 *
	 * Source names carry the size inconsistently and in every position —
	 * "Hurricane 26ft", "30FT WELLCRAFT", "44FT 2 SUNDANCER" — which reads
	 * as clutter now that size has its own line on the card. The number is
	 * never lost: it lives in the Size (ft) field.
	 */
	public static function clean_yacht_name( $name ) {
		$name = (string) $name;

		// "26ft" / "30 FT" / "44-foot" / "50'" anywhere in the name.
		$name = preg_replace( '/\b\d{2,3}\s*[-]?\s*(?:ft|fts|feet|foot)\b\.?/i', ' ', $name );
		$name = preg_replace( '/\b\d{2,3}\s*[\'’]/u', ' ', $name );

		// Tidy up what the removal left behind: doubled spaces, and stray
		// separators now sitting at either end ("- Wellcraft", "Hurricane -").
		$name = preg_replace( '/\s+/', ' ', $name );
		$name = trim( $name, " \t\n\r\0\x0B-–—|,·" );

		return self::title_case( $name );
	}

	/**
	 * Cleans up a raw "Brand" cell for use as both the spec-pill value and a
	 * tag — real-world spreadsheets are never consistent (SeaRay / Sea Ray /
	 * azimut / Azimut Sport / "None" / trailing model numbers like "Shaefer
	 * V33"), and importing that noise straight into tags would fragment SEO
	 * across near-duplicate tag pages instead of consolidating it.
	 */
	private static function normalize_brand( $raw ) {
		$value = trim( (string) $raw );
		if ( '' === $value || 'none' === strtolower( $value ) ) {
			return '';
		}
		// A few rows carry a trailing model number/code in the Brand cell
		// (e.g. "Shaefer V33", "Yamaha 255XD") — strip it, brand only.
		$value = preg_replace( '/\s+([0-9]+[a-z]*|v[0-9]+)$/i', '', $value );
		$key   = strtolower( preg_replace( '/\s+/', ' ', trim( $value ) ) );
		if ( '' === $key ) {
			return '';
		}

		$known = array(
			'searay'              => 'Sea Ray',
			'sea ray'             => 'Sea Ray',
			'azimut'              => 'Azimut',
			'azimut sport'        => 'Azimut',
			'custome line'        => 'Custom Line',
			'custom line'         => 'Custom Line',
			'jhonson'             => 'Johnson',
			'ocean alexander'     => 'Ocean Alexander',
			'monterrey'           => 'Monterey',
			'monterey'            => 'Monterey',
			'prestige'            => 'Prestige',
			'rodman'              => 'Rodman',
			'sunseeker manhattan' => 'Sunseeker',
			'sunseeker'           => 'Sunseeker',
			'shaefer'             => 'Schaefer',
			'schaefer'            => 'Schaefer',
			'ferretti look'       => 'Ferretti',
			'ferretti'            => 'Ferretti',
		);
		if ( isset( $known[ $key ] ) ) {
			return $known[ $key ];
		}

		// No known mapping — Title Case so at least casing is consistent
		// across rows (Azimut/azimut, Formula/formula, …) even for brands
		// this list doesn't explicitly know about.
		return ucwords( $value );
	}

	/**
	 * Best-effort neighborhood/area name from a free-form marina address, for
	 * use as a location tag ("Miami Beach", "Miami River", …).
	 *
	 * Matching is ordered most-specific-first, because these addresses nest:
	 * a Bal Harbour address also contains "Miami Beach", which also contains
	 * "Miami". Whatever matches first wins, so the narrowest true area is the
	 * one tagged.
	 *
	 * Returns '' when nothing matches confidently — an absent tag is far
	 * better than a wrong one, which would mislead customers and pollute the
	 * location tag pages this feeds.
	 */
	private static function extract_neighborhood( $address ) {
		$low = strtolower( trim( (string) $address ) );
		if ( '' === $low ) {
			return '';
		}

		// Ordered: narrowest / most specific first. Value = the tag text,
		// key list = the spellings that appear in real address data.
		$areas = array(
			'Bal Harbour'       => array( 'bal harbour', 'bal harbor' ),
			'Haulover'          => array( 'haulover', 'bill bird marina' ),
			'Sunny Isles'       => array( 'sunny isles' ),
			'Surfside'          => array( 'surfside' ),
			'Golden Beach'      => array( 'golden beach' ),
			'Aventura'          => array( 'aventura', 'marina palms' ),
			'North Bay Village' => array( 'north bay village', 'shuckers' ),
			'North Miami Beach' => array( 'north miami beach' ),
			'North Miami'       => array( 'north miami' ),
			'Miami Shores'      => array( 'miami shores' ),
			'Key Biscayne'      => array( 'key biscayne', 'rickenbacker' ),
			'Coconut Grove'     => array( 'coconut grove', 'cocowalk' ),
			'Coral Gables'      => array( 'coral gables' ),
			'Palmetto Bay'      => array( 'palmetto bay' ),
			'Cutler Bay'        => array( 'cutler bay' ),
			'Brickell'          => array( 'brickell' ),
			'Miami River'       => array( 'miami river', 'river dr', 'river drive', 'river landing', 'harbor west', 'harbour west' ),
			'Miami Beach'       => array( 'miami beach', 'fontainebleau', 'sunset harbour', 'south beach' ),
			'Fort Lauderdale'   => array( 'fort lauderdale', 'ft lauderdale', 'fll' ),
			'Hollywood'         => array( 'hollywood' ),
			'Hallandale'        => array( 'hallandale' ),
			// Marina/venue names the fleet's own marina library (see
			// FY_Fleet_Settings::default_marinas()) places in Miami proper.
			'Miami'             => array( 'miami', 'bayshore dr', 'bayside', 'venetian', 'chamonix', 'epic kimpton', 'epic marina' ),
		);

		foreach ( $areas as $tag => $needles ) {
			foreach ( $needles as $needle ) {
				if ( false !== strpos( $low, $needle ) ) {
					return $tag;
				}
			}
		}

		return '';
	}

	/** Strip the "Specs: … | Location: …" boilerplate lines some exports embed in Description. */
	private static function clean_description( $text ) {
		$lines = preg_split( '/\r\n|\r|\n/', (string) $text );
		$keep  = array();
		foreach ( $lines as $line ) {
			$trimmed = trim( $line );
			if ( '' === $trimmed ) {
				continue;
			}
			if ( 0 === stripos( $trimmed, 'Specs:' ) || 0 === stripos( $trimmed, 'Location:' ) ) {
				continue;
			}
			$keep[] = $trimmed;
		}
		return implode( "\n\n", $keep );
	}

	private static function row_to_params( $cell, $map, $row, $do_images = false ) {
		$attrs = self::attribute_lookup( $map, $row );

		$params = array(
			'title'  => self::clean_yacht_name( $cell( 'Name' ) ),
			'status' => in_array( $cell( 'Published' ), array( '1', 'yes', 'true' ), true ) ? 'publish' : 'draft',
		);

		$price = $cell( 'Regular price' );
		if ( '' !== $price ) {
			$params['price'] = (float) preg_replace( '/[^0-9.]/', '', $price );
		}

		// The description is WRITTEN from this yacht's specs rather than
		// copied from the sheet — see build_description(). Composed at the
		// end of this method, once every spec has been parsed.
		$source_desc = $cell( 'Short description' );
		if ( '' === $source_desc ) {
			$source_desc = self::clean_description( $cell( 'Description' ) );
		}

		if ( isset( $attrs['capacity (guests)'] ) && '' !== $attrs['capacity (guests)'] ) {
			$params['capacity_max'] = intval( $attrs['capacity (guests)'] );
		}
		if ( isset( $attrs['length (ft)'] ) && '' !== $attrs['length (ft)'] ) {
			$params['size_ft'] = intval( $attrs['length (ft)'] );
		}
		if ( isset( $attrs['year'] ) && '' !== $attrs['year'] ) {
			$params['year'] = intval( $attrs['year'] );
		}
		$brand = isset( $attrs['brand'] ) ? self::normalize_brand( $attrs['brand'] ) : '';
		if ( '' !== $brand ) {
			$params['brand'] = $brand;
		}
		if ( isset( $attrs['captain included'] ) ) {
			$params['captain_included'] = in_array( strtolower( $attrs['captain included'] ), array( 'yes', 'y', '1', 'true' ), true );
		}

		$model = $cell( 'Meta: Model' );
		if ( '' !== $model ) {
			$params['model'] = $model;
		}
		$rating = $cell( 'Meta: Rating' );
		if ( '' !== $rating ) {
			$params['rating'] = (float) $rating;
		}
		$owner = $cell( 'Meta: Owner' );
		if ( '' !== $owner ) {
			$params['source_owner'] = $owner;
		}
		$listing_id = $cell( 'Meta: Source Listing ID' );
		if ( '' !== $listing_id ) {
			$params['source_listing_id'] = $listing_id;
		}
		$sku = $cell( 'SKU' );
		if ( '' !== $sku ) {
			$params['sku'] = $sku;
		}

		$location = $cell( 'Meta: Location' );

		// The source system's "Categories" (boat type, e.g. "Catamaran") is
		// NOT the same concept as this plugin's fy_yacht_cat city taxonomy —
		// imported as tags instead, alongside brand, model, year and the
		// departure neighborhood, for SEO facets. The city itself is set
		// once for the whole import (see fy_import_city in handle_import()),
		// never per-row, so these yachts land in one dedicated fleet
		// regardless of tags.
		$tags = array();
		$categories = $cell( 'Categories' );
		if ( '' !== $categories ) {
			$tags = array_merge( $tags, array_filter( array_map( 'trim', explode( ',', $categories ) ) ) );
		}
		if ( '' !== $brand ) {
			$tags[] = $brand;
		}
		if ( '' !== $model ) {
			$tags[] = $model;
		}
		if ( isset( $params['year'] ) && $params['year'] > 0 ) {
			$tags[] = (string) $params['year'];
		}
		$location_tag = self::extract_neighborhood( $location );
		if ( '' !== $location_tag ) {
			$tags[] = $location_tag;
		}
		if ( ! empty( $tags ) ) {
			$params['tags'] = array_values( array_unique( $tags ) );
		}

		// Pink fleet flag. The sheet has no dedicated pink column, but every
		// pink boat announces itself in its name, description or type tags —
		// which is also exactly what a visitor tapping the "Pink yachts"
		// filter expects to match. Without this, the whole imported fleet
		// arrived unflagged and that filter showed nothing. Only ever SETS
		// the flag; the Visualizer checkbox still unsets it per yacht.
		$pink_haystack = $params['title'] . ' ' . $source_desc . ' ' . $model . ' ' . implode( ' ', $tags );
		if ( false !== stripos( $pink_haystack, 'pink' ) ) {
			$params['is_pink'] = true;
		}

		// Hours & Pricing rows: one bookable duration per "N Hour Price"
		// column present. Regular price is a per-hour RATE, not a real
		// charter length — it is NOT turned into a bookable "1 Hour" option
		// (charters have a multi-hour minimum in practice); it only feeds
		// the "Starting Price" figure via $params['price'] above.
		$pricing = array();
		foreach ( array( 2, 3, 4, 5, 6, 7, 8 ) as $hrs ) {
			$col_label = $hrs . ' Hour Price';
			$val       = $cell( $col_label );
			if ( '' === $val ) {
				continue;
			}
			$pricing[] = array(
				'type'     => 'price',
				'duration' => $hrs . ' Hours',
				'price'    => (float) preg_replace( '/[^0-9.]/', '', $val ),
			);
		}
		if ( ! empty( $pricing ) ) {
			$params['pricing']        = $pricing;
			$params['duration_label'] = $pricing[0]['duration'];
		}

		// Marina: location name/address + coordinates → the yacht's own
		// marina fields, which already power [fy_yacht_location],
		// [fy_yacht_marina] and the keyless Google Maps embed.
		$lat      = $cell( 'Meta: Latitude' );
		$lng      = $cell( 'Meta: Longitude' );
		if ( '' !== $location || ( '' !== $lat && '' !== $lng ) ) {
			$params['marina'] = array(
				'source' => 'custom',
				'title'  => $location,
				'lat'    => $lat,
				'lng'    => $lng,
			);
		}

		// When the full gallery is about to be downloaded, its importer sets
		// the featured image itself (from the same first URL) — setting
		// image_url here too would just make fill_defaults() sideload a
		// redundant duplicate copy of photo #1 before the gallery importer
		// replaces it a moment later.
		if ( ! $do_images ) {
			$images = self::split_urls( $cell( 'Images' ) );
			if ( ! empty( $images ) ) {
				$params['image_url'] = $images[0];
			}
		}

		// Finally, the description — written from everything parsed above, so
		// every yacht reads differently instead of sharing the sheet's
		// repeated boilerplate. Falls back to the sheet's own text only if
		// there were not enough specs to say anything meaningful.
		$hour_list = array();
		foreach ( $pricing as $row_price ) {
			$hour_list[] = FY_Fleet_Pricing::hours_from_label( $row_price['duration'] );
		}

		$generated = self::build_description(
			array(
				'name'     => $params['title'],
				'brand'    => $brand,
				'model'    => $model,
				'year'     => isset( $params['year'] ) ? (int) $params['year'] : 0,
				'size'     => isset( $params['size_ft'] ) ? (int) $params['size_ft'] : 0,
				'capacity' => isset( $params['capacity_max'] ) ? (int) $params['capacity_max'] : 0,
				'captain'  => ! empty( $params['captain_included'] ),
				'type'     => $categories,
				'area'     => $location_tag,
				'hours'    => $hour_list,
				'price'    => isset( $params['price'] ) ? (float) $params['price'] : 0,
			)
		);

		$final_desc = ( '' !== $generated ) ? $generated : $source_desc;
		if ( '' !== $final_desc ) {
			$params['special_desc'] = wp_kses_post( $final_desc );
		}

		return $params;
	}

	/**
	 * Header row → column-label => 0-based index, tolerant of a BOM and of
	 * extra/collapsed whitespace.
	 */
	private static function map_headers( $header ) {
		$map = array();
		foreach ( $header as $i => $label ) {
			$clean = trim( preg_replace( '/\s+/', ' ', str_replace( "\xEF\xBB\xBF", '', (string) $label ) ) );
			if ( '' === $clean ) {
				continue;
			}
			$map[ $clean ] = $i;
		}
		return $map;
	}

	/* ------------------------------------------------------------------
	 * File readers
	 * ---------------------------------------------------------------- */

	private static function read_csv( $path ) {
		$handle = fopen( $path, 'r' ); // phpcs:ignore -- tmp upload
		if ( ! $handle ) {
			return new WP_Error( 'fy_read_failed', __( 'Could not read the uploaded file.', 'fy-fleet' ) );
		}
		$rows = array();
		while ( false !== ( $row = fgetcsv( $handle ) ) ) {
			$rows[] = $row;
		}
		fclose( $handle ); // phpcs:ignore
		return $rows;
	}

	/**
	 * Minimal, dependency-free .xlsx reader: an xlsx is a zip of XML parts.
	 * Reads the first worksheet plus the shared-strings table — everything
	 * this importer needs, without requiring Composer/PhpSpreadsheet on the
	 * host.
	 */
	private static function read_xlsx( $path ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'fy_no_zip', __( 'This server\'s PHP is missing the Zip extension needed to read .xlsx files — export the spreadsheet as .csv instead and upload that.', 'fy-fleet' ) );
		}

		$zip = new ZipArchive();
		if ( true !== $zip->open( $path ) ) {
			return new WP_Error( 'fy_bad_zip', __( 'That file is not a valid .xlsx workbook.', 'fy-fleet' ) );
		}

		$shared = array();
		$shared_xml = $zip->getFromName( 'xl/sharedStrings.xml' );
		if ( false !== $shared_xml ) {
			$shared = self::parse_shared_strings( $shared_xml );
		}

		// First sheet by workbook order (falls back to sheet1.xml, true for
		// every export this importer targets).
		$sheet_path  = 'xl/worksheets/sheet1.xml';
		$sheet_xml   = $zip->getFromName( $sheet_path );
		if ( false === $sheet_xml ) {
			$zip->close();
			return new WP_Error( 'fy_no_sheet', __( 'Could not find a worksheet inside that file.', 'fy-fleet' ) );
		}
		$zip->close();

		return self::parse_sheet_xml( $sheet_xml, $shared );
	}

	private static function parse_shared_strings( $xml ) {
		$doc = simplexml_load_string( $xml );
		if ( ! $doc ) {
			return array();
		}
		$out = array();
		foreach ( $doc->si as $si ) {
			if ( isset( $si->t ) ) {
				$out[] = (string) $si->t;
				continue;
			}
			// Rich text runs (<r><t>…</t></r>+) — concatenate every run.
			$text = '';
			foreach ( $si->r as $run ) {
				$text .= (string) $run->t;
			}
			$out[] = $text;
		}
		return $out;
	}

	/** Spreadsheet column letters ("A", "AB", …) → 0-based index. */
	private static function col_index( $ref ) {
		preg_match( '/^([A-Z]+)/', $ref, $m );
		$letters = isset( $m[1] ) ? $m[1] : 'A';
		$index   = 0;
		for ( $i = 0; $i < strlen( $letters ); $i++ ) {
			$index = $index * 26 + ( ord( $letters[ $i ] ) - 64 );
		}
		return $index - 1;
	}

	private static function parse_sheet_xml( $xml, $shared ) {
		$doc = simplexml_load_string( $xml );
		if ( ! $doc ) {
			return new WP_Error( 'fy_bad_sheet', __( 'Could not parse that worksheet.', 'fy-fleet' ) );
		}

		$rows = array();
		foreach ( $doc->sheetData->row as $row_node ) {
			$row = array();
			foreach ( $row_node->c as $cell_node ) {
				$ref   = (string) $cell_node['r'];
				$index = $ref ? self::col_index( $ref ) : count( $row );
				$type  = (string) $cell_node['t'];

				if ( 's' === $type ) {
					$sid       = (int) $cell_node->v;
					$value     = isset( $shared[ $sid ] ) ? $shared[ $sid ] : '';
				} elseif ( 'inlineStr' === $type ) {
					$value = isset( $cell_node->is->t ) ? (string) $cell_node->is->t : '';
				} elseif ( isset( $cell_node->v ) ) {
					$value = (string) $cell_node->v;
				} else {
					$value = '';
				}
				$row[ $index ] = $value;
			}
			if ( empty( $row ) ) {
				$rows[] = array();
				continue;
			}
			// Dense array, in column order, blanks filled in.
			$max = max( array_keys( $row ) );
			$out = array();
			for ( $i = 0; $i <= $max; $i++ ) {
				$out[] = isset( $row[ $i ] ) ? $row[ $i ] : '';
			}
			$rows[] = $out;
		}

		return $rows;
	}
}
