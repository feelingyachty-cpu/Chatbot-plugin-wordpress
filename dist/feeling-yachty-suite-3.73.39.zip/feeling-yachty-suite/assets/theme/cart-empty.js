/**
 * Feeling Yachty — branded empty-cart scene.
 *
 * The cart is a WooCommerce Cart BLOCK, rendered by React after page load, so
 * there is no PHP template to filter and no server-side hook that fires. The
 * markup has to be adjusted once the block has painted, and re-adjusted if
 * React re-renders it (removing the last item does exactly that).
 *
 * What this changes:
 *   - "Your cart is currently empty!" → charter wording, not shop wording
 *   - the stock crying-face icon      → a flat 2D Miami golden-hour scene
 *   - "New in store" + its product grid → removed entirely, so only the
 *     panel (scene, copy, "Talk to our team") shows on an empty cart
 *
 * All motion lives in cart-empty.css and is transform/opacity only.
 */
( function () {
	'use strict';

	var CFG = ( typeof fyCartEmpty !== 'undefined' ) ? fyCartEmpty : {};
	var CONTACT_URL = CFG.contactUrl || '';

	function scene() {
		// Inline SVG: no image request, flat brand colours only (no gradients).
		// viewBox is 320x180 (16:9). Sun, skyline gap and reflection all sit on
		// the x=160 centre line; the right-hand palm is hand-mirrored point by
		// point (x' = 320-x) rather than an SVG transform, so the symmetry is
		// exact regardless of how a browser reports a transformed bbox.
		return '' +
		'<div class="fy-cart-scene" aria-hidden="true">' +
		'<svg viewBox="0 0 320 180" xmlns="http://www.w3.org/2000/svg" role="presentation" focusable="false">' +
			'<defs>' +
				'<clipPath id="fyCeClip"><rect x="0" y="0" width="320" height="180" rx="18"/></clipPath>' +
				'<mask id="fyCeSunMask">' +
					'<rect x="126" y="36" width="68" height="68" fill="#fff"/>' +
					'<rect x="126" y="73.5" width="68" height="2" fill="#000"/>' +
					'<rect x="126" y="79.8" width="68" height="2.8" fill="#000"/>' +
					'<rect x="126" y="86.8" width="68" height="3.6" fill="#000"/>' +
					'<rect x="126" y="94.5" width="68" height="4.6" fill="#000"/>' +
				'</mask>' +
			'</defs>' +
			'<g clip-path="url(#fyCeClip)">' +
				'<rect x="0" y="0" width="320" height="44" fill="#f4e8ff"/>' +
				'<rect x="0" y="44" width="320" height="28" fill="#ffdcf5"/>' +
				'<rect x="0" y="72" width="320" height="24" fill="#ffc6ec"/>' +
				'<rect x="0" y="96" width="320" height="24" fill="#ffb0e2"/>' +
				'<circle cx="160" cy="70" r="32" fill="#ff5fb8" mask="url(#fyCeSunMask)"/>' +
				'<g class="fy-ce-birds" fill="none" stroke="#7C3AED" stroke-width="1.4" stroke-linecap="round" opacity=".32">' +
					'<path d="M-36 34 q4.5 -4.5 9 0 q4.5 -4.5 9 0"/><path d="M-14 43 q3.5 -3.5 7 0 q3.5 -3.5 7 0"/>' +
				'</g>' +
				'<g fill="#b79cfb">' +
					'<rect x="4" y="86" width="8" height="34"/><rect x="18" y="82" width="7" height="38"/><rect x="28" y="78" width="8" height="42"/>' +
					'<rect x="48" y="80" width="7" height="40"/><rect x="74" y="64" width="8" height="56"/><rect x="90" y="72" width="9" height="48"/>' +
					'<rect x="108" y="82" width="7" height="38"/><rect x="118" y="96" width="8" height="24"/><rect x="130" y="101" width="8" height="19"/>' +
					'<rect x="144" y="104" width="9" height="16"/><rect x="160" y="102" width="8" height="18"/><rect x="175" y="100" width="8" height="20"/>' +
					'<rect x="191" y="98" width="8" height="22"/><rect x="206" y="94" width="9" height="26"/><rect x="216" y="88" width="8" height="32"/>' +
					'<rect x="228" y="80" width="9" height="40"/><rect x="246" y="66" width="8" height="54"/><rect x="272" y="74" width="8" height="46"/>' +
					'<rect x="286" y="84" width="7" height="36"/><rect x="298" y="80" width="8" height="40"/><rect x="310" y="90" width="8" height="30"/>' +
					'<rect x="77.2" y="54" width="1.6" height="10"/><rect x="249.2" y="56" width="1.6" height="10"/>' +
				'</g>' +
				'<g fill="#7C3AED">' +
					'<rect x="0" y="100" width="10" height="20"/><rect x="12" y="94" width="9" height="26"/><rect x="23" y="104" width="8" height="16"/>' +
					'<rect x="33" y="92" width="10" height="28"/><rect x="45" y="98" width="8" height="22"/>' +
					'<path d="M55 120 V88 H57 V81 H59 V74 H65 V81 H67 V88 H69 V120 Z"/>' +
					'<rect x="71" y="96" width="8" height="24"/><rect x="81" y="86" width="10" height="34"/><rect x="93" y="102" width="7" height="18"/>' +
					'<path d="M102 120 V96 Q107 88 112 96 V120 Z"/>' +
					'<rect x="114" y="106" width="8" height="14"/><rect x="124" y="110" width="9" height="10"/><rect x="135" y="107" width="10" height="13"/>' +
					'<rect x="147" y="112" width="8" height="8"/><rect x="157" y="109" width="9" height="11"/><rect x="168" y="113" width="8" height="7"/>' +
					'<rect x="178" y="108" width="10" height="12"/><rect x="190" y="111" width="8" height="9"/><rect x="200" y="106" width="9" height="14"/>' +
					'<rect x="211" y="110" width="8" height="10"/><rect x="221" y="102" width="9" height="18"/><rect x="232" y="92" width="10" height="28"/>' +
					'<rect x="244" y="98" width="8" height="22"/>' +
					'<path d="M254 120 V92 H259 V82 H260.5 V73 H262.5 V82 H264 V92 H268 V120 Z"/>' +
					'<rect x="270" y="88" width="9" height="32"/><rect x="281" y="100" width="8" height="20"/><rect x="291" y="94" width="10" height="26"/>' +
					'<rect x="303" y="104" width="7" height="16"/><rect x="312" y="98" width="8" height="22"/>' +
				'</g>' +
				'<rect x="0" y="118" width="320" height="62" fill="#c4b0fd"/>' +
				'<g class="fy-ce-wave fy-ce-wave--1"><path d="M-120 124 q30 -3.5 60 0 q30 -2 60 0 q30 -3.5 60 0 q30 -2 60 0 q30 -3.5 60 0 q30 -2 60 0 q30 -3.5 60 0 q30 -2 60 0 q30 -3.5 60 0 q30 -2 60 0 V180 H-120 Z" fill="#a78bfa"/></g>' +
				'<g class="fy-ce-wave fy-ce-wave--2"><path d="M-120 134 q30 -4 60 0 q30 -2.5 60 0 q30 -4 60 0 q30 -2.5 60 0 q30 -4 60 0 q30 -2.5 60 0 q30 -4 60 0 q30 -2.5 60 0 q30 -4 60 0 q30 -2.5 60 0 V180 H-120 Z" fill="#8b5cf6"/></g>' +
				'<path class="fy-ce-wake" d="M92 143.5 Q74 141.5 54 145.5 Q74 148 92 147.5 Z" fill="#fff"/>' +
				'<path class="fy-ce-wake fy-ce-wake--b" d="M90 147 Q80 146 64 149 Q80 150.5 90 150.5 Z" fill="#fff"/>' +
				'<g class="fy-ce-yacht">' +
					'<path d="M132 97.2 V90" stroke="#4c1d95" stroke-width="1.2" stroke-linecap="round"/>' +
					'<path d="M141 96.9 Q146 91.8 151 96.8 Z" fill="#4c1d95"/>' +
					'<path d="M128.5 104.8 L124 100.5 L127.2 100.4 L131.5 104.7 Z" fill="#4c1d95"/>' +
					'<rect x="166" y="99.8" width="1.8" height="4.2" fill="#4c1d95"/>' +
					'<path d="M122 100.8 L124 97.6 L180 96.8 L184.5 100.2 Z" fill="#fff"/>' +
					'<path d="M106 113.5 L106 111 L117 110.7 L117 113.3 Z" fill="#fff"/>' +
					'<path d="M115 113.5 L117.5 104.5 L160 103 L175.5 111.5 Z" fill="#fff"/>' +
					'<path d="M155 103.8 L161 103.5 L173.5 110.4 L167.5 110.7 Z" fill="#4c1d95"/>' +
					'<path d="M110 133 L112 113.5 L172 110.8 L196 123.5 L199 133 Z" fill="#fff"/>' +
					'<g fill="#4c1d95">' +
						'<path d="M119 122 L119 116 L138 115.2 L138 121.3 Z"/>' +
						'<path d="M141 121.2 L141 115 L160 114.2 L160 120.4 Z"/>' +
						'<path d="M163 120.4 L163 114 L174 113.5 L187 120 L187 120.7 Z"/>' +
					'</g>' +
					'<rect x="90" y="127.6" width="17" height="1.4" fill="#fff"/>' +
					'<path d="M90.5 131 V122.5" stroke="#4c1d95" stroke-width="1.2" stroke-linecap="round"/>' +
					'<path class="fy-ce-flag" d="M90.5 122 L82 124.3 L90.5 126.6 Z" fill="#d600d6"/>' +
					'<path d="M89 129 Q160 125.5 227 119 L230 120.5 Q228.5 135.5 220 148.5 L100 153.5 L93 151 Z" fill="#E45C9C"/>' +
					'<g fill="#4c1d95">' +
						'<path d="M156 131.8 L204 128 L204 130.8 L156 134.8 Z"/>' +
						'<path d="M118 135 L146 132.8 L146 135.6 L118 138 Z"/>' +
					'</g>' +
					'<path d="M96 142 L224 139.6 L222.5 142.6 L96.5 145 Z" fill="#fff"/>' +
					'<path d="M89 129 Q160 125.5 227 119" fill="none" stroke="#fff" stroke-width="1.2" stroke-linecap="round"/>' +
				'</g>' +
				'<path class="fy-ce-wake fy-ce-wake--s" d="M221 148 Q229 140 240 142.5 Q232 145.5 230 149.5 Z" fill="#fff"/>' +
				'<g class="fy-ce-wave fy-ce-wave--3"><path d="M-120 149 q30 -4.5 60 0 q30 -3 60 0 q30 -4.5 60 0 q30 -3 60 0 q30 -4.5 60 0 q30 -3 60 0 q30 -4.5 60 0 q30 -3 60 0 q30 -4.5 60 0 q30 -3 60 0 V180 H-120 Z" fill="#7C3AED"/></g>' +
				'<g class="fy-ce-wave fy-ce-wave--4"><path d="M-120 162 q30 -5 60 0 q30 -3 60 0 q30 -5 60 0 q30 -3 60 0 q30 -5 60 0 q30 -3 60 0 q30 -5 60 0 q30 -3 60 0 q30 -5 60 0 q30 -3 60 0 V180 H-120 Z" fill="#6d28d9"/></g>' +
				'<g fill="#ff8fd4">' +
					'<rect class="fy-ce-shim" x="142" y="153" width="36" height="2.8" rx="1.4"/>' +
					'<rect class="fy-ce-shim fy-ce-shim--2" x="137" y="160" width="46" height="3.2" rx="1.6"/>' +
					'<rect class="fy-ce-shim fy-ce-shim--3" x="131" y="167" width="58" height="3.6" rx="1.8"/>' +
					'<rect class="fy-ce-shim fy-ce-shim--4" x="125" y="174" width="70" height="4" rx="2"/>' +
				'</g>' +
				'<g class="fy-ce-palm" fill="#4c1d95">' +
					'<path d="M6 182 Q0 118 24 62 L30 63 Q9 120 15 182 Z"/>' +
					'<path d="M27 63 Q8 66 1 84 Q13 72 27 63 Z"/>' +
					'<path d="M27 63 Q9 54 -5 68 Q10 62 27 63 Z"/>' +
					'<path d="M27 63 Q21 48 5 46 Q17 54 27 63 Z"/>' +
					'<path d="M27 63 Q32 48 21 38 Q24 51 27 63 Z"/>' +
					'<path d="M27 63 Q29 48 43 42 Q35 52 27 63 Z"/>' +
					'<path d="M27 63 Q43 51 55 56 Q42 58 27 63 Z"/>' +
					'<path d="M27 63 Q45 62 53 78 Q41 69 27 63 Z"/>' +
					'<path d="M27 63 Q16 70 17 84 Q22 73 27 63 Z"/>' +
					'<circle cx="27" cy="63.5" r="3.4"/>' +
				'</g>' +
				'<g class="fy-ce-palm fy-ce-palm--r" fill="#4c1d95">' +
					'<path d="M314 182 Q320 118 296 62 L290 63 Q311 120 305 182 Z"/>' +
					'<path d="M293 63 Q312 66 319 84 Q307 72 293 63 Z"/>' +
					'<path d="M293 63 Q311 54 325 68 Q310 62 293 63 Z"/>' +
					'<path d="M293 63 Q299 48 315 46 Q303 54 293 63 Z"/>' +
					'<path d="M293 63 Q288 48 299 38 Q296 51 293 63 Z"/>' +
					'<path d="M293 63 Q291 48 277 42 Q285 52 293 63 Z"/>' +
					'<path d="M293 63 Q277 51 265 56 Q278 58 293 63 Z"/>' +
					'<path d="M293 63 Q275 62 267 78 Q279 69 293 63 Z"/>' +
					'<path d="M293 63 Q304 70 303 84 Q298 73 293 63 Z"/>' +
					'<circle cx="293" cy="63.5" r="3.4"/>' +
				'</g>' +
			'</g>' +
		'</svg>' +
		'</div>';
	}

	function esc( s ) {
		var d = document.createElement( 'div' );
		d.textContent = s;
		return d.innerHTML;
	}

	function decorate() {
		var block = document.querySelector( '.wp-block-woocommerce-empty-cart-block' );
		if ( ! block || block.getAttribute( 'data-fy-cart' ) === '1' ) {
			return !! block;
		}
		block.setAttribute( 'data-fy-cart', '1' );

		// Hide every one of WooCommerce's own children — the crying-face
		// heading, the dotted separator, "New in store" and its product grid
		// — so only our panel shows. Hiding by position rather than matching
		// heading text also survives WooCommerce renaming that string between
		// versions.
		var original = Array.prototype.slice.call( block.children );
		for ( var i = 0; i < original.length; i++ ) {
			original[ i ].classList.add( 'fy-cart-hidden' );
		}

		var panel = document.createElement( 'div' );
		panel.className = 'fy-cart-empty';
		panel.innerHTML =
			scene() +
			'<h2 class="fy-cart-empty__title">No charters booked yet</h2>' +
			'<p class="fy-cart-empty__sub">Pick your yacht, your date and your hours. Only crew + fuel are charged online now to confirm your booking. This reserves both the boat and your crew. If you cancel, the fuel charge is taken as a deposit. Remaining balance is due at the dock by cash or Zelle only.</p>' +
			( CONTACT_URL
				? '<div class="fy-cart-empty__actions">' +
					'<a class="fy-cart-btn fy-cart-btn--ghost" href="' + esc( CONTACT_URL ) + '">Talk to our team</a>' +
				  '</div>'
				: '' ) +
			'<div class="fy-cart-empty__trust">' +
				'<span>⚓ Captain &amp; crew included</span>' +
				'<span>💳 Crew + deposit online</span>' +
				'<span>⚓ Cash or Zelle at the dock</span>' +
			'</div>';

		block.insertBefore( panel, block.firstChild );
		return true;
	}

	function start() {
		decorate();
		// The block paints after its own JS runs, and re-renders when the last
		// item is removed — so watch rather than assuming a single moment.
		if ( 'MutationObserver' in window ) {
			var mo = new MutationObserver( function () { decorate(); } );
			mo.observe( document.body, { childList: true, subtree: true } );
			// The observer is enough on its own; the timer below is only a
			// safety net for the first paint on a slow connection.
		}
		var tries = 0;
		var t = setInterval( function () {
			tries++;
			if ( decorate() || tries > 24 ) { clearInterval( t ); }
		}, 250 );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', start );
	} else {
		start();
	}
} )();
