<?php
/**
 * Plugin Name: Feeling Yachty Command Center
 * Description: The complete sales suite for your charter fleet — yachts, deposit checkout via Stripe/PayPal, bookings calendar, customer database, marinas, galleries, reviews, SEO, spreadsheet import, and an n8n-ready API. Elementor widget and shortcodes included. Also carries the admin/login/storefront branding formerly shipped as a separate "Admin Theme" plugin.
 * Version: 3.73.11
 * Author: Feeling Yachty
 * Text Domain: fy-fleet
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'FY_FLEET_VERSION', '3.73.11' );
define( 'FY_FLEET_FILE', __FILE__ );
define( 'FY_FLEET_DIR', plugin_dir_path( __FILE__ ) );
define( 'FY_FLEET_URL', plugin_dir_url( __FILE__ ) );

require_once FY_FLEET_DIR . 'includes/class-fy-features.php';
require_once FY_FLEET_DIR . 'includes/class-fy-cpt.php';
require_once FY_FLEET_DIR . 'includes/class-fy-metaboxes.php';
require_once FY_FLEET_DIR . 'includes/class-fy-settings.php';
require_once FY_FLEET_DIR . 'includes/class-fy-render.php';
require_once FY_FLEET_DIR . 'includes/class-fy-elementor.php';
require_once FY_FLEET_DIR . 'includes/class-fy-seed.php';
require_once FY_FLEET_DIR . 'includes/class-fy-visualizer.php';
require_once FY_FLEET_DIR . 'includes/class-fy-pricing.php';
require_once FY_FLEET_DIR . 'includes/class-fy-woo.php';
require_once FY_FLEET_DIR . 'includes/class-fy-product-editor.php';
require_once FY_FLEET_DIR . 'includes/class-fy-checkout.php';
require_once FY_FLEET_DIR . 'includes/class-fy-bookings-admin.php';
require_once FY_FLEET_DIR . 'includes/class-fy-marina.php';
require_once FY_FLEET_DIR . 'includes/class-fy-seo.php';
require_once FY_FLEET_DIR . 'includes/class-fy-schema.php';
require_once FY_FLEET_DIR . 'includes/class-fy-rest.php';
require_once FY_FLEET_DIR . 'includes/class-fy-gallery.php';
require_once FY_FLEET_DIR . 'includes/class-fy-help.php';
require_once FY_FLEET_DIR . 'includes/class-fy-log.php';
require_once FY_FLEET_DIR . 'includes/class-fy-reviews.php';
require_once FY_FLEET_DIR . 'includes/class-fy-fleetpages.php';
require_once FY_FLEET_DIR . 'includes/class-fy-payments.php';
require_once FY_FLEET_DIR . 'includes/class-fy-customers.php';
require_once FY_FLEET_DIR . 'includes/class-fy-tickets.php';
require_once FY_FLEET_DIR . 'includes/class-fy-account.php';
require_once FY_FLEET_DIR . 'includes/class-fy-submissions.php';
require_once FY_FLEET_DIR . 'includes/class-fy-demo-seed.php';
require_once FY_FLEET_DIR . 'includes/class-fy-dashboard.php';
require_once FY_FLEET_DIR . 'includes/class-fy-twilio.php';
require_once FY_FLEET_DIR . 'includes/class-fy-ai.php';
require_once FY_FLEET_DIR . 'includes/class-fy-emails.php';
require_once FY_FLEET_DIR . 'includes/class-fy-theme.php';
require_once FY_FLEET_DIR . 'includes/class-fy-import.php';
require_once FY_FLEET_DIR . 'includes/class-fy-addons.php';
require_once FY_FLEET_DIR . 'includes/class-fy-support-bot.php';

final class FY_Fleet_Plugin {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		FY_Fleet_Features::init();
		FY_Fleet_CPT::init();
		FY_Fleet_Metaboxes::init();
		FY_Fleet_Settings::init();
		FY_Fleet_Render::init();
		FY_Fleet_Elementor::init();
		FY_Fleet_Seed::init();
		FY_Fleet_Visualizer::init();
		FY_Fleet_Woo::init();
		FY_Fleet_Product_Editor::init();
		FY_Fleet_Checkout::init();
		FY_Fleet_Bookings_Admin::init();
		FY_Fleet_Marina::init();
		// Optional modules — switched on/off from ⚙️ Control Panel, no code edits.
		if ( FY_Fleet_Features::on( 'seo' ) ) {
			FY_Fleet_SEO::init();
		}
		// NOT behind the SEO toggle: this also undoes the noindex that this
		// plugin's own catalog-hiding causes, and that must never depend on an
		// optional module being switched on. It gates its own schema output.
		FY_Fleet_Schema::init();
		FY_Fleet_REST::init();
		if ( FY_Fleet_Features::on( 'galleries' ) ) {
			FY_Fleet_Gallery::init();
		}
		FY_Fleet_Help::init();
		FY_Fleet_Log::init();
		FY_Fleet_Reviews::init();
		FY_Fleet_Pages::init();
		if ( FY_Fleet_Features::on( 'payments_hub' ) ) {
			FY_Fleet_Payments::init();
		}
		FY_Fleet_Customers::init();
		FY_Fleet_Tickets::init();
		FY_Fleet_Account::init();
		FY_Fleet_Submissions::init();
		FY_Fleet_Demo_Seed::init();
		FY_Fleet_Dashboard::init();
		FY_Fleet_Twilio::init();
		FY_Fleet_AI::init();
		FY_Fleet_Emails::init();
		FY_Fleet_Theme::init();
		FY_Fleet_Import::init();
		FY_Fleet_Addons::init();
		// GHL owns guest comms. feeling-yachty-no-chatbot defines this
		// constant so the Support Bot never boots on this site.
		if ( ! defined( 'FEELING_YACHTY_NO_CHATBOT' ) || ! FEELING_YACHTY_NO_CHATBOT ) {
			FY_Support_Bot::init();
		}
	}

	/** Stop our scheduled jobs when the plugin is switched off. */
	public static function deactivate() {
		wp_clear_scheduled_hook( 'fy_fleet_daily_backup' );
	}

	/**
	 * Register the post type, then import the starter fleet on a fresh install.
	 */
	public static function activate() {
		FY_Fleet_CPT::activate();
		FY_Fleet_Seed::maybe_seed_on_activation();
	}
}

// Activation hooks must be registered the moment this file loads — during a
// plugin-activation request the plugins_loaded action has already fired.
register_activation_hook( __FILE__, array( 'FY_Fleet_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'FY_Fleet_Plugin', 'deactivate' ) );

/*
 * Boot on plugins_loaded, NOT at file load. WordPress loads plugins in
 * alphabetical order, so "feeling-yachty-fleet" loads BEFORE "woocommerce" —
 * booting here made every class_exists('WooCommerce') check answer no, which
 * silently disabled the whole WooCommerce bridge (product auto-creation, the
 * ⚓ Yacht Card panel on the product screen, description shortcodes, checkout
 * pricing). By plugins_loaded, every plugin's classes exist and the checks
 * answer truthfully.
 */
if ( did_action( 'plugins_loaded' ) ) {
	FY_Fleet_Plugin::instance(); // e.g. mid-activation request — load now.
} else {
	add_action( 'plugins_loaded', array( 'FY_Fleet_Plugin', 'instance' ) );
}
