<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Product-first editing — the WooCommerce product IS the front door.
 *
 * The product edit screen carries the full yacht card field set, so staff can
 * work entirely from Products → Add New: publish a product with the
 * "⚓ List in Fleet widget" box ticked and the yacht card behind it is created
 * (or updated) automatically. The widget picks the card up on its own, the
 * card button points at the product's own URL, and the product description
 * keeps the [fy_yacht_*] shortcode stack that renders the yacht sections.
 *
 * Yacht-first editing (⚓ FY Command Center → Add New Yacht) keeps working —
 * both screens edit the same record, so it never matters where you start.
 */
class FY_Fleet_Product_Editor {

	/** True while a sync is running, so the two save hooks cannot loop. */
	private static $busy = false;

	public static function init() {
		if ( ! FY_Fleet_Woo::active() ) {
			return;
		}
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_box' ) );
		add_action( 'save_post_product', array( __CLASS__, 'save' ), 25, 2 );
		add_action( 'trashed_post', array( __CLASS__, 'on_product_trashed' ) );
		add_action( 'untrashed_post', array( __CLASS__, 'on_product_untrashed' ) );
		add_filter( 'default_content', array( __CLASS__, 'default_description' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		// WooCommerce's own "Duplicate" copies all meta — unlink the copy so it
		// gets its OWN yacht card on publish instead of hijacking the original's.
		add_action( 'woocommerce_product_duplicate', array( __CLASS__, 'unlink_duplicate' ), 10, 2 );
	}

	/** A duplicated product must not share the source product's yacht card. */
	public static function unlink_duplicate( $duplicate, $product ) {
		if ( $duplicate && is_callable( array( $duplicate, 'delete_meta_data' ) ) ) {
			$duplicate->delete_meta_data( '_fy_yacht_id' );
		}
	}

	/** New products start with the shortcode stack already in the description. */
	public static function default_description( $content, $post ) {
		if ( $post && 'product' === $post->post_type && '' === trim( (string) $content ) ) {
			return FY_Fleet_Woo::default_description_stack();
		}
		return $content;
	}

	public static function enqueue( $hook ) {
		global $post_type;
		if ( 'product' !== $post_type || ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'fy-fleet-admin', FY_FLEET_URL . 'assets/admin.css', array(), FY_FLEET_VERSION );
		wp_enqueue_script( 'fy-fleet-admin', FY_FLEET_URL . 'assets/admin.js', array( 'jquery', 'jquery-ui-sortable' ), FY_FLEET_VERSION, true );
	}

	/** Yacht cards that do not yet have a product of their own. */
	private static function unlinked_yachts() {
		$yachts = get_posts(
			array(
				'post_type'      => FY_Fleet_CPT::POST_TYPE,
				'post_status'    => array( 'publish', 'draft', 'pending' ),
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);
		$out = array();
		foreach ( $yachts as $yacht ) {
			$pid = (int) get_post_meta( $yacht->ID, '_fy_product_id', true );
			if ( $pid && 'product' === get_post_type( $pid ) && 'trash' !== get_post_status( $pid ) ) {
				continue;
			}
			$out[] = $yacht;
		}
		return $out;
	}

	private static function linked_yacht_id( $product_id ) {
		$yacht_id = (int) get_post_meta( $product_id, '_fy_yacht_id', true );
		if ( $yacht_id && FY_Fleet_CPT::POST_TYPE === get_post_type( $yacht_id ) && 'trash' !== get_post_status( $yacht_id ) ) {
			return $yacht_id;
		}
		return 0;
	}

	public static function add_box() {
		add_meta_box(
			'fy_product_yacht',
			__( '⚓ Feeling Yachty — Yacht Card', 'fy-fleet' ),
			array( __CLASS__, 'render' ),
			'product',
			'normal',
			'high'
		);
	}

	public static function render( $post ) {
		$yacht_id = self::linked_yacht_id( $post->ID );
		// With no yacht linked yet the renderers read meta from ID 0, which
		// simply comes back empty — exactly the blank form we want.
		$yacht = $yacht_id ? get_post( $yacht_id ) : (object) array( 'ID' => 0 );
		?>
		<?php if ( $yacht_id ) : ?>
			<p>
				✅ <strong><?php esc_html_e( 'This product is live in the Fleet widget.', 'fy-fleet' ); ?></strong>
				<a href="<?php echo esc_url( get_edit_post_link( $yacht_id ) ); ?>"><?php esc_html_e( 'Open yacht record', 'fy-fleet' ); ?></a> ·
				<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-visualizer' ) ); ?>"><?php esc_html_e( 'Fleet Visualizer', 'fy-fleet' ); ?></a>
			</p>
			<input type="hidden" name="fy_make_yacht" value="1">
		<?php else : ?>
			<p>
				<label style="font-weight:700">
					<input type="checkbox" name="fy_make_yacht" value="1" checked>
					<?php esc_html_e( 'List this product in the Fleet widget (the yacht card is created automatically when you publish)', 'fy-fleet' ); ?>
				</label>
			</p>
			<p class="description"><?php esc_html_e( 'Untick only for non-yacht products (merch, gift cards). Ticked: publishing creates the card, the widget updates by itself, and the card button links straight to THIS product page.', 'fy-fleet' ); ?></p>
			<?php $unlinked = self::unlinked_yachts(); ?>
			<?php if ( $unlinked ) : ?>
				<p style="margin-top:10px">
					<label for="fy_link_yacht" style="font-weight:700">🔗 <?php esc_html_e( 'Already have a yacht card for this boat?', 'fy-fleet' ); ?></label>
					<select id="fy_link_yacht" name="fy_link_yacht">
						<option value="0"><?php esc_html_e( '— Create a new yacht card —', 'fy-fleet' ); ?></option>
						<?php foreach ( $unlinked as $unlinked_yacht ) : ?>
							<option value="<?php echo esc_attr( $unlinked_yacht->ID ); ?>"><?php echo esc_html( $unlinked_yacht->post_title ); ?></option>
						<?php endforeach; ?>
					</select>
				</p>
				<p class="description"><?php esc_html_e( 'Pick the existing yacht and click Update: this product adopts that yacht’s size, pricing, hours and photos, and the [fy_yacht_…] blocks fill in immediately. Its data is left exactly as it is — nothing on this screen overwrites it.', 'fy-fleet' ); ?></p>
			<?php endif; ?>
		<?php endif; ?>
		<?php
		// Which city widget/visualizer this yacht belongs to. One select, one
		// answer — a Panama yacht never needs a second screen to be filed right.
		$cities        = get_terms( array( 'taxonomy' => 'fy_yacht_cat', 'hide_empty' => false ) );
		$cities        = is_wp_error( $cities ) ? array() : $cities;
		$current_city  = 0;
		if ( $yacht_id ) {
			$assigned = wp_get_object_terms( $yacht_id, 'fy_yacht_cat', array( 'fields' => 'ids' ) );
			if ( ! is_wp_error( $assigned ) && ! empty( $assigned ) ) {
				$current_city = (int) $assigned[0];
			}
		}
		?>
		<?php if ( ! empty( $cities ) ) : ?>
			<p>
				<label for="fy_yacht_city" style="font-weight:700">🌎 <?php esc_html_e( 'City / fleet widget:', 'fy-fleet' ); ?></label>
				<select id="fy_yacht_city" name="fy_yacht_city">
					<?php foreach ( $cities as $city_term ) : ?>
						<option value="<?php echo esc_attr( $city_term->term_id ); ?>" <?php selected( $current_city ? $current_city === (int) $city_term->term_id : 'miami-yacht-rentals' === $city_term->slug ); ?>>
							<?php echo esc_html( $city_term->name ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<a href="<?php echo esc_url( admin_url( 'edit-tags.php?taxonomy=fy_yacht_cat&post_type=' . FY_Fleet_CPT::POST_TYPE ) ); ?>" style="margin-left:6px"><?php esc_html_e( '＋ manage cities', 'fy-fleet' ); ?></a>
			</p>
			<p class="description"><?php esc_html_e( 'The yacht card appears ONLY in this city’s widget and its tab in the Fleet Visualizer — pick Panama and it will never show on the Miami page.', 'fy-fleet' ); ?></p>
		<?php endif; ?>

		<p class="description">
			<?php esc_html_e( 'Keep the [fy_yacht_…] shortcodes in the description box above — they render the sections below on the product page, in whatever order you arrange them. Everything you fill in here feeds those shortcodes.', 'fy-fleet' ); ?>
		</p>

		<?php // Carried through so saving from this screen never blanks the card button. The URL is re-pointed at this product on publish anyway. ?>
		<input type="hidden" name="fy_button_url" value="<?php echo esc_attr( $yacht_id ? get_post_meta( $yacht_id, '_fy_button_url', true ) : '' ); ?>">

		<h3><?php esc_html_e( 'Card Summary', 'fy-fleet' ); ?></h3>
		<?php FY_Fleet_Metaboxes::render_summary( $yacht ); ?>
		<h3><?php esc_html_e( 'Hours & Pricing', 'fy-fleet' ); ?></h3>
		<?php FY_Fleet_Metaboxes::render_pricing( $yacht ); ?>
		<p class="description">📸 <?php esc_html_e( 'Gallery: managed from the WooCommerce "Product Gallery" box below (in the sidebar) on this screen — it stays in sync with the Fleet Visualizer\'s Gallery box automatically in both directions. Edit photos in only one place per save to avoid the two overwriting each other.', 'fy-fleet' ); ?></p>
		<h3><?php esc_html_e( 'Badges', 'fy-fleet' ); ?></h3>
		<?php FY_Fleet_Metaboxes::render_badges( $yacht ); ?>
		<h3><?php esc_html_e( 'Booking Options', 'fy-fleet' ); ?></h3>
		<?php FY_Fleet_Metaboxes::render_booking_options( $yacht ); ?>
		<?php if ( class_exists( 'FY_Fleet_Marina' ) ) : ?>
			<h3><?php esc_html_e( 'Marina & Map', 'fy-fleet' ); ?></h3>
			<?php FY_Fleet_Marina::render_meta_box( $yacht ); ?>
		<?php endif; ?>
		<?php if ( class_exists( 'FY_Fleet_Reviews' ) ) : ?>
			<h3><?php esc_html_e( 'Reviews (shown on page + Google stars)', 'fy-fleet' ); ?></h3>
			<?php FY_Fleet_Reviews::render_meta_box( $yacht ); ?>
		<?php endif; ?>
		<h3><?php esc_html_e( 'Card Photo', 'fy-fleet' ); ?></h3>
		<p class="description"><?php esc_html_e( 'The Product Image (right sidebar) is used automatically everywhere. The URL below is a fallback for photos hosted elsewhere.', 'fy-fleet' ); ?></p>
		<?php FY_Fleet_Metaboxes::render_image( $yacht ); ?>
		<h3><?php esc_html_e( 'Extra Search Keywords', 'fy-fleet' ); ?></h3>
		<?php FY_Fleet_Metaboxes::render_search( $yacht ); ?>
		<h3><?php esc_html_e( 'Internal Reference (not shown on site)', 'fy-fleet' ); ?></h3>
		<?php FY_Fleet_Metaboxes::render_reference( $yacht ); ?>
		<?php
	}

	/**
	 * Product saved → create/update the yacht card behind it.
	 * The product is the front door here: card title, status, photo and the
	 * card button URL all follow the product.
	 */
	public static function save( $product_id, $product_post ) {
		if ( self::$busy || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
			return;
		}
		if ( wp_is_post_revision( $product_id ) || 'auto-draft' === $product_post->post_status || 'trash' === $product_post->post_status ) {
			return;
		}
		if ( ! isset( $_POST['fy_fleet_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fy_fleet_nonce'] ) ), 'fy_fleet_save' ) ) {
			return;
		}
		// Only genuine product-screen submissions. A yacht-screen save posts the
		// same nonce and re-saves the product mid-chain — without this guard the
		// product side would run too and overwrite a hand-typed Button URL.
		if ( ! isset( $_POST['post_type'] ) || 'product' !== $_POST['post_type'] ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $product_id ) ) {
			return;
		}

		$yacht_id = self::linked_yacht_id( $product_id );

		// Adopting an EXISTING yacht card: link the two and stop. The fields on
		// this screen were rendered blank (there was no yacht yet), so running
		// the normal save would wipe the size, pricing and hours already stored
		// on that yacht. Link only; the next save edits it normally.
		if ( ! $yacht_id && ! empty( $_POST['fy_link_yacht'] ) ) {
			$candidate = intval( $_POST['fy_link_yacht'] );
			if ( $candidate && FY_Fleet_CPT::POST_TYPE === get_post_type( $candidate ) ) {
				self::$busy = true;
				update_post_meta( $product_id, '_fy_yacht_id', $candidate );
				update_post_meta( $candidate, '_fy_product_id', $product_id );
				$permalink = get_permalink( $product_id );
				if ( $permalink && 'publish' === $product_post->post_status ) {
					update_post_meta( $candidate, '_fy_button_url', $permalink );
				}
				FY_Fleet_Woo::sync_product( $candidate );
				if ( class_exists( 'FY_Fleet_Log' ) ) {
					FY_Fleet_Log::add( 'yacht.linked', sprintf( 'Product "%s" linked to existing yacht "%s"', $product_post->post_title, get_the_title( $candidate ) ) );
				}
				self::$busy = false;
				return;
			}
		}

		if ( ! $yacht_id && empty( $_POST['fy_make_yacht'] ) ) {
			return; // A plain product — leave it alone.
		}

		self::$busy = true;
		$status     = 'publish' === $product_post->post_status ? 'publish' : 'draft';

		if ( ! $yacht_id ) {
			// Inserting the yacht fires the yacht→product sync hooks, which
			// would spawn a SECOND product — detach them for the insert. The
			// city and metabox hooks stay attached on purpose: they file the
			// new card under the default city and save all submitted fields.
			remove_action( 'save_post_' . FY_Fleet_CPT::POST_TYPE, array( 'FY_Fleet_Woo', 'fill_defaults' ), 15 );
			remove_action( 'save_post_' . FY_Fleet_CPT::POST_TYPE, array( 'FY_Fleet_Woo', 'sync_product' ), 20 );
			$yacht_id = wp_insert_post(
				array(
					'post_type'   => FY_Fleet_CPT::POST_TYPE,
					'post_title'  => $product_post->post_title,
					'post_status' => $status,
				)
			);
			add_action( 'save_post_' . FY_Fleet_CPT::POST_TYPE, array( 'FY_Fleet_Woo', 'fill_defaults' ), 15, 2 );
			add_action( 'save_post_' . FY_Fleet_CPT::POST_TYPE, array( 'FY_Fleet_Woo', 'sync_product' ), 20, 2 );

			if ( ! $yacht_id || is_wp_error( $yacht_id ) ) {
				self::$busy = false;
				return;
			}
			update_post_meta( $product_id, '_fy_yacht_id', $yacht_id );
			update_post_meta( $yacht_id, '_fy_product_id', $product_id );
			if ( class_exists( 'FY_Fleet_Log' ) ) {
				FY_Fleet_Log::add( 'yacht.created', sprintf( 'Yacht card created from product "%s"', $product_post->post_title ) );
			}
		}

		// All submitted card fields → the yacht record. Marina and Reviews carry
		// their own nonces and no-op harmlessly when theirs is absent.
		FY_Fleet_Metaboxes::save( $yacht_id, get_post( $yacht_id ) );
		if ( class_exists( 'FY_Fleet_Marina' ) ) {
			FY_Fleet_Marina::save( $yacht_id, get_post( $yacht_id ) );
		}
		if ( class_exists( 'FY_Fleet_Reviews' ) ) {
			FY_Fleet_Reviews::save( $yacht_id, get_post( $yacht_id ) );
		}

		// Photo: the product image doubles as the card photo.
		$thumb_id = get_post_thumbnail_id( $product_id );
		if ( $thumb_id && (int) get_post_thumbnail_id( $yacht_id ) !== (int) $thumb_id ) {
			set_post_thumbnail( $yacht_id, $thumb_id );
		}

		// Gallery: whatever is on the product's own Product Gallery field
		// (WooCommerce saves it earlier in this same save_post_product
		// request, at its default priority) becomes the yacht's gallery too
		// — so a photo added/removed on the product screen shows up in
		// [fy_yacht_gallery] without a separate step.
		if ( class_exists( 'WC_Product' ) ) {
			$product = wc_get_product( $product_id );
			if ( $product ) {
				$gallery_ids = array_map( 'intval', $product->get_gallery_image_ids() );
				$full        = $thumb_id ? array_merge( array( (int) $thumb_id ), $gallery_ids ) : $gallery_ids;
				update_post_meta( $yacht_id, '_fy_gallery_image_ids', $full );
			}
		}

		// Name/status follow the product. (The re-entrant product save this
		// triggers is caught by the $busy flag above.)
		$yacht = get_post( $yacht_id );
		if ( $yacht && ( $yacht->post_title !== $product_post->post_title || $yacht->post_status !== $status ) ) {
			wp_update_post(
				array(
					'ID'          => $yacht_id,
					'post_title'  => $product_post->post_title,
					'post_status' => $status,
				)
			);
		}

		// City → the widget/visualizer this yacht belongs to.
		if ( isset( $_POST['fy_yacht_city'] ) && taxonomy_exists( 'fy_yacht_cat' ) ) {
			$city_id = intval( $_POST['fy_yacht_city'] );
			$term    = $city_id ? get_term( $city_id, 'fy_yacht_cat' ) : null;
			if ( $term && ! is_wp_error( $term ) ) {
				wp_set_object_terms( $yacht_id, array( (int) $term->term_id ), 'fy_yacht_cat' );
			}
		}

		// Card button → this product's own URL (the WooCommerce URL structure).
		if ( 'publish' === $status ) {
			$permalink = get_permalink( $product_id );
			if ( $permalink ) {
				update_post_meta( $yacht_id, '_fy_button_url', $permalink );
			}
		}

		// Push the deposit price + shortcode description back onto the product.
		FY_Fleet_Woo::sync_product( $yacht_id );

		self::$busy = false;
	}

	/** Update the yacht without firing its yacht→product sync hooks. */
	private static function quiet_yacht_update( $args ) {
		self::$busy = true;
		remove_action( 'save_post_' . FY_Fleet_CPT::POST_TYPE, array( 'FY_Fleet_Woo', 'fill_defaults' ), 15 );
		remove_action( 'save_post_' . FY_Fleet_CPT::POST_TYPE, array( 'FY_Fleet_Woo', 'sync_product' ), 20 );
		wp_update_post( $args );
		add_action( 'save_post_' . FY_Fleet_CPT::POST_TYPE, array( 'FY_Fleet_Woo', 'fill_defaults' ), 15, 2 );
		add_action( 'save_post_' . FY_Fleet_CPT::POST_TYPE, array( 'FY_Fleet_Woo', 'sync_product' ), 20, 2 );
		self::$busy = false;
	}

	/** Product trashed → pull its card off the widget (draft, nothing deleted). */
	public static function on_product_trashed( $post_id ) {
		if ( 'product' !== get_post_type( $post_id ) ) {
			return;
		}
		$yacht_id = (int) get_post_meta( $post_id, '_fy_yacht_id', true );
		if ( $yacht_id && FY_Fleet_CPT::POST_TYPE === get_post_type( $yacht_id ) && 'publish' === get_post_status( $yacht_id ) ) {
			self::quiet_yacht_update( array( 'ID' => $yacht_id, 'post_status' => 'draft' ) );
			if ( class_exists( 'FY_Fleet_Log' ) ) {
				FY_Fleet_Log::add( 'yacht.unlisted', sprintf( 'Product trashed — yacht card "%s" set to draft', get_the_title( $yacht_id ) ) );
			}
		}
	}

	/** Product restored to published → put its card back on the widget. */
	public static function on_product_untrashed( $post_id ) {
		if ( 'product' !== get_post_type( $post_id ) || 'publish' !== get_post_status( $post_id ) ) {
			return;
		}
		$yacht_id = (int) get_post_meta( $post_id, '_fy_yacht_id', true );
		if ( $yacht_id && FY_Fleet_CPT::POST_TYPE === get_post_type( $yacht_id ) && 'publish' !== get_post_status( $yacht_id ) ) {
			self::quiet_yacht_update( array( 'ID' => $yacht_id, 'post_status' => 'publish' ) );
		}
	}
}
