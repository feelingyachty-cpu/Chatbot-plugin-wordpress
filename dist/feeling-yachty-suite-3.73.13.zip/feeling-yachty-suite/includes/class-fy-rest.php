<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * REST API + taxonomies.
 *
 * Yachts are readable and writable at /wp-json/fy/v1/yachts so automations
 * (n8n, Make, scripts) can create yachts and edit descriptions/SEO in one call
 * instead of juggling dozens of meta endpoints.
 *
 * Authenticate with a WordPress Application Password over Basic auth:
 *   Users → Profile → Application Passwords → Add New.
 */
class FY_Fleet_REST {

	const NAMESPACE_V1 = 'fy/v1';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_taxonomies' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		self::register_admin_actions();
	}

	public static function register_admin_actions() {
		add_action( 'admin_post_fy_export_fleet', array( __CLASS__, 'handle_export' ) );
		add_action( 'admin_post_fy_import_fleet_json', array( __CLASS__, 'handle_import_json' ) );
		add_action( 'admin_post_fy_export_csv', array( __CLASS__, 'handle_export_csv' ) );
		add_action( 'admin_post_fy_import_csv', array( __CLASS__, 'handle_import_csv' ) );
		add_action( 'admin_post_fy_backup_now', array( __CLASS__, 'handle_backup_now' ) );
		add_action( 'admin_post_fy_restore_backup', array( __CLASS__, 'handle_restore' ) );

		// Daily automatic snapshot, rotating the newest seven.
		add_action( 'fy_fleet_daily_backup', array( __CLASS__, 'cron_backup' ) );
		if ( ! wp_next_scheduled( 'fy_fleet_daily_backup' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'fy_fleet_daily_backup' );
		}
	}

	/* ------------------------------------------------------------------
	 * Backups: JSON snapshots in uploads/fy-fleet-backups, newest 7 kept.
	 * ---------------------------------------------------------------- */

	const BACKUP_KEEP = 7;

	private static function backup_dir() {
		$uploads = wp_upload_dir();
		$dir     = trailingslashit( $uploads['basedir'] ) . 'fy-fleet-backups';
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
			// Block direct listing/downloading of customer-facing data.
			@file_put_contents( $dir . '/.htaccess', "Deny from all\n" ); // phpcs:ignore
			@file_put_contents( $dir . '/index.php', "<?php // Silence.\n" ); // phpcs:ignore
		}
		return $dir;
	}

	/** Everything worth restoring: yachts + the suite's own settings. */
	public static function export_payload() {
		$yachts = get_posts(
			array(
				'post_type'      => FY_Fleet_CPT::POST_TYPE,
				'post_status'    => array( 'publish', 'draft', 'pending' ),
				'posts_per_page' => -1,
			)
		);

		$payload = array(
			'exported_at' => gmdate( 'c' ),
			'site'        => home_url(),
			'yachts'      => array(),
			'options'     => array(
				'fy_fleet_settings'         => get_option( 'fy_fleet_settings', array() ),
				'fy_fleet_booking_settings' => get_option( 'fy_fleet_booking_settings', array() ),
				'fy_fleet_seo'              => get_option( 'fy_fleet_seo', array() ),
				'fy_fleet_marinas'          => get_option( 'fy_fleet_marinas', array() ),
			),
		);
		foreach ( $yachts as $yacht ) {
			$payload['yachts'][] = self::shape( $yacht->ID );
		}
		return $payload;
	}

	/** @return array{created:int,updated:int} */
	public static function import_payload( $data ) {
		$created = 0;
		$updated = 0;

		if ( isset( $data['yachts'] ) && is_array( $data['yachts'] ) ) {
			foreach ( $data['yachts'] as $yacht ) {
				if ( empty( $yacht['title'] ) ) {
					continue;
				}
				$request = new WP_REST_Request( 'POST' );
				foreach ( $yacht as $key => $value ) {
					$request->set_param( $key, $value );
				}

				$existing = get_posts(
					array(
						'post_type'      => FY_Fleet_CPT::POST_TYPE,
						'post_status'    => 'any',
						'title'          => $yacht['title'],
						'posts_per_page' => 1,
						'fields'         => 'ids',
					)
				);
				if ( $existing ) {
					$request['id'] = $existing[0];
					self::update_yacht( $request );
					$updated++;
				} else {
					self::create_yacht( $request );
					$created++;
				}
			}
		}

		// Suite settings, only the keys we own.
		if ( isset( $data['options'] ) && is_array( $data['options'] ) ) {
			foreach ( array( 'fy_fleet_settings', 'fy_fleet_booking_settings', 'fy_fleet_seo', 'fy_fleet_marinas' ) as $option ) {
				if ( array_key_exists( $option, $data['options'] ) ) {
					update_option( $option, $data['options'][ $option ] );
				}
			}
		}

		return array( 'created' => $created, 'updated' => $updated );
	}

	/** Write a snapshot file and rotate old ones out. */
	public static function create_backup( $reason = 'manual' ) {
		$dir  = self::backup_dir();
		$name = sprintf( 'fleet-backup-%s-%s-%s.json', gmdate( 'Y-m-d-His' ), sanitize_key( $reason ), wp_generate_password( 8, false, false ) );

		$written = @file_put_contents( // phpcs:ignore
			$dir . '/' . $name,
			wp_json_encode( self::export_payload(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
		);
		if ( false === $written ) {
			return new WP_Error( 'fy_backup_write', __( 'Could not write the backup file.', 'fy-fleet' ) );
		}

		// Keep only the newest seven.
		$files = self::list_backups();
		foreach ( array_slice( $files, self::BACKUP_KEEP ) as $old ) {
			@unlink( $old['path'] ); // phpcs:ignore
		}

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'backup.created', sprintf( 'Backup created (%s): %s', $reason, $name ) );
		}
		return $name;
	}

	/** Newest first. @return array[] {path,name,time,size,yachts} */
	public static function list_backups() {
		$dir   = self::backup_dir();
		$found = glob( $dir . '/fleet-backup-*.json' );
		$out   = array();
		foreach ( (array) $found as $path ) {
			$out[] = array(
				'path' => $path,
				'name' => basename( $path ),
				'time' => (int) filemtime( $path ),
				'size' => (int) filesize( $path ),
			);
		}
		usort( $out, function ( $a, $b ) { return $b['time'] <=> $a['time']; } );
		return $out;
	}

	public static function cron_backup() {
		self::create_backup( 'auto' );
	}

	/* ------------------------------------------------------------------
	 * CSV (Excel) export / import — bulk-edit the fleet in a spreadsheet.
	 *
	 * Cell rules on import:  blank = leave unchanged · "-" = clear the field.
	 * Rows match by the id column; no id (or no match) = new yacht by title.
	 * ---------------------------------------------------------------- */

	/** Column key => spreadsheet header. Order defines the sheet. */
	public static function csv_columns() {
		return array(
			'id'                => 'ID (do not edit)',
			'title'             => 'Yacht Name',
			'status'            => 'Status (publish/draft)',
			'size_ft'           => 'Size (ft)',
			'capacity_max'      => 'Max Guests',
			'price'             => 'Starting Price',
			'duration_label'    => 'Starting Duration',
			'price_note'        => 'Price Note',
			'special_desc'      => 'Yacht Page Description',
			'year'              => 'Year',
			'brand'             => 'Brand',
			'model'             => 'Model',
			'captain_included'  => 'Captain Included (yes/no)',
			'rating'            => 'Rating (0-5)',
			'sku'               => 'SKU',
			'source_owner'      => 'Source Owner',
			'source_listing_id' => 'Source Listing ID',
			'crew_rate'         => 'Crew $/hr (blank = fleet default)',
			'fuel_rate'         => 'Hourly boat deposit $/hr (blank = fleet default)',
			'service_fee'       => 'Service Fee $ (blank = fleet default)',
			'is_pink'           => 'Pink Yacht (yes/no)',
			'is_free_hour'      => 'Free Hour (yes/no)',
			'weekend_surcharge' => 'Weekend Surcharge',
			'image_url'         => 'Image URL',
			'button_url'        => 'Button URL',
			'button_label'      => 'Button Label',
			'button_sub'        => 'Button Sub-label',
			'pricing'           => 'Hours & Pricing (see syntax)',
			'badges'            => 'Badges (Text | style per line)',
			'categories'        => 'Fleets (comma separated)',
			'tags'              => 'Tags (comma separated)',
			'marina'            => 'Marina key',
			'search_terms'      => 'Search Keywords',
			'seo_title'         => 'Meta Title',
			'seo_description'   => 'Meta Description',
		);
	}

	/**
	 * Pricing rows → human-editable multi-line cell text:
	 *   # Monday–Thursday        (day heading)
	 *   3 Hours = 845            (price row; append * for free-hour styling)
	 *   note: Weekend surcharge  (note row)
	 */
	public static function pricing_to_text( $rows ) {
		$lines = array();
		foreach ( (array) $rows as $row ) {
			$type = isset( $row['type'] ) ? $row['type'] : 'price';
			if ( 'heading' === $type ) {
				$lines[] = '# ' . $row['text'];
			} elseif ( 'note' === $type ) {
				$lines[] = 'note: ' . $row['text'];
			} else {
				$lines[] = $row['duration'] . ' = ' . ( isset( $row['price'] ) ? $row['price'] : 0 ) . ( ! empty( $row['free'] ) ? ' *' : '' );
			}
		}
		return implode( "\n", $lines );
	}

	public static function text_to_pricing( $text ) {
		$rows = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			if ( '#' === substr( $line, 0, 1 ) ) {
				$rows[] = array( 'type' => 'heading', 'text' => trim( substr( $line, 1 ) ) );
			} elseif ( 0 === stripos( $line, 'note:' ) ) {
				$rows[] = array( 'type' => 'note', 'text' => trim( substr( $line, 5 ) ) );
			} elseif ( false !== strpos( $line, '=' ) ) {
				list( $duration, $price ) = array_map( 'trim', explode( '=', $line, 2 ) );
				$free = false;
				if ( '*' === substr( $price, -1 ) ) {
					$free  = true;
					$price = trim( substr( $price, 0, -1 ) );
				}
				if ( '' !== $duration ) {
					$rows[] = array(
						'type'     => 'price',
						'duration' => $duration,
						'price'    => (float) preg_replace( '/[^0-9.]/', '', $price ),
						'free'     => $free,
					);
				}
			}
		}
		return $rows;
	}

	public static function badges_to_text( $badges ) {
		$lines = array();
		foreach ( (array) $badges as $badge ) {
			if ( ! empty( $badge['text'] ) ) {
				$lines[] = $badge['text'] . ' | ' . ( isset( $badge['style'] ) ? $badge['style'] : 'hot' );
			}
		}
		return implode( "\n", $lines );
	}

	public static function text_to_badges( $text ) {
		$badges = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			$parts = array_map( 'trim', explode( '|', $line, 2 ) );
			if ( '' !== $parts[0] ) {
				$badges[] = array(
					'text'  => $parts[0],
					'style' => isset( $parts[1] ) && '' !== $parts[1] ? $parts[1] : 'hot',
				);
			}
		}
		return $badges;
	}

	public static function handle_export_csv() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		check_admin_referer( 'fy_export_csv' );

		$columns = self::csv_columns();
		$yachts  = get_posts(
			array(
				'post_type'      => FY_Fleet_CPT::POST_TYPE,
				'post_status'    => array( 'publish', 'draft', 'pending' ),
				'posts_per_page' => -1,
			)
		);

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=feeling-yachty-yachts-' . gmdate( 'Y-m-d' ) . '.csv' );

		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" ); // UTF-8 BOM so Excel shows – and emoji correctly.
		fputcsv( $out, array_values( $columns ) );

		foreach ( $yachts as $yacht ) {
			$shape  = self::shape( $yacht->ID );
			$marina = get_post_meta( $yacht->ID, '_fy_marina_source', true );
			$line   = array();
			foreach ( array_keys( $columns ) as $key ) {
				switch ( $key ) {
					case 'pricing':
						$line[] = self::pricing_to_text( $shape['pricing'] );
						break;
					case 'badges':
						$line[] = self::badges_to_text( $shape['badges'] );
						break;
					case 'categories':
						$line[] = implode( ', ', (array) $shape['categories'] );
						break;
					case 'tags':
						$line[] = implode( ', ', (array) $shape['tags'] );
						break;
					case 'marina':
						$line[] = $marina;
						break;
					case 'is_pink':
					case 'is_free_hour':
					case 'captain_included':
						$line[] = $shape[ $key ] ? 'yes' : 'no';
						break;
					case 'seo_title':
						$line[] = $shape['seo']['meta_title'];
						break;
					case 'seo_description':
						$line[] = $shape['seo']['meta_description'];
						break;
					default:
						$line[] = isset( $shape[ $key ] ) ? $shape[ $key ] : '';
				}
			}
			fputcsv( $out, $line );
		}
		fclose( $out ); // phpcs:ignore

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'export.csv', sprintf( 'Exported %d yachts to CSV', count( $yachts ) ) );
		}
		exit;
	}

	public static function handle_import_csv() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		check_admin_referer( 'fy_import_csv' );

		if ( empty( $_FILES['fy_csv_file']['tmp_name'] ) ) {
			wp_die( esc_html__( 'No file uploaded.', 'fy-fleet' ) );
		}

		$handle = fopen( sanitize_text_field( $_FILES['fy_csv_file']['tmp_name'] ), 'r' ); // phpcs:ignore -- tmp upload
		if ( ! $handle ) {
			wp_die( esc_html__( 'Could not read the file.', 'fy-fleet' ) );
		}

		// Header row → column keys (tolerant of Excel's edits and the BOM).
		$header = fgetcsv( $handle );
		if ( ! is_array( $header ) ) {
			wp_die( esc_html__( 'That file has no header row.', 'fy-fleet' ) );
		}
		$labels = array();
		foreach ( self::csv_columns() as $key => $label ) {
			$labels[ strtolower( preg_replace( '/\s+/', ' ', trim( $label ) ) ) ] = $key;
		}
		$map = array();
		foreach ( $header as $i => $cell ) {
			$cell = strtolower( preg_replace( '/\s+/', ' ', trim( str_replace( "\xEF\xBB\xBF", '', (string) $cell ) ) ) );
			if ( isset( $labels[ $cell ] ) ) {
				$map[ $i ] = $labels[ $cell ];
			}
		}
		if ( ! in_array( 'title', $map, true ) ) {
			wp_die( esc_html__( 'The "Yacht Name" column is missing — export a fresh CSV and edit that file.', 'fy-fleet' ) );
		}

		// Every import is reversible.
		self::create_backup( 'pre-import' );

		$created = 0;
		$updated = 0;
		while ( false !== ( $row = fgetcsv( $handle ) ) ) {
			$cells = array();
			foreach ( $map as $i => $key ) {
				$cells[ $key ] = isset( $row[ $i ] ) ? trim( (string) $row[ $i ] ) : '';
			}
			if ( '' === trim( isset( $cells['title'] ) ? $cells['title'] : '' ) ) {
				continue;
			}

			// blank = skip; "-" = clear.
			$params = array( 'title' => $cells['title'] );
			$seo    = array();
			foreach ( $cells as $key => $value ) {
				if ( in_array( $key, array( 'id', 'title' ), true ) || '' === $value ) {
					continue;
				}
				$value = ( '-' === $value ) ? '' : $value;
				switch ( $key ) {
					case 'pricing':
						$params['pricing'] = self::text_to_pricing( $value );
						break;
					case 'badges':
						$params['badges'] = self::text_to_badges( $value );
						break;
					case 'categories':
					case 'tags':
						$params[ $key ] = '' === $value ? array() : array_filter( array_map( 'trim', explode( ',', $value ) ) );
						break;
					case 'marina':
						$params['marina'] = array( 'source' => $value );
						break;
					case 'is_pink':
					case 'is_free_hour':
					case 'captain_included':
						$params[ $key ] = in_array( strtolower( $value ), array( 'yes', 'y', '1', 'true' ), true );
						break;
					case 'seo_title':
						$seo['meta_title'] = $value;
						break;
					case 'seo_description':
						$seo['meta_description'] = $value;
						break;
					default:
						$params[ $key ] = $value;
				}
			}
			if ( $seo ) {
				$params['seo'] = $seo;
			}

			$request = new WP_REST_Request( 'POST' );
			foreach ( $params as $key => $value ) {
				$request->set_param( $key, $value );
			}

			$target = 0;
			if ( ! empty( $cells['id'] ) && FY_Fleet_CPT::POST_TYPE === get_post_type( (int) $cells['id'] ) ) {
				$target = (int) $cells['id'];
			} else {
				$existing = get_posts(
					array(
						'post_type'      => FY_Fleet_CPT::POST_TYPE,
						'post_status'    => 'any',
						'title'          => $cells['title'],
						'posts_per_page' => 1,
						'fields'         => 'ids',
					)
				);
				$target = $existing ? (int) $existing[0] : 0;
			}

			if ( $target ) {
				$request['id'] = $target;
				self::update_yacht( $request );
				$updated++;
			} else {
				self::create_yacht( $request );
				$created++;
			}
		}
		fclose( $handle ); // phpcs:ignore

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'import.csv', sprintf( 'CSV import: %d created, %d updated', $created, $updated ) );
		}

		wp_safe_redirect(
			add_query_arg(
				array( 'page' => 'fy-fleet-api', 'post_type' => FY_Fleet_CPT::POST_TYPE, 'fy_json_created' => $created, 'fy_json_updated' => $updated ),
				admin_url( 'edit.php' )
			)
		);
		exit;
	}

	public static function handle_backup_now() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		check_admin_referer( 'fy_backup_now' );
		$result = self::create_backup( 'manual' );
		wp_safe_redirect(
			add_query_arg(
				array( 'page' => 'fy-fleet-api', 'post_type' => FY_Fleet_CPT::POST_TYPE, 'fy_backup' => is_wp_error( $result ) ? 'fail' : 'ok' ),
				admin_url( 'edit.php' )
			)
		);
		exit;
	}

	public static function handle_restore() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		check_admin_referer( 'fy_restore_backup' );

		$name = isset( $_GET['backup'] ) ? sanitize_file_name( wp_unslash( $_GET['backup'] ) ) : '';
		$path = self::backup_dir() . '/' . $name;
		if ( '' === $name || 0 !== strpos( $name, 'fleet-backup-' ) || ! file_exists( $path ) ) {
			wp_die( esc_html__( 'Backup not found.', 'fy-fleet' ) );
		}

		// Snapshot the current state first, so a restore is itself reversible.
		self::create_backup( 'pre-restore' );

		$data = json_decode( (string) file_get_contents( $path ), true ); // phpcs:ignore
		if ( ! is_array( $data ) ) {
			wp_die( esc_html__( 'That backup file is unreadable.', 'fy-fleet' ) );
		}

		$result = self::import_payload( $data );

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'backup.restored', sprintf( 'Restored %s — %d created, %d updated', $name, $result['created'], $result['updated'] ) );
		}

		wp_safe_redirect(
			add_query_arg(
				array( 'page' => 'fy-fleet-api', 'post_type' => FY_Fleet_CPT::POST_TYPE, 'fy_json_created' => $result['created'], 'fy_json_updated' => $result['updated'] ),
				admin_url( 'edit.php' )
			)
		);
		exit;
	}

	/** Stream the whole fleet as a JSON download. */
	public static function handle_export() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		check_admin_referer( 'fy_export_fleet' );

		$out = self::export_payload();

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'export', sprintf( 'Exported %d yachts to JSON', count( $out['yachts'] ) ) );
		}

		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=feeling-yachty-fleet-' . gmdate( 'Y-m-d' ) . '.json' );
		echo wp_json_encode( $out, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		exit;
	}

	/** Restore/merge a fleet from an exported JSON file (matched by title). */
	public static function handle_import_json() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		check_admin_referer( 'fy_import_fleet_json' );

		if ( empty( $_FILES['fy_fleet_file']['tmp_name'] ) ) {
			wp_die( esc_html__( 'No file uploaded.', 'fy-fleet' ) );
		}

		$raw  = file_get_contents( sanitize_text_field( $_FILES['fy_fleet_file']['tmp_name'] ) ); // phpcs:ignore -- tmp upload path
		$data = json_decode( $raw, true );
		if ( ! is_array( $data ) || empty( $data['yachts'] ) || ! is_array( $data['yachts'] ) ) {
			wp_die( esc_html__( 'That file is not a fleet export.', 'fy-fleet' ) );
		}

		// Snapshot the current fleet first, so any import can be undone.
		self::create_backup( 'pre-import' );

		$result = self::import_payload( $data );

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'import', sprintf( 'JSON import: %d created, %d updated', $result['created'], $result['updated'] ) );
		}

		wp_safe_redirect(
			add_query_arg(
				array( 'page' => 'fy-fleet-api', 'post_type' => FY_Fleet_CPT::POST_TYPE, 'fy_json_created' => $result['created'], 'fy_json_updated' => $result['updated'] ),
				admin_url( 'edit.php' )
			)
		);
		exit;
	}

	public static function add_menu() {
		add_submenu_page(
			'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE,
			__( 'API / n8n', 'fy-fleet' ),
			__( 'API / n8n', 'fy-fleet' ),
			'manage_options',
			'fy-fleet-api',
			array( __CLASS__, 'render_api_page' )
		);
	}

	public static function render_api_page() {
		$base    = rest_url( self::NAMESPACE_V1 );
		$example = wp_json_encode(
			array(
				'title'          => '55ft Example Yacht',
				'size_ft'        => 55,
				'capacity_max'   => 13,
				'price'          => 1200,
				'duration_label' => '3 Hours',
				'price_note'     => '3-hour private charter',
				'image_url'      => 'https://feelingyachty.com/wp-content/uploads/example.jpg',
				'button_url'     => 'https://feelingyachty.com/miami-yacht-rentals/55ft-example/',
				'is_pink'        => false,
				'is_free_hour'   => true,
				'categories'     => array( 'Miami Yacht Rentals' ),
				'tags'           => array( 'sunset', 'birthday' ),
				'badges'         => array( array( 'style' => 'hot', 'text' => 'New Yacht' ) ),
				'pricing'        => array(
					array( 'type' => 'heading', 'text' => 'Monday–Thursday' ),
					array( 'type' => 'price', 'duration' => '3 Hours', 'price' => 1200 ),
					array( 'type' => 'price', 'duration' => 'Pay for 4 Hours Get 5 Hours Total', 'price' => 1500, 'free' => true ),
					array( 'type' => 'heading', 'text' => 'Friday–Sunday' ),
					array( 'type' => 'price', 'duration' => '3 Hours', 'price' => 1400 ),
					array( 'type' => 'note', 'text' => 'Weekend surcharge — $150' ),
				),
				'marina'         => array( 'source' => 'dinner-key' ),
				'seo'            => array(
					'meta_title'       => '55ft Example Yacht Charter Miami | Feeling Yachty',
					'meta_description' => 'Charter the 55ft Example in Miami from $1,200. Compare hours, add-ons and reserve with a deposit.',
					'main_entity'      => '55ft Example yacht charter',
					'faq'              => "How many guests?|Up to 13 guests.\nWhat is included?|Captain and standard charter essentials.",
				),
			),
			JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
		);
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'API / n8n', 'fy-fleet' ); ?></h1>
			<p class="description" style="max-width:900px">
				<?php esc_html_e( 'Create yachts and edit descriptions, pricing and SEO from n8n, Make, or any script. Everything on a yacht is available in a single call.', 'fy-fleet' ); ?>
			</p>

			<h2><?php esc_html_e( '1. Create a login for your automation', 'fy-fleet' ); ?></h2>
			<p>
				<?php
				printf(
					/* translators: %s: profile URL */
					esc_html__( 'Go to %s → Application Passwords → give it a name like "n8n" → Add. Copy the generated password (you only see it once).', 'fy-fleet' ),
					'<a href="' . esc_url( admin_url( 'profile.php#application-passwords-section' ) ) . '"><strong>' . esc_html__( 'Users → Profile', 'fy-fleet' ) . '</strong></a>'
				);
				?>
			</p>
			<p><?php esc_html_e( 'In n8n use the HTTP Request node with Authentication = Basic Auth: username is your WordPress username, password is the application password.', 'fy-fleet' ); ?></p>

			<h2><?php esc_html_e( '2. Endpoints', 'fy-fleet' ); ?></h2>
			<table class="widefat striped" style="max-width:900px">
				<thead><tr><th><?php esc_html_e( 'Method', 'fy-fleet' ); ?></th><th><?php esc_html_e( 'URL', 'fy-fleet' ); ?></th><th><?php esc_html_e( 'Does', 'fy-fleet' ); ?></th></tr></thead>
				<tbody>
					<tr><td><code>GET</code></td><td><code><?php echo esc_html( $base ); ?>/yachts</code></td><td><?php esc_html_e( 'List all yachts', 'fy-fleet' ); ?></td></tr>
					<tr><td><code>GET</code></td><td><code><?php echo esc_html( $base ); ?>/yachts/123</code></td><td><?php esc_html_e( 'One yacht', 'fy-fleet' ); ?></td></tr>
					<tr><td><code>POST</code></td><td><code><?php echo esc_html( $base ); ?>/yachts</code></td><td><?php esc_html_e( 'Create a yacht', 'fy-fleet' ); ?></td></tr>
					<tr><td><code>POST</code></td><td><code><?php echo esc_html( $base ); ?>/yachts/123</code></td><td><?php esc_html_e( 'Update a yacht (only the fields you send)', 'fy-fleet' ); ?></td></tr>
					<tr><td><code>DELETE</code></td><td><code><?php echo esc_html( $base ); ?>/yachts/123</code></td><td><?php esc_html_e( 'Move a yacht to trash', 'fy-fleet' ); ?></td></tr>
					<tr><td><code>GET</code></td><td><code><?php echo esc_html( $base ); ?>/fleets</code></td><td><?php esc_html_e( 'All city fleets with their own endpoint URLs', 'fy-fleet' ); ?></td></tr>
					<tr><td><code>GET</code></td><td><code><?php echo esc_html( $base ); ?>/fleets/miami-yacht-rentals/yachts</code></td><td><?php esc_html_e( 'Yachts in one city', 'fy-fleet' ); ?></td></tr>
					<tr><td><code>POST</code></td><td><code><?php echo esc_html( $base ); ?>/fleets/panama-yacht-rentals/yachts</code></td><td><?php esc_html_e( 'Create a yacht directly in that city — the fleet is created automatically if new. Ideal for one n8n workflow per city.', 'fy-fleet' ); ?></td></tr>
						<tr><td><code>GET</code></td><td><code><?php echo esc_html( $base ); ?>/marinas</code></td><td><?php esc_html_e( 'Marina library (use the key as marina.source)', 'fy-fleet' ); ?></td></tr>
				<tr><td><code>GET</code></td><td><code><?php echo esc_html( $base ); ?>/bookings</code></td><td><?php esc_html_e( 'Bookings from WooCommerce orders (?from=&to=) — date, time, duration, guests, occasion, notes, marina, totals', 'fy-fleet' ); ?></td></tr>
					<tr><td><code>GET</code></td><td><code><?php echo esc_html( $base ); ?>/tickets</code></td><td><?php esc_html_e( 'Customer messages with full reply threads — pushed to your webhook in real time too (events ticket.created / ticket.reply)', 'fy-fleet' ); ?></td></tr>
					<tr><td><code>GET</code></td><td><code><?php echo esc_html( $base ); ?>/customers</code></td><td><?php esc_html_e( 'Customer database for GHL sync', 'fy-fleet' ); ?></td></tr>
				</tbody>
			</table>

			<h2><?php esc_html_e( '3. Example body', 'fy-fleet' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Send as JSON with Content-Type: application/json. On update, send only the fields you want changed — everything else is left alone.', 'fy-fleet' ); ?></p>
			<textarea class="large-text code" rows="26" readonly onclick="this.select()" style="font-family:Consolas,Monaco,monospace;font-size:12px"><?php echo esc_textarea( $example ); ?></textarea>

			<h2><?php esc_html_e( 'Backup', 'fy-fleet' ); ?></h2>
			<?php if ( isset( $_GET['fy_json_created'] ) ) : ?>
				<div class="notice notice-success"><p><?php printf( esc_html__( 'Import finished: %1$d created, %2$d updated.', 'fy-fleet' ), intval( $_GET['fy_json_created'] ), intval( isset( $_GET['fy_json_updated'] ) ? $_GET['fy_json_updated'] : 0 ) ); ?></p></div>
			<?php endif; ?>
			<p style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
				<a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=fy_export_fleet' ), 'fy_export_fleet' ) ); ?>">
					⬇️ <?php esc_html_e( 'Export all yachts (JSON)', 'fy-fleet' ); ?>
				</a>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data" style="display:inline-flex;gap:8px;align-items:center">
					<input type="hidden" name="action" value="fy_import_fleet_json">
					<?php wp_nonce_field( 'fy_import_fleet_json' ); ?>
					<input type="file" name="fy_fleet_file" accept="application/json,.json" required>
					<button type="submit" class="button" onclick="return confirm('<?php echo esc_js( __( 'Import this file? Yachts are matched by name — existing ones are updated, new ones created. Nothing is deleted.', 'fy-fleet' ) ); ?>');">⬆️ <?php esc_html_e( 'Import JSON', 'fy-fleet' ); ?></button>
				</form>
			</p>
			<p class="description"><?php esc_html_e( 'Weekly habit: export once, keep the file. It restores the entire fleet — pricing rows, SEO, marinas, everything — on this or any other site running this plugin.', 'fy-fleet' ); ?></p>

			<h3><?php esc_html_e( 'Bulk edit in Excel (CSV)', 'fy-fleet' ); ?></h3>
			<p style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
				<a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=fy_export_csv' ), 'fy_export_csv' ) ); ?>">
					📊 <?php esc_html_e( 'Export all yachts (CSV for Excel)', 'fy-fleet' ); ?>
				</a>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data" style="display:inline-flex;gap:8px;align-items:center">
					<input type="hidden" name="action" value="fy_import_csv">
					<?php wp_nonce_field( 'fy_import_csv' ); ?>
					<input type="file" name="fy_csv_file" accept=".csv,text/csv" required>
					<button type="submit" class="button" onclick="return confirm('<?php echo esc_js( __( 'Import this CSV? Rows match by ID (or name for new yachts). Blank cells leave fields unchanged; a single dash clears them. A backup is taken automatically first.', 'fy-fleet' ) ); ?>');">⬆️ <?php esc_html_e( 'Import CSV', 'fy-fleet' ); ?></button>
				</form>
			</p>
			<p class="description">
				<?php esc_html_e( 'Open the CSV in Excel, edit prices/names/anything in bulk, save as CSV, import back. Rules: blank cell = unchanged · a single "-" = clear the field · delete a row = that yacht is simply left alone (never deleted).', 'fy-fleet' ); ?><br>
				<?php echo wp_kses_post( __( '<strong>Hours & Pricing cell syntax</strong> (one per line): <code># Friday–Sunday</code> = day heading · <code>3 Hours = 845</code> = price row (add <code>*</code> for free-hour styling) · <code>note: Weekend surcharge — $150</code> = note.', 'fy-fleet' ) ); ?>
			</p>

			<h3><?php esc_html_e( 'Automatic snapshots (newest 7 kept)', 'fy-fleet' ); ?></h3>
			<?php if ( isset( $_GET['fy_backup'] ) ) : ?>
				<div class="notice <?php echo 'ok' === $_GET['fy_backup'] ? 'notice-success' : 'notice-error'; ?> inline"><p>
					<?php echo 'ok' === $_GET['fy_backup'] ? esc_html__( 'Backup created ✅', 'fy-fleet' ) : esc_html__( 'Backup failed — the uploads folder is not writable.', 'fy-fleet' ); ?>
				</p></div>
			<?php endif; ?>
			<p>
				<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=fy_backup_now' ), 'fy_backup_now' ) ); ?>">💾 <?php esc_html_e( 'Create backup now', 'fy-fleet' ); ?></a>
				<span class="description" style="margin-left:8px"><?php esc_html_e( 'Also runs daily by itself, and automatically before every import or restore.', 'fy-fleet' ); ?></span>
			</p>
			<table class="widefat striped" style="max-width:900px">
				<thead><tr>
					<th><?php esc_html_e( 'Backup', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'When', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'Size', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'Action', 'fy-fleet' ); ?></th>
				</tr></thead>
				<tbody>
				<?php $backups = self::list_backups(); ?>
				<?php if ( empty( $backups ) ) : ?>
					<tr><td colspan="4"><?php esc_html_e( 'No snapshots yet — the first one is created within a day, or click "Create backup now".', 'fy-fleet' ); ?></td></tr>
				<?php else : ?>
					<?php foreach ( $backups as $i => $backup ) : ?>
						<tr>
							<td><code><?php echo esc_html( $backup['name'] ); ?></code><?php echo 0 === $i ? ' <strong>(' . esc_html__( 'latest', 'fy-fleet' ) . ')</strong>' : ''; ?></td>
							<td><?php echo esc_html( date_i18n( 'M j, Y g:i a', $backup['time'] ) ); ?></td>
							<td><?php echo esc_html( size_format( $backup['size'] ) ); ?></td>
							<td>
								<a class="button button-small" onclick="return confirm('<?php echo esc_js( __( 'Restore this backup? Yachts are matched by name and updated; a snapshot of the current state is taken first, so this is reversible.', 'fy-fleet' ) ); ?>');"
									href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=fy_restore_backup&backup=' . rawurlencode( $backup['name'] ) ), 'fy_restore_backup' ) ); ?>">
									♻️ <?php esc_html_e( 'Restore', 'fy-fleet' ); ?>
								</a>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
				</tbody>
			</table>

			<h2><?php esc_html_e( '4. Quick test', 'fy-fleet' ); ?></h2>
			<p><?php esc_html_e( 'Paste this in a terminal, swapping in your username and application password:', 'fy-fleet' ); ?></p>
			<textarea class="large-text code" rows="3" readonly onclick="this.select()" style="font-family:Consolas,Monaco,monospace;font-size:12px">curl -u "USERNAME:APP PASSWORD" "<?php echo esc_url( $base ); ?>/yachts"</textarea>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------
	 * Taxonomies — categories & tags with their own URLs
	 * ---------------------------------------------------------------- */

	/**
	 * Cities (fy_yacht_cat) power the multi-city system: per-city widgets,
	 * /fy/v1/fleets/{city} endpoints and city landing pages.
	 * Tags are governed by the ⚙️ Control Panel toggle.
	 */
	const ENABLE_TAXONOMIES = true;

	public static function register_taxonomies() {
		if ( ! self::ENABLE_TAXONOMIES ) {
			return;
		}
		register_taxonomy(
			'fy_yacht_cat',
			FY_Fleet_CPT::POST_TYPE,
			array(
				'labels'            => array(
					'name'          => __( 'Cities / Fleets', 'fy-fleet' ),
					'singular_name' => __( 'City', 'fy-fleet' ),
					'menu_name'     => __( '🌎 Cities', 'fy-fleet' ),
					'add_new_item'  => __( 'Add New City', 'fy-fleet' ),
					'edit_item'     => __( 'Edit City', 'fy-fleet' ),
					'search_items'  => __( 'Search Cities', 'fy-fleet' ),
					'not_found'     => __( 'No cities yet — add "Panama Yacht Rentals" here and assign yachts to it.', 'fy-fleet' ),
				),
				'hierarchical'      => true,
				'public'            => true,
				'show_admin_column' => true,
				'show_in_rest'      => true,
				'rewrite'           => array( 'slug' => 'yacht-category', 'with_front' => false ),
			)
		);

		if ( ! class_exists( 'FY_Fleet_Features' ) || ! FY_Fleet_Features::on( 'tags' ) ) {
			// Custom-URL term meta still registers for Cities below.
			register_term_meta(
				'fy_yacht_cat',
				'fy_custom_url',
				array(
					'type'              => 'string',
					'single'            => true,
					'show_in_rest'      => true,
					'sanitize_callback' => 'esc_url_raw',
					'auth_callback'     => function () {
						return current_user_can( 'manage_categories' );
					},
				)
			);
			return;
		}

		register_taxonomy(
			'fy_yacht_tag',
			FY_Fleet_CPT::POST_TYPE,
			array(
				'labels'            => array(
					'name'          => __( 'Yacht Tags', 'fy-fleet' ),
					'singular_name' => __( 'Yacht Tag', 'fy-fleet' ),
					'menu_name'     => __( 'Tags', 'fy-fleet' ),
				),
				'hierarchical'      => false,
				'public'            => true,
				'show_admin_column' => true,
				'show_in_rest'      => true,
				'rewrite'           => array( 'slug' => 'yacht-tag', 'with_front' => false ),
			)
		);

		// Optional custom destination URL per term, editable and REST-exposed.
		foreach ( array( 'fy_yacht_cat', 'fy_yacht_tag' ) as $taxonomy ) {
			register_term_meta(
				$taxonomy,
				'fy_custom_url',
				array(
					'type'              => 'string',
					'single'            => true,
					'show_in_rest'      => true,
					'sanitize_callback' => 'esc_url_raw',
					'auth_callback'     => function () {
						return current_user_can( 'manage_categories' );
					},
				)
			);
		}
	}

	/* ------------------------------------------------------------------
	 * Routes
	 * ---------------------------------------------------------------- */

	public static function register_routes() {
		register_rest_route(
			self::NAMESPACE_V1,
			'/yachts',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'list_yachts' ),
					'permission_callback' => '__return_true',
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'create_yacht' ),
					'permission_callback' => array( __CLASS__, 'can_edit' ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/yachts/(?P<id>\d+)',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_yacht' ),
					'permission_callback' => '__return_true',
				),
				array(
					'methods'             => array( 'POST', 'PUT', 'PATCH' ),
					'callback'            => array( __CLASS__, 'update_yacht' ),
					'permission_callback' => array( __CLASS__, 'can_edit' ),
				),
				array(
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => array( __CLASS__, 'delete_yacht' ),
					'permission_callback' => array( __CLASS__, 'can_delete' ),
				),
			)
		);

		// Per-city fleets: each city gets its own endpoint for n8n.
		register_rest_route(
			self::NAMESPACE_V1,
			'/fleets',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'list_fleets' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/marinas',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'list_marinas' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/fleets/(?P<fleet>[a-z0-9-]+)/yachts',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'list_fleet_yachts' ),
					'permission_callback' => '__return_true',
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'create_fleet_yacht' ),
					'permission_callback' => array( __CLASS__, 'can_edit' ),
				),
			)
		);


		register_rest_route(
			self::NAMESPACE_V1,
			'/tickets',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'list_tickets' ),
				'permission_callback' => array( __CLASS__, 'can_read_orders' ),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/bookings',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'list_bookings' ),
				'permission_callback' => array( __CLASS__, 'can_read_orders' ),
			)
		);
	}

	public static function can_edit() {
		return current_user_can( 'edit_posts' );
	}

	public static function can_delete() {
		return current_user_can( 'delete_posts' );
	}

	public static function can_read_orders() {
		return current_user_can( 'edit_shop_orders' ) || current_user_can( 'manage_options' );
	}

	/* ------------------------------------------------------------------
	 * Read
	 * ---------------------------------------------------------------- */

	public static function shape( $yacht_id ) {
		$meta = function ( $key ) use ( $yacht_id ) {
			return get_post_meta( $yacht_id, $key, true );
		};

		$badges = $meta( '_fy_badges' );
		$rows   = $meta( '_fy_pricing' );

		return array(
			'id'               => $yacht_id,
			'title'            => get_the_title( $yacht_id ),
			'status'           => get_post_status( $yacht_id ),
			'size_ft'          => (int) $meta( '_fy_size_ft' ),
			// Effective value: the yacht's own number, or the fleet default.
			'capacity_max'     => FY_Fleet_CPT::capacity( $yacht_id ),
			'special_desc'     => $meta( '_fy_special_desc' ),
			'price'            => (float) $meta( '_fy_price' ),
			'duration_label'   => $meta( '_fy_duration_label' ),
			'price_note'       => $meta( '_fy_price_note' ),
			'year'             => $meta( '_fy_year' ),
			'brand'            => $meta( '_fy_brand' ),
			'model'            => $meta( '_fy_model' ),
			'captain_included' => (bool) $meta( '_fy_captain_included' ),
			'rating'           => $meta( '_fy_rating' ),
			'sku'              => $meta( '_fy_sku' ),
			'source_owner'     => $meta( '_fy_source_owner' ),
			'source_listing_id'=> $meta( '_fy_source_listing_id' ),
			'image_url'        => FY_Fleet_Pricing::yacht_image( $yacht_id ),
			'button_url'       => $meta( '_fy_button_url' ),
			'button_label'     => $meta( '_fy_button_label' ),
			'button_sub'       => $meta( '_fy_button_sub' ),
			'is_pink'          => (bool) $meta( '_fy_is_pink' ),
			'is_free_hour'     => (bool) $meta( '_fy_is_free_hour' ),
			'weekend_surcharge'=> '' === $meta( '_fy_weekend_surcharge' ) ? null : (float) $meta( '_fy_weekend_surcharge' ),
			'crew_rate'        => '' === $meta( '_fy_crew_rate' ) ? null : (float) $meta( '_fy_crew_rate' ),
			'fuel_rate'        => '' === $meta( '_fy_fuel_rate' ) ? null : (float) $meta( '_fy_fuel_rate' ),
			'service_fee'      => '' === $meta( '_fy_service_fee' ) ? null : (float) $meta( '_fy_service_fee' ),
			'blackout_dates'   => $meta( '_fy_blackout_dates' ),
			'disabled_addons'  => is_array( $meta( '_fy_disabled_addons' ) ) ? $meta( '_fy_disabled_addons' ) : array(),
			'custom_addons'    => is_array( $meta( '_fy_custom_addons' ) ) ? $meta( '_fy_custom_addons' ) : array(),
			'gallery_id'       => (int) $meta( '_fy_gallery_id' ),
			'reviews'          => class_exists( 'FY_Fleet_Reviews' ) ? FY_Fleet_Reviews::get( $yacht_id ) : array(),
			'search_terms'     => $meta( '_fy_search_terms' ),
			'badges'           => is_array( $badges ) ? $badges : array(),
			'pricing'          => is_array( $rows ) ? $rows : array(),
			'categories'       => wp_get_object_terms( $yacht_id, 'fy_yacht_cat', array( 'fields' => 'names' ) ),
			'tags'             => wp_get_object_terms( $yacht_id, 'fy_yacht_tag', array( 'fields' => 'names' ) ),
			'marina'           => class_exists( 'FY_Fleet_Marina' ) ? FY_Fleet_Marina::for_yacht( $yacht_id ) : null,
			'seo'              => array(
				'meta_title'        => $meta( '_fy_seo_title' ),
				'meta_description'  => $meta( '_fy_seo_description' ),
				'page_title'        => $meta( '_fy_page_title' ),
				'main_entity'       => $meta( '_fy_main_entity' ),
				'entity_attributes' => $meta( '_fy_entity_attributes' ),
				'focus_keyphrase'   => $meta( '_fy_focus_keyphrase' ),
				'secondary_terms'   => $meta( '_fy_secondary_terms' ),
				'canonical'         => $meta( '_fy_canonical' ),
				'robots'            => $meta( '_fy_robots' ),
				'og_title'          => $meta( '_fy_og_title' ),
				'og_description'    => $meta( '_fy_og_description' ),
				'og_image'          => $meta( '_fy_og_image' ),
				'breadcrumb'        => $meta( '_fy_breadcrumb' ),
				'faq'               => $meta( '_fy_faq' ),
				'content'           => $meta( '_fy_seo_content' ),
			),
			'product_id'       => (int) $meta( '_fy_product_id' ),
			'product_url'      => ( (int) $meta( '_fy_product_id' ) && 'product' === get_post_type( (int) $meta( '_fy_product_id' ) ) ) ? get_permalink( (int) $meta( '_fy_product_id' ) ) : '',
			'edit_url'         => get_edit_post_link( $yacht_id, 'raw' ),
		);
	}

	/** Same "From $…" trip total the fleet cards sort by. */
	private static function sort_amount( $shaped ) {
		$id = isset( $shaped['id'] ) ? (int) $shaped['id'] : 0;
		if ( $id && class_exists( 'FY_Fleet_Pricing' ) ) {
			$from = FY_Fleet_Pricing::display_from_price( $id );
			if ( $from && $from['amount'] > 0 ) {
				return (float) $from['amount'];
			}
		}
		if ( ! empty( $shaped['pricing'] ) && is_array( $shaped['pricing'] ) ) {
			$best = 0.0;
			foreach ( $shaped['pricing'] as $row ) {
				if ( isset( $row['type'] ) && 'price' !== $row['type'] ) {
					continue;
				}
				$amt = isset( $row['price'] ) ? (float) $row['price'] : 0;
				if ( $amt > 0 && ( $best <= 0 || $amt < $best ) ) {
					$best = $amt;
				}
			}
			if ( $best > 0 ) {
				return $best;
			}
		}
		return isset( $shaped['price'] ) ? (float) $shaped['price'] : 0.0;
	}

	public static function list_yachts( $request ) {
		$yachts = get_posts(
			array(
				'post_type'      => FY_Fleet_CPT::POST_TYPE,
				'post_status'    => $request->get_param( 'status' ) ? sanitize_key( $request->get_param( 'status' ) ) : 'publish',
				'posts_per_page' => $request->get_param( 'per_page' ) ? min( 200, max( 1, intval( $request->get_param( 'per_page' ) ) ) ) : 200,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);

		$out = array();
		foreach ( $yachts as $yacht ) {
			$out[] = self::shape( $yacht->ID );
		}

		usort(
			$out,
			function ( $a, $b ) {
				$amt_a = self::sort_amount( $a );
				$amt_b = self::sort_amount( $b );
				if ( ( $amt_a > 0 ) !== ( $amt_b > 0 ) ) {
					return $amt_a > 0 ? -1 : 1;
				}
				if ( $amt_a === $amt_b ) {
					return strcasecmp( $a['title'], $b['title'] );
				}
				return $amt_a <=> $amt_b;
			}
		);

		return rest_ensure_response( $out );
	}

	public static function get_yacht( $request ) {
		$id = intval( $request['id'] );
		if ( FY_Fleet_CPT::POST_TYPE !== get_post_type( $id ) ) {
			return new WP_Error( 'fy_not_found', __( 'Yacht not found.', 'fy-fleet' ), array( 'status' => 404 ) );
		}
		return rest_ensure_response( self::shape( $id ) );
	}

	/* ------------------------------------------------------------------
	 * Write
	 * ---------------------------------------------------------------- */

	public static function create_yacht( $request ) {
		$params = $request->get_json_params();
		if ( ! is_array( $params ) ) {
			$params = $request->get_params();
		}

		$title = isset( $params['title'] ) ? sanitize_text_field( $params['title'] ) : '';
		if ( '' === $title ) {
			return new WP_Error( 'fy_missing_title', __( 'A title is required.', 'fy-fleet' ), array( 'status' => 400 ) );
		}

		$post_id = wp_insert_post(
			array(
				'post_type'   => FY_Fleet_CPT::POST_TYPE,
				'post_title'  => $title,
				'post_status' => isset( $params['status'] ) ? sanitize_key( $params['status'] ) : 'publish',
			),
			true
		);

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		self::apply( $post_id, $params );

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'api.create', sprintf( 'Created yacht "%s" (#%d)', $title, $post_id ), array( 'fields' => array_keys( $params ) ) );
		}

		return rest_ensure_response( self::shape( $post_id ) );
	}

	public static function update_yacht( $request ) {
		$id = intval( $request['id'] );
		if ( FY_Fleet_CPT::POST_TYPE !== get_post_type( $id ) ) {
			return new WP_Error( 'fy_not_found', __( 'Yacht not found.', 'fy-fleet' ), array( 'status' => 404 ) );
		}

		$params = $request->get_json_params();
		if ( ! is_array( $params ) ) {
			$params = $request->get_params();
		}

		$post_update = array( 'ID' => $id );
		if ( isset( $params['title'] ) && '' !== trim( $params['title'] ) ) {
			$post_update['post_title'] = sanitize_text_field( $params['title'] );
		}
		if ( isset( $params['status'] ) ) {
			$post_update['post_status'] = sanitize_key( $params['status'] );
		}
		if ( count( $post_update ) > 1 ) {
			wp_update_post( $post_update );
		}

		self::apply( $id, $params );

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'api.update', sprintf( 'Updated yacht "%s" (#%d)', get_the_title( $id ), $id ), array( 'fields' => array_keys( $params ) ) );
		}

		return rest_ensure_response( self::shape( $id ) );
	}

	public static function delete_yacht( $request ) {
		$id = intval( $request['id'] );
		if ( FY_Fleet_CPT::POST_TYPE !== get_post_type( $id ) ) {
			return new WP_Error( 'fy_not_found', __( 'Yacht not found.', 'fy-fleet' ), array( 'status' => 404 ) );
		}
		$title = get_the_title( $id );
		wp_trash_post( $id );

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'api.delete', sprintf( 'Trashed yacht "%s" (#%d)', $title, $id ) );
		}

		return rest_ensure_response( array( 'deleted' => true, 'id' => $id ) );
	}

	/** Map an incoming payload onto post meta. Only supplied keys are touched. */
	private static function apply( $post_id, $params ) {
		$simple = array(
			'size_ft'        => array( '_fy_size_ft', 'int' ),
			'capacity_max'   => array( '_fy_capacity_max', 'int_or_blank' ),
			'price'          => array( '_fy_price', 'float' ),
			'duration_label' => array( '_fy_duration_label', 'text' ),
			'price_note'     => array( '_fy_price_note', 'text' ),
			'image_url'      => array( '_fy_image_url', 'url' ),
			'button_url'     => array( '_fy_button_url', 'url' ),
			'button_label'   => array( '_fy_button_label', 'text' ),
			'button_sub'     => array( '_fy_button_sub', 'text' ),
			'search_terms'   => array( '_fy_search_terms', 'textarea' ),
			'weekend_surcharge' => array( '_fy_weekend_surcharge', 'float_or_blank' ),
			'crew_rate'      => array( '_fy_crew_rate', 'float_or_blank' ),
			'fuel_rate'      => array( '_fy_fuel_rate', 'float_or_blank' ),
			'service_fee'    => array( '_fy_service_fee', 'float_or_blank' ),
			'brand'          => array( '_fy_brand', 'text' ),
			'model'          => array( '_fy_model', 'text' ),
			'sku'            => array( '_fy_sku', 'text' ),
			'source_owner'   => array( '_fy_source_owner', 'text' ),
			'source_listing_id' => array( '_fy_source_listing_id', 'text' ),
			'year'           => array( '_fy_year', 'int_or_blank' ),
		);

		foreach ( $simple as $param => $config ) {
			if ( ! array_key_exists( $param, $params ) ) {
				continue;
			}
			list( $meta_key, $type ) = $config;
			$value = $params[ $param ];

			switch ( $type ) {
				case 'int':
					$value = intval( $value );
					break;
				case 'int_or_blank':
					$value = ( '' === $value || null === $value ) ? '' : intval( $value );
					break;
				case 'float':
					$value = floatval( $value );
					break;
				case 'float_or_blank':
					$value = ( '' === $value || null === $value ) ? '' : floatval( $value );
					break;
				case 'url':
					$value = esc_url_raw( $value );
					break;
				case 'textarea':
					$value = sanitize_textarea_field( $value );
					break;
				default:
					$value = sanitize_text_field( $value );
			}
			update_post_meta( $post_id, $meta_key, $value );
		}

		if ( array_key_exists( 'special_desc', $params ) ) {
			update_post_meta( $post_id, '_fy_special_desc', wp_kses_post( $params['special_desc'] ) );
		}

		if ( array_key_exists( 'rating', $params ) ) {
			$rating = $params['rating'];
			update_post_meta( $post_id, '_fy_rating', ( '' === $rating || null === $rating ) ? '' : max( 0, min( 5, floatval( $rating ) ) ) );
		}

		if ( array_key_exists( 'blackout_dates', $params ) ) {
			$dates = array();
			$raw   = is_array( $params['blackout_dates'] ) ? $params['blackout_dates'] : preg_split( '/\r\n|\r|\n|,/', (string) $params['blackout_dates'] );
			foreach ( $raw as $date ) {
				$date = trim( (string) $date );
				if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
					$dates[] = $date;
				}
			}
			update_post_meta( $post_id, '_fy_blackout_dates', implode( "\n", array_unique( $dates ) ) );
		}

		if ( array_key_exists( 'disabled_addons', $params ) && is_array( $params['disabled_addons'] ) ) {
			update_post_meta( $post_id, '_fy_disabled_addons', array_map( 'sanitize_text_field', $params['disabled_addons'] ) );
		}

		if ( array_key_exists( 'custom_addons', $params ) && is_array( $params['custom_addons'] ) ) {
			$custom = array();
			foreach ( $params['custom_addons'] as $addon ) {
				$label = isset( $addon['label'] ) ? sanitize_text_field( $addon['label'] ) : '';
				if ( '' === $label ) {
					continue;
				}
				$custom[] = array(
					'label' => $label,
					'price' => isset( $addon['price'] ) ? floatval( $addon['price'] ) : 0,
					'unit'  => ( isset( $addon['unit'] ) && 'hour' === $addon['unit'] ) ? 'hour' : 'flat',
					'max'   => ( isset( $addon['max'] ) && intval( $addon['max'] ) > 0 ) ? intval( $addon['max'] ) : 1,
					'note'  => isset( $addon['note'] ) ? sanitize_text_field( $addon['note'] ) : '',
				);
			}
			update_post_meta( $post_id, '_fy_custom_addons', $custom );
		}

		if ( array_key_exists( 'gallery_id', $params ) ) {
			$gallery_id = intval( $params['gallery_id'] );
			update_post_meta( $post_id, '_fy_gallery_id', ( $gallery_id && 'fy_gallery' === get_post_type( $gallery_id ) ) ? $gallery_id : 0 );
		}

		if ( array_key_exists( 'reviews', $params ) && is_array( $params['reviews'] ) ) {
			$reviews = array();
			foreach ( $params['reviews'] as $review ) {
				$text = isset( $review['text'] ) ? sanitize_textarea_field( $review['text'] ) : '';
				$name = isset( $review['name'] ) ? sanitize_text_field( $review['name'] ) : '';
				if ( '' === $text && '' === $name ) {
					continue;
				}
				$date      = isset( $review['date'] ) ? sanitize_text_field( $review['date'] ) : '';
				$reviews[] = array(
					'name'   => $name,
					'rating' => max( 1, min( 5, intval( isset( $review['rating'] ) ? $review['rating'] : 5 ) ) ),
					'date'   => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ? $date : '',
					'text'   => $text,
				);
			}
			update_post_meta( $post_id, '_fy_reviews', $reviews );
		}

		foreach ( array( 'is_pink' => '_fy_is_pink', 'is_free_hour' => '_fy_is_free_hour', 'captain_included' => '_fy_captain_included' ) as $param => $meta_key ) {
			if ( array_key_exists( $param, $params ) ) {
				update_post_meta( $post_id, $meta_key, ! empty( $params[ $param ] ) ? '1' : '' );
			}
		}

		if ( isset( $params['badges'] ) && is_array( $params['badges'] ) ) {
			$badges = array();
			foreach ( $params['badges'] as $badge ) {
				$text = isset( $badge['text'] ) ? sanitize_text_field( $badge['text'] ) : '';
				if ( '' === $text ) {
					continue;
				}
				$style = isset( $badge['style'] ) ? sanitize_key( $badge['style'] ) : 'hot';
				if ( ! in_array( $style, array( 'hot', 'pink', 'free', 'commercial', 'size' ), true ) ) {
					$style = 'hot';
				}
				$badges[] = array( 'text' => $text, 'style' => $style );
			}
			update_post_meta( $post_id, '_fy_badges', $badges );
		}

		if ( isset( $params['pricing'] ) && is_array( $params['pricing'] ) ) {
			$rows = array();
			foreach ( $params['pricing'] as $row ) {
				$type = isset( $row['type'] ) ? sanitize_key( $row['type'] ) : 'price';
				if ( 'heading' === $type || 'note' === $type ) {
					$text = isset( $row['text'] ) ? sanitize_text_field( $row['text'] ) : '';
					if ( '' === $text ) {
						continue;
					}
					$rows[] = array( 'type' => $type, 'text' => $text );
				} else {
					$duration = isset( $row['duration'] ) ? sanitize_text_field( $row['duration'] ) : '';
					if ( '' === $duration ) {
						continue;
					}
					$rows[] = array(
						'type'     => 'price',
						'duration' => $duration,
						'price'    => isset( $row['price'] ) ? floatval( $row['price'] ) : 0,
						'free'     => ! empty( $row['free'] ) ? '1' : '',
					);
				}
			}
			update_post_meta( $post_id, '_fy_pricing', $rows );
		}

		// SEO block.
		if ( isset( $params['seo'] ) && is_array( $params['seo'] ) ) {
			$seo_map = array(
				'meta_title'        => '_fy_seo_title',
				'meta_description'  => '_fy_seo_description',
				'page_title'        => '_fy_page_title',
				'main_entity'       => '_fy_main_entity',
				'entity_attributes' => '_fy_entity_attributes',
				'focus_keyphrase'   => '_fy_focus_keyphrase',
				'secondary_terms'   => '_fy_secondary_terms',
				'robots'            => '_fy_robots',
				'og_title'          => '_fy_og_title',
				'og_description'    => '_fy_og_description',
				'breadcrumb'        => '_fy_breadcrumb',
				'faq'               => '_fy_faq',
				'content'           => '_fy_seo_content',
			);
			foreach ( $seo_map as $param => $meta_key ) {
				if ( array_key_exists( $param, $params['seo'] ) ) {
					update_post_meta( $post_id, $meta_key, sanitize_textarea_field( $params['seo'][ $param ] ) );
				}
			}
			foreach ( array( 'canonical' => '_fy_canonical', 'og_image' => '_fy_og_image' ) as $param => $meta_key ) {
				if ( array_key_exists( $param, $params['seo'] ) ) {
					update_post_meta( $post_id, $meta_key, esc_url_raw( $params['seo'][ $param ] ) );
				}
			}
		}

		// Marina.
		if ( isset( $params['marina'] ) && is_array( $params['marina'] ) ) {
			$marina_map = array(
				'source' => '_fy_marina_source',
				'title'  => '_fy_marina_title',
				'lat'    => '_fy_marina_lat',
				'lng'    => '_fy_marina_lng',
				'note'   => '_fy_marina_note',
			);
			foreach ( $marina_map as $param => $meta_key ) {
				if ( array_key_exists( $param, $params['marina'] ) ) {
					update_post_meta( $post_id, $meta_key, sanitize_text_field( $params['marina'][ $param ] ) );
				}
			}
			if ( array_key_exists( 'embed', $params['marina'] ) ) {
				update_post_meta( $post_id, '_fy_marina_embed', esc_url_raw( $params['marina']['embed'] ) );
			}
		}

		// Taxonomies.
		if ( isset( $params['categories'] ) && is_array( $params['categories'] ) ) {
			wp_set_object_terms( $post_id, array_map( 'sanitize_text_field', $params['categories'] ), 'fy_yacht_cat', false );
		}
		if ( isset( $params['tags'] ) && is_array( $params['tags'] ) ) {
			wp_set_object_terms( $post_id, array_map( 'sanitize_text_field', $params['tags'] ), 'fy_yacht_tag', false );
		}

		// Same zero-click defaults as the admin editor (button URL, featured
		// image), then keep the WooCommerce product in step.
		if ( class_exists( 'FY_Fleet_Woo' ) && FY_Fleet_Woo::active() ) {
			FY_Fleet_Woo::fill_defaults( $post_id );
			FY_Fleet_Woo::sync_product( $post_id );
		}
	}

	/* ------------------------------------------------------------------
	 * Marinas & bookings
	 * ---------------------------------------------------------------- */

	/** All fleets (yacht categories) with slugs for the per-city endpoints. */
	public static function list_fleets() {
		$terms = get_terms( array( 'taxonomy' => 'fy_yacht_cat', 'hide_empty' => false ) );
		if ( is_wp_error( $terms ) ) {
			return rest_ensure_response( array() );
		}
		$out = array();
		foreach ( $terms as $term ) {
			$out[] = array(
				'slug'       => $term->slug,
				'name'       => $term->name,
				'count'      => (int) $term->count,
				'yachts_url' => rest_url( self::NAMESPACE_V1 . '/fleets/' . $term->slug . '/yachts' ),
			);
		}
		return rest_ensure_response( $out );
	}

	public static function list_fleet_yachts( $request ) {
		$slug = sanitize_key( $request['fleet'] );

		$yachts = get_posts(
			array(
				'post_type'      => FY_Fleet_CPT::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => min( 200, intval( $request->get_param( 'per_page' ) ) ?: 200 ),
				'tax_query'      => array(
					array(
						'taxonomy' => 'fy_yacht_cat',
						'field'    => 'slug',
						'terms'    => $slug,
					),
				),
			)
		);

		$out = array();
		foreach ( $yachts as $yacht ) {
			$out[] = self::shape( $yacht->ID );
		}
		return rest_ensure_response( $out );
	}

	/**
	 * Create a yacht inside a specific fleet. The fleet term is created on the
	 * fly if it does not exist yet, so a new city needs no manual setup.
	 */
	public static function create_fleet_yacht( $request ) {
		$slug = sanitize_key( $request['fleet'] );

		$term = get_term_by( 'slug', $slug, 'fy_yacht_cat' );
		if ( ! $term ) {
			$created = wp_insert_term( ucwords( str_replace( '-', ' ', $slug ) ), 'fy_yacht_cat', array( 'slug' => $slug ) );
			if ( is_wp_error( $created ) ) {
				return $created;
			}
			$term = get_term( $created['term_id'], 'fy_yacht_cat' );
		}

		$response = self::create_yacht( $request );
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$data = $response->get_data();
		if ( ! empty( $data['id'] ) ) {
			wp_set_object_terms( $data['id'], array( (int) $term->term_id ), 'fy_yacht_cat', true );
			$data['categories'] = wp_get_object_terms( $data['id'], 'fy_yacht_cat', array( 'fields' => 'names' ) );
			$response->set_data( $data );
		}
		return $response;
	}

	public static function list_marinas() {
		if ( ! class_exists( 'FY_Fleet_Marina' ) ) {
			return rest_ensure_response( array() );
		}
		return rest_ensure_response( array_values( FY_Fleet_Marina::library() ) );
	}

	/** Tickets with full reply threads, newest first — for n8n → GHL sync. */
	public static function list_tickets( $request ) {
		if ( ! class_exists( 'FY_Fleet_Tickets' ) ) {
			return rest_ensure_response( array() );
		}

		$tickets = get_posts(
			array(
				'post_type'      => FY_Fleet_Tickets::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => min( 200, max( 1, intval( $request->get_param( 'per_page' ) ? $request->get_param( 'per_page' ) : 100 ) ) ),
			)
		);

		$out = array();
		foreach ( $tickets as $ticket ) {
			$replies = array();
			foreach ( FY_Fleet_Tickets::get_replies( $ticket->ID ) as $reply ) {
				$replies[] = array(
					'from'     => '1' === get_comment_meta( $reply->comment_ID, '_fy_is_staff', true ) ? 'staff' : 'customer',
					'author'   => $reply->comment_author,
					'message'  => wp_strip_all_tags( $reply->comment_content ),
					'date_gmt' => $reply->comment_date_gmt,
				);
			}
			$out[] = array(
				'id'         => $ticket->ID,
				'subject'    => $ticket->post_title,
				'department' => get_post_meta( $ticket->ID, '_fy_department', true ),
				'status'     => get_post_meta( $ticket->ID, '_fy_status', true ),
				'customer'   => array(
					'name'  => get_post_meta( $ticket->ID, '_fy_customer_name', true ),
					'email' => get_post_meta( $ticket->ID, '_fy_customer_email', true ),
				),
				'order_id'   => (int) get_post_meta( $ticket->ID, '_fy_order_id', true ),
				'created'    => $ticket->post_date_gmt,
				'replies'    => $replies,
			);
		}
		return rest_ensure_response( $out );
	}

	public static function list_bookings( $request ) {
		$from = $request->get_param( 'from' ) ? sanitize_text_field( $request->get_param( 'from' ) ) : '';
		$to   = $request->get_param( 'to' ) ? sanitize_text_field( $request->get_param( 'to' ) ) : '';
		return rest_ensure_response( FY_Fleet_Bookings_Admin::get_bookings( $from, $to ) );
	}
}
