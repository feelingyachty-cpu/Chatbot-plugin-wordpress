<?php
// AUTO-GENERATED — 2026-08-10 marina audit. Each entry: a marina whose
// imported coordinates were verified wrong (>1 km from the street
// address, confirmed via OpenStreetMap geocoding), and where it really
// is. Keyed by the marina title lowercased with everything but
// letters/digits stripped — FY_Fleet_Marina::normalize_title() must
// produce the same key. Generic titles ("MIAMI RIVER") are deliberately
// absent: a geocoder's guess for those is not a dock.
if ( ! defined( 'ABSPATH' ) ) { exit; }
return array(
	'1354bayviewdrfortlauderdalefl33304' => array( 'label' => '1354 Bayview Dr, Fort Lauderdale, FL 33304', 'lat' => '26.1445', 'lng' => '-80.1116' ),
	'1631nwsouthriverdrmiamifl33125unitedstates' => array( 'label' => '1631 NW South River Dr, Miami, FL 33125, United States', 'lat' => '25.7843', 'lng' => '-80.2221' ),
	'1675nwsriverdrmiamifl33125' => array( 'label' => '1675 NW S River Dr, Miami, FL 33125', 'lat' => '25.7845', 'lng' => '-80.2226' ),
	'201nwsouthriverdrmiamifl33128' => array( 'label' => '201 NW South River Dr Miami Fl 33128', 'lat' => '25.7761', 'lng' => '-80.2039' ),
	'2118noceandrhollywoodfl33019' => array( 'label' => '2118 N Ocean Dr Hollywood, FL 33019', 'lat' => '26.0247', 'lng' => '-80.1166' ),
	'2145nw32ndavemiamifl33142' => array( 'label' => '2145 NW 32nd Ave Miami FL 33142', 'lat' => '25.7954', 'lng' => '-80.2471' ),
	'2147nw32ndavemiamifl33142' => array( 'label' => '2147 NW 32nd Ave, Miami, FL 33142', 'lat' => '25.7958', 'lng' => '-80.2468' ),
	'2215nw14thstmiamifl33125' => array( 'label' => '2215 NW 14th St, Miami, FL 33125', 'lat' => '25.7877', 'lng' => '-80.2321' ),
	'2215nw14thstmiamifl33125usa' => array( 'label' => '2215 NW 14th St, Miami, FL 33125, USA', 'lat' => '25.7877', 'lng' => '-80.2321' ),
	'2215nw14thstreet' => array( 'label' => '2215 NW 14TH Street', 'lat' => '25.7877', 'lng' => '-80.2321' ),
	'2215nw14thstreetmiamifl33125' => array( 'label' => '2215 NW 14th Street Miami Fl 33125', 'lat' => '25.7877', 'lng' => '-80.2321' ),
	'2550sbayshoredrmiamifl33133unitedstates' => array( 'label' => '2550 S Bayshore Dr, Miami, FL 33133, United States', 'lat' => '25.7321', 'lng' => '-80.2324' ),
	'300altonrdmiamibeachfl33139' => array( 'label' => '300 Alton Rd, Miami Beach, FL 33139', 'lat' => '25.7727', 'lng' => '-80.1403' ),
	'300altonrdmiamifl33139' => array( 'label' => '300 Alton Rd, Miami, FL 33139', 'lat' => '25.7727', 'lng' => '-80.1403' ),
	'300altonroadmiamibeachfl33139' => array( 'label' => '300 Alton Road, Miami Beach, FL 33139', 'lat' => '25.7709', 'lng' => '-80.1406' ),
	'3350nw21ststmiamifl33142' => array( 'label' => '3350 NW 21st st Miami, FL 33142', 'lat' => '25.7950', 'lng' => '-80.2509' ),
	'3399nwsriverdr' => array( 'label' => '3399 NW S River Dr', 'lat' => '25.7999', 'lng' => '-80.2509' ),
	'3480nw21stst' => array( 'label' => '3480 NW 21st St', 'lat' => '25.7949', 'lng' => '-80.2518' ),
	'3480nw21ststmiami33142' => array( 'label' => '3480 nw 21st st, Miami, 33142', 'lat' => '25.7949', 'lng' => '-80.2518' ),
	'3480nw21ststmiamifl33142' => array( 'label' => '3480 NW 21st St, Miami, FL 33142', 'lat' => '25.7949', 'lng' => '-80.2518' ),
	'3660nw21stst' => array( 'label' => '3660 NW 21st St', 'lat' => '25.7947', 'lng' => '-80.2549' ),
	'3660nw21ststmiamifl33142' => array( 'label' => '3660 NW 21st St Miami, FL 33142', 'lat' => '25.7947', 'lng' => '-80.2549' ),
	'3660nw21ststmiamiflorida33142' => array( 'label' => '3660 Nw 21st St Miami Florida 33142', 'lat' => '25.7947', 'lng' => '-80.2549' ),
	'401biscayneblvdmiamifl33132' => array( 'label' => '401 Biscayne Blvd, Miami FL 33132', 'lat' => '25.7775', 'lng' => '-80.1845' ),
	'555nwsouthriverdr' => array( 'label' => '555 NW South River Dr', 'lat' => '25.7802', 'lng' => '-80.2106' ),
	'961nw7thstmiamifl33136' => array( 'label' => '961 NW 7th St, Miami, FL 33136', 'lat' => '25.7806', 'lng' => '-80.2110' ),
	'billbirdmarina' => array( 'label' => 'Bill Bird Marina', 'lat' => '25.9059', 'lng' => '-80.1252' ),
	'billbirdmarina10800collinsavemiamibeachfl33154' => array( 'label' => 'Bill Bird Marina, 10800 Collins Ave, Miami Beach FL 33154', 'lat' => '25.9059', 'lng' => '-80.1252' ),
	'fontainebleau' => array( 'label' => 'Fontainebleau', 'lat' => '25.8181', 'lng' => '-80.1220' ),
	'marinapalms' => array( 'label' => 'Marina Palms', 'lat' => '25.9350', 'lng' => '-80.1503' ),
	'miamibeachmarina' => array( 'label' => 'Miami Beach Marina', 'lat' => '25.7709', 'lng' => '-80.1406' ),
	'miamibeachmarina300altonrdmiamifl33139' => array( 'label' => 'Miami Beach Marina, 300 Alton Rd, Miami, FL 33139', 'lat' => '25.7709', 'lng' => '-80.1406' ),
	'rickenbackermarina' => array( 'label' => 'Rickenbacker Marina', 'lat' => '25.7468', 'lng' => '-80.1758' ),
);
