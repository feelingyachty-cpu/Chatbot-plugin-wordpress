<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Payments hub.
 *
 * Card/Apple Pay/PayPal processing is deliberately NOT re-implemented here —
 * that is PCI-sensitive ground owned by the official, audited WooCommerce
 * gateway plugins. This screen makes them part of the suite: detect, install,
 * activate and configure Stripe and PayPal from one place, and show exactly
 * which payment methods customers currently see at checkout.
 */
class FY_Fleet_Payments {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
	}

	public static function add_menu() {
		add_submenu_page(
			'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE,
			__( 'Payments', 'fy-fleet' ),
			__( 'Payments', 'fy-fleet' ),
			'manage_options',
			'fy-fleet-payments',
			array( __CLASS__, 'render_page' )
		);
	}

	/** The two gateways the fleet runs on. */
	public static function gateways() {
		return array(
			'stripe' => array(
				'name'       => 'Stripe (cards, Apple Pay, Google Pay)',
				'slug'       => 'woocommerce-gateway-stripe',
				'file'       => 'woocommerce-gateway-stripe/woocommerce-gateway-stripe.php',
				'gateway_id' => 'stripe',
				'section'    => 'stripe',
			),
			'paypal' => array(
				'name'       => 'PayPal (PayPal, Venmo, Pay Later)',
				'slug'       => 'woocommerce-paypal-payments',
				'file'       => 'woocommerce-paypal-payments/woocommerce-paypal-payments.php',
				'gateway_id' => 'ppcp-gateway',
				'section'    => 'ppcp-gateway',
			),
		);
	}

	private static function status( $gateway ) {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			include_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$installed = file_exists( WP_PLUGIN_DIR . '/' . $gateway['file'] );
		$active    = $installed && is_plugin_active( $gateway['file'] );

		$enabled = false;
		if ( $active && function_exists( 'WC' ) && WC()->payment_gateways() ) {
			$all = WC()->payment_gateways()->payment_gateways();
			if ( isset( $all[ $gateway['gateway_id'] ] ) && 'yes' === $all[ $gateway['gateway_id'] ]->enabled ) {
				$enabled = true;
			}
		}

		return array( 'installed' => $installed, 'active' => $active, 'enabled' => $enabled );
	}

	public static function render_page() {
		if ( ! FY_Fleet_Woo::active() ) {
			echo '<div class="wrap"><h1>' . esc_html__( 'Payments', 'fy-fleet' ) . '</h1><div class="notice notice-error"><p>' . esc_html__( 'WooCommerce must be active first.', 'fy-fleet' ) . '</p></div></div>';
			return;
		}
		?>
		<div class="wrap" style="max-width:980px">
			<h1>💳 <?php esc_html_e( 'Payments', 'fy-fleet' ); ?></h1>
			<p class="description" style="max-width:860px">
				<?php esc_html_e( 'Deposits are charged through WooCommerce checkout using the official Stripe and PayPal gateways — fully PCI-compliant, built and audited by Stripe/PayPal themselves. Set both up here; once a gateway shows three green checks, customers see it at checkout.', 'fy-fleet' ); ?>
			</p>

			<?php foreach ( self::gateways() as $gateway ) : ?>
				<?php $status = self::status( $gateway ); ?>
				<div style="background:#fff;border:1px solid #dcdcde;border-left:5px solid <?php echo $status['enabled'] ? '#00a32a' : '#dba617'; ?>;border-radius:8px;padding:16px 20px;margin:14px 0">
					<h2 style="margin:0 0 10px"><?php echo esc_html( $gateway['name'] ); ?></h2>
					<p style="margin:0 0 12px">
						<?php echo $status['installed'] ? '✅' : '❌'; ?> <?php esc_html_e( 'Installed', 'fy-fleet' ); ?> &nbsp;·&nbsp;
						<?php echo $status['active'] ? '✅' : '❌'; ?> <?php esc_html_e( 'Activated', 'fy-fleet' ); ?> &nbsp;·&nbsp;
						<?php echo $status['enabled'] ? '✅' : '❌'; ?> <?php esc_html_e( 'Enabled at checkout', 'fy-fleet' ); ?>
					</p>
					<p style="margin:0;display:flex;gap:8px;flex-wrap:wrap">
						<?php if ( ! $status['installed'] && current_user_can( 'install_plugins' ) ) : ?>
							<a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=' . $gateway['slug'] ), 'install-plugin_' . $gateway['slug'] ) ); ?>">
								<?php esc_html_e( 'Install now (free, from WordPress.org)', 'fy-fleet' ); ?>
							</a>
						<?php elseif ( ! $status['active'] && current_user_can( 'activate_plugins' ) ) : ?>
							<a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( self_admin_url( 'plugins.php?action=activate&plugin=' . $gateway['file'] ), 'activate-plugin_' . $gateway['file'] ) ); ?>">
								<?php esc_html_e( 'Activate', 'fy-fleet' ); ?>
							</a>
						<?php else : ?>
							<a class="button <?php echo $status['enabled'] ? '' : 'button-primary'; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . $gateway['section'] ) ); ?>">
								<?php echo $status['enabled'] ? esc_html__( 'Open settings', 'fy-fleet' ) : esc_html__( 'Connect account & enable', 'fy-fleet' ); ?>
							</a>
						<?php endif; ?>
					</p>
				</div>
			<?php endforeach; ?>

			<?php if ( isset( $_GET['fy_synced'] ) ) : ?>
				<div class="notice notice-success inline"><p><?php printf( esc_html__( '%d yacht products re-synced.', 'fy-fleet' ), intval( $_GET['fy_synced'] ) ); ?></p></div>
			<?php endif; ?>
			<h2><?php esc_html_e( 'Yacht products', 'fy-fleet' ); ?></h2>
			<p>
				<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=fy_sync_products' ), 'fy_sync_products' ) ); ?>">
					🔄 <?php esc_html_e( 'Re-sync all yacht products', 'fy-fleet' ); ?>
				</a>
			</p>
			<p class="description"><?php esc_html_e( 'One click updates every yacht from its latest info: fills missing button URLs, imports missing featured images, refreshes deposit prices and the stored descriptions. Product pages already render live, so this is for the stored copies and images. Importing many photos is capped at ~20 seconds per run — just click again to continue where it left off.', 'fy-fleet' ); ?></p>

			<h2><?php esc_html_e( 'What customers currently see at checkout', 'fy-fleet' ); ?></h2>
			<?php
			$available = WC()->payment_gateways() ? WC()->payment_gateways()->get_available_payment_gateways() : array();
			if ( empty( $available ) ) {
				echo '<div class="notice notice-error inline"><p><strong>' . esc_html__( 'No payment methods are enabled — customers cannot pay!', 'fy-fleet' ) . '</strong> ' . esc_html__( 'Finish the setup above.', 'fy-fleet' ) . '</p></div>';
			} else {
				echo '<ul style="list-style:disc;padding-left:22px">';
				foreach ( $available as $available_gateway ) {
					echo '<li><strong>' . esc_html( $available_gateway->get_title() ) . '</strong></li>';
				}
				echo '</ul>';
			}
			?>
			<p class="description"><?php esc_html_e( 'Test the full flow with Stripe test mode (card 4242 4242 4242 4242) before going live.', 'fy-fleet' ); ?></p>
		</div>
		<?php
	}
}
