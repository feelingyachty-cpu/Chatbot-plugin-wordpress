<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class FY_Fleet_Metaboxes {

	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_boxes' ) );
		add_action( 'save_post_' . FY_Fleet_CPT::POST_TYPE, array( __CLASS__, 'save' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
	}

	public static function enqueue( $hook ) {
		global $post_type;
		if ( FY_Fleet_CPT::POST_TYPE !== $post_type ) {
			return;
		}
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'fy-fleet-admin', FY_FLEET_URL . 'assets/admin.css', array(), FY_FLEET_VERSION );
		wp_enqueue_script( 'fy-fleet-admin', FY_FLEET_URL . 'assets/admin.js', array( 'jquery', 'jquery-ui-sortable' ), FY_FLEET_VERSION, true );
	}

	public static function add_boxes() {
		add_meta_box( 'fy_summary', __( 'Card Summary (top of card)', 'fy-fleet' ), array( __CLASS__, 'render_summary' ), FY_Fleet_CPT::POST_TYPE, 'normal', 'high' );
		add_meta_box( 'fy_badges', __( 'Badges', 'fy-fleet' ), array( __CLASS__, 'render_badges' ), FY_Fleet_CPT::POST_TYPE, 'normal', 'default' );
		add_meta_box( 'fy_pricing', __( 'Hours & Pricing', 'fy-fleet' ), array( __CLASS__, 'render_pricing' ), FY_Fleet_CPT::POST_TYPE, 'normal', 'default' );
		add_meta_box( 'fy_gallery_images', __( 'Gallery', 'fy-fleet' ), array( __CLASS__, 'render_gallery_images' ), FY_Fleet_CPT::POST_TYPE, 'normal', 'default' );
		add_meta_box( 'fy_image', __( 'Card Photo', 'fy-fleet' ), array( __CLASS__, 'render_image' ), FY_Fleet_CPT::POST_TYPE, 'side', 'high' );
		add_meta_box( 'fy_cta', __( 'Button / Booking Link', 'fy-fleet' ), array( __CLASS__, 'render_cta' ), FY_Fleet_CPT::POST_TYPE, 'side', 'default' );
		add_meta_box( 'fy_search', __( 'Extra Search Keywords', 'fy-fleet' ), array( __CLASS__, 'render_search' ), FY_Fleet_CPT::POST_TYPE, 'side', 'low' );
		add_meta_box( 'fy_booking_opts', __( 'Booking Options', 'fy-fleet' ), array( __CLASS__, 'render_booking_options' ), FY_Fleet_CPT::POST_TYPE, 'normal', 'default' );
		add_meta_box( 'fy_reference', __( 'Internal Reference (not shown on site)', 'fy-fleet' ), array( __CLASS__, 'render_reference' ), FY_Fleet_CPT::POST_TYPE, 'side', 'low' );
	}

	private static function nonce_field() {
		wp_nonce_field( 'fy_fleet_save', 'fy_fleet_nonce' );
	}

	public static function render_summary( $post ) {
		self::nonce_field();
		$size     = get_post_meta( $post->ID, '_fy_size_ft', true );
		$capacity = get_post_meta( $post->ID, '_fy_capacity_max', true );
		$price    = get_post_meta( $post->ID, '_fy_price', true );
		$duration = get_post_meta( $post->ID, '_fy_duration_label', true );
		$note     = get_post_meta( $post->ID, '_fy_price_note', true );
		$is_pink  = get_post_meta( $post->ID, '_fy_is_pink', true );
		$is_free  = get_post_meta( $post->ID, '_fy_is_free_hour', true );
		$year     = get_post_meta( $post->ID, '_fy_year', true );
		$model    = get_post_meta( $post->ID, '_fy_model', true );
		$brand    = get_post_meta( $post->ID, '_fy_brand', true );
		$captain  = get_post_meta( $post->ID, '_fy_captain_included', true );
		$rating   = get_post_meta( $post->ID, '_fy_rating', true );
		?>
		<table class="form-table fy-form-table">
			<tr>
				<th><label for="fy_size_ft"><?php esc_html_e( 'Size (feet)', 'fy-fleet' ); ?> *</label></th>
				<td><input type="number" min="1" step="1" id="fy_size_ft" name="fy_size_ft" value="<?php echo esc_attr( $size ); ?>" class="small-text">
				<p class="description"><?php esc_html_e( 'Drives automatic size ordering and the size filter buckets (Under 40ft, 40-49ft, 50-59ft, 60-69ft, 70ft+).', 'fy-fleet' ); ?></p></td>
			</tr>
			<tr>
				<th><label for="fy_capacity_max"><?php esc_html_e( 'Max Guests', 'fy-fleet' ); ?></label></th>
				<td><input type="number" min="0" step="1" id="fy_capacity_max" name="fy_capacity_max" value="<?php echo esc_attr( $capacity ); ?>" class="small-text" placeholder="<?php echo esc_attr( FY_Fleet_CPT::DEFAULT_CAPACITY ); ?>">
				<p class="description">
					<?php
					printf(
						/* translators: %d: fleet-wide default guest capacity */
						esc_html__( 'Shown on the yacht card and product page. Leave blank to use the fleet default of %d guests; enter 0 to hide it on this yacht only.', 'fy-fleet' ),
						(int) FY_Fleet_CPT::DEFAULT_CAPACITY
					);
					?>
				</p></td>
			</tr>
			<tr>
				<th><label for="fy_price"><?php esc_html_e( 'Starting Price ($)', 'fy-fleet' ); ?> *</label></th>
				<td><input type="number" min="0" step="0.01" id="fy_price" name="fy_price" value="<?php echo esc_attr( $price ); ?>" class="small-text">
				<p class="description"><?php esc_html_e( 'Used for the "From $..." price, price sorting, and the "Under $1,400" filter.', 'fy-fleet' ); ?>
				<?php
				// The public "per hour" wording is derived from this value vs the
				// Hours & Pricing rows — tell the editor which reading applies.
				if ( class_exists( 'FY_Fleet_Pricing' ) && FY_Fleet_Pricing::starting_price_is_hourly( $post->ID ) ) {
					echo ' <strong>' . esc_html__( 'This yacht\'s rows make this a PER-HOUR rate, so the site shows "per hour".', 'fy-fleet' ) . '</strong>';
				} else {
					echo ' <strong>' . esc_html__( 'This yacht\'s rows make this a whole-charter price, so "per hour" is not shown.', 'fy-fleet' ) . '</strong>';
				}
				?>
				</p></td>
			</tr>
			<tr>
				<th><label for="fy_duration_label"><?php esc_html_e( 'Starting Duration Label', 'fy-fleet' ); ?> *</label></th>
				<td><input type="text" id="fy_duration_label" name="fy_duration_label" value="<?php echo esc_attr( $duration ); ?>" class="regular-text" placeholder="e.g. 3 Hours, or Pay for 4 Hours Get 5 Hours Total"></td>
			</tr>
			<tr>
				<th><label for="fy_price_note"><?php esc_html_e( 'Starting Price Note', 'fy-fleet' ); ?></label></th>
				<td><input type="text" id="fy_price_note" name="fy_price_note" value="<?php echo esc_attr( $note ); ?>" class="regular-text" placeholder="e.g. 3-hour private charter"></td>
			</tr>
			<tr>
				<th><label for="fy_special_desc"><?php esc_html_e( 'Yacht Page Description (product page only)', 'fy-fleet' ); ?></label></th>
				<td><textarea id="fy_special_desc" name="fy_special_desc" rows="3" class="large-text" placeholder="<?php esc_attr_e( 'e.g. Miami’s most-requested party yacht — fresh interior for 2026, booked out most weekends…', 'fy-fleet' ); ?>"><?php echo esc_textarea( get_post_meta( $post->ID, '_fy_special_desc', true ) ); ?></textarea>
				<p class="description"><?php echo wp_kses_post( sprintf( __( 'Shows ONLY on the WooCommerce product description, as a styled highlight above the auto specs (size, price, hours, capacity). Never appears on the fleet grid or gallery. Basic HTML (<code>&lt;strong&gt;</code>, <code>&lt;em&gt;</code>) allowed. Shortcode: <code>[fy_yacht_special yacht="%d"]</code>', 'fy-fleet' ), $post->ID ) ); ?></p></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Filters', 'fy-fleet' ); ?></th>
				<td>
					<label><input type="checkbox" name="fy_is_pink" value="1" <?php checked( $is_pink, '1' ); ?>> <?php esc_html_e( 'Pink Yacht (adds "Pink Yacht" badge + Pink filter)', 'fy-fleet' ); ?></label><br>
					<label><input type="checkbox" name="fy_is_free_hour" value="1" <?php checked( $is_free, '1' ); ?>> <?php esc_html_e( 'Free-Hour Offer (adds "+1 Free Hour" badge + Free-hour filter)', 'fy-fleet' ); ?></label>
				</td>
			</tr>
			<tr>
				<th><label for="fy_year"><?php esc_html_e( 'Year', 'fy-fleet' ); ?></label></th>
				<td><input type="number" min="1900" max="2100" step="1" id="fy_year" name="fy_year" value="<?php echo esc_attr( $year ); ?>" class="small-text" placeholder="2020"></td>
			</tr>
			<tr>
				<th><label for="fy_brand"><?php esc_html_e( 'Brand / Builder', 'fy-fleet' ); ?></label></th>
				<td><input type="text" id="fy_brand" name="fy_brand" value="<?php echo esc_attr( $brand ); ?>" class="regular-text" placeholder="<?php esc_attr_e( 'e.g. Azimut, Leopard, PowerCat', 'fy-fleet' ); ?>"></td>
			</tr>
			<tr>
				<th><label for="fy_model"><?php esc_html_e( 'Model', 'fy-fleet' ); ?></label></th>
				<td><input type="text" id="fy_model" name="fy_model" value="<?php echo esc_attr( $model ); ?>" class="regular-text" placeholder="<?php esc_attr_e( 'e.g. 440 Power Catamaran', 'fy-fleet' ); ?>"></td>
			</tr>
			<tr>
				<th><label for="fy_rating"><?php esc_html_e( 'Rating (0–5)', 'fy-fleet' ); ?></label></th>
				<td><input type="number" min="0" max="5" step="0.1" id="fy_rating" name="fy_rating" value="<?php echo esc_attr( $rating ); ?>" class="small-text">
				<p class="description"><?php esc_html_e( 'Shown as a small star badge in the yacht specs. Leave blank to hide.', 'fy-fleet' ); ?></p></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Captain', 'fy-fleet' ); ?></th>
				<td><label><input type="checkbox" name="fy_captain_included" value="1" <?php checked( $captain, '1' ); ?>> <?php esc_html_e( 'Captain included', 'fy-fleet' ); ?></label></td>
			</tr>
		</table>
		<p class="description"><?php esc_html_e( 'Tip: set the Featured Image (right sidebar) — that is the photo shown on the card.', 'fy-fleet' ); ?></p>
		<?php
	}

	public static function render_badges( $post ) {
		$badges = get_post_meta( $post->ID, '_fy_badges', true );
		if ( ! is_array( $badges ) ) {
			$badges = array();
		}
		?>
		<p class="description"><?php esc_html_e( 'Extra badges shown over the photo (e.g. "New Yacht", "Guest Favorite", "Value Pick"). Pink Yacht and Free-Hour badges are added automatically from the checkboxes above.', 'fy-fleet' ); ?></p>
		<div id="fy-badges-rows" class="fy-repeater">
			<?php foreach ( $badges as $i => $badge ) : ?>
				<?php self::badge_row( $i, $badge ); ?>
			<?php endforeach; ?>
		</div>
		<button type="button" class="button" id="fy-add-badge"><?php esc_html_e( '+ Add Badge', 'fy-fleet' ); ?></button>
		<script type="text/template" id="fy-badge-template"><?php self::badge_row( '__INDEX__', array() ); ?></script>
		<?php
	}

	private static function badge_row( $i, $badge ) {
		$text  = isset( $badge['text'] ) ? $badge['text'] : '';
		$style = isset( $badge['style'] ) ? $badge['style'] : 'hot';
		?>
		<div class="fy-repeater-row">
			<select name="fy_badges[<?php echo esc_attr( $i ); ?>][style]">
				<option value="hot" <?php selected( $style, 'hot' ); ?>><?php esc_html_e( 'Highlight (red)', 'fy-fleet' ); ?></option>
				<option value="pink" <?php selected( $style, 'pink' ); ?>><?php esc_html_e( 'Pink Yacht (pink)', 'fy-fleet' ); ?></option>
				<option value="free" <?php selected( $style, 'free' ); ?>><?php esc_html_e( 'Free Hour (blue)', 'fy-fleet' ); ?></option>
				<option value="commercial" <?php selected( $style, 'commercial' ); ?>><?php esc_html_e( 'Commercial (indigo)', 'fy-fleet' ); ?></option>
				<option value="size" <?php selected( $style, 'size' ); ?>><?php esc_html_e( 'Size accent (rose)', 'fy-fleet' ); ?></option>
			</select>
			<input type="text" name="fy_badges[<?php echo esc_attr( $i ); ?>][text]" value="<?php echo esc_attr( $text ); ?>" placeholder="<?php esc_attr_e( 'e.g. New Yacht', 'fy-fleet' ); ?>" class="regular-text">
			<button type="button" class="button-link-delete fy-remove-row"><?php esc_html_e( 'Remove', 'fy-fleet' ); ?></button>
		</div>
		<?php
	}

	public static function render_pricing( $post ) {
		$rows = get_post_meta( $post->ID, '_fy_pricing', true );
		if ( ! is_array( $rows ) ) {
			$rows = array();
		}
		?>
		<p class="description"><?php esc_html_e( 'These are the rows shown inside "View Hours & Pricing" on the card. Add a day heading to split rates by day (e.g. Monday-Thursday vs Friday-Sunday), or a note for surcharges/add-ons.', 'fy-fleet' ); ?></p>
		<div id="fy-pricing-rows" class="fy-repeater">
			<?php foreach ( $rows as $i => $row ) : ?>
				<?php self::pricing_row( $i, $row ); ?>
			<?php endforeach; ?>
		</div>
		<button type="button" class="button" id="fy-add-price-row"><?php esc_html_e( '+ Add Price Row', 'fy-fleet' ); ?></button>
		<button type="button" class="button" id="fy-add-heading-row"><?php esc_html_e( '+ Add Day Heading', 'fy-fleet' ); ?></button>
		<button type="button" class="button" id="fy-add-note-row"><?php esc_html_e( '+ Add Note', 'fy-fleet' ); ?></button>
		<span class="fy-quick-headings">
			<?php esc_html_e( 'Quick add:', 'fy-fleet' ); ?>
			<button type="button" class="button button-small fy-quick-heading" data-heading="Monday–Thursday"><?php esc_html_e( 'Weekday (Mon–Thu)', 'fy-fleet' ); ?></button>
			<button type="button" class="button button-small fy-quick-heading" data-heading="Monday–Friday"><?php esc_html_e( 'Weekday (Mon–Fri)', 'fy-fleet' ); ?></button>
			<button type="button" class="button button-small fy-quick-heading" data-heading="Friday–Sunday"><?php esc_html_e( '🌴 Weekend (Fri–Sun)', 'fy-fleet' ); ?></button>
			<button type="button" class="button button-small fy-quick-heading" data-heading="Saturday–Sunday"><?php esc_html_e( '🌴 Weekend (Sat–Sun)', 'fy-fleet' ); ?></button>
		</span>
		<p class="description">
			<?php esc_html_e( 'A day heading applies to every price row beneath it, until the next heading. The booking form reads these headings and automatically shows the correct rates for the date your customer picks.', 'fy-fleet' ); ?>
		</p>
		<script type="text/template" id="fy-price-row-template"><?php self::pricing_row( '__INDEX__', array( 'type' => 'price' ) ); ?></script>
		<script type="text/template" id="fy-heading-row-template"><?php self::pricing_row( '__INDEX__', array( 'type' => 'heading' ) ); ?></script>
		<script type="text/template" id="fy-note-row-template"><?php self::pricing_row( '__INDEX__', array( 'type' => 'note' ) ); ?></script>
		<?php
	}

	private static function pricing_row( $i, $row ) {
		$type     = isset( $row['type'] ) ? $row['type'] : 'price';
		$duration = isset( $row['duration'] ) ? $row['duration'] : '';
		$price    = isset( $row['price'] ) ? $row['price'] : '';
		$free     = isset( $row['free'] ) ? $row['free'] : '';
		$text     = isset( $row['text'] ) ? $row['text'] : '';
		?>
		<div class="fy-repeater-row fy-price-row-<?php echo esc_attr( $type ); ?>">
			<input type="hidden" name="fy_pricing[<?php echo esc_attr( $i ); ?>][type]" value="<?php echo esc_attr( $type ); ?>">
			<?php if ( 'heading' === $type ) : ?>
				<span class="fy-row-tag"><?php esc_html_e( 'Day Heading', 'fy-fleet' ); ?></span>
				<input type="text" name="fy_pricing[<?php echo esc_attr( $i ); ?>][text]" value="<?php echo esc_attr( $text ); ?>" placeholder="<?php esc_attr_e( 'e.g. Monday-Thursday', 'fy-fleet' ); ?>" class="regular-text">
			<?php elseif ( 'note' === $type ) : ?>
				<span class="fy-row-tag"><?php esc_html_e( 'Note', 'fy-fleet' ); ?></span>
				<input type="text" name="fy_pricing[<?php echo esc_attr( $i ); ?>][text]" value="<?php echo esc_attr( $text ); ?>" placeholder="<?php esc_attr_e( 'e.g. Weekend surcharge — $150', 'fy-fleet' ); ?>" class="regular-text">
			<?php else : ?>
				<span class="fy-row-tag"><?php esc_html_e( 'Price', 'fy-fleet' ); ?></span>
				<input type="text" name="fy_pricing[<?php echo esc_attr( $i ); ?>][duration]" value="<?php echo esc_attr( $duration ); ?>" placeholder="<?php esc_attr_e( 'e.g. 3 Hours', 'fy-fleet' ); ?>" class="regular-text">
				<input type="number" min="0" step="0.01" name="fy_pricing[<?php echo esc_attr( $i ); ?>][price]" value="<?php echo esc_attr( $price ); ?>" placeholder="<?php esc_attr_e( 'Total $', 'fy-fleet' ); ?>" class="small-text">
				<label class="fy-inline-check"><input type="checkbox" name="fy_pricing[<?php echo esc_attr( $i ); ?>][free]" value="1" <?php checked( $free, '1' ); ?>> <?php esc_html_e( 'Free-hour row style', 'fy-fleet' ); ?></label>
			<?php endif; ?>
			<button type="button" class="button-link-delete fy-remove-row"><?php esc_html_e( 'Remove', 'fy-fleet' ); ?></button>
		</div>
		<?php
	}

	/**
	 * Full photo gallery for this yacht — the same _fy_gallery_image_ids
	 * field the spreadsheet importer fills in, and the same field that
	 * mirrors onto the WooCommerce product gallery both ways (edit it here
	 * or on the product screen — sync_product() and FY_Fleet_Product_Editor
	 * keep the two in step automatically on save).
	 */
	public static function render_gallery_images( $post ) {
		$ids = get_post_meta( $post->ID, '_fy_gallery_image_ids', true );
		$ids = is_array( $ids ) ? array_map( 'intval', $ids ) : array();
		?>
		<input type="hidden" name="fy_gallery_images_present" value="1">
		<p class="description"><?php esc_html_e( 'Drag to reorder — the first photo is used as the featured image everywhere (card, product page, social sharing). Add photos from the Media Library or upload new ones. This is the same gallery shown by [fy_yacht_gallery] and on the WooCommerce product page.', 'fy-fleet' ); ?></p>
		<div id="fy-yacht-gallery-items" class="fy-yacht-gallery-grid">
			<?php foreach ( $ids as $id ) : ?>
				<?php self::yacht_gallery_item( $id ); ?>
			<?php endforeach; ?>
		</div>
		<button type="button" class="button" id="fy-yacht-gallery-add"><?php esc_html_e( '+ Add Photos', 'fy-fleet' ); ?></button>
		<script type="text/template" id="fy-yacht-gallery-item-template"><?php self::yacht_gallery_item( 0 ); ?></script>
		<?php
	}

	private static function yacht_gallery_item( $id ) {
		$url = $id ? wp_get_attachment_image_url( $id, 'thumbnail' ) : '';
		?>
		<div class="fy-yacht-gallery-item">
			<span class="fy-yacht-gallery-thumb"><img src="<?php echo esc_url( $url ); ?>" <?php echo $url ? '' : 'style="display:none"'; ?>></span>
			<input type="hidden" class="fy-yacht-gallery-id" name="fy_gallery_image_ids[]" value="<?php echo esc_attr( $id ); ?>">
			<button type="button" class="fy-yacht-gallery-remove" aria-label="<?php esc_attr_e( 'Remove photo', 'fy-fleet' ); ?>">&times;</button>
		</div>
		<?php
	}

	public static function render_image( $post ) {
		$image_url = get_post_meta( $post->ID, '_fy_image_url', true );
		?>
		<p><label for="fy_image_url"><strong><?php esc_html_e( 'Image URL', 'fy-fleet' ); ?></strong></label><br>
		<input type="url" id="fy_image_url" name="fy_image_url" value="<?php echo esc_attr( $image_url ); ?>" class="widefat fy-image-url-input" placeholder="https://"></p>
		<div class="fy-image-preview-wrap">
			<img class="fy-image-preview" src="<?php echo esc_url( $image_url ); ?>" alt="" <?php echo $image_url ? '' : 'style="display:none"'; ?>>
			<p class="fy-image-empty description" <?php echo $image_url ? 'style="display:none"' : ''; ?>><?php esc_html_e( 'No photo yet — paste an image URL above or set a Featured Image.', 'fy-fleet' ); ?></p>
		</div>
		<p class="description"><?php esc_html_e( 'A Featured Image (if set) takes priority over this URL. The URL is handy for photos already hosted on your site.', 'fy-fleet' ); ?></p>
		<?php
	}

	public static function render_cta( $post ) {
		$url        = get_post_meta( $post->ID, '_fy_button_url', true );
		$label      = get_post_meta( $post->ID, '_fy_button_label', true );
		$sub        = get_post_meta( $post->ID, '_fy_button_sub', true );
		$product_id = (int) get_post_meta( $post->ID, '_fy_product_id', true );
		if ( $product_id && 'product' !== get_post_type( $product_id ) ) {
			$product_id = 0;
		}
		?>
		<?php if ( $product_id ) : ?>
			<p>🛒 <strong><?php esc_html_e( 'WooCommerce product:', 'fy-fleet' ); ?></strong>
				<a href="<?php echo esc_url( get_permalink( $product_id ) ); ?>" target="_blank"><?php esc_html_e( 'View', 'fy-fleet' ); ?></a> ·
				<a href="<?php echo esc_url( get_edit_post_link( $product_id ) ); ?>"><?php esc_html_e( 'Edit', 'fy-fleet' ); ?></a>
			</p>
		<?php elseif ( class_exists( 'FY_Fleet_Woo' ) && FY_Fleet_Woo::active() ) : ?>
			<p class="description">🛒 <?php esc_html_e( 'The WooCommerce product (checkout page) is created automatically when you publish this yacht.', 'fy-fleet' ); ?></p>
		<?php endif; ?>
		<p><label for="fy_button_url"><strong><?php esc_html_e( 'Button URL', 'fy-fleet' ); ?></strong></label><br>
		<input type="url" id="fy_button_url" name="fy_button_url" value="<?php echo esc_attr( $url ); ?>" class="widefat" placeholder="https://"></p>
		<p class="description"><?php esc_html_e( 'Leave blank (recommended): it fills itself with this yacht\'s WooCommerce product page on publish — that\'s where Add to Cart and checkout live. Or point it anywhere you like.', 'fy-fleet' ); ?></p>
		<p><label for="fy_button_label"><?php esc_html_e( 'Button Label (optional)', 'fy-fleet' ); ?></label><br>
		<input type="text" id="fy_button_label" name="fy_button_label" value="<?php echo esc_attr( $label ); ?>" class="widefat" placeholder="<?php esc_attr_e( 'Default: View {Yacht Name}', 'fy-fleet' ); ?>"></p>
		<p><label for="fy_button_sub"><?php esc_html_e( 'Button Sub-label (optional)', 'fy-fleet' ); ?></label><br>
		<input type="text" id="fy_button_sub" name="fy_button_sub" value="<?php echo esc_attr( $sub ); ?>" class="widefat" placeholder="<?php esc_attr_e( 'Default: Photos, amenities & booking', 'fy-fleet' ); ?>"></p>
		<?php
	}

	public static function render_booking_options( $post ) {
		$surcharge = get_post_meta( $post->ID, '_fy_weekend_surcharge', true );
		$crew_rate = get_post_meta( $post->ID, '_fy_crew_rate', true );
		$fuel_rate = get_post_meta( $post->ID, '_fy_fuel_rate', true );
		$service   = get_post_meta( $post->ID, '_fy_service_fee', true );
		$disabled  = get_post_meta( $post->ID, '_fy_disabled_addons', true );
		$disabled  = is_array( $disabled ) ? $disabled : array();
		$custom    = get_post_meta( $post->ID, '_fy_custom_addons', true );
		$custom    = is_array( $custom ) ? $custom : array();
		$catalog   = FY_Fleet_Settings::get_addons();
		?>
		<input type="hidden" name="fy_booking_opts_present" value="1">
		<table class="form-table fy-form-table">
			<tr>
				<th><?php esc_html_e( 'Crew / fuel / service fee for THIS yacht', 'fy-fleet' ); ?></th>
				<td>
					<label style="display:inline-block;margin-right:18px"><?php esc_html_e( 'Crew ($/hr)', 'fy-fleet' ); ?><br>
						<input type="number" min="0" step="0.01" name="fy_crew_rate" value="<?php echo esc_attr( $crew_rate ); ?>" class="small-text" placeholder="<?php echo esc_attr( FY_Fleet_Settings::get_crew_rate() ); ?>"></label>
					<label style="display:inline-block;margin-right:18px"><?php esc_html_e( 'Fuel ($/hr)', 'fy-fleet' ); ?><br>
						<input type="number" min="0" step="0.01" name="fy_fuel_rate" value="<?php echo esc_attr( $fuel_rate ); ?>" class="small-text" placeholder="<?php echo esc_attr( FY_Fleet_Settings::get_fuel_rate() ); ?>"></label>
					<label style="display:inline-block"><?php esc_html_e( 'Service fee ($)', 'fy-fleet' ); ?><br>
						<input type="number" min="0" step="0.01" name="fy_service_fee" value="<?php echo esc_attr( $service ); ?>" class="small-text" placeholder="<?php echo esc_attr( FY_Fleet_Settings::get_service_fee() ); ?>"></label>
					<p class="description"><?php esc_html_e( 'Leave blank to use the fleet boat-cost lines: at or under $800 = $75/hr crew and $25/hr fuel; over $800 and at or under $1,400 = $75/hr crew and $50/hr fuel; over $1,400 = $100/hr crew and $50/hr fuel plus the 20% reservation deposit. Fill a field to override that split for this yacht only.', 'fy-fleet' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><label for="fy_weekend_surcharge"><?php esc_html_e( 'Weekend surcharge ($)', 'fy-fleet' ); ?></label></th>
				<td>
					<input type="number" min="0" step="0.01" id="fy_weekend_surcharge" name="fy_weekend_surcharge" value="<?php echo esc_attr( $surcharge ); ?>" class="small-text">
					<p class="description">
						<?php esc_html_e( 'Added automatically when the customer picks a weekend date. Leave blank for none. Only use this on yachts that do NOT already have separate weekend rate rows, otherwise the weekend is charged twice.', 'fy-fleet' ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th><label for="fy_blackout_dates"><?php esc_html_e( 'Blocked dates', 'fy-fleet' ); ?></label></th>
				<td>
					<textarea id="fy_blackout_dates" name="fy_blackout_dates" rows="3" class="regular-text" placeholder="2026-08-15&#10;2026-08-16"><?php echo esc_textarea( get_post_meta( $post->ID, '_fy_blackout_dates', true ) ); ?></textarea>
					<p class="description"><?php esc_html_e( 'One date per line (YYYY-MM-DD). Customers cannot book this yacht online on these days — use for maintenance, private events or dates already sold elsewhere.', 'fy-fleet' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Available add-ons', 'fy-fleet' ); ?></th>
				<td>
					<?php if ( empty( $catalog ) ) : ?>
						<p class="description"><?php esc_html_e( 'No add-ons defined yet — set them up under Checkout & Integrations.', 'fy-fleet' ); ?></p>
					<?php else : ?>
						<?php foreach ( $catalog as $addon ) : ?>
							<label style="display:block;margin-bottom:4px">
								<input type="checkbox" name="fy_enabled_addons[]" value="<?php echo esc_attr( $addon['key'] ); ?>" <?php checked( ! in_array( $addon['key'], $disabled, true ) ); ?>>
								<?php echo esc_html( $addon['label'] ); ?>
								<span class="description">
									— $<?php echo esc_html( number_format( (float) $addon['price'] ) ); ?><?php echo 'hour' === $addon['unit'] ? esc_html__( ' per hour', 'fy-fleet' ) : ''; ?>
								</span>
							</label>
						<?php endforeach; ?>
						<p class="description"><?php esc_html_e( 'Untick anything this yacht cannot offer.', 'fy-fleet' ); ?></p>
					<?php endif; ?>
				</td>
			</tr>
		</table>

		<h4><?php esc_html_e( 'Add-ons only for this yacht', 'fy-fleet' ); ?></h4>
		<p class="description"><?php esc_html_e( 'For extras unique to this boat, such as a water slide.', 'fy-fleet' ); ?></p>
		<div id="fy-custom-addon-rows" class="fy-repeater">
			<?php foreach ( $custom as $i => $addon ) : ?>
				<?php self::custom_addon_row( $i, $addon ); ?>
			<?php endforeach; ?>
		</div>
		<button type="button" class="button" id="fy-add-custom-addon"><?php esc_html_e( '+ Add Yacht Add-On', 'fy-fleet' ); ?></button>
		<script type="text/template" id="fy-custom-addon-template"><?php self::custom_addon_row( '__INDEX__', array() ); ?></script>
		<?php
	}

	private static function custom_addon_row( $i, $addon ) {
		$label = isset( $addon['label'] ) ? $addon['label'] : '';
		$price = isset( $addon['price'] ) ? $addon['price'] : '';
		$unit  = isset( $addon['unit'] ) ? $addon['unit'] : 'flat';
		$note  = isset( $addon['note'] ) ? $addon['note'] : '';
		$max   = isset( $addon['max'] ) ? $addon['max'] : 1;
		?>
		<div class="fy-repeater-row">
			<input type="text" name="fy_custom_addons[<?php echo esc_attr( $i ); ?>][label]" value="<?php echo esc_attr( $label ); ?>" placeholder="<?php esc_attr_e( 'e.g. Water slide', 'fy-fleet' ); ?>" class="regular-text">
			<input type="number" min="0" step="0.01" name="fy_custom_addons[<?php echo esc_attr( $i ); ?>][price]" value="<?php echo esc_attr( $price ); ?>" placeholder="<?php esc_attr_e( 'Price', 'fy-fleet' ); ?>" class="small-text">
			<select name="fy_custom_addons[<?php echo esc_attr( $i ); ?>][unit]">
				<option value="flat" <?php selected( $unit, 'flat' ); ?>><?php esc_html_e( 'Flat fee', 'fy-fleet' ); ?></option>
				<option value="hour" <?php selected( $unit, 'hour' ); ?>><?php esc_html_e( 'Per hour', 'fy-fleet' ); ?></option>
			</select>
			<input type="number" min="1" step="1" name="fy_custom_addons[<?php echo esc_attr( $i ); ?>][max]" value="<?php echo esc_attr( $max ); ?>" title="<?php esc_attr_e( 'Max quantity', 'fy-fleet' ); ?>" class="small-text">
			<input type="text" name="fy_custom_addons[<?php echo esc_attr( $i ); ?>][note]" value="<?php echo esc_attr( $note ); ?>" placeholder="<?php esc_attr_e( 'Note (optional)', 'fy-fleet' ); ?>" class="regular-text">
			<button type="button" class="button-link-delete fy-remove-row"><?php esc_html_e( 'Remove', 'fy-fleet' ); ?></button>
		</div>
		<?php
	}

	public static function render_search( $post ) {
		$terms = get_post_meta( $post->ID, '_fy_search_terms', true );
		?>
		<p><textarea name="fy_search_terms" class="widefat" rows="3" placeholder="<?php esc_attr_e( 'Optional: brand names, nicknames, keywords people might search for', 'fy-fleet' ); ?>"><?php echo esc_textarea( $terms ); ?></textarea></p>
		<?php
	}

	/**
	 * Bookkeeping copied over from a source spreadsheet (SKU, previous
	 * owner/agent, original listing ID). Never rendered on the public site
	 * or in any shortcode — purely for staff reference and re-import
	 * matching.
	 */
	public static function render_reference( $post ) {
		$sku        = get_post_meta( $post->ID, '_fy_sku', true );
		$owner      = get_post_meta( $post->ID, '_fy_source_owner', true );
		$listing_id = get_post_meta( $post->ID, '_fy_source_listing_id', true );
		?>
		<p><label for="fy_sku"><?php esc_html_e( 'SKU', 'fy-fleet' ); ?></label><br>
		<input type="text" id="fy_sku" name="fy_sku" value="<?php echo esc_attr( $sku ); ?>" class="widefat"></p>
		<p><label for="fy_source_owner"><?php esc_html_e( 'Source owner / agent (free text)', 'fy-fleet' ); ?></label><br>
		<input type="text" id="fy_source_owner" name="fy_source_owner" value="<?php echo esc_attr( $owner ); ?>" class="widefat"></p>
		<p><label for="fy_source_listing_id"><?php esc_html_e( 'Source listing ID', 'fy-fleet' ); ?></label><br>
		<input type="text" id="fy_source_listing_id" name="fy_source_listing_id" value="<?php echo esc_attr( $listing_id ); ?>" class="widefat"></p>
		<p class="description"><?php esc_html_e( 'Used to match this yacht when re-importing the fleet spreadsheet. Never shown to customers.', 'fy-fleet' ); ?></p>
		<hr>
		<?php self::render_owner_picker( $post ); ?>
		<?php
	}

	/**
	 * Links this yacht post to a REAL user account — separate from the free-
	 * text "Source owner / agent" field above. This is what "My Yacht
	 * Bookings" and the account-portal submission flow key off (post_author);
	 * yachts submitted through the portal already have this set correctly by
	 * FY_Fleet_Submissions, so this picker exists to retro-fit ownership onto
	 * yachts that were imported or created directly in wp-admin.
	 */
	private static function render_owner_picker( $post ) {
		$current = get_userdata( $post->post_author );
		$owners  = get_users(
			array(
				'role__in' => array( 'fy_yacht_owner', 'administrator' ),
				'orderby'  => 'display_name',
				'number'   => 200,
			)
		);
		?>
		<p><label for="fy_yacht_owner_id"><strong><?php esc_html_e( 'Yacht owner account', 'fy-fleet' ); ?></strong></label><br>
		<select id="fy_yacht_owner_id" name="fy_yacht_owner_id" class="widefat">
			<option value=""><?php esc_html_e( '— No linked owner account —', 'fy-fleet' ); ?></option>
			<?php foreach ( $owners as $user ) : ?>
				<option value="<?php echo esc_attr( $user->ID ); ?>" <?php selected( $current && (int) $current->ID === (int) $user->ID ); ?>>
					<?php echo esc_html( $user->display_name . ' (' . $user->user_email . ')' ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<p class="description"><?php esc_html_e( 'The account that sees this yacht\'s bookings under My Account → My Yacht Bookings. Changing this reassigns the post author.', 'fy-fleet' ); ?></p></p>
		<?php
	}

	public static function save( $post_id, $post ) {
		if ( ! isset( $_POST['fy_fleet_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fy_fleet_nonce'] ) ), 'fy_fleet_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$fields = array(
			'fy_size_ft'       => 'intval',
			'fy_price'         => 'floatval',
			'fy_duration_label'=> 'sanitize_text_field',
			'fy_price_note'    => 'sanitize_text_field',
			'fy_button_label'  => 'sanitize_text_field',
			'fy_button_sub'    => 'sanitize_text_field',
			'fy_brand'         => 'sanitize_text_field',
			'fy_model'         => 'sanitize_text_field',
			'fy_sku'           => 'sanitize_text_field',
			'fy_source_owner'  => 'sanitize_text_field',
			'fy_source_listing_id' => 'sanitize_text_field',
		);
		foreach ( $fields as $field => $sanitizer ) {
			$value = isset( $_POST[ $field ] ) ? call_user_func( $sanitizer, wp_unslash( $_POST[ $field ] ) ) : '';
			update_post_meta( $post_id, '_' . $field, $value );
		}

		// Blank must stay blank (so the fleet default applies) rather than become 0.
		$capacity_raw = isset( $_POST['fy_capacity_max'] ) ? trim( wp_unslash( $_POST['fy_capacity_max'] ) ) : '';
		update_post_meta( $post_id, '_fy_capacity_max', '' === $capacity_raw ? '' : intval( $capacity_raw ) );

		$year_raw = isset( $_POST['fy_year'] ) ? trim( wp_unslash( $_POST['fy_year'] ) ) : '';
		update_post_meta( $post_id, '_fy_year', '' === $year_raw ? '' : intval( $year_raw ) );

		$rating_raw = isset( $_POST['fy_rating'] ) ? trim( wp_unslash( $_POST['fy_rating'] ) ) : '';
		update_post_meta( $post_id, '_fy_rating', '' === $rating_raw ? '' : max( 0, min( 5, (float) $rating_raw ) ) );

		update_post_meta( $post_id, '_fy_captain_included', isset( $_POST['fy_captain_included'] ) ? '1' : '' );

		update_post_meta( $post_id, '_fy_button_url', isset( $_POST['fy_button_url'] ) ? esc_url_raw( wp_unslash( $_POST['fy_button_url'] ) ) : '' );
		update_post_meta( $post_id, '_fy_image_url', isset( $_POST['fy_image_url'] ) ? esc_url_raw( wp_unslash( $_POST['fy_image_url'] ) ) : '' );

		// Gallery — only touched when the box actually rendered on this
		// screen (it always does for the yacht/product editors, so this
		// just guards against some other, unrelated save_post_fy_yacht
		// caller that never submitted the field at all).
		if ( isset( $_POST['fy_gallery_images_present'] ) ) {
			$gallery_ids = array();
			if ( isset( $_POST['fy_gallery_image_ids'] ) && is_array( $_POST['fy_gallery_image_ids'] ) ) {
				foreach ( wp_unslash( $_POST['fy_gallery_image_ids'] ) as $raw_id ) {
					$id = intval( $raw_id );
					if ( $id && 'attachment' === get_post_type( $id ) ) {
						$gallery_ids[] = $id;
					}
				}
			}
			update_post_meta( $post_id, '_fy_gallery_image_ids', $gallery_ids );
			if ( ! empty( $gallery_ids ) ) {
				set_post_thumbnail( $post_id, $gallery_ids[0] );
			}
		}
		update_post_meta( $post_id, '_fy_special_desc', isset( $_POST['fy_special_desc'] ) ? wp_kses_post( wp_unslash( $_POST['fy_special_desc'] ) ) : '' );
		update_post_meta( $post_id, '_fy_search_terms', isset( $_POST['fy_search_terms'] ) ? sanitize_textarea_field( wp_unslash( $_POST['fy_search_terms'] ) ) : '' );
		update_post_meta( $post_id, '_fy_is_pink', isset( $_POST['fy_is_pink'] ) ? '1' : '' );
		update_post_meta( $post_id, '_fy_is_free_hour', isset( $_POST['fy_is_free_hour'] ) ? '1' : '' );

		// Badges.
		$badges = array();
		if ( isset( $_POST['fy_badges'] ) && is_array( $_POST['fy_badges'] ) ) {
			foreach ( $_POST['fy_badges'] as $badge ) {
				$text = isset( $badge['text'] ) ? sanitize_text_field( wp_unslash( $badge['text'] ) ) : '';
				if ( '' === $text ) {
					continue;
				}
				$style = isset( $badge['style'] ) ? sanitize_key( $badge['style'] ) : 'hot';
				if ( ! in_array( $style, array( 'hot', 'pink', 'free', 'commercial', 'size' ), true ) ) {
					$style = 'hot';
				}
				$badges[] = array( 'text' => $text, 'style' => $style );
			}
		}
		update_post_meta( $post_id, '_fy_badges', $badges );

		// Pricing rows.
		$rows = array();
		if ( isset( $_POST['fy_pricing'] ) && is_array( $_POST['fy_pricing'] ) ) {
			foreach ( $_POST['fy_pricing'] as $row ) {
				$type = isset( $row['type'] ) ? sanitize_key( $row['type'] ) : 'price';
				if ( 'heading' === $type || 'note' === $type ) {
					$text = isset( $row['text'] ) ? sanitize_text_field( wp_unslash( $row['text'] ) ) : '';
					if ( '' === $text ) {
						continue;
					}
					$rows[] = array( 'type' => $type, 'text' => $text );
				} else {
					$duration = isset( $row['duration'] ) ? sanitize_text_field( wp_unslash( $row['duration'] ) ) : '';
					$price    = isset( $row['price'] ) ? floatval( $row['price'] ) : 0;
					if ( '' === $duration ) {
						continue;
					}
					$rows[] = array(
						'type'     => 'price',
						'duration' => $duration,
						'price'    => $price,
						'free'     => isset( $row['free'] ) ? '1' : '',
					);
				}
			}
		}
		update_post_meta( $post_id, '_fy_pricing', $rows );

		// Booking options.
		if ( isset( $_POST['fy_blackout_dates'] ) ) {
			$dates = array();
			foreach ( preg_split( '/\r\n|\r|\n/', sanitize_textarea_field( wp_unslash( $_POST['fy_blackout_dates'] ) ) ) as $line ) {
				$line = trim( $line );
				if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $line ) ) {
					$dates[] = $line;
				}
			}
			update_post_meta( $post_id, '_fy_blackout_dates', implode( "\n", array_unique( $dates ) ) );
		}

		$surcharge = isset( $_POST['fy_weekend_surcharge'] ) ? trim( wp_unslash( $_POST['fy_weekend_surcharge'] ) ) : '';
		update_post_meta( $post_id, '_fy_weekend_surcharge', '' === $surcharge ? '' : floatval( $surcharge ) );

		// Per-yacht crew/fuel/service-fee overrides — blank means "use the
		// fleet-wide rate", same convention as Max Guests and this surcharge.
		foreach ( array( 'fy_crew_rate', 'fy_fuel_rate', 'fy_service_fee' ) as $field ) {
			$raw = isset( $_POST[ $field ] ) ? trim( wp_unslash( $_POST[ $field ] ) ) : '';
			update_post_meta( $post_id, '_' . $field, '' === $raw ? '' : max( 0, floatval( $raw ) ) );
		}

		// Store the inverse (disabled) so add-ons added later are on by default.
		$enabled  = isset( $_POST['fy_enabled_addons'] ) && is_array( $_POST['fy_enabled_addons'] )
			? array_map( 'sanitize_text_field', wp_unslash( $_POST['fy_enabled_addons'] ) )
			: array();
		$disabled = array();
		if ( isset( $_POST['fy_booking_opts_present'] ) || isset( $_POST['fy_enabled_addons'] ) ) {
			foreach ( FY_Fleet_Settings::get_addons() as $addon ) {
				if ( ! in_array( $addon['key'], $enabled, true ) ) {
					$disabled[] = $addon['key'];
				}
			}
			update_post_meta( $post_id, '_fy_disabled_addons', $disabled );
		}

		$custom_addons = array();
		if ( isset( $_POST['fy_custom_addons'] ) && is_array( $_POST['fy_custom_addons'] ) ) {
			foreach ( wp_unslash( $_POST['fy_custom_addons'] ) as $addon ) {
				$label = isset( $addon['label'] ) ? sanitize_text_field( $addon['label'] ) : '';
				if ( '' === $label ) {
					continue;
				}
				$custom_addons[] = array(
					'label' => $label,
					'price' => isset( $addon['price'] ) ? floatval( $addon['price'] ) : 0,
					'unit'  => ( isset( $addon['unit'] ) && 'hour' === $addon['unit'] ) ? 'hour' : 'flat',
					'max'   => ( isset( $addon['max'] ) && intval( $addon['max'] ) > 0 ) ? intval( $addon['max'] ) : 1,
					'note'  => isset( $addon['note'] ) ? sanitize_text_field( $addon['note'] ) : '',
				);
			}
		}
		update_post_meta( $post_id, '_fy_custom_addons', $custom_addons );

		// Owner account reassignment (see render_owner_picker()). Only acted
		// on when the field was actually present, so this never fires for
		// unrelated save_post_fy_yacht callers.
		if ( isset( $_POST['fy_yacht_owner_id'] ) ) {
			$owner_id = absint( $_POST['fy_yacht_owner_id'] );
			if ( $owner_id && get_userdata( $owner_id ) && (int) $post->post_author !== $owner_id ) {
				// Reassigning triggers this same save_post hook again via
				// wp_update_post() — the unchanged nonce/guard checks above
				// make that a harmless no-op second pass, not a loop, since
				// $post->post_author will match on the second call.
				remove_action( 'save_post_' . FY_Fleet_CPT::POST_TYPE, array( __CLASS__, 'save' ), 10 );
				wp_update_post( array( 'ID' => $post_id, 'post_author' => $owner_id ) );
				add_action( 'save_post_' . FY_Fleet_CPT::POST_TYPE, array( __CLASS__, 'save' ), 10, 2 );

				$user = get_userdata( $owner_id );
				if ( $user && ! in_array( 'fy_yacht_owner', (array) $user->roles, true ) && ! user_can( $user, 'manage_options' ) ) {
					$user->add_role( 'fy_yacht_owner' );
				}
			}
		}
	}
}
