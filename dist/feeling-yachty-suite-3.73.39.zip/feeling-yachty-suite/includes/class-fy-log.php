<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Lightweight activity log: API writes, webhook deliveries, imports.
 * Stored as a hidden post type; the newest 300 entries are kept.
 */
class FY_Fleet_Log {

	const POST_TYPE = 'fy_log';
	const KEEP      = 300;

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
	}

	public static function register() {
		register_post_type(
			self::POST_TYPE,
			array(
				'public'          => false,
				'show_ui'         => false,
				'supports'        => array( 'title' ),
				'capability_type' => 'post',
			)
		);
	}

	/**
	 * @param string $action  Short slug, e.g. "api.update", "webhook.sent".
	 * @param string $summary One human-readable line.
	 * @param array  $data    Extra detail, stored as JSON.
	 */
	public static function add( $action, $summary, $data = array() ) {
		$user    = wp_get_current_user();
		$post_id = wp_insert_post(
			array(
				'post_type'   => self::POST_TYPE,
				'post_status' => 'publish',
				'post_title'  => wp_slash( '[' . $action . '] ' . $summary ),
			)
		);
		if ( ! $post_id || is_wp_error( $post_id ) ) {
			return;
		}
		update_post_meta( $post_id, '_fy_log_action', sanitize_key( str_replace( '.', '-', $action ) ) );
		update_post_meta( $post_id, '_fy_log_user', $user && $user->ID ? $user->user_login : 'system' );
		if ( ! empty( $data ) ) {
			update_post_meta( $post_id, '_fy_log_data', wp_json_encode( $data ) );
		}
		self::trim();
	}

	private static function trim() {
		$old = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'any',
				'offset'         => self::KEEP,
				'posts_per_page' => 50,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'fields'         => 'ids',
			)
		);
		foreach ( $old as $id ) {
			wp_delete_post( $id, true );
		}
	}

	public static function add_menu() {
		add_submenu_page(
			'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE,
			__( 'Activity Log', 'fy-fleet' ),
			__( 'Activity Log', 'fy-fleet' ),
			'manage_options',
			'fy-fleet-log',
			array( __CLASS__, 'render_page' )
		);
	}

	public static function render_page() {
		$entries = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'any',
				'posts_per_page' => 100,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Activity Log', 'fy-fleet' ); ?></h1>
			<p class="description"><?php esc_html_e( 'Every API write (n8n), webhook delivery and import — so a misfired automation can be traced. Newest 300 entries are kept.', 'fy-fleet' ); ?></p>
			<table class="widefat striped">
				<thead><tr>
					<th style="width:160px"><?php esc_html_e( 'When', 'fy-fleet' ); ?></th>
					<th style="width:120px"><?php esc_html_e( 'Who', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'What', 'fy-fleet' ); ?></th>
					<th style="width:80px"><?php esc_html_e( 'Detail', 'fy-fleet' ); ?></th>
				</tr></thead>
				<tbody>
				<?php if ( empty( $entries ) ) : ?>
					<tr><td colspan="4"><?php esc_html_e( 'Nothing logged yet.', 'fy-fleet' ); ?></td></tr>
				<?php else : ?>
					<?php foreach ( $entries as $entry ) : ?>
						<?php $data = get_post_meta( $entry->ID, '_fy_log_data', true ); ?>
						<tr>
							<td><?php echo esc_html( get_the_date( 'M j, Y g:i a', $entry ) ); ?></td>
							<td><code><?php echo esc_html( get_post_meta( $entry->ID, '_fy_log_user', true ) ); ?></code></td>
							<td><?php echo esc_html( $entry->post_title ); ?></td>
							<td>
								<?php if ( $data ) : ?>
									<details><summary><?php esc_html_e( 'JSON', 'fy-fleet' ); ?></summary>
									<pre style="white-space:pre-wrap;max-width:520px;font-size:11px"><?php echo esc_html( $data ); ?></pre></details>
								<?php else : ?>&mdash;<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}
}
