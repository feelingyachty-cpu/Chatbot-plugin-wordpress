/* Feeling Yachty — storefront extras:
   1) Sticky booking bar on product pages (appears after scrolling past the form)
   2) Contact buttons card on the order-received (thank-you) page
   3) "Added to cart" popup with a straight-to-checkout button

   #3 exists because this store uses WooCommerce's AJAX add-to-cart
   (cart_redirect_after_add: "no"), which only bumps the mini-cart count —
   the classic .woocommerce-message bar WooCommerce prints on a full-page
   submit never appears at all here. On mobile especially, tapping "Add to
   Cart" looked like nothing happened. This listens for WooCommerce's own
   'added_to_cart' event (fired by its core add-to-cart-ajax script on every
   AJAX add, product page or shop loop alike) and shows real confirmation. */
jQuery( function ( $ ) {

	// ---- Sticky booking bar (product pages) ----
	var $form = $( 'form.cart' );
	if ( $form.length && document.body.classList.contains( 'single-product' ) ) {
		// The price used to be scraped from WooCommerce's own price element
		// via .text() — which also pulls in the visually-hidden "Price
		// range: $X through $Y" text WooCommerce adds for screen readers,
		// so the bar showed the visible range and that hidden string mashed
		// together with no space. fyStickyBar carries the SAME "From $X"
		// figure the card and product header already show — one number,
		// computed once, server-side.
		var sb = ( typeof fyStickyBar !== 'undefined' ) ? fyStickyBar : {};
		// .fy-sticky-book is full-width so it can sit flush against the
		// screen edges; .fy-sticky-book__inner is the part that's actually
		// centered and width-capped, so on a wide desktop window the price
		// and button sit together in the middle instead of pinned to
		// opposite edges with a wall of empty space between them.
		var $bar = $(
			'<div class="fy-sticky-book" role="region" aria-label="Book this experience">' +
				'<div class="fy-sticky-book__inner">' +
					'<div class="fy-sticky-book__price-block">' +
						'<span class="fy-sticky-book__label">From</span>' +
						'<span class="fy-sticky-book__price"></span>' +
						'<span class="fy-sticky-book__unit"></span>' +
					'</div>' +
					// Hidden until fleet.js's fySavedSync() (loaded on every
					// page, not just the grid) finds something in the
					// visitor's shortlist and fills in the count — a
					// product page has no fleet grid of its own to filter,
					// so without this the shortlist is invisible here.
					// Clicking it opens fleet.js's own Saved popup.
					'<button type="button" class="fy-sticky-book__saved" data-fy-saved-trigger hidden>' +
						'<span aria-hidden="true">♥</span> <span class="fy-saved-count">0</span> saved' +
					'</button>' +
					'<button type="button" class="fy-sticky-book__btn">Book Experience</button>' +
				'</div>' +
			'</div>'
		);
		if ( sb.fromPrice ) {
			$bar.find( '.fy-sticky-book__price' ).text( sb.fromPrice );
			$bar.find( '.fy-sticky-book__unit' ).text( sb.fromUnit || '' );
		} else {
			// No computed price for this yacht — the label alone reads
			// oddly on its own, so drop the whole price block rather than
			// show "From" with nothing after it.
			$bar.find( '.fy-sticky-book__price-block' ).remove();
		}
		$( 'body' ).append( $bar );

		$bar.on( 'click', '.fy-sticky-book__btn', function () {
			$( 'html, body' ).animate( { scrollTop: $form.offset().top - 130 }, 400 );
		} );

		if ( 'IntersectionObserver' in window ) {
			new IntersectionObserver( function ( entries ) {
				var e = entries[ 0 ];
				$bar.toggleClass( 'fy-show', ! e.isIntersecting && e.boundingClientRect.top < 0 );
			}, { threshold: 0 } ).observe( $form[ 0 ] );
		}

		// Live price: product-express.js re-renders .fy-pay-summary on every
		// date/duration/add-on pick. Mirror its "Charged today" figure into
		// the sticky bar, so the bar stops saying a generic "From $X" the
		// moment the visitor has a real quote — same pattern as the app's
		// footer quote bar. Watching the DOM instead of recomputing keeps
		// exactly ONE source of pricing truth on the page.
		var lastShown = '';
		function syncBarPrice() {
			var summary = document.querySelector( '.fy-pay-summary' );
			if ( ! summary ) {
				return;
			}
			var due = '';
			$( summary ).find( '.fy-pay-summary__line--total' ).each( function () {
				var t = $( this ).text();
				if ( -1 !== t.indexOf( 'Charged today' ) ) {
					var m = t.match( /\$[\d,]+(\.\d+)?/ );
					if ( m ) {
						due = m[ 0 ];
					}
				}
			} );
			if ( ! due ) {
				var $pre = $( summary ).find( '.fy-pay-summary__due' );
				if ( $pre.length && -1 !== $pre.find( 'span' ).first().text().indexOf( 'Due today' ) ) {
					due = $pre.find( 'strong' ).first().text().trim();
				}
			}
			if ( ! due || due === lastShown ) {
				return;
			}
			lastShown = due;
			var $price = $bar.find( '.fy-sticky-book__price' );
			if ( ! $price.length ) {
				return;
			}
			$bar.find( '.fy-sticky-book__label' ).text( 'Due today' );
			$bar.find( '.fy-sticky-book__unit' ).text( '' );
			// Re-trigger the pop animation on every change.
			$price.text( due );
			$bar.removeClass( 'fy-live' );
			void $bar[ 0 ].offsetWidth;
			$bar.addClass( 'fy-live' );
		}
		if ( 'MutationObserver' in window ) {
			new MutationObserver( syncBarPrice ).observe( document.body, { childList: true, subtree: true } );
		}
		syncBarPrice();
	}

	// ---- "Added to cart" popup ----
	var $cartPopup = null;
	var cartPopupOpener = null;

	function escHtml( s ) {
		return String( s == null ? '' : s ).replace( /[&<>"']/g, function ( c ) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ c ];
		} );
	}

	function cartPopupBox() {
		if ( $cartPopup ) {
			return $cartPopup;
		}
		var checkoutUrl = ( typeof wc_checkout_params !== 'undefined' && wc_checkout_params.checkout_url )
			? wc_checkout_params.checkout_url
			: ( ( typeof wc_add_to_cart_params !== 'undefined' && wc_add_to_cart_params.cart_url ) ? wc_add_to_cart_params.cart_url.replace( /\/cart\/?$/, '/checkout/' ) : '/checkout/' );
		var cartUrl = ( typeof wc_add_to_cart_params !== 'undefined' && wc_add_to_cart_params.cart_url ) ? wc_add_to_cart_params.cart_url : '/cart/';
		var cad = ( typeof fyCartAddedData !== 'undefined' ) ? fyCartAddedData : {};
		var fleetUrl = cad.fleetUrl || '/miami-yacht-rental/';

		// Subtle cross-sell: one line of small linked service names, not a
		// second grid of buttons — "add-on services exist" should register
		// in passing, not compete with Checkout for attention.
		var servicesLine = '';
		if ( cad.services && cad.services.length ) {
			var links = cad.services.map( function ( s ) {
				return '<a href="' + escHtml( s.url ) + '" target="_blank" rel="noopener">' + escHtml( s.label ) + '</a>';
			} ).join( ' · ' );
			servicesLine =
				'<div class="fy-cart-added__services">' +
					'<span class="fy-cart-added__services-label">Complete the experience:</span> ' + links +
					( cad.servicesUrl ? ' — <a class="fy-cart-added__services-all" href="' + escHtml( cad.servicesUrl ) + '" target="_blank" rel="noopener">see all →</a>' : '' ) +
				'</div>';
		}

		$cartPopup = $(
			'<div class="fy-cart-added" hidden>' +
				'<div class="fy-cart-added__backdrop" data-fy-cart-close></div>' +
				'<div class="fy-cart-added__panel" role="dialog" aria-modal="true" aria-labelledby="fy-cart-added-title" tabindex="-1">' +
					'<button type="button" class="fy-cart-added__close" data-fy-cart-close aria-label="Close">&times;</button>' +
					'<div class="fy-cart-added__head">' +
						'<span class="fy-cart-added__check" aria-hidden="true">✓</span>' +
						'<span class="fy-cart-added__eyebrow">Added to your Feeling Yachty experience</span>' +
					'</div>' +
					'<div class="fy-cart-added__product">' +
						'<img class="fy-cart-added__thumb" alt="" hidden>' +
						'<span class="fy-cart-added__name" id="fy-cart-added-title"></span>' +
					'</div>' +
					'<div class="fy-cart-added__actions">' +
						'<a class="fy-cart-added__btn fy-cart-added__btn--ghost" href="' + cartUrl + '">View Cart</a>' +
						'<a class="fy-cart-added__btn fy-cart-added__btn--checkout" href="' + checkoutUrl + '">Checkout →</a>' +
					'</div>' +
					servicesLine +
					'<a class="fy-cart-added__fleet-link" href="' + escHtml( fleetUrl ) + '">🛥️ View All Yachts</a>' +
				'</div>' +
			'</div>'
		);
		$( 'body' ).append( $cartPopup );

		$cartPopup.on( 'click', '[data-fy-cart-close]', closeCartPopup );
		$( document ).on( 'keydown', function ( e ) {
			if ( e.key === 'Escape' && ! $cartPopup.attr( 'hidden' ) ) {
				closeCartPopup();
			}
		} );

		return $cartPopup;
	}

	function closeCartPopup() {
		if ( ! $cartPopup ) {
			return;
		}
		$cartPopup.attr( 'hidden', true ).removeClass( 'fy-show' );
		if ( cartPopupOpener && cartPopupOpener.length && document.contains( cartPopupOpener[ 0 ] ) ) {
			cartPopupOpener.trigger( 'focus' );
		}
		cartPopupOpener = null;
	}

	function showCartAddedPopup( name, imgSrc, $opener ) {
		var $box = cartPopupBox();
		cartPopupOpener = $opener && $opener.length ? $opener : null;
		$box.find( '.fy-cart-added__name' ).text( name || 'Your yacht experience' );

		var $thumb = $box.find( '.fy-cart-added__thumb' );
		if ( imgSrc ) {
			$thumb.attr( 'src', imgSrc ).removeAttr( 'hidden' );
		} else {
			$thumb.attr( 'hidden', true );
		}

		$box.removeAttr( 'hidden' );
		// Two ticks: hidden -> block, then add the class that animates in —
		// doing both in the same frame skips the transition entirely.
		requestAnimationFrame( function () {
			requestAnimationFrame( function () {
				$box.addClass( 'fy-show' );
			} );
		} );
		$box.find( '.fy-cart-added__panel' ).trigger( 'focus' );
	}

	// Path 1: a genuine AJAX add (WooCommerce fires this JS event itself) —
	// covers shop-loop "Add to Cart" buttons and any other AJAX add on the
	// site.
	$( document.body ).on( 'added_to_cart', function ( event, fragments, cart_hash, $button ) {
		// Name: the single-product H1 covers the common case here (each
		// yacht has its own dedicated page); a shop-loop click falls back to
		// that product's own card title so the popup is never blank.
		var name = '';
		if ( document.body.classList.contains( 'single-product' ) ) {
			name = $( 'h1.product_title' ).first().text().trim();
		}
		if ( ! name && $button && $button.length ) {
			var $card = $button.closest( '.product' );
			name = $card.find( '.woocommerce-loop-product__title' ).first().text().trim();
		}

		var imgSrc = $( '.woocommerce-product-gallery__image img' ).first().attr( 'src' );
		if ( ! imgSrc && $button && $button.length ) {
			imgSrc = $button.closest( '.product' ).find( 'img' ).first().attr( 'src' );
		}

		showCartAddedPopup( name, imgSrc, $button );
	} );

	// Path 2: the classic (non-AJAX) add. This store's single-product "Add
	// to Cart" button is a normal form submit — WooCommerce POSTs, adds the
	// item, and redirects back with its own .woocommerce-message notice
	// rendered server-side. The 'added_to_cart' JS event above never fires
	// for this, and it's the path actually used on this site's product
	// pages, so this is checked for on every page load. The .wc-forward
	// link is specific to add-to-cart success notices (as opposed to e.g.
	// "Cart updated"), so it's the marker used to tell them apart.
	var $classicMessage = $( '.woocommerce-message' ).filter( function () {
		return $( this ).find( '.wc-forward' ).length > 0;
	} );
	if ( $classicMessage.length ) {
		var classicName = document.body.classList.contains( 'single-product' )
			? $( 'h1.product_title' ).first().text().trim()
			: '';
		var classicImg = $( '.woocommerce-product-gallery__image img' ).first().attr( 'src' );
		showCartAddedPopup( classicName, classicImg, null );
		// Our popup replaces it — leaving the plain-text bar visible too
		// underneath would just be a second, redundant confirmation.
		$classicMessage.hide();
	}

	// ---- Thank-you page contact card ----
	var $received = $( '.woocommerce-thankyou-order-received' );
	if ( $received.length ) {
		$received.after(
			'<div class="fy-thankyou-contact">' +
				'<p class="fy-thankyou-contact__title">Questions about your charter? We answer fast — WhatsApp, SMS or call:</p>' +
				'<div class="fy-thankyou-contact__row">' +
					'<a class="fy-contact-btn fy-contact-btn--wa" href="https://wa.me/19542463636" target="_blank" rel="noopener">💬 WhatsApp Miami</a>' +
					'<a class="fy-contact-btn fy-contact-btn--wa" href="https://wa.me/5072021729" target="_blank" rel="noopener">💬 WhatsApp Panamá</a>' +
					'<a class="fy-contact-btn" href="tel:+19542463636">📞 Miami (954) 246-3636</a>' +
					'<a class="fy-contact-btn" href="tel:+5072021729">📞 Panamá +507 202-1729</a>' +
				'</div>' +
			'</div>'
		);
	}
} );
