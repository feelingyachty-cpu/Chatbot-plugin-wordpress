<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 🛥️ List Your Yacht — owner submission portal.
 *
 * Logged-in customers get a My Account tab where they can submit their own
 * yacht (same core fields as the yacht editor: name, size, description,
 * hour/price rows, photos). Submissions are created as
 * PENDING fy_yacht posts — nothing appears on the site until staff review
 * them in FY Command Center → Yacht Requests, where they can open the full
 * yacht editor to fix text/images and then Approve (publish) or Reject.
 */
class FY_Fleet_Submissions {

	const EP = 'fy-list-yacht';

	public static function init() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		add_action( 'init', array( __CLASS__, 'add_endpoint' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_flush' ) );
		add_filter( 'woocommerce_account_menu_items', array( __CLASS__, 'menu_item' ), 20 );
		add_action( 'woocommerce_account_' . self::EP . '_endpoint', array( __CLASS__, 'render' ) );
		add_action( 'wp_loaded', array( __CLASS__, 'handle_submit' ) );

		add_action( 'admin_menu', array( __CLASS__, 'add_admin_menu' ) );
		add_action( 'admin_post_fy_submission_decide', array( __CLASS__, 'handle_decide' ) );

		// Notification: a reminder banner on EVERY wp-admin screen (not just
		// Fleet Suite pages) that only clears when the submission is actually
		// decided — and a one-time popup the first time an admin sees a NEW
		// one, so it doesn't rely on someone noticing the awaiting-mod badge.
		add_action( 'admin_notices', array( __CLASS__, 'admin_reminder_banner' ) );
		add_action( 'admin_footer', array( __CLASS__, 'admin_new_submission_popup' ) );
	}

	/** Persistent reminder — every wp-admin screen, until Approved/Rejected. */
	public static function admin_reminder_banner() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$count = count( self::pending() );
		if ( ! $count ) {
			return;
		}
		printf(
			'<div class="notice notice-warning"><p>🛥️ %s <a href="%s"><strong>%s</strong></a></p></div>',
			esc_html(
				sprintf(
					/* translators: %d: number of pending yacht submissions */
					_n( '%d new yacht submission is waiting for review.', '%d new yacht submissions are waiting for review.', $count, 'fy-fleet' ),
					$count
				)
			),
			esc_url( admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-requests' ) ),
			esc_html__( 'Review now →', 'fy-fleet' )
		);
	}

	/**
	 * One-time popup: fires only when the NEWEST pending submission is one
	 * this admin hasn't already been shown (tracked per-user, not
	 * per-session, so it survives across browser tabs/devices). The banner
	 * above is the ongoing reminder; this is just the "heads up, something
	 * just came in" moment.
	 */
	public static function admin_new_submission_popup() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$pending = self::pending();
		if ( ! $pending ) {
			return;
		}
		$newest_id = max( wp_list_pluck( $pending, 'ID' ) );
		$user_id   = get_current_user_id();
		$last_seen = (int) get_user_meta( $user_id, '_fy_last_seen_submission_id', true );
		if ( $newest_id <= $last_seen ) {
			return;
		}
		update_user_meta( $user_id, '_fy_last_seen_submission_id', $newest_id );

		$newest = null;
		foreach ( $pending as $p ) {
			if ( (int) $p->ID === $newest_id ) {
				$newest = $p;
				break;
			}
		}
		$review_url = admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-requests' );
		?>
		<div id="fy-sub-popup" role="alertdialog" aria-modal="true" aria-label="<?php esc_attr_e( 'New yacht submission', 'fy-fleet' ); ?>"
			style="position:fixed;inset:0;z-index:999999;display:flex;align-items:center;justify-content:center;background:rgba(15,20,33,.72);font-family:ui-sans-serif,system-ui,-apple-system,'Segoe UI',Roboto,Arial,sans-serif">
			<div style="max-width:420px;width:92%;background:#fff;border-radius:18px;padding:30px 28px;text-align:center;box-shadow:0 30px 80px rgba(0,0,0,.4)">
				<div style="font-size:42px;line-height:1">🛥️</div>
				<h2 style="margin:12px 0 6px;font-size:20px;font-weight:950;letter-spacing:-.02em;
					background:linear-gradient(90deg,#C94386,#7C3AED,#2563EB);-webkit-background-clip:text;background-clip:text;color:transparent">
					<?php esc_html_e( 'New yacht submission', 'fy-fleet' ); ?>
				</h2>
				<p style="margin:0 0 20px;color:#526079;font-size:14px;line-height:1.6">
					<?php
					echo $newest
						? esc_html( sprintf( __( '"%s" was just submitted for review.', 'fy-fleet' ), $newest->post_title ) )
						: esc_html__( 'A yacht was just submitted for review.', 'fy-fleet' );
					?>
				</p>
				<a href="<?php echo esc_url( $review_url ); ?>" class="button button-primary" style="margin-right:8px"><?php esc_html_e( 'Review now', 'fy-fleet' ); ?></a>
				<button type="button" class="button" onclick="document.getElementById('fy-sub-popup').remove()"><?php esc_html_e( 'Dismiss', 'fy-fleet' ); ?></button>
			</div>
		</div>
		<script>document.addEventListener('keydown',function(e){if(e.key==='Escape'){var p=document.getElementById('fy-sub-popup');if(p)p.remove();}});</script>
		<?php
	}

	public static function add_endpoint() {
		add_rewrite_endpoint( self::EP, EP_ROOT | EP_PAGES );
	}

	public static function maybe_flush() {
		if ( '1' !== get_option( 'fy_submission_endpoints_v' ) ) {
			flush_rewrite_rules();
			update_option( 'fy_submission_endpoints_v', '1' );
		}
	}

	public static function menu_item( $items ) {
		$logout = isset( $items['customer-logout'] ) ? array( 'customer-logout' => $items['customer-logout'] ) : array();
		unset( $items['customer-logout'] );
		$items[ self::EP ] = __( '🛥️ List Your Yacht', 'fy-fleet' );
		return $items + $logout;
	}

	/* ------------------------------------------------------------------
	 * Front: submission form + the user's own submissions
	 * ---------------------------------------------------------------- */

	private static function user_submissions() {
		return get_posts(
			array(
				'post_type'   => FY_Fleet_CPT::POST_TYPE,
				'post_status' => array( 'pending', 'publish', 'draft' ),
				'author'      => get_current_user_id(),
				'numberposts' => 20,
				'meta_key'    => '_fy_submitted_via',
				'meta_value'  => 'portal',
			)
		);
	}

	public static function render() {
		$sent = isset( $_GET['fy_yacht_submitted'] );
		?>
		<style>
		.fy-sub{font-family:ui-sans-serif,system-ui,"Segoe UI",Roboto,Arial,sans-serif;color:#172033}
		.fy-sub-title{font-size:clamp(19px,2.6vw,25px);font-weight:950;letter-spacing:-.02em;margin:0 0 6px;
			background:linear-gradient(90deg,#C94386,#7C3AED,#2563EB);-webkit-background-clip:text;background-clip:text;color:transparent}
		.fy-sub-intro{color:#526079;font-size:14px;line-height:1.65;margin:0 0 16px}
		.fy-sub-card{border:1px solid rgba(124,58,237,.16);border-radius:16px;background:linear-gradient(180deg,#fff,#fffafd);
			padding:20px;margin-bottom:14px;box-shadow:0 8px 22px rgba(23,32,51,.06)}
		.fy-sub label{display:block;font-size:11.5px;font-weight:950;text-transform:uppercase;letter-spacing:.05em;color:#5B21B6;margin:12px 0 4px}
		.fy-sub input[type=text],.fy-sub input[type=number],.fy-sub textarea{width:100%;min-height:44px;border:1.5px solid #E6EAF3;border-radius:11px;padding:9px 12px;font:inherit}
		.fy-sub textarea{min-height:110px}
		.fy-sub input:focus,.fy-sub textarea:focus{border-color:#7C3AED;outline:none;box-shadow:0 0 0 1px #7C3AED}
		.fy-sub-grid{display:grid;grid-template-columns:1fr 1fr;gap:0 14px}
		.fy-sub-prices{display:grid;grid-template-columns:1fr 1fr 1fr;gap:0 10px}
		.fy-sub-send{margin-top:16px;width:100%;min-height:52px;border:0;border-radius:999px;cursor:pointer;color:#fff;font:inherit;font-weight:950;font-size:15px;
			background:linear-gradient(105deg,#C94386,#7C3AED);box-shadow:0 8px 20px rgba(184,50,128,.28)}
		.fy-sub-note{font-size:12.5px;color:#526079;margin-top:10px;line-height:1.6}
		.fy-sub-status{padding:4px 11px;border-radius:999px;font-size:11px;font-weight:900;text-transform:uppercase}
		.fy-sub-status.st-pending{background:#FAEEDA;color:#633806}
		.fy-sub-status.st-publish{background:#E1F5EE;color:#085041}
		.fy-sub-row{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:11px 14px;border:1px solid #E6EAF3;border-radius:12px;margin-bottom:8px}
		.fy-sub-ok{border:1.5px solid #1D9E75;background:#E1F5EE;color:#085041;border-radius:12px;padding:13px 16px;font-weight:800;margin-bottom:14px}
		@media(max-width:560px){.fy-sub-grid,.fy-sub-prices{grid-template-columns:1fr}}
		</style>
		<div class="fy-sub">
			<h2 class="fy-sub-title">🛥️ <?php esc_html_e( 'List Your Yacht With Us', 'fy-fleet' ); ?></h2>
			<p class="fy-sub-intro"><?php esc_html_e( 'Own a yacht? Add it to the Feeling Yachty fleet. Fill in the details below — our team reviews every submission, polishes the photos and text if needed, and approves it onto the site. We\'ll email you when it\'s live.', 'fy-fleet' ); ?></p>

			<?php if ( $sent ) : ?>
				<div class="fy-sub-ok">✅ <?php esc_html_e( 'Submitted! Our team will review your yacht and email you once it\'s approved.', 'fy-fleet' ); ?></div>
			<?php endif; ?>

			<?php $mine = self::user_submissions(); ?>
			<?php if ( $mine ) : ?>
				<div class="fy-sub-card">
					<strong><?php esc_html_e( 'Your submissions', 'fy-fleet' ); ?></strong>
					<div style="margin-top:10px">
					<?php foreach ( $mine as $y ) : ?>
						<div class="fy-sub-row">
							<span style="font-weight:800"><?php echo esc_html( $y->post_title ); ?></span>
							<span class="fy-sub-status st-<?php echo esc_attr( $y->post_status ); ?>">
								<?php echo 'publish' === $y->post_status ? esc_html__( 'Live ✓', 'fy-fleet' ) : esc_html__( 'In review', 'fy-fleet' ); ?>
							</span>
						</div>
					<?php endforeach; ?>
					</div>
				</div>
			<?php endif; ?>

			<form class="fy-sub-card" method="post" enctype="multipart/form-data">
				<?php wp_nonce_field( 'fy_submit_yacht', 'fy_submit_nonce' ); ?>

				<label for="fy_sub_name"><?php esc_html_e( 'Yacht name', 'fy-fleet' ); ?> *</label>
				<input type="text" id="fy_sub_name" name="fy_sub_name" required maxlength="120" placeholder="<?php esc_attr_e( 'e.g. 45ft Sea Ray Sundancer', 'fy-fleet' ); ?>">

				<div class="fy-sub-grid">
					<div>
						<label for="fy_sub_size"><?php esc_html_e( 'Length (ft)', 'fy-fleet' ); ?> *</label>
						<input type="number" id="fy_sub_size" name="fy_sub_size" required min="10" max="400" placeholder="45">
					</div>
					<div>
						<label for="fy_sub_capacity"><?php esc_html_e( 'Max guests', 'fy-fleet' ); ?></label>
						<input type="number" id="fy_sub_capacity" name="fy_sub_capacity" min="1" max="500" placeholder="13">
					</div>
					<div>
						<label for="fy_sub_brand"><?php esc_html_e( 'Brand / builder', 'fy-fleet' ); ?></label>
						<input type="text" id="fy_sub_brand" name="fy_sub_brand" maxlength="80" placeholder="<?php esc_attr_e( 'e.g. Sea Ray, Azimut', 'fy-fleet' ); ?>">
					</div>
					<div>
						<label for="fy_sub_year"><?php esc_html_e( 'Year', 'fy-fleet' ); ?></label>
						<input type="number" id="fy_sub_year" name="fy_sub_year" min="1900" max="2100" placeholder="2020">
					</div>
				</div>

				<label for="fy_sub_desc"><?php esc_html_e( 'Describe your yacht', 'fy-fleet' ); ?> *</label>
				<textarea id="fy_sub_desc" name="fy_sub_desc" required maxlength="4000" placeholder="<?php esc_attr_e( 'Features, amenities, what makes it special, what\'s included (captain, fuel, ice, cooler...)', 'fy-fleet' ); ?>"></textarea>

				<label for="fy_sub_marina"><?php esc_html_e( 'Home marina', 'fy-fleet' ); ?></label>
				<input type="text" id="fy_sub_marina" name="fy_sub_marina" maxlength="160" placeholder="<?php esc_attr_e( 'e.g. Rickenbacker Marina, Key Biscayne', 'fy-fleet' ); ?>">

				<label for="fy_sub_map_embed"><?php esc_html_e( 'Google Maps embed link (optional)', 'fy-fleet' ); ?></label>
				<input type="url" id="fy_sub_map_embed" name="fy_sub_map_embed" placeholder="https://www.google.com/maps/embed?pb=…">
				<p class="fy-sub-note" style="margin-top:-8px"><?php esc_html_e( 'In Google Maps: find your marina → Share → Embed a map → copy the src=\"…\" link and paste it here.', 'fy-fleet' ); ?></p>

				<label><?php esc_html_e( 'Charter pricing', 'fy-fleet' ); ?> *</label>
				<div id="fy-sub-price-rows"></div>
				<button type="button" class="button" id="fy-sub-add-price"><?php esc_html_e( '+ Add a duration', 'fy-fleet' ); ?></button>
				<p class="fy-sub-note" style="margin-top:6px"><?php esc_html_e( 'Add every charter length you offer with its total price (not per hour) — e.g. "3 Hours" → $900.', 'fy-fleet' ); ?></p>

				<label for="fy_sub_photos"><?php esc_html_e( 'Photos (up to 10 — the first becomes the cover)', 'fy-fleet' ); ?> *</label>
				<input type="file" id="fy_sub_photos" name="fy_sub_photos[]" accept="image/jpeg,image/png,image/webp" multiple required>

				<button type="submit" name="fy_submit_yacht" value="1" class="fy-sub-send"><?php esc_html_e( 'Submit for review 🛥️', 'fy-fleet' ); ?></button>
				<p class="fy-sub-note"><?php esc_html_e( 'By submitting you confirm you own this yacht (or represent the owner) and have the rights to the photos. Our team may edit photos and text before publishing.', 'fy-fleet' ); ?></p>
			</form>
		</div>
		<script>
		(function(){
			// Vanilla JS on purpose — this form must work even on a theme/page
			// where jQuery hasn't loaded yet at this point in the DOM.
			var wrap = document.getElementById('fy-sub-price-rows');
			var addBtn = document.getElementById('fy-sub-add-price');
			var i = 0;
			function addRow(duration, price){
				var row = document.createElement('div');
				row.className = 'fy-sub-price-row';
				row.style.cssText = 'display:flex;gap:8px;align-items:center;margin-bottom:8px';
				row.innerHTML =
					'<input type="text" name="fy_sub_pricing[' + i + '][duration]" placeholder="<?php echo esc_js( __( 'e.g. 3 Hours', 'fy-fleet' ) ); ?>" style="flex:1" value="' + (duration||'').replace(/"/g,'&quot;') + '">' +
					'<input type="number" name="fy_sub_pricing[' + i + '][price]" min="0" step="0.01" placeholder="<?php echo esc_js( __( 'Total $', 'fy-fleet' ) ); ?>" style="width:110px" value="' + (price||'') + '">' +
					'<button type="button" class="button-link-delete fy-sub-remove-price" aria-label="<?php echo esc_js( __( 'Remove', 'fy-fleet' ) ); ?>">&times;</button>';
				wrap.appendChild(row);
				row.querySelector('.fy-sub-remove-price').addEventListener('click', function(){
					// Always leave at least one row — an empty required-feeling
					// pricing section reads as broken, not optional.
					if (wrap.children.length > 1) { row.remove(); }
				});
				i++;
			}
			addBtn.addEventListener('click', function(){ addRow(); });
			addRow(); // start with one row so the form isn't visibly empty
		})();
		</script>
		<?php
	}

	public static function handle_submit() {
		if ( empty( $_POST['fy_submit_yacht'] ) || ! is_user_logged_in() ) {
			return;
		}
		if ( ! isset( $_POST['fy_submit_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['fy_submit_nonce'] ), 'fy_submit_yacht' ) ) {
			return;
		}

		$name = isset( $_POST['fy_sub_name'] ) ? sanitize_text_field( wp_unslash( $_POST['fy_sub_name'] ) ) : '';
		$desc = isset( $_POST['fy_sub_desc'] ) ? wp_kses_post( wp_unslash( $_POST['fy_sub_desc'] ) ) : '';
		if ( '' === $name || '' === $desc ) {
			return;
		}

		$yacht_id = wp_insert_post(
			array(
				'post_type'   => FY_Fleet_CPT::POST_TYPE,
				'post_status' => 'pending',
				'post_title'  => wp_slash( $name ),
				'post_author' => get_current_user_id(),
			),
			true
		);
		if ( is_wp_error( $yacht_id ) ) {
			return;
		}

		update_post_meta( $yacht_id, '_fy_submitted_via', 'portal' );
		update_post_meta( $yacht_id, '_fy_size_ft', absint( $_POST['fy_sub_size'] ?? 0 ) );
		update_post_meta( $yacht_id, '_fy_special_desc', $desc );

		// Same meta keys the admin metabox (class-fy-metaboxes.php) uses —
		// a portal submission must be 100% interchangeable with a
		// staff-created yacht, since Approve just publishes it as-is and
		// staff finish it in the normal post editor from here on.
		$capacity_raw = isset( $_POST['fy_sub_capacity'] ) ? trim( wp_unslash( $_POST['fy_sub_capacity'] ) ) : '';
		update_post_meta( $yacht_id, '_fy_capacity_max', '' === $capacity_raw ? '' : absint( $capacity_raw ) );
		update_post_meta( $yacht_id, '_fy_brand', isset( $_POST['fy_sub_brand'] ) ? sanitize_text_field( wp_unslash( $_POST['fy_sub_brand'] ) ) : '' );
		$year_raw = isset( $_POST['fy_sub_year'] ) ? trim( wp_unslash( $_POST['fy_sub_year'] ) ) : '';
		update_post_meta( $yacht_id, '_fy_year', '' === $year_raw ? '' : absint( $year_raw ) );

		// Marina — same fields FY_Fleet_Marina reads via for_yacht(). 'custom'
		// rather than a library entry: the owner is describing their own
		// marina directly, not picking from the shared preset list staff use
		// to avoid re-typing the same marina across many yachts.
		$marina_title = isset( $_POST['fy_sub_marina'] ) ? sanitize_text_field( wp_unslash( $_POST['fy_sub_marina'] ) ) : '';
		if ( '' !== $marina_title ) {
			update_post_meta( $yacht_id, '_fy_marina_source', 'custom' );
			update_post_meta( $yacht_id, '_fy_marina_title', $marina_title );
			$map_embed = isset( $_POST['fy_sub_map_embed'] ) ? esc_url_raw( wp_unslash( $_POST['fy_sub_map_embed'] ) ) : '';
			if ( $map_embed ) {
				update_post_meta( $yacht_id, '_fy_marina_embed', $map_embed );
			}
		}

		// Pricing rows in the exact shape the yacht editor uses.
		$pricing = array();
		if ( isset( $_POST['fy_sub_pricing'] ) && is_array( $_POST['fy_sub_pricing'] ) ) {
			foreach ( wp_unslash( $_POST['fy_sub_pricing'] ) as $row ) {
				$duration = isset( $row['duration'] ) ? sanitize_text_field( $row['duration'] ) : '';
				$price    = isset( $row['price'] ) ? max( 0, floatval( $row['price'] ) ) : 0;
				if ( '' === $duration || $price <= 0 ) {
					continue;
				}
				$pricing[] = array(
					'type'     => 'price',
					'duration' => $duration,
					'price'    => $price,
				);
			}
		}
		if ( $pricing ) {
			update_post_meta( $yacht_id, '_fy_pricing', $pricing );
		}

		// Photos: first becomes the featured image, the rest attach for staff.
		if ( ! empty( $_FILES['fy_sub_photos'] ) && ! empty( $_FILES['fy_sub_photos']['name'][0] ) ) {
			require_once ABSPATH . 'wp-admin/includes/image.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';

			$files = $_FILES['fy_sub_photos']; // phpcs:ignore
			$count = min( count( $files['name'] ), 10 );
			for ( $i = 0; $i < $count; $i++ ) {
				if ( UPLOAD_ERR_OK !== $files['error'][ $i ] ) {
					continue;
				}
				$_FILES['fy_sub_single'] = array(
					'name'     => $files['name'][ $i ],
					'type'     => $files['type'][ $i ],
					'tmp_name' => $files['tmp_name'][ $i ],
					'error'    => $files['error'][ $i ],
					'size'     => $files['size'][ $i ],
				);
				$attach_id = media_handle_upload( 'fy_sub_single', $yacht_id );
				if ( ! is_wp_error( $attach_id ) && ! has_post_thumbnail( $yacht_id ) ) {
					set_post_thumbnail( $yacht_id, $attach_id );
				}
			}
			unset( $_FILES['fy_sub_single'] );
		}

		$user = wp_get_current_user();

		// First submission makes them a yacht owner — no separate admin
		// approval step just to get portal access; the vetting happens on
		// the YACHT (staff review below), not the account. Skipped for
		// staff/admins, who already have every capability they need.
		//
		// ensure_roles() normally registers fy_yacht_owner on admin_init,
		// but this is a front-end request — on a site updated in place
		// (file replace, no deactivate/reactivate) rather than freshly
		// activated, this can run before any admin has ever loaded a
		// wp-admin screen since the update. Registering it here too is
		// idempotent (get_role() short-circuits if it already exists) and
		// guarantees the role actually carries its capabilities the moment
		// it's granted, not just the bare slug.
		if ( ! get_role( 'fy_yacht_owner' ) && class_exists( 'FY_Fleet_CPT' ) ) {
			FY_Fleet_CPT::ensure_roles();
		}
		if ( ! in_array( 'fy_yacht_owner', (array) $user->roles, true ) && ! user_can( $user, 'manage_options' ) ) {
			$user->add_role( 'fy_yacht_owner' );
		}

		// Tell the team by email…
		wp_mail(
			get_option( 'admin_email' ),
			sprintf( '[%s] 🛥️ New yacht submission: %s', get_bloginfo( 'name' ), $name ),
			sprintf(
				"%s (%s) submitted a yacht for review.\n\nReview and approve it here:\n%s",
				$user->display_name,
				$user->user_email,
				admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-requests' )
			)
		);

		// …in the Activity Log…
		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'yacht.submitted', sprintf( '"%s" submitted by %s — awaiting review', $name, $user->user_email ), array( 'yacht' => $yacht_id ) );
		}

		// …and to n8n.
		if ( class_exists( 'FY_Fleet_Woo' ) ) {
			FY_Fleet_Woo::post_webhook(
				array(
					'event'     => 'yacht.submitted',
					'yacht_id'  => $yacht_id,
					'name'      => $name,
					'submitter' => array(
						'name'  => $user->display_name,
						'email' => $user->user_email,
					),
					'admin_url' => admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-requests' ),
					'sent_at'   => gmdate( 'c' ),
				)
			);
		}

		wp_safe_redirect( add_query_arg( 'fy_yacht_submitted', '1', wc_get_account_endpoint_url( self::EP ) ) );
		exit;
	}

	/* ------------------------------------------------------------------
	 * Admin: Yacht Requests review panel
	 * ---------------------------------------------------------------- */

	private static function pending() {
		return get_posts(
			array(
				'post_type'   => FY_Fleet_CPT::POST_TYPE,
				'post_status' => 'pending',
				'numberposts' => 50,
			)
		);
	}

	public static function add_admin_menu() {
		$count = count( self::pending() );
		$badge = $count ? sprintf( ' <span class="awaiting-mod count-%1$d"><span class="pending-count">%1$d</span></span>', $count ) : '';
		add_submenu_page(
			'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE,
			__( 'Yacht Requests', 'fy-fleet' ),
			__( 'Yacht Requests', 'fy-fleet' ) . $badge,
			'manage_options',
			'fy-fleet-requests',
			array( __CLASS__, 'render_admin' )
		);
	}

	public static function render_admin() {
		$pending = self::pending();
		?>
		<div class="wrap">
			<h1>🛥️ <?php esc_html_e( 'Yacht Requests', 'fy-fleet' ); ?></h1>
			<p class="description"><?php esc_html_e( 'Yachts submitted by customers from My Account → List Your Yacht. Open the editor to adjust photos and text, then Approve to publish it to the site (the WooCommerce product is created automatically) — or Reject to remove it. The submitter is emailed either way.', 'fy-fleet' ); ?></p>

			<?php if ( isset( $_GET['fy_decided'] ) ) : ?>
				<div class="notice notice-success"><p><?php echo 'approved' === $_GET['fy_decided'] ? esc_html__( 'Yacht approved and published ✔', 'fy-fleet' ) : esc_html__( 'Submission rejected.', 'fy-fleet' ); ?></p></div>
			<?php endif; ?>

			<?php if ( ! $pending ) : ?>
				<p><?php esc_html_e( 'No pending submissions — all clear! 🌊', 'fy-fleet' ); ?></p>
			<?php else : ?>
				<table class="wp-list-table widefat fixed striped">
					<thead><tr>
						<th style="width:90px"><?php esc_html_e( 'Photo', 'fy-fleet' ); ?></th>
						<th><?php esc_html_e( 'Yacht', 'fy-fleet' ); ?></th>
						<th><?php esc_html_e( 'Submitted by', 'fy-fleet' ); ?></th>
						<th><?php esc_html_e( 'Date', 'fy-fleet' ); ?></th>
						<th style="width:300px"><?php esc_html_e( 'Actions', 'fy-fleet' ); ?></th>
					</tr></thead>
					<tbody>
					<?php foreach ( $pending as $y ) : $author = get_userdata( $y->post_author ); ?>
						<tr>
							<td><?php echo get_the_post_thumbnail( $y->ID, array( 70, 70 ), array( 'style' => 'border-radius:8px;object-fit:cover' ) ); ?></td>
							<td>
								<strong><?php echo esc_html( $y->post_title ); ?></strong><br>
								<span class="description">
									<?php echo esc_html( get_post_meta( $y->ID, '_fy_size_ft', true ) ); ?>ft
								</span>
							</td>
							<td><?php echo $author ? esc_html( $author->display_name . ' (' . $author->user_email . ')' ) : '—'; ?></td>
							<td><?php echo esc_html( get_the_date( '', $y ) ); ?></td>
							<td>
								<a class="button" href="<?php echo esc_url( get_edit_post_link( $y->ID ) ); ?>"><?php esc_html_e( '✏️ Edit', 'fy-fleet' ); ?></a>
								<a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=fy_submission_decide&decision=approve&yacht=' . $y->ID ), 'fy_decide_' . $y->ID ) ); ?>"><?php esc_html_e( '✅ Approve', 'fy-fleet' ); ?></a>
								<a class="button" style="color:#b32d2e" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=fy_submission_decide&decision=reject&yacht=' . $y->ID ), 'fy_decide_' . $y->ID ) ); ?>" onclick="return confirm('<?php echo esc_js( __( 'Reject and remove this submission?', 'fy-fleet' ) ); ?>');"><?php esc_html_e( 'Reject', 'fy-fleet' ); ?></a>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
		<?php
	}

	public static function handle_decide() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		$yacht_id = isset( $_GET['yacht'] ) ? absint( $_GET['yacht'] ) : 0;
		check_admin_referer( 'fy_decide_' . $yacht_id );

		$yacht = get_post( $yacht_id );
		if ( ! $yacht || FY_Fleet_CPT::POST_TYPE !== $yacht->post_type ) {
			wp_die( esc_html__( 'Yacht not found.', 'fy-fleet' ) );
		}

		$decision = isset( $_GET['decision'] ) && 'approve' === $_GET['decision'] ? 'approve' : 'reject';
		$author   = get_userdata( $yacht->post_author );

		if ( 'approve' === $decision ) {
			// Publishing triggers the normal save hooks, so the WooCommerce
			// product, defaults and description are generated automatically.
			wp_update_post( array( 'ID' => $yacht_id, 'post_status' => 'publish' ) );

			if ( $author ) {
				// Link the owner to the buy page — the WooCommerce product.
				$live_url   = home_url( '/' );
				$product_id = (int) get_post_meta( $yacht_id, '_fy_product_id', true );
				if ( $product_id && 'product' === get_post_type( $product_id ) ) {
					$live_url = get_permalink( $product_id );
				}
				wp_mail(
					$author->user_email,
					sprintf( '🎉 Your yacht "%s" is live on %s!', $yacht->post_title, get_bloginfo( 'name' ) ),
					sprintf( "Great news %s!\n\nYour yacht \"%s\" was approved and is now live:\n%s\n\nQuestions? WhatsApp or call — Miami (954) 246-3636 · Panamá +507 202-1729.\n\n— The Feeling Yachty team", $author->display_name, $yacht->post_title, $live_url )
				);
			}
			if ( class_exists( 'FY_Fleet_Log' ) ) {
				FY_Fleet_Log::add( 'yacht.approved', sprintf( '"%s" approved and published', $yacht->post_title ), array( 'yacht' => $yacht_id ) );
			}
		} else {
			wp_trash_post( $yacht_id );
			if ( $author ) {
				wp_mail(
					$author->user_email,
					sprintf( 'About your yacht submission on %s', get_bloginfo( 'name' ) ),
					sprintf( "Hi %s,\n\nThanks for submitting \"%s\". After review we can't list it right now. Reply to this email or WhatsApp us — Miami (954) 246-3636 · Panamá +507 202-1729 — and we'll help you get it ready.\n\n— The Feeling Yachty team", $author->display_name, $yacht->post_title )
				);
			}
			if ( class_exists( 'FY_Fleet_Log' ) ) {
				FY_Fleet_Log::add( 'yacht.rejected', sprintf( '"%s" rejected', $yacht->post_title ), array( 'yacht' => $yacht_id ) );
			}
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'post_type'  => FY_Fleet_CPT::POST_TYPE,
					'page'       => 'fy-fleet-requests',
					'fy_decided' => 'approve' === $decision ? 'approved' : 'rejected',
				),
				admin_url( 'edit.php' )
			)
		);
		exit;
	}
}
