/**
 * Feeling Yachty — product gallery thumbnails as a swipeable strip.
 *
 * Pairs with gallery-slider.css. The CSS does the layout and every animation;
 * this file only handles the things CSS cannot know about:
 *
 *   - arrows, and hiding them when there is nothing left to scroll to
 *   - keeping the active thumbnail in view when the main image changes
 *   - a "3 / 24" counter
 *   - lazy-loading every thumbnail past the first few
 *
 * Deliberately NOT a carousel library. WooCommerce's FlexSlider already drives
 * the main image, and the thumbnail strip is a native overflow-scroll element,
 * so swiping and momentum come from the browser. There is no animation loop
 * here — the only per-frame work the browser does is the scroll it was going
 * to do anyway, which is why a 30-photo yacht costs no more than a 4-photo one.
 */
( function ( $ ) {
	'use strict';

	if ( ! document.body || ! document.body.classList.contains( 'single-product' ) ) {
		return;
	}

	function init() {
		var gallery = document.querySelector( '.woocommerce-product-gallery' );
		if ( ! gallery || gallery.classList.contains( 'fy-gs' ) ) {
			return !! gallery;
		}
		var thumbs = gallery.querySelector( '.flex-control-thumbs' );
		if ( ! thumbs ) {
			return false;   // FlexSlider hasn't built them yet
		}

		gallery.classList.add( 'fy-gs' );

		/* ---- lazy-load everything below the first row ------------------
		 * The first few are visible immediately, so they load normally; the
		 * rest are deferred. This is what actually keeps a 30-photo yacht
		 * cheap — the strip layout only decides how much is on screen.
		 */
		var imgs = thumbs.querySelectorAll( 'img' );
		for ( var i = 0; i < imgs.length; i++ ) {
			if ( i > 3 && ! imgs[ i ].getAttribute( 'loading' ) ) {
				imgs[ i ].setAttribute( 'loading', 'lazy' );
				imgs[ i ].setAttribute( 'decoding', 'async' );
			}
		}

		/* ---- arrows ---------------------------------------------------- */
		var prev = document.createElement( 'button' );
		var next = document.createElement( 'button' );
		prev.type = next.type = 'button';
		prev.className = 'fy-gs-arrow fy-gs-arrow--prev';
		next.className = 'fy-gs-arrow fy-gs-arrow--next';
		prev.setAttribute( 'aria-label', 'Previous photos' );
		next.setAttribute( 'aria-label', 'More photos' );
		prev.innerHTML = '◀';
		next.innerHTML = '▶';
		gallery.appendChild( prev );
		gallery.appendChild( next );

		function page( dir ) {
			// One "page" is most of the visible width, so a tap always lands
			// on a fresh set of photos rather than nudging by a sliver.
			thumbs.scrollBy( {
				left: dir * Math.max( 160, Math.round( thumbs.clientWidth * 0.8 ) ),
				behavior: prefersReduced() ? 'auto' : 'smooth'
			} );
			setTimeout( arrows, 320 );
		}
		prev.addEventListener( 'click', function () { page( -1 ); } );
		next.addEventListener( 'click', function () { page( 1 ); } );

		function prefersReduced() {
			return window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
		}

		function arrows() {
			var over = thumbs.scrollWidth > thumbs.clientWidth + 2;
			var atStart = thumbs.scrollLeft <= 2;
			var atEnd = thumbs.scrollLeft + thumbs.clientWidth >= thumbs.scrollWidth - 2;
			prev.classList.toggle( 'is-hidden', ! over || atStart );
			next.classList.toggle( 'is-hidden', ! over || atEnd );
		}
		thumbs.addEventListener( 'scroll', arrows, { passive: true } );
		window.addEventListener( 'resize', arrows );
		arrows();
		setTimeout( arrows, 400 );

		/* ---- counter over the main image -------------------------------- */
		var total = imgs.length;
		var counter = null;
		if ( total > 1 ) {
			counter = document.createElement( 'div' );
			counter.className = 'fy-gs-count';
			gallery.appendChild( counter );
		}

		/* ---- follow the active thumbnail --------------------------------
		 * FlexSlider moves .flex-active as the main image changes (arrow keys,
		 * swiping the main image, clicking a thumb). Watching for that class
		 * is cheaper and more reliable than hooking FlexSlider's own events,
		 * which differ between WooCommerce versions.
		 */
		function syncActive() {
			var active = thumbs.querySelector( 'img.flex-active' );
			if ( ! active ) { return; }

			if ( counter ) {
				var idx = Array.prototype.indexOf.call( imgs, active );
				counter.textContent = ( idx + 1 ) + ' / ' + total;
			}

			// Scroll it into view only when it is actually out of view, so
			// simply clicking a visible thumb doesn't jerk the strip about.
			var tr = thumbs.getBoundingClientRect();
			var ar = active.getBoundingClientRect();
			if ( ar.left < tr.left + 2 || ar.right > tr.right - 2 ) {
				thumbs.scrollBy( {
					left: ( ar.left - tr.left ) - ( tr.width / 2 ) + ( ar.width / 2 ),
					behavior: prefersReduced() ? 'auto' : 'smooth'
				} );
			}
		}

		if ( 'MutationObserver' in window ) {
			new MutationObserver( syncActive ).observe( thumbs, {
				attributes: true, attributeFilter: [ 'class' ], subtree: true
			} );
		}
		thumbs.addEventListener( 'click', function () { setTimeout( syncActive, 60 ); } );
		syncActive();

		return true;
	}

	$( function () {
		// FlexSlider builds the thumbnail list after its own script runs, so
		// retry briefly rather than assuming it exists at ready().
		if ( init() ) { return; }
		var tries = 0;
		var timer = setInterval( function () {
			tries++;
			if ( init() || tries > 20 ) { clearInterval( timer ); }
		}, 250 );
	} );
} )( jQuery );
