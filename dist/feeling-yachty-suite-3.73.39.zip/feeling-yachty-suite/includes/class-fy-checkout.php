<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Checkout gate: the bareboat verification form must be acknowledged before an
 * order containing a yacht booking can be placed.
 */
class FY_Fleet_Checkout {

	const FIELD = 'fy_bareboat_confirmed';

	public static function init() {
		if ( ! FY_Fleet_Woo::active() ) {
			return;
		}
		// Classic checkout hooks. The terms hook is avoided on purpose — it
		// only runs when a Terms page is configured in WooCommerce.
		add_action( 'woocommerce_before_checkout_form', array( __CLASS__, 'render' ), 5 );
		add_action( 'woocommerce_review_order_before_submit', array( __CLASS__, 'render_checkbox' ), 5 );
		add_action( 'woocommerce_checkout_process', array( __CLASS__, 'validate' ) );

		// WooCommerce BLOCKS checkout (the modern default) ignores all classic
		// hooks, so the agreement checkbox registers through the additional-
		// fields API and the form/deposit panel injects above the block.
		add_action( 'woocommerce_init', array( __CLASS__, 'register_block_field' ) );
		add_filter( 'the_content', array( __CLASS__, 'inject_for_blocks' ), 5 );

		// Brand skin for cart + checkout (Blocks and classic).
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_skin' ) );
		add_action( 'woocommerce_checkout_update_order_meta', array( __CLASS__, 'save' ) );
		add_action( 'woocommerce_admin_order_data_after_billing_address', array( __CLASS__, 'admin_display' ) );
	}

	public static function enqueue_skin() {
		if ( ! function_exists( 'is_cart' ) || ( ! is_cart() && ! is_checkout() ) ) {
			return;
		}
		wp_enqueue_style( 'fy-checkout', FY_FLEET_URL . 'assets/checkout.css', array(), FY_FLEET_VERSION );
		wp_add_inline_style( 'fy-checkout', FY_Fleet_Settings::color_override_css() );
	}

	/**
	 * Native required checkbox in the Blocks checkout — Woo refuses the order
	 * until it is ticked, no custom validation needed. WC 8.6+.
	 */
	public static function register_block_field() {
		if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
			return;
		}
		$opts = FY_Fleet_Settings::get_booking();
		if ( empty( $opts['require_form'] ) ) {
			return;
		}
		woocommerce_register_additional_checkout_field(
			array(
				'id'       => 'feeling-yachty/bareboat-confirmed',
				'label'    => __( 'I confirm that I have completed and submitted the Bareboat Charter Reservation Verification Form (required by U.S. Coast Guard bareboat rules).', 'fy-fleet' ),
				'location' => 'order',
				'type'     => 'checkbox',
				'required' => true,
			)
		);
	}

	/**
	 * Blocks pages have no classic hooks, so the verification form (checkout)
	 * and the deposit-vs-dock panel (cart + checkout) are prepended to the
	 * page content, directly above the block.
	 */
	public static function inject_for_blocks( $content ) {
		if ( is_admin() || ! in_the_loop() || ! is_main_query() || ! function_exists( 'WC' ) || ! WC()->cart ) {
			return $content;
		}
		if ( ! self::cart_has_booking() ) {
			return $content;
		}

		$page_id     = get_the_ID();
		$is_checkout = has_block( 'woocommerce/checkout', $page_id );
		$is_cart     = has_block( 'woocommerce/cart', $page_id );
		if ( ! $is_checkout && ! $is_cart ) {
			return $content; // Classic pages keep their hook-based output.
		}

		$prefix = '';

		if ( $is_checkout ) {
			ob_start();
			self::render();
			$prefix .= ob_get_clean();
		}

		if ( class_exists( 'FY_Fleet_Woo' ) ) {
			ob_start();
			FY_Fleet_Woo::payment_split_panel();
			$prefix .= ob_get_clean();
		}

		return $prefix . $content;
	}

	/**
	 * Was the bareboat form confirmed on this order? Covers both the classic
	 * checkbox and the Blocks additional-field storage.
	 */
	public static function order_confirmed( $order ) {
		if ( 'yes' === $order->get_meta( '_fy_bareboat_confirmed' ) ) {
			return true;
		}
		$block_value = $order->get_meta( '_wc_other/feeling-yachty/bareboat-confirmed' );
		return ! empty( $block_value ) && 'false' !== $block_value;
	}

	/** True when the cart actually contains a yacht charter. */
	public static function cart_has_booking() {
		if ( ! WC()->cart ) {
			return false;
		}
		foreach ( WC()->cart->get_cart() as $item ) {
			if ( ! empty( $item['fy_booking'] ) ) {
				return true;
			}
			// Native add-to-cart: any yacht-backed product counts — the GHL
			// bareboat form and the deposit panel must show for these too.
			$product_id = ! empty( $item['product_id'] ) ? (int) $item['product_id'] : 0;
			if ( $product_id && get_post_meta( $product_id, '_fy_yacht_id', true ) ) {
				return true;
			}
		}
		return false;
	}

	public static function render() {
		if ( ! self::cart_has_booking() ) {
			return;
		}

		$opts = FY_Fleet_Settings::get_booking();
		$code = FY_Fleet_Settings::get_ghl_output();

		echo '<div class="fy-checkout-verification" id="fy-checkout-verification">';

		if ( $code ) {
			// Stored by an administrator with unfiltered_html rights; printed as authored.
			echo $code; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		echo '</div>';
	}

	/** The required acknowledgement, rendered directly above "Place order". */
	public static function render_checkbox() {
		if ( ! self::cart_has_booking() ) {
			return;
		}
		$opts = FY_Fleet_Settings::get_booking();
		if ( empty( $opts['require_form'] ) ) {
			return;
		}
		?>
		<div id="fy-checkout-verification-ack">
			<style>
				#fy-checkout-verification-ack .fy-verify-ack{
					margin:18px 0 20px;padding:16px 18px;border:2px solid #E45C9C;border-left:6px solid #C7347B;
					border-radius:14px;background:#FFF7FB;
					font-family:Arial,Helvetica,sans-serif;color:#334155;
				}
				#fy-checkout-verification-ack .fy-verify-ack label{
					display:flex;align-items:flex-start;gap:11px;cursor:pointer;
					font-size:15px;font-weight:700;line-height:1.55;margin:0;
				}
				#fy-checkout-verification-ack .fy-verify-ack input{
					margin-top:3px;width:20px;height:20px;flex:none;accent-color:#C7347B;
				}
				#fy-checkout-verification-ack .fy-verify-required{color:#B91C1C;font-weight:900}
				#fy-checkout-verification-ack .fy-verify-hint{
					margin:9px 0 0 31px;color:#64748B;font-size:12.5px;font-weight:600;line-height:1.5;
				}
				#fy-checkout-verification-ack .fy-verify-link{color:#C7347B;font-weight:800}
			</style>
			<div class="fy-verify-ack">
				<label for="<?php echo esc_attr( self::FIELD ); ?>">
					<input type="checkbox" id="<?php echo esc_attr( self::FIELD ); ?>" name="<?php echo esc_attr( self::FIELD ); ?>" value="1">
					<span>
						<?php esc_html_e( 'I confirm that I have completed and submitted the Bareboat Charter Reservation Verification Form.', 'fy-fleet' ); ?>
						<span class="fy-verify-required">*</span>
					</span>
				</label>
				<p class="fy-verify-hint">
					<?php esc_html_e( 'Required by U.S. Coast Guard bareboat charter rules. Your charter cannot depart until this form is completed, signed and approved.', 'fy-fleet' ); ?>
					<a class="fy-verify-link" href="#fy-checkout-verification"><?php esc_html_e( 'Back to the form ↑', 'fy-fleet' ); ?></a>
				</p>
			</div>
		</div>
		<?php
	}

	public static function validate() {
		if ( ! self::cart_has_booking() ) {
			return;
		}
		$opts = FY_Fleet_Settings::get_booking();
		if ( empty( $opts['require_form'] ) ) {
			return;
		}
		if ( empty( $_POST[ self::FIELD ] ) ) {
			wc_add_notice(
				__( 'Please confirm you have completed the Bareboat Charter Reservation Verification Form before placing your order.', 'fy-fleet' ),
				'error'
			);
		}
	}

	public static function save( $order_id ) {
		if ( empty( $_POST[ self::FIELD ] ) ) {
			return;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$order->update_meta_data( '_fy_bareboat_confirmed', 'yes' );
		$order->update_meta_data( '_fy_bareboat_confirmed_at', current_time( 'mysql' ) );
		$order->save();
	}

	public static function admin_display( $order ) {
		if ( 'yes' !== $order->get_meta( '_fy_bareboat_confirmed' ) ) {
			return;
		}
		$when = $order->get_meta( '_fy_bareboat_confirmed_at' );
		echo '<p><strong>' . esc_html__( 'Bareboat form confirmed:', 'fy-fleet' ) . '</strong> ';
		echo esc_html( $when ? $when : __( 'yes', 'fy-fleet' ) ) . '</p>';
	}
}
