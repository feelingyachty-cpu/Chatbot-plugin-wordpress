(function(){
// position:sticky is silently cancelled by ANY ancestor that is a scroll
// container (overflow other than visible/clip). Elementor sections,
// containers and widget wrappers ship overflow:hidden in several presets,
// and page builders nest many levels, so walk up from the filter bar and
// opt those ancestors back out. Only overflow is touched: clearing an
// ancestor transform would break Elementor's entrance animations, and a
// transform ancestor is rare compared with a clipped one.
function fyUnblockSticky(root){
  const panel=root.querySelector('.fy-inventory-panel');
  if(!panel)return;

  // Intermediate wrappers (theme + Elementor): clipping here cancels sticky.
  let node=panel.parentElement;
  while(node&&node!==document.body&&node!==document.documentElement){
    const cs=window.getComputedStyle(node);
    if(/^(auto|hidden|scroll)$/.test(cs.overflowY)||/^(auto|hidden|scroll)$/.test(cs.overflowX)){
      node.style.setProperty('overflow','visible','important');
    }
    node=node.parentElement;
  }

  // html/body: themes almost always set overflow-x:hidden to stop sideways
  // scrolling, which turns the document into a scroll container and leaves
  // sticky nothing to stick to. overflow-x:clip stops sideways scrolling
  // identically without that side effect, so swap only when it is 'hidden'.
  [document.documentElement,document.body].forEach(el=>{
    if(window.getComputedStyle(el).overflowX==='hidden'){
      el.style.setProperty('overflow-x','clip','important');
    }
  });
}

// The filter bar sticks below whatever is pinned to the top of the page —
// an Elementor fixed header, the WordPress admin bar, or both stacked. A
// hard-coded offset would tuck it underneath and cut it in half, so measure
// the real clearance and hand it to CSS as --fy-sticky-top.
function fyStickyOffset(root){
  if(!root.querySelector('.fy-inventory-panel'))return;
  let clearance=0;
  document.querySelectorAll('body *').forEach(el=>{
    if(el.closest('.fy-fleet-root'))return;      // never measure ourselves
    const cs=window.getComputedStyle(el);
    if(cs.position!=='fixed'&&cs.position!=='sticky')return;
    if(cs.visibility==='hidden'||cs.display==='none')return;
    const r=el.getBoundingClientRect();
    if(r.height<20||r.height>400)return;         // ignore slivers and overlays
    if(r.top>150||r.bottom<=0)return;            // only bars pinned near the top
    if(r.bottom>clearance)clearance=r.bottom;
  });
  root.style.setProperty('--fy-sticky-top',(Math.round(clearance)+12)+'px');
}

// Filter bar: stays put while you scroll UP, tucks away while you scroll
// DOWN — so browsing the grid gives you the full screen, and the filters
// come straight back the moment you head back up. Never hides while the
// bar is being used (focus inside it) or at the very top of the page.
function fyAutoHideFilters(root){
  const panel=root.querySelector('.fy-inventory-panel');
  if(!panel)return;

  let lastY=window.scrollY||window.pageYOffset||0;
  let ticking=false;
  let upTravel=0;      // upward scroll accumulated since the last down-scroll
  const THRESHOLD=8;   // ignore sub-pixel jitter and elastic overscroll

  // Scrolling up doesn't bring the bar back until you've travelled about two
  // cards' worth — a small upward nudge (repositioning a thumb, a bounce at
  // the end of a fling) no longer plants the bar over the listing being read.
  // Measured from a real card so phones and desktop both get "two listings",
  // with a fallback for before the grid has rendered.
  function revealDistance(){
    const card=root.querySelector('.fy-card');
    return card?card.getBoundingClientRect().height*2:700;
  }

  // True once the panel has actually docked at the top of the screen
  // (position:sticky engaging), not merely once the page has scrolled some
  // fixed number of pixels. A flat "y<120" guard broke on pages with a tall
  // intro/pricing block above the panel: scrolling past 120px while that
  // intro was still fully on screen tucked the panel away, and — since
  // un-tucking then needs ~2 cards of upward scroll — it stayed invisible
  // while still reserving its full height (position:sticky, transform-only
  // hide), leaving a blank gap where the search/filter bar should be.
  // Checking the panel's own position is correct regardless of how tall
  // anything above it is.
  function isPinned(){
    const stickyTop=parseFloat(getComputedStyle(root).getPropertyValue('--fy-sticky-top'))||12;
    return panel.getBoundingClientRect().top<=stickyTop+1;
  }

  function update(){
    ticking=false;
    const y=window.scrollY||window.pageYOffset||0;
    const delta=y-lastY;

    if(Math.abs(delta)<THRESHOLD){return;}

    // Using the filters (typing in search, an open dropdown) keeps it visible.
    if(panel.contains(document.activeElement)){
      panel.classList.remove('is-tucked');
      upTravel=0;
      lastY=y;
      return;
    }

    // Not pinned yet (still in normal flow, above/at its resting spot) —
    // nothing to hide from, and tucking here is what left a phantom gap.
    if(!isPinned()){
      panel.classList.remove('is-tucked');
      upTravel=0;
      lastY=y;
      return;
    }

    if(delta>0){
      panel.classList.add('is-tucked');
      upTravel=0;
    }else{
      upTravel+=-delta;
      if(upTravel>=revealDistance()){
        panel.classList.remove('is-tucked');
      }
    }
    lastY=y;
  }

  window.addEventListener('scroll',()=>{
    if(ticking)return;
    ticking=true;
    window.requestAnimationFrame(update);
  },{passive:true});

  // Focusing anything inside (e.g. tabbing to search) brings it back.
  panel.addEventListener('focusin',()=>panel.classList.remove('is-tucked'));
}

/**
 * Shows the "swipe for more" arrow over the popular-filters strip only
 * while there's genuinely somewhere left to scroll to — never when every
 * button already fits (nothing to point at), and it fades out once you've
 * actually scrolled to the last button (pointing at nothing is worse than
 * no arrow, it reads as broken).
 */
function fyInitFilterRowHint(root){
  const row=root.querySelector('.fy-filter-row');
  const hint=root.querySelector('.fy-filter-row-hint');
  if(!row||!hint)return function(){};

  function update(){
    const overflows=row.scrollWidth>row.clientWidth+1;
    const atEnd=row.scrollLeft+row.clientWidth>=row.scrollWidth-4;
    hint.classList.toggle('is-visible',overflows&&!atEnd);
  }

  row.addEventListener('scroll',update,{passive:true});
  window.addEventListener('resize',update);
  // Fonts/images finishing layout can change scrollWidth after first paint.
  window.addEventListener('load',update);
  setTimeout(update,300);
  update();
  // Exposed so code that hides/shows chips (the Saved Yachts view) can force
  // an immediate recheck instead of waiting on scroll/resize to fire.
  return update;
}

function fyInitFleet(root){
  if(root.getAttribute('data-fy-init')==='1')return;
  root.setAttribute('data-fy-init','1');

  fyUnblockSticky(root);
  fyStickyOffset(root);
  fyAutoHideFilters(root);
  const refreshFilterHint=fyInitFilterRowHint(root);
  // Headers often finish initialising (or shrink) after first paint.
  window.addEventListener('load',()=>fyStickyOffset(root));
  setTimeout(()=>fyStickyOffset(root),600);
  let offsetTimer=null;
  window.addEventListener('resize',()=>{
    clearTimeout(offsetTimer);
    offsetTimer=setTimeout(()=>fyStickyOffset(root),150);
  });

  const grid=root.querySelector('.fy-grid');
  const cards=Array.prototype.slice.call(root.querySelectorAll('.fy-card[data-size]'));
  const sizeButtons=Array.prototype.slice.call(root.querySelectorAll('[data-size-filter]'));
  const sizeSelect=root.querySelector('.fy-size-select');
  const featureButtons=Array.prototype.slice.call(root.querySelectorAll('[data-feature-filter]'));
  const searchInput=root.querySelector('.fy-search');
  // The size dropdown borrows .fy-sort for styling, so exclude it here.
  const sortSelect=root.querySelector('.fy-sort:not(.fy-size-select)');
  const noResults=root.querySelector('[data-fy-no-results]');
  const viewAllWrap=root.querySelector('.fy-view-all-wrap');
  const viewAllButton=root.querySelector('.fy-view-all');
  const viewAllNote=root.querySelector('.fy-view-all-note');
  const mobileViewAll=root.querySelector('.fy-mobile-view-all');
  const clearFilters=root.querySelector('.fy-clear-filters');

  if(!grid||!cards.length)return;

  let activeSize='all';
  let activeFeature='all';
  let fleetExpanded=false;
  let resizeTimer=null;

  const normalize=value=>(value||'').toLowerCase().replace(/[–—]/g,'-').replace(/\s+/g,' ').trim();
  const getInitialLimit=()=>window.innerWidth<=640?6:(window.innerWidth<=1024?10:15);

  // Auto-load state: how many cards are currently revealed, and how many
  // more each scroll-triggered batch adds.
  let visibleLimit=getInitialLimit();
  const getBatchSize=()=>window.innerWidth<=640?6:(window.innerWidth<=1024?8:12);
  const autoLoadSupported='IntersectionObserver' in window;
  let autoStatus=null;
  let lastRemaining=0;
  let revealObserver=null;

  // Fade each card up as it scrolls into view — but only cards that START
  // below the fold. Anything already on screen renders instantly, so nobody
  // waits on an animation to read a price. Runs once per card.
  function primeReveal(list){
    if(!revealObserver)return;
    list.forEach(card=>{
      if(card.dataset.fyReveal)return;
      card.dataset.fyReveal='1';
      if(card.getBoundingClientRect().top < window.innerHeight + 40){
        return; // Already visible: leave it completely alone.
      }
      card.classList.add('fy-reveal');
      revealObserver.observe(card);
    });
  }

  function matchesSize(card){
    return activeSize==='all'||card.dataset.size===activeSize;
  }

  function matchesFeature(card){
    if(activeFeature==='all')return true;
    // "Saved" is per-visitor and changes as they browse, so it is answered
    // from localStorage rather than from the card's server-rendered
    // data-feature list like every other filter.
    if(activeFeature==='saved')return fySavedHas(card.dataset.yachtId);
    const features=normalize(card.dataset.feature).split(/[\s,|]+/).filter(Boolean);
    if(activeFeature==='under-1400')return features.includes('under-1400')||Number(card.dataset.startingPrice)<1400;
    return features.includes(activeFeature);
  }

  function matchesSearch(card){
    const query=normalize(searchInput?searchInput.value:'');
    if(!query)return true;
    const haystack=normalize(card.dataset.search);
    return query.split(' ').every(term=>haystack.includes(term));
  }

  function getSortedCards(matching){
    const mode=sortSelect?sortSelect.value:'price-low';
    return matching.slice().sort((a,b)=>{
      const priceA=Number(a.dataset.startingPrice||0);
      const priceB=Number(b.dataset.startingPrice||0);
      const sizeA=Number(a.dataset.yachtSize||999);
      const sizeB=Number(b.dataset.yachtSize||999);
      const indexA=Number(a.dataset.index||0);
      const indexB=Number(b.dataset.index||0);
      if(mode==='price-low'||mode==='price-high'){
        if((priceA>0)!==(priceB>0))return priceA>0?-1:1;
        return mode==='price-low'?priceA-priceB:priceB-priceA;
      }
      if(mode==='size-small')return sizeA-sizeB;
      if(mode==='size-large')return sizeB-sizeA;
      return indexA-indexB;
    });
  }

  function syncFilterButtons(){
    if(sizeSelect&&sizeSelect.value!==activeSize)sizeSelect.value=activeSize;
    sizeButtons.forEach(button=>{
      const active=button.dataset.sizeFilter===activeSize;
      button.classList.toggle('is-active',active);
      button.setAttribute('aria-pressed',String(active));
    });
    // Viewing your shortlist isn't "another category alongside Pink/2-hour" —
    // those chips don't apply to a personal list and just add clutter, so
    // they hide while Saved Yachts is active. "All styles" stays put (its
    // label swaps to make it read as the way back) as one of two ways out,
    // alongside clicking Saved Yachts again.
    const savedActive=activeFeature==='saved';
    featureButtons.forEach(button=>{
      const filter=button.dataset.featureFilter;
      const active=filter===activeFeature;
      button.classList.toggle('is-active',active);
      button.setAttribute('aria-pressed',String(active));
      if(filter==='all'&&button.dataset.labelSaved){
        button.textContent=savedActive?button.dataset.labelSaved:button.dataset.labelDefault;
      }
      button.hidden=savedActive&&filter!=='all';
    });
    if(typeof refreshFilterHint==='function')refreshFilterHint();
  }

  function applyFilters(){
    syncFilterButtons();
    const matching=cards.filter(card=>matchesSize(card)&&matchesFeature(card)&&matchesSearch(card));
    const sorted=getSortedCards(matching);
    const hasDiscovery=activeSize!=='all'||activeFeature!=='all'||normalize(searchInput?searchInput.value:'')!=='';
    const showAll=fleetExpanded||hasDiscovery;
    const shown=showAll?sorted:sorted.slice(0,Math.max(visibleLimit,getInitialLimit()));

    cards.forEach(card=>{card.hidden=true;});
    sorted.forEach(card=>grid.appendChild(card));
    shown.forEach(card=>{card.hidden=false;});

    primeReveal(shown);

    const remaining=Math.max(0,sorted.length-shown.length);
    lastRemaining=remaining;
    // With auto-load running, the manual "View more" button is redundant —
    // it stays only as the fallback for browsers without IntersectionObserver.
    const shouldShowViewAll=!showAll&&remaining>0&&!autoLoadSupported;
    if(autoStatus){
      // Nothing is loading while this sits idle — it appears the moment a
      // batch is revealed and waits for the next scroll, so word it as a
      // count, not as activity.
      autoStatus.hidden=remaining<1;
      autoStatus.textContent=remaining>0?`${remaining} more yacht${remaining===1?'':'s'} below — keep scrolling`:'';
    }
    if(viewAllWrap&&viewAllButton){
      viewAllWrap.hidden=!shouldShowViewAll;
      viewAllButton.setAttribute('aria-expanded',String(fleetExpanded));
      const lineOne=viewAllButton.querySelector('.fy-view-all-line-one');
      if(lineOne)lineOne.textContent=`View ${remaining} More`;
      viewAllButton.setAttribute('aria-label',`View ${remaining} more Miami yacht rentals`);
      if(viewAllNote)viewAllNote.textContent=`Showing ${shown.length} featured yachts first. Open ${remaining} more options to compare the complete fleet.`;
    }

    if(mobileViewAll){
      mobileViewAll.hidden=!shouldShowViewAll;
      mobileViewAll.setAttribute('aria-expanded',String(fleetExpanded));
      mobileViewAll.textContent=`Showing ${shown.length} of ${sorted.length} yachts · View all`;
    }

    if(noResults){
      noResults.hidden=sorted.length!==0;
      const savedMsg=noResults.querySelector('.fy-no-results-saved');
      const defaultMsg=noResults.querySelector('.fy-no-results-default');
      const showSavedMsg=activeFeature==='saved';
      if(savedMsg)savedMsg.hidden=!showSavedMsg;
      if(defaultMsg)defaultMsg.hidden=showSavedMsg;
    }
  }

  function expandFleet(){
    fleetExpanded=true;
    applyFilters();
  }

  // Filtering 51 yachts down to a handful collapses the page height, and the
  // browser clamps the scroll position to the new maximum — which dumps the
  // visitor at the bottom of the results they just asked for. So after any
  // deliberate filter/sort change, put them back at the top of the grid,
  // parked just under the sticky bar.
  function scrollToResults(){
    const panel=root.querySelector('.fy-inventory-panel')||root;
    const offset=parseInt(window.getComputedStyle(root).getPropertyValue('--fy-sticky-top'),10)||12;
    const target=window.scrollY+panel.getBoundingClientRect().top-offset-8;
    const reduce=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    window.scrollTo({top:Math.max(0,target),behavior:reduce?'auto':'smooth'});
  }

  function filterChanged(){
    visibleLimit=getInitialLimit();
    applyFilters();
    scrollToResults();
  }

  sizeButtons.forEach(button=>button.addEventListener('click',function(){
    activeSize=this.dataset.sizeFilter||'all';
    filterChanged();
  }));

  featureButtons.forEach(button=>button.addEventListener('click',function(){
    const clicked=this.dataset.featureFilter||'all';
    // "Saved" is a personal view, not a category alongside Pink/2-hour/etc —
    // clicking it a second time backs out to "All styles" directly, so
    // getting out doesn't require hunting for a different button. The other
    // filters stay radio-style (clicking the same one again is a no-op),
    // since re-picking a category you're already viewing isn't "get me out
    // of this" the way tapping your own shortlist twice is.
    activeFeature=(clicked==='saved'&&activeFeature==='saved')?'all':clicked;
    filterChanged();
  }));

  if(sizeSelect)sizeSelect.addEventListener('change',function(){
    activeSize=this.value||'all';
    filterChanged();
  });

  // Search deliberately does NOT scroll — jumping the page on every keystroke
  // makes typing unusable. It only re-filters in place.
  if(searchInput)searchInput.addEventListener('input',applyFilters);
  if(sortSelect)sortSelect.addEventListener('change',filterChanged);
  if(viewAllButton)viewAllButton.addEventListener('click',expandFleet);
  if(mobileViewAll)mobileViewAll.addEventListener('click',expandFleet);
  if(clearFilters)clearFilters.addEventListener('click',()=>{
    activeSize='all';
    activeFeature='all';
    fleetExpanded=false;
    if(searchInput)searchInput.value='';
    if(sortSelect)sortSelect.value='price-low';
    filterChanged();
  });

  // Reveal observer must exist before the first applyFilters() run.
  if(autoLoadSupported&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches){
    revealObserver=new IntersectionObserver(entries=>{
      entries.forEach(entry=>{
        if(!entry.isIntersecting)return;
        entry.target.classList.add('fy-in');
        revealObserver.unobserve(entry.target);
      });
    },{rootMargin:'0px 0px -40px 0px'});
  }

  // ---- Auto-load on scroll --------------------------------------------
  // A 1px tripwire sits just below the grid. Once it comes within 400px of
  // the viewport the next batch is revealed, and again on the next scroll,
  // until every matching yacht is on screen — no button to press.
  if(autoLoadSupported){
    autoStatus=document.createElement('p');
    autoStatus.className='fy-autoload-status';
    autoStatus.setAttribute('aria-live','polite');
    autoStatus.hidden=true;

    const sentinel=document.createElement('div');
    sentinel.className='fy-autoload-sentinel';
    sentinel.setAttribute('aria-hidden','true');

    grid.parentNode.insertBefore(autoStatus,grid.nextSibling);
    grid.parentNode.insertBefore(sentinel,autoStatus.nextSibling);

    new IntersectionObserver(entries=>{
      if(!entries[0].isIntersecting)return;
      if(lastRemaining<1)return; // Everything is already shown.
      visibleLimit+=getBatchSize();
      applyFilters();
    },{rootMargin:'400px 0px'}).observe(sentinel);
  }

  root.addEventListener('toggle',event=>{
    const opened=event.target;
    if(!(opened instanceof HTMLDetailsElement)||!opened.open||!opened.classList.contains('fy-pricing-details'))return;
    root.querySelectorAll('.fy-pricing-details[open]').forEach(details=>{
      if(details!==opened)details.removeAttribute('open');
    });
  },true);

  window.addEventListener('resize',()=>{
    if(fleetExpanded)return;
    clearTimeout(resizeTimer);
    resizeTimer=setTimeout(applyFilters,120);
  });

  // Saving/unsaving from a card's heart.
  root.addEventListener('click',event=>{
    const btn=event.target.closest?event.target.closest('[data-fy-save]'):null;
    if(!btn)return;
    event.preventDefault();
    fySavedToggle(btn.getAttribute('data-fy-save'));
    fySavedNotify();
  });

  // Fired by any heart, including the one inside the photo popup (which
  // sits on <body>, outside this grid). Elementor's editor destroys and
  // rebuilds a widget's whole DOM subtree on every re-render, so this can
  // run again on a fresh .fy-fleet-root without the old one ever being
  // removed from the page — document.contains() turns that leftover
  // listener into a no-op instead of quietly re-filtering and repainting
  // a grid nobody can see anymore.
  document.addEventListener('fy_saved_changed',()=>{
    if(!document.contains(root))return;
    // Unsaving the last yacht while viewing the shortlist would leave an
    // empty grid with no obvious way back, so fall back to showing all.
    if(activeFeature==='saved'&&!fySavedList().length){activeFeature='all';}
    applyFilters();
    fySavedSync(document);
  });

  fySavedSync(root);
  applyFilters();
}

// [fy_yacht_details] tab switching — Special / Yacht Specs / Hours /
// Add-Ons / Location. Plain click-to-show/hide, no framework needed.
function fyInitDetailTabs(root){
  var groups=root.querySelectorAll('[data-fy-dt]');
  for(var g=0;g<groups.length;g++){
    var group=groups[g];
    if(group.dataset.fyDtBound)continue;
    group.dataset.fyDtBound='1';
    group.addEventListener('click',function(event){
      var btn=event.target.closest('[data-fy-dt-tab]');
      if(!btn)return;
      var group=btn.closest('[data-fy-dt]');
      var tabs=group.querySelectorAll('.fy-dt-tab');
      var panels=group.querySelectorAll('.fy-dt-panel');
      for(var i=0;i<tabs.length;i++){
        var active=tabs[i]===btn;
        tabs[i].classList.toggle('fy-dt-tab--active',active);
        tabs[i].setAttribute('aria-selected',active?'true':'false');
      }
      for(var j=0;j<panels.length;j++){
        var match=panels[j].id===btn.getAttribute('aria-controls');
        panels[j].classList.toggle('fy-dt-panel--active',match);
        if(match){panels[j].removeAttribute('hidden');}else{panels[j].setAttribute('hidden','');}
      }
    });
  }
}

/* ---------------------------------------------------------------------------
   Saved yachts ("shortlist").

   Someone comparing five yachts across ~180 cards otherwise has to keep five
   browser tabs open. Saving is deliberately anonymous: the list is just yacht
   IDs in this browser's localStorage — no account, no cookie, nothing sent to
   the server — so it costs the visitor nothing to start using and there is no
   personal data to look after.
--------------------------------------------------------------------------- */
var FY_SAVED_KEY='fyFleetSaved';

function fySavedList(){
  try{
    var raw=window.localStorage.getItem(FY_SAVED_KEY);
    var list=raw?JSON.parse(raw):[];
    return Object.prototype.toString.call(list)==='[object Array]'
      ? list.map(String).filter(Boolean) : [];
  }catch(e){
    // Private-browsing modes and blocked storage throw on access. Saving
    // simply does nothing in that case; the rest of the grid is unaffected.
    return [];
  }
}

function fySavedHas(id){
  return fySavedList().indexOf(String(id))>-1;
}

function fySavedToggle(id){
  id=String(id);
  var list=fySavedList();
  var at=list.indexOf(id);
  if(at>-1){list.splice(at,1);}else{list.push(id);}
  try{ window.localStorage.setItem(FY_SAVED_KEY,JSON.stringify(list)); }catch(e){}
  return at===-1; // true when it is now saved
}

/**
 * Announce that the shortlist changed. Every fleet grid on the page
 * re-filters and then repaints, in that order — the chip's own pressed
 * state is only settled by applyFilters(), so repainting before it would
 * leave a stale "Saved (0)" chip on screen. Sent as an event because the
 * popup lives on <body>, outside any one grid's scope.
 */
function fySavedNotify(){
  document.dispatchEvent(new CustomEvent('fy_saved_changed'));
  // Nothing is listening when the popup is used on a page with no grid,
  // so repaint here too; a grid, if present, repaints again after filtering.
  fySavedSync(document);
}

/** Repaint every heart and the "Saved (n)" chip from the stored list. */
function fySavedSync(root){
  var scope=root||document;
  var list=fySavedList();
  var count=list.length;

  Array.prototype.forEach.call(scope.querySelectorAll('[data-fy-save]'),function(btn){
    var on=list.indexOf(String(btn.getAttribute('data-fy-save')))>-1;
    btn.classList.toggle('is-saved',on);
    btn.setAttribute('aria-pressed',String(on));
    var icon=btn.querySelector('.fy-save-toggle__icon');
    if(icon){icon.textContent=on?'♥':'♡';}
  });

  Array.prototype.forEach.call(scope.querySelectorAll('.fy-saved-filter'),function(chip){
    var num=chip.querySelector('.fy-saved-count');
    if(num){num.textContent=count;}
  });

  // The sticky-bar "N saved" link (product pages, no grid of their own to
  // filter) — front-extras.js renders it hidden with count 0; this is the
  // only place its count and visibility actually get set.
  Array.prototype.forEach.call(scope.querySelectorAll('[data-fy-saved-trigger]'),function(trigger){
    var num=trigger.querySelector('.fy-saved-count');
    if(num){num.textContent=count;}
    trigger.hidden=count===0;
  });
}

/* ---------------------------------------------------------------------------
   Fleet grid photo lightbox.

   Clicking a card's PHOTO opens that yacht's own photos over the grid, so a
   visitor can look through a boat without losing their place in the list.
   Clicking the card's button still goes to the product page, unchanged.

   Photos are fetched when the gallery is opened, never up front: a city page
   lists ~180 yachts and one yacht can carry 40+ photos.
--------------------------------------------------------------------------- */
var fyPhotoCache={},fyPhotoState={photos:[],index:0,opener:null,lastSwipeAt:0};

function fyPhotoFetch(yachtId){
  if(fyPhotoCache[yachtId])return fyPhotoCache[yachtId];
  var cfg=window.fyFleetPhotos||{};
  if(!cfg.ajaxUrl||!window.fetch)return Promise.reject(new Error('unsupported'));
  var url=cfg.ajaxUrl+'?action=fy_yacht_photos&yacht='+encodeURIComponent(yachtId)+
          '&nonce='+encodeURIComponent(cfg.nonce||'');
  fyPhotoCache[yachtId]=fetch(url,{credentials:'same-origin'})
    .then(function(res){return res.json();})
    .then(function(body){
      if(!body||!body.success||!body.data||!body.data.photos||!body.data.photos.length){
        throw new Error('empty');
      }
      return body.data;
    })
    .catch(function(err){
      // Don't cache a failure — a flaky request shouldn't disable the
      // gallery for the rest of the visit.
      delete fyPhotoCache[yachtId];
      throw err;
    });
  return fyPhotoCache[yachtId];
}

function fyPhotoBox(){
  if(fyPhotoBox.el)return fyPhotoBox.el;

  var box=document.createElement('div');
  box.className='fy-plb';
  box.id='fy-photo-lightbox';
  box.hidden=true;
  box.setAttribute('role','dialog');
  box.setAttribute('aria-modal','true');
  box.setAttribute('aria-label','Yacht photos');
  box.innerHTML=
    '<div class="fy-plb__backdrop" data-fy-plb-close></div>'+
    '<div class="fy-plb__panel">'+
      '<div class="fy-plb__head">'+
        '<span class="fy-plb__name"></span>'+
        '<button type="button" class="fy-plb__save" data-fy-save="" aria-pressed="false" aria-label="Save this yacht to compare later">'+
          '<span class="fy-save-toggle__icon" aria-hidden="true">&#9825;</span>'+
          '<span class="fy-plb__save-text">Save</span>'+
        '</button>'+
        '<button type="button" class="fy-plb__close" data-fy-plb-close aria-label="Close photos">&times;</button>'+
      '</div>'+
      '<div class="fy-plb__stage">'+
        // .fy-plb__frame shrink-wraps to the image's own rendered size (not
        // the full stage width), so the prev/next buttons — positioned
        // absolute within it — sit right on the photo's edges instead of
        // floating out in the letterboxed space beside a portrait photo.
        '<div class="fy-plb__frame">'+
          '<button type="button" class="fy-plb__nav fy-plb__prev" aria-label="Previous photo">&lsaquo;</button>'+
          '<img class="fy-plb__img" src="" alt="" hidden>'+
          '<button type="button" class="fy-plb__nav fy-plb__next" aria-label="Next photo">&rsaquo;</button>'+
        '</div>'+
        '<p class="fy-plb__status">Loading photos&hellip;</p>'+
      '</div>'+
      '<div class="fy-plb__foot">'+
        '<span class="fy-plb__count"></span>'+
        '<a class="fy-plb__cta" href="#">'+
          '<span class="fy-plb__cta-main">Book this yacht</span>'+
          '<span class="fy-plb__cta-sub">Check dates, prices &amp; availability</span>'+
        '</a>'+
      '</div>'+
    '</div>';
  document.body.appendChild(box);
  fyPhotoBox.el=box;

  box.addEventListener('click',function(event){
    if(event.target.closest('[data-fy-plb-close]')){fyPhotoClose();return;}
    if(event.target.closest('.fy-plb__prev')){fyPhotoShow(fyPhotoState.index-1);return;}
    if(event.target.closest('.fy-plb__next')){fyPhotoShow(fyPhotoState.index+1);return;}
    // Tapping/clicking the photo itself also advances — the arrows stay as
    // the precise, discoverable control, this is the fast path for anyone
    // just flicking through, same as most gallery apps. Wraps past the last
    // photo back to the first (fyPhotoShow does the modulo).
    if(event.target.closest('.fy-plb__img')){
      // A touchscreen swipe is followed by a SYNTHETIC click on the same
      // element a moment later. Without this guard that click advanced a
      // second time, so every swipe on a phone skipped a photo (verified:
      // 2 of 3 -> 3 of 3 -> 1 of 3 from one swipe).
      if(Date.now()-fyPhotoState.lastSwipeAt<600)return;
      fyPhotoShow(fyPhotoState.index+1);
      return;
    }
    var save=event.target.closest('.fy-plb__save');
    if(save){
      var id=save.getAttribute('data-fy-save');
      if(!id)return;
      var nowSaved=fySavedToggle(id);
      // The card heart behind the popup, the "Saved (n)" chip and the
      // grid itself all have to agree with what the visitor just did here.
      fySavedNotify();
      var label=save.querySelector('.fy-plb__save-text');
      if(label){label.textContent=nowSaved?'Saved':'Save';}
    }
  });

  var touchX=null;
  box.addEventListener('touchstart',function(event){touchX=event.touches[0].clientX;},{passive:true});
  box.addEventListener('touchend',function(event){
    if(touchX===null)return;
    var moved=event.changedTouches[0].clientX-touchX;
    if(Math.abs(moved)>40){
      // Stamped so the synthetic click this gesture is about to produce
      // can be ignored by the image's click handler above.
      fyPhotoState.lastSwipeAt=Date.now();
      fyPhotoShow(fyPhotoState.index+(moved<0?1:-1));
    }
    touchX=null;
  },{passive:true});

  document.addEventListener('keydown',function(event){
    if(box.hidden)return;
    if(event.key==='Escape'){fyPhotoClose();}
    else if(event.key==='ArrowLeft'){fyPhotoShow(fyPhotoState.index-1);}
    else if(event.key==='ArrowRight'){fyPhotoShow(fyPhotoState.index+1);}
    else if(event.key==='Tab'){
      // Keep keyboard focus inside the dialog while it's open.
      var stops=box.querySelectorAll('button:not([hidden]),a[href]:not([hidden])');
      if(!stops.length)return;
      var first=stops[0],last=stops[stops.length-1];
      if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
      else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
    }
  });

  return box;
}

function fyPhotoShow(index){
  var box=fyPhotoBox(),photos=fyPhotoState.photos;
  if(!photos.length)return;

  fyPhotoState.index=(index+photos.length)%photos.length;
  var photo=photos[fyPhotoState.index];
  var img=box.querySelector('.fy-plb__img');

  img.src=photo.url;
  if(photo.srcset){img.srcset=photo.srcset;}else{img.removeAttribute('srcset');}
  img.alt=photo.alt||'';
  img.hidden=false;

  box.querySelector('.fy-plb__status').hidden=true;
  box.querySelector('.fy-plb__count').textContent=(fyPhotoState.index+1)+' of '+photos.length;

  var solo=photos.length<2;
  box.querySelector('.fy-plb__prev').hidden=solo;
  box.querySelector('.fy-plb__next').hidden=solo;

  // Warm the neighbours so arrow-tapping feels instant.
  [1,-1].forEach(function(step){
    var next=photos[(fyPhotoState.index+step+photos.length)%photos.length];
    if(next){var pre=new Image();pre.src=next.url;}
  });
}

function fyPhotoClose(){
  var box=fyPhotoBox();
  box.hidden=true;
  // Only overflow-Y is ours to clear. Setting the "overflow" shorthand here
  // would also wipe fyUnblockSticky's "overflow-x:clip !important" (the
  // fix that lets the filter panel stick at all) — clearing the whole
  // shorthand drops every longhand it touches, not just the one this
  // function set.
  document.documentElement.style.removeProperty('overflow-y');
  document.body.style.removeProperty('overflow-y');
  document.body.classList.remove('fy-plb-open');
  fyPhotoState.photos=[];
  if(fyPhotoState.opener&&document.contains(fyPhotoState.opener)){
    fyPhotoState.opener.focus();
  }
  fyPhotoState.opener=null;
}

function fyPhotoOpen(trigger){
  var box=fyPhotoBox();
  var yachtId=trigger.getAttribute('data-fy-photos');
  var name=trigger.getAttribute('data-fy-name')||'';
  var link=trigger.getAttribute('data-fy-url')||'';

  fyPhotoState.opener=trigger;
  fyPhotoState.photos=[];
  fyPhotoState.index=0;

  // Point the popup's heart at the yacht being viewed, and show whether
  // it is already on the visitor's shortlist.
  var save=box.querySelector('.fy-plb__save');
  if(save){
    save.setAttribute('data-fy-save',yachtId||'');
    save.hidden=!yachtId;
    var saved=yachtId?fySavedHas(yachtId):false;
    var saveText=save.querySelector('.fy-plb__save-text');
    if(saveText){saveText.textContent=saved?'Saved':'Save';}
    save.classList.toggle('is-saved',saved);
    save.setAttribute('aria-pressed',String(saved));
    var saveIcon=save.querySelector('.fy-save-toggle__icon');
    if(saveIcon){saveIcon.textContent=saved?'♥':'♡';}
  }

  box.querySelector('.fy-plb__name').textContent=name;
  box.querySelector('.fy-plb__count').textContent='';
  box.querySelector('.fy-plb__img').hidden=true;
  box.querySelector('.fy-plb__prev').hidden=true;
  box.querySelector('.fy-plb__next').hidden=true;

  var status=box.querySelector('.fy-plb__status');
  status.hidden=false;
  status.textContent='Loading photos…';

  var cta=box.querySelector('.fy-plb__cta');
  if(link){
    cta.href=link;
    cta.hidden=false;
    var ctaMain=cta.querySelector('.fy-plb__cta-main');
    if(ctaMain){
      // Long names ("50ft Sea Ray Sundancer FANTASEA…") would wrap the pill
      // into a block, so trim on a word boundary rather than mid-word.
      var shortName=name.length>24?name.slice(0,24).replace(/\s+\S*$/,'')+'…':name;
      ctaMain.textContent=shortName?('Book '+shortName):'Book this yacht';
    }
    cta.setAttribute('aria-label',name?('Book '+name+' — check dates, prices and availability'):'Book this yacht');
  }
  else{cta.hidden=true;cta.removeAttribute('href');}

  box.hidden=false;
  // overflow-Y only — see the matching comment in fyPhotoClose().
  document.documentElement.style.setProperty('overflow-y','hidden');
  document.body.style.setProperty('overflow-y','hidden');
  // The Call/SMS/WhatsApp bar (from a different, site-wide plugin, not
  // this one) is pinned to the same bottom edge on phones as the popup's
  // own prev/next arrows and "See <yacht>" button — hide it for as long as
  // the popup is open so the two don't sit on top of each other.
  document.body.classList.add('fy-plb-open');
  box.querySelector('.fy-plb__close').focus();

  fyPhotoFetch(yachtId).then(function(data){
    // The visitor may have closed the gallery, or opened a different yacht,
    // while this request was still in flight.
    if(box.hidden||fyPhotoState.opener!==trigger)return;
    fyPhotoState.photos=data.photos;
    if(data.title){box.querySelector('.fy-plb__name').textContent=data.title;}
    fyPhotoShow(0);
  }).catch(function(){
    if(box.hidden||fyPhotoState.opener!==trigger)return;
    status.hidden=false;
    status.textContent=link
      ? 'Photos couldn’t load right now — open the yacht page below to see them.'
      : 'Photos couldn’t load right now. Please try again.';
  });
}

function fyInitPhotoLightbox(){
  if(fyInitPhotoLightbox.bound)return;
  fyInitPhotoLightbox.bound=true;

  document.addEventListener('click',function(event){
    var trigger=event.target.closest?event.target.closest('.fy-photo-open'):null;
    if(!trigger)return;
    event.preventDefault();
    fyPhotoOpen(trigger);
  });

  // Start fetching as soon as someone hovers the photo, so the gallery is
  // usually already loaded by the time they actually click. Debounced: each
  // request is a full WordPress + WooCommerce boot, and a mouse sweeping
  // across a page of ~180 cards would otherwise fire one per card passed.
  var hoverTimer=null;
  document.addEventListener('mouseover',function(event){
    var trigger=event.target.closest?event.target.closest('.fy-photo-open'):null;
    if(!trigger){clearTimeout(hoverTimer);return;}
    var id=trigger.getAttribute('data-fy-photos');
    if(!id||fyPhotoCache[id])return;
    clearTimeout(hoverTimer);
    hoverTimer=setTimeout(function(){fyPhotoFetch(id).catch(function(){});},150);
  });
}

/* ---------------------------------------------------------------------------
   Saved-yachts popup.

   The shortlist itself (fySavedList()) is only ever a list of IDs in
   localStorage — turning those into something showable (name, price,
   photo) needs the server, which matters most on a product page: there is
   no fleet grid there to read a card's details from directly, so a visitor
   who saved 5 yachts while browsing had no way back to that list without
   returning to the grid. Opens over whatever page it's triggered from.
---------------------------------------------------------------------------- */
function fySavedPopupBox(){
  if(fySavedPopupBox.el)return fySavedPopupBox.el;

  var box=document.createElement('div');
  box.className='fy-plb fy-svp';
  box.id='fy-saved-popup';
  box.hidden=true;
  box.setAttribute('role','dialog');
  box.setAttribute('aria-modal','true');
  box.setAttribute('aria-label','Your saved yachts');
  box.innerHTML=
    '<div class="fy-plb__backdrop" data-fy-plb-close></div>'+
    '<div class="fy-plb__panel fy-svp__panel">'+
      '<div class="fy-plb__head">'+
        '<span class="fy-plb__name">Your Saved Yachts</span>'+
        '<button type="button" class="fy-plb__close" data-fy-plb-close aria-label="Close saved yachts">&times;</button>'+
      '</div>'+
      '<div class="fy-svp__body">'+
        '<p class="fy-svp__status">Loading your saved yachts&hellip;</p>'+
        '<ul class="fy-svp__list" hidden></ul>'+
      '</div>'+
    '</div>';
  document.body.appendChild(box);
  fySavedPopupBox.el=box;

  box.addEventListener('click',function(event){
    if(event.target.closest('[data-fy-plb-close]')){fySavedPopupClose();return;}
    var remove=event.target.closest('.fy-svp__remove');
    if(remove){
      var id=remove.getAttribute('data-fy-save');
      if(!id)return;
      fySavedToggle(id); // always removes here — items are only ever "saved" in this list
      fySavedNotify();
      // Drop just that row rather than refetching everyone else's data again.
      var li=remove.closest('.fy-svp__item');
      if(li)li.remove();
      fySavedPopupRenderEmptyIfNeeded();
    }
  });

  document.addEventListener('keydown',function(event){
    if(box.hidden)return;
    if(event.key==='Escape'){fySavedPopupClose();}
    else if(event.key==='Tab'){
      var stops=box.querySelectorAll('button:not([hidden]),a[href]:not([hidden])');
      if(!stops.length)return;
      var first=stops[0],last=stops[stops.length-1];
      if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
      else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
    }
  });

  return box;
}

/** Removing the last saved yacht from inside the popup should say so, not sit empty. */
function fySavedPopupRenderEmptyIfNeeded(){
  var box=fySavedPopupBox.el;
  if(!box)return;
  var list=box.querySelector('.fy-svp__list');
  if(list&&!list.hidden&&!list.children.length){
    fySavedPopupRenderEmpty();
  }
}

function fySavedPopupRenderEmpty(){
  var box=fySavedPopupBox();
  var status=box.querySelector('.fy-svp__status');
  var list=box.querySelector('.fy-svp__list');
  list.hidden=true;
  status.hidden=false;
  status.textContent='You haven’t saved any yachts yet — tap the ♡ on a photo to add one to your shortlist.';
}

function fySavedPopupOpen(trigger){
  var box=fySavedPopupBox();
  fySavedPopupState.opener=trigger||null;

  box.hidden=false;
  document.documentElement.style.setProperty('overflow-y','hidden');
  document.body.style.setProperty('overflow-y','hidden');
  document.body.classList.add('fy-plb-open'); // also tucks the mobile Call/SMS/WhatsApp bar, same as the photo popup
  box.querySelector('.fy-plb__close').focus();

  var ids=fySavedList();
  var status=box.querySelector('.fy-svp__status');
  var list=box.querySelector('.fy-svp__list');
  list.hidden=true;
  list.innerHTML='';

  if(!ids.length){
    fySavedPopupRenderEmpty();
    return;
  }

  status.hidden=false;
  status.textContent='Loading your saved yachts…';

  var data=(typeof fySavedPopupData!=='undefined')?fySavedPopupData:{ajaxUrl:'',nonce:''};
  var body='action=fy_saved_summary&nonce='+encodeURIComponent(data.nonce)+
    ids.map(function(id){return '&ids[]='+encodeURIComponent(id);}).join('');

  fetch(data.ajaxUrl,{method:'POST',credentials:'same-origin',
    headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body})
    .then(function(r){return r.json();})
    .then(function(res){
      if(box.hidden)return; // closed while the request was in flight
      var items=(res&&res.success&&res.data&&res.data.items)?res.data.items:[];
      if(!items.length){fySavedPopupRenderEmpty();return;}
      status.hidden=true;
      list.hidden=false;
      list.innerHTML=items.map(function(item){
        var priceLine=item.price?(item.price+(item.unit?' '+item.unit:'')):'';
        return '<li class="fy-svp__item">'+
          '<a class="fy-svp__thumb" href="'+esc(item.url||'#')+'">'+
            (item.image?'<img src="'+esc(item.image)+'" alt="" loading="lazy">':'')+
          '</a>'+
          '<div class="fy-svp__info">'+
            '<a class="fy-svp__title" href="'+esc(item.url||'#')+'">'+esc(item.title||'')+'</a>'+
            (priceLine?'<span class="fy-svp__price">'+esc(priceLine)+'</span>':'')+
          '</div>'+
          '<button type="button" class="fy-svp__remove" data-fy-save="'+esc(item.id)+'" aria-label="Remove '+esc(item.title||'this yacht')+' from saved">✕</button>'+
        '</li>';
      }).join('');
    })
    .catch(function(){
      if(box.hidden)return;
      status.hidden=false;
      status.textContent='Couldn’t load your saved yachts right now — please try again.';
    });
}

function fySavedPopupClose(){
  var box=fySavedPopupBox.el;
  if(!box)return;
  box.hidden=true;
  document.documentElement.style.removeProperty('overflow-y');
  document.body.style.removeProperty('overflow-y');
  document.body.classList.remove('fy-plb-open');
  if(fySavedPopupState.opener&&document.contains(fySavedPopupState.opener)){
    fySavedPopupState.opener.focus();
  }
  fySavedPopupState.opener=null;
}

/** Minimal HTML-escape for the strings this popup builds itself from AJAX JSON. */
function esc(s){
  return String(s==null?'':s).replace(/[&<>"']/g,function(c){
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
  });
}

var fySavedPopupState={opener:null};

function fyInitSavedPopup(){
  if(fyInitSavedPopup.bound)return;
  fyInitSavedPopup.bound=true;

  document.addEventListener('click',function(event){
    var trigger=event.target.closest?event.target.closest('[data-fy-saved-trigger]'):null;
    if(!trigger)return;
    event.preventDefault();
    fySavedPopupOpen(trigger);
  });
}

/* ---------------------------------------------------------------------------
   "Your Saved Yachts" section (product pages).

   Server-rendered heading/description (crawlable, always accurate), list
   filled in here from the SAME fy_saved_summary endpoint the popup and the
   account portal use — so this can never drift out of sync with the hearts
   on the fleet grid. Hidden entirely when the shortlist is empty.
---------------------------------------------------------------------------- */
/**
 * The section is normally printed server-side on
 * woocommerce_after_single_product_summary. But an Elementor-built product
 * page renders WooCommerce's parts as widgets and never fires that hook —
 * confirmed on the live site, where the same bypass hides the related
 * products block. So on a single-product page with no section present,
 * build it here instead. Same markup, same classes, same behaviour.
 */
function fySavedSectionEnsure(){
  var existing=document.getElementById('fy-saved-yachts');
  if(existing)return existing;
  if(!document.body.classList.contains('single-product'))return null;
  if(typeof fySavedSectionData==='undefined')return null;

  var section=document.createElement('section');
  section.className='fy-saved-section';
  section.id='fy-saved-yachts';
  section.hidden=true;
  section.setAttribute('aria-labelledby','fy-saved-section-title');
  section.innerHTML=
    '<div class="fy-saved-section__head">'+
      '<h2 class="fy-saved-section__title" id="fy-saved-section-title">'+esc(fySavedSectionData.title)+'</h2>'+
      '<p class="fy-saved-section__desc">'+esc(fySavedSectionData.desc)+'</p>'+
    '</div>'+
    '<ul class="fy-saved-section__grid"></ul>'+
    '<div class="fy-saved-section__foot">'+
      '<a class="fy-saved-section__browse" href="'+esc(fySavedSectionData.fleetUrl)+'">'+esc(fySavedSectionData.browse)+'</a>'+
    '</div>';

  // Right after the summary/add-to-cart form and BEFORE the Description
  // tab's yacht specs — matches class-fy-woo.php's server-rendered position
  // (priority 5, ahead of the tabs at 10) so this Elementor-bypass fallback
  // reads the same: this yacht → your saved ones → yacht details → other
  // suggestions. Falls back to right before the related-products row, then
  // to the end of the main content area, if a page has no tabs block at all.
  var anchor=document.querySelector('.woocommerce-tabs, .elementor-widget-woocommerce-product-additional-information, .related, .up-sells, .elementor-widget-woocommerce-product-related');
  if(anchor&&anchor.parentNode){anchor.parentNode.insertBefore(section,anchor);}
  else{
    var main=document.querySelector('main, .site-main, #content, .elementor-location-single')||document.body;
    main.appendChild(section);
  }
  return section;
}

function fySavedSectionRender(){
  var section=fySavedSectionEnsure();
  if(!section)return;
  var grid=section.querySelector('.fy-saved-section__grid');
  var ids=fySavedList();

  if(!ids.length){section.hidden=true;grid.innerHTML='';return;}

  var data=(typeof fySavedPopupData!=='undefined')?fySavedPopupData:{ajaxUrl:'',nonce:''};
  var body='action=fy_saved_summary&nonce='+encodeURIComponent(data.nonce)+
    ids.map(function(id){return '&ids[]='+encodeURIComponent(id);}).join('');

  fetch(data.ajaxUrl,{method:'POST',credentials:'same-origin',
    headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body})
    .then(function(r){return r.json();})
    .then(function(res){
      var items=(res&&res.success&&res.data&&res.data.items)?res.data.items:[];
      if(!items.length){section.hidden=true;grid.innerHTML='';return;}
      // Already sorted cheapest-first server-side (ajax_saved_summary).
      grid.innerHTML=items.map(function(item){
        var priceLine=item.price?(item.price+(item.unit?' '+item.unit:'')):'';
        return '<li class="fy-saved-card">'+
          '<a class="fy-saved-card__link" href="'+esc(item.url||'#')+'">'+
            (item.image?'<span class="fy-saved-card__media"><img src="'+esc(item.image)+'" alt="'+esc(item.title||'')+'" loading="lazy"></span>':'')+
            '<span class="fy-saved-card__body">'+
              '<span class="fy-saved-card__name">'+esc(item.title||'')+'</span>'+
              (priceLine?'<span class="fy-saved-card__price">'+esc(priceLine)+'</span>':'')+
            '</span>'+
          '</a>'+
          '<button type="button" class="fy-saved-card__remove" data-fy-save="'+esc(item.id)+'" aria-label="Remove '+esc(item.title||'this yacht')+' from your saved list">✕ Remove</button>'+
        '</li>';
      }).join('');
      section.hidden=false;
    })
    .catch(function(){ section.hidden=true; });
}

function fyInitSavedSection(){
  if(fyInitSavedSection.bound)return;
  fyInitSavedSection.bound=true;

  document.addEventListener('click',function(event){
    var btn=event.target.closest?event.target.closest('.fy-saved-card__remove'):null;
    if(!btn)return;
    event.preventDefault();
    var id=btn.getAttribute('data-fy-save');
    if(!id)return;
    fySavedToggle(id);
    // Notifies the grid hearts, the "N saved" chip and the sticky bar; the
    // listener below then re-renders this section from the new list.
    fySavedNotify();
  });

  // Any save/unsave anywhere on the page rebuilds this section, so it stays
  // identical to what the popup and the account portal would show.
  document.addEventListener('fy_saved_changed',fySavedSectionRender);

  fySavedSectionRender();
}

function fyInitAll(){
  var roots=document.querySelectorAll('.fy-fleet-root');
  for(var i=0;i<roots.length;i++){fyInitFleet(roots[i]);}
  fyInitDetailTabs(document);
  fyInitPhotoLightbox();
  fyInitSavedPopup();
  fyInitSavedSection();
  // fyInitFleet() already syncs hearts/chips for pages that have a grid;
  // a product page has none, so its sticky-bar "N saved" trigger and any
  // stray heart on the page would otherwise never get their real count on
  // first load.
  fySavedSync(document);
}

if(document.readyState==='loading'){
  document.addEventListener('DOMContentLoaded',fyInitAll);
}else{
  fyInitAll();
}
// Re-scan after full load and after Elementor re-renders a widget in the editor.
window.addEventListener('load',fyInitAll);
if(window.jQuery){
  jQuery(window).on('elementor/frontend/init',fyInitAll);
  jQuery(document).on('elementor/popup/show',fyInitAll);
}
})();