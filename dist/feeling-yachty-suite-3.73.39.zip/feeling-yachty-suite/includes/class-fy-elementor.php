<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class FY_Fleet_Elementor {

	public static function init() {
		add_action( 'elementor/widgets/register', array( __CLASS__, 'register_widget' ) );
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'register_category' ) );
	}

	public static function register_category( $elements_manager ) {
		$elements_manager->add_category(
			'feeling-yachty',
			array(
				'title' => __( 'Feeling Yachty', 'fy-fleet' ),
				'icon'  => 'fa fa-ship',
			)
		);
	}

	public static function register_widget( $widgets_manager ) {
		if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
			return;
		}
		require_once FY_FLEET_DIR . 'includes/elementor/widget-yacht-fleet.php';
		$widgets_manager->register( new \FY_Fleet_Elementor_Widget() );
	}
}
