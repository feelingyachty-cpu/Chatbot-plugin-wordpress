<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WooCommerce bridge.
 *
 * Each yacht is mirrored to a hidden WooCommerce product so that Woo handles
 * the cart, checkout, payment gateways (Stripe/PayPal), taxes, emails, refunds
 * and reporting. The line price charged is the deposit; the full charter total
 * and the balance due at the dock ride along as order item meta.
 */
class FY_Fleet_Woo {

	public static function init() {
		add_action( 'before_woocommerce_init', array( __CLASS__, 'declare_hpos_compatibility' ) );

		if ( ! self::active() ) {
			return;
		}

		// Fill smart defaults first (button URL, featured image), then sync the
		// product so it picks those defaults up in the same save.
		add_action( 'save_post_' . FY_Fleet_CPT::POST_TYPE, array( __CLASS__, 'fill_defaults' ), 15, 2 );
		add_action( 'save_post_' . FY_Fleet_CPT::POST_TYPE, array( __CLASS__, 'sync_product' ), 20, 2 );
		add_action( 'trashed_post', array( __CLASS__, 'on_yacht_trashed' ) );

		// One-time auto-rollout of the new [fy_yacht_details] tabs to every
		// existing yacht, so the owner doesn't have to click "Sync All
		// Products" by hand. Runs once on an admin page load only — never on
		// the public site, so a real visitor never waits on it.
		add_action( 'admin_init', array( __CLASS__, 'maybe_auto_sync_details_tabs' ) );
		// WooCommerce sends customers away from wp-admin. If My Account is
		// the homepage (or login landed on a customer session), opening
		// Plugins looks like "it dumped me on the home page." Staff who can
		// manage plugins or the fleet stay in wp-admin.
		add_filter( 'woocommerce_prevent_admin_access', array( __CLASS__, 'allow_staff_admin_access' ), 99 );
		add_filter( 'login_redirect', array( __CLASS__, 'keep_admin_login_in_admin' ), 99, 3 );

		// The plugin's own date/start-time inputs, so the booking UI no longer
		// depends on the theme rendering them (see render_schedule_fields).
		add_action( 'woocommerce_before_add_to_cart_button', array( __CLASS__, 'render_schedule_fields' ), 5 );

		// Booking line pricing.
		add_filter( 'woocommerce_add_cart_item_data', array( __CLASS__, 'keep_unique' ), 10, 3 );
		add_action( 'woocommerce_before_calculate_totals', array( __CLASS__, 'apply_deposit_price' ), 20 );
		add_filter( 'woocommerce_get_item_data', array( __CLASS__, 'cart_item_meta' ), 10, 2 );
		add_action( 'woocommerce_checkout_create_order_line_item', array( __CLASS__, 'order_line_meta' ), 10, 4 );

		// One booking per line; quantity is meaningless here.
		add_filter( 'woocommerce_is_sold_individually', array( __CLASS__, 'sold_individually' ), 10, 2 );

		// Totals table rows (must be <tr> — these hooks fire inside the table).
		add_action( 'woocommerce_cart_totals_after_order_total', array( __CLASS__, 'balance_row' ) );
		add_action( 'woocommerce_review_order_after_order_total', array( __CLASS__, 'balance_row' ) );

		// Side-by-side "pay now vs pay at dock" panel.
		add_action( 'woocommerce_after_cart_totals', array( __CLASS__, 'payment_split_panel' ) );
		add_action( 'woocommerce_checkout_before_order_review', array( __CLASS__, 'payment_split_panel' ) );
		add_action( 'woocommerce_thankyou', array( __CLASS__, 'thankyou_balance' ), 5 );

		// Fire the n8n webhook the moment a deposit is paid — scheduled onto
		// WP-Cron rather than run inline, so the customer's checkout/thank-you
		// request never blocks on the outbound HTTP call.
		add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'schedule_booking_webhook' ), 10, 1 );
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'schedule_booking_webhook' ), 10, 1 );
		add_action( 'fy_fleet_send_booking_webhook', array( __CLASS__, 'send_booking_webhook' ), 10, 1 );

		// Product pages render the yacht card LIVE, so global changes (add-on
		// prices, deposit %, marinas) show instantly without re-saving yachts.
		add_filter( 'the_content', array( __CLASS__, 'live_product_description' ), 9 );

		// The fleet card's header (name, size · brand · model, FROM price,
		// max capacity, expandable Hours & Pricing) repeated at the top of
		// the BOOKING column, right above Select Date — so the numbers a
		// customer clicked on the gallery card are still in front of them
		// while they pick a date. Reads the same yacht meta the Visualizer
		// edits, so all three views can never disagree.
		add_action( 'woocommerce_before_add_to_cart_form', array( __CLASS__, 'card_header' ) );
		// Catalog / product "$500" is the Woo variation (due today). Replace
		// that listed figure with boat + crew + fuel so browse and the product page
		// agree. Cart and checkout keep charging crew + deposit.
		add_filter( 'woocommerce_get_price_html', array( __CLASS__, 'listed_price_html' ), 20, 2 );
		add_action( 'admin_post_fy_sync_products', array( __CLASS__, 'handle_sync_all' ) );
		add_action( 'admin_post_fy_link_products', array( __CLASS__, 'handle_link_products' ) );
		add_action( 'admin_post_fy_save_links', array( __CLASS__, 'handle_save_links' ) );
		add_action( 'admin_post_fy_fix_city_urls', array( __CLASS__, 'handle_fix_city_urls' ) );

		// Yacht-linked products get a pretty URL matching the fleet's own URL
		// base (e.g. /miami-yacht-rentals/{yacht-name}/) instead of
		// WooCommerce's default /product/{slug}/ — this is now the REAL,
		// final page (registered with 'top' priority so it matches before
		// the fy_yacht CPT's own same-shaped, redirect-only rewrite).
		add_action( 'init', array( __CLASS__, 'add_pretty_url_rewrite' ), 20 );
		add_filter( 'post_type_link', array( __CLASS__, 'yacht_product_permalink' ), 10, 2 );
		add_filter( 'request', array( __CLASS__, 'fallback_pretty_url' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_flush_pretty_url_rewrite' ) );

		// Composable description blocks. The default product description is the
		// full stack of these; reorder or remove them per product freely.
		add_shortcode( 'fy_yacht_info', array( __CLASS__, 'yacht_info_shortcode' ) );
		foreach ( array( 'fy_yacht_special', 'fy_yacht_specs', 'fy_yacht_hours', 'fy_yacht_addons', 'fy_yacht_location', 'fy_yacht_deposit', 'fy_yacht_reviews', 'fy_yacht_marina' ) as $section_tag ) {
			add_shortcode( $section_tag, array( __CLASS__, 'section_shortcode' ) );
		}
		add_shortcode( 'fy_yacht_details', array( __CLASS__, 'details_tabs_shortcode' ) );
		add_shortcode( 'fy_yacht_layout', array( __CLASS__, 'layout_shortcode' ) );

		// "Feeling Yachty Experiences" carousel: replaces WooCommerce's own
		// related-products output (a static, 4-card block) with a swipeable
		// row that starts with 10 cards and can lazy-load more as the visitor
		// scrolls. WooCommerce still decides WHICH yachts are related (same
		// categories/tags) — this only changes how many render and how.
		//
		// The swap MUST happen later than this method: WooCommerce registers
		// its template hooks after plugins_loaded, and this plugin boots
		// BEFORE WooCommerce (see the load-order note in the bootstrap). A
		// remove_action() here would find nothing to remove, fail silently,
		// and the page would then render BOTH the stock block and the
		// carousel. template_redirect fires once, well after every hook is
		// registered and before any template output.
		// Both headings. The related one matters even though this class also
		// renders its own carousel: on a site where ELEMENTOR draws the
		// related-products row (its widget bypasses the hook swapped below),
		// this filter is the only thing that still reaches the heading.
		add_filter( 'woocommerce_product_related_products_heading', array( __CLASS__, 'experiences_heading' ) );
		add_filter( 'woocommerce_product_upsells_products_heading', array( __CLASS__, 'experiences_heading' ) );
		add_action( 'template_redirect', array( __CLASS__, 'swap_related_products' ) );
		add_action( 'wp_ajax_fy_load_related', array( __CLASS__, 'ajax_load_related' ) );
		add_action( 'wp_ajax_nopriv_fy_load_related', array( __CLASS__, 'ajax_load_related' ) );

		// "Your Saved Yachts" — the visitor's own shortlist, on the product
		// page. Priority 5 puts it right after the summary/add-to-cart form
		// but BEFORE the Description tab's Yacht Specifications content
		// (priority 10) and the related-products carousel (priority 20) —
		// requested so it reads: this yacht → the ones you saved → yacht
		// details → other suggestions, not buried below the specs.
		add_action( 'woocommerce_after_single_product_summary', array( __CLASS__, 'output_saved_yachts' ), 5 );
		add_shortcode( 'fy_saved_yachts', array( __CLASS__, 'saved_yachts_shortcode' ) );

		// Ask for more than the stock 4. This is the one lever that also
		// reaches an Elementor-rendered row, since that widget still routes
		// through WooCommerce's related-products query. It's a request, not
		// a guarantee — an Elementor widget with its own "products per page"
		// set in the page builder wins, and that has to be changed there.
		add_filter( 'woocommerce_output_related_products_args', array( __CLASS__, 'related_products_args' ) );
	}

	/** Keep fleet staff and plugin admins inside wp-admin. */
	public static function allow_staff_admin_access( $prevent ) {
		if ( current_user_can( 'activate_plugins' ) || current_user_can( 'manage_options' ) || current_user_can( 'manage_fleet' ) ) {
			return false;
		}
		return $prevent;
	}

	/**
	 * After wp-login, do not drop an administrator on the homepage.
	 * Honor an explicit redirect_to when it is a wp-admin URL.
	 */
	public static function keep_admin_login_in_admin( $redirect_to, $requested, $user ) {
		if ( ! ( $user instanceof WP_User ) || ! $user->exists() ) {
			return $redirect_to;
		}
		if ( ! user_can( $user, 'activate_plugins' ) && ! user_can( $user, 'manage_options' ) ) {
			return $redirect_to;
		}
		$requested = (string) $requested;
		if ( $requested && false !== strpos( $requested, 'wp-admin' ) ) {
			return $requested;
		}
		$home = untrailingslashit( home_url() );
		$dest = untrailingslashit( (string) $redirect_to );
		if ( '' === $dest || $dest === $home || $dest === $home . '/' || false !== strpos( $dest, '/my-account' ) ) {
			return admin_url( 'index.php' );
		}
		return $redirect_to;
	}

	public static function related_products_args( $args ) {
		$args['posts_per_page'] = self::RELATED_INITIAL;
		$args['columns']        = 4;
		return $args;
	}

	/**
	 * The gallery card's header block, re-rendered on the product page above
	 * the booking form — same design language, sized to the booking column.
	 *
	 * Everything is read live from the yacht record (the meta the Fleet
	 * Visualizer's quick-editor writes), never copied: change a price or the
	 * capacity there and the gallery card, this header and the booking page
	 * all update on the next view.
	 */
	public static function card_header() {
		if ( ! is_product() ) {
			return;
		}
		// (yacht_for_product() lives on FY_Fleet_Addons, not here — calling
		// it on this class fataled every yacht product page in testing.)
		$yacht_id = (int) get_post_meta( get_the_ID(), '_fy_yacht_id', true );
		if ( ! $yacht_id || ! class_exists( 'FY_Fleet_CPT' ) || FY_Fleet_CPT::POST_TYPE !== get_post_type( $yacht_id ) ) {
			return;
		}

		$title    = get_the_title( $yacht_id );
		$size     = (int) get_post_meta( $yacht_id, '_fy_size_ft', true );
		$brand    = trim( (string) get_post_meta( $yacht_id, '_fy_brand', true ) );
		$model    = trim( (string) get_post_meta( $yacht_id, '_fy_model', true ) );
		$price    = (float) get_post_meta( $yacht_id, '_fy_price', true );
		$capacity = class_exists( 'FY_Fleet_CPT' ) ? FY_Fleet_CPT::capacity( $yacht_id ) : 0;
		$rows     = get_post_meta( $yacht_id, '_fy_pricing', true );
		$rows     = is_array( $rows ) ? $rows : array();

		// "26 ft · Hurricane · SunDeck 2400" — skip missing parts, dedupe a
		// model that already starts with the brand.
		$sub_bits = array();
		if ( $size > 0 ) {
			$sub_bits[] = $size . ' ft';
		}
		if ( '' !== $brand ) {
			$sub_bits[] = $brand;
		}
		if ( '' !== $model && strcasecmp( $model, $brand ) !== 0 ) {
			$sub_bits[] = $model;
		}

		echo '<div class="fy-product-card-header" style="margin:0 0 18px;padding:16px 18px;background:#fff;border:1px solid rgba(124,58,237,.18);border-radius:16px;box-shadow:0 6px 18px rgba(23,32,51,.06)">';

		echo '<div style="font-family:\'Space Grotesk\',\'Plus Jakarta Sans\',sans-serif;font-size:22px;font-weight:800;letter-spacing:-.01em;color:#172033;line-height:1.15">' . esc_html( $title ) . '</div>';
		if ( $sub_bits ) {
			echo '<div style="margin:3px 0 12px;font-size:13.5px;font-weight:700;color:#526079">' . esc_html( implode( ' · ', $sub_bits ) ) . '</div>';
		}

		// Headline the shortest real charter (the 3-hour price), matching the
		// gallery card — see FY_Fleet_Pricing::display_from_price().
		$from = FY_Fleet_Pricing::display_from_price( $yacht_id );
		if ( $from ) {
			$unit = FY_Fleet_Pricing::display_from_unit( $yacht_id, $from );
			echo '<div style="display:flex;align-items:baseline;flex-wrap:wrap;gap:10px;margin:0 0 12px;padding:10px 16px;border-left:4px solid #E45C9C;border-radius:14px;background:linear-gradient(135deg,#FDF2F8,#F5F3FF)">'
				. '<span style="font-size:11px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:#7C3AED">' . esc_html__( 'From', 'fy-fleet' ) . '</span>'
				. '<span style="font-size:30px;font-weight:900;color:#EC4899;line-height:1">$' . esc_html( number_format( $from['amount'] ) ) . '</span>'
				. ( $unit ? '<span style="font-size:13px;font-weight:800;color:#526079">' . esc_html( $unit ) . '</span>' : '' )
				. '</div>';
		}

		if ( $capacity > 0 ) {
			echo '<div style="display:flex;justify-content:space-between;align-items:center;margin:0 0 12px;padding:10px 14px;border:1px solid #E6EAF3;border-radius:12px;background:#F8FAFF;font-size:13.5px">'
				. '<span style="font-weight:800;color:#4338CA">👥 ' . esc_html__( 'Max capacity', 'fy-fleet' ) . '</span>'
				. '<strong style="color:#172033">' . esc_html( sprintf( _n( '%d guest', '%d guests', $capacity, 'fy-fleet' ), $capacity ) ) . '</strong>'
				. '</div>';
		}

		if ( $rows ) {
			echo '<details class="fy-card-hours" style="border:2px solid #C7D2FE;border-radius:14px;background:#fff;overflow:hidden">';
			echo '<summary style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:12px 14px;cursor:pointer;list-style:none">'
				. '<span><span style="display:block;font-size:15px;font-weight:800;color:#4338CA">' . esc_html__( 'View Hours & Pricing', 'fy-fleet' ) . '</span>'
				. '<span style="display:block;font-size:12px;font-weight:600;color:#526079">' . esc_html__( 'Exact durations and total charter prices', 'fy-fleet' ) . '</span></span>'
				. '<span aria-hidden="true" style="flex:0 0 auto;width:30px;height:30px;border-radius:999px;background:linear-gradient(135deg,#7C3AED,#5B21B6);color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:13px">▾</span>'
				. '</summary>';
			echo '<div style="padding:4px 14px 12px">';
			foreach ( $rows as $row ) {
				$type = isset( $row['type'] ) ? $row['type'] : 'price';
				if ( 'heading' === $type ) {
					echo '<div style="margin:9px 0 4px;font-size:11.5px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:#7C3AED">📅 ' . esc_html( $row['text'] ) . '</div>';
				} elseif ( 'note' === $type ) {
					echo '<div style="margin:6px 0;font-size:12.5px;color:#526079">📝 ' . esc_html( $row['text'] ) . '</div>';
				} else {
					$boat   = isset( $row['price'] ) ? (float) $row['price'] : 0;
					$hours  = FY_Fleet_Pricing::hours_from_label( isset( $row['duration'] ) ? $row['duration'] : '' );
					$listed = FY_Fleet_Pricing::listed_total( $yacht_id, $boat, $hours );
					echo '<div style="display:flex;justify-content:space-between;gap:12px;padding:6px 0;border-bottom:1px dashed #EDE9FE;font-size:13.5px">'
						. '<span style="color:#3A4459;font-weight:600">' . esc_html( $row['duration'] ) . ( ! empty( $row['free'] ) ? ' <span style="color:#0F6E56;font-weight:800">· ' . esc_html__( 'free-hour deal', 'fy-fleet' ) . '</span>' : '' ) . '</span>'
						. '<strong style="color:#172033">$' . esc_html( number_format( $listed ) )
						. ' <span style="font-weight:700;color:#94a3b8;font-size:11px;text-transform:uppercase">' . esc_html__( 'boat + crew + fuel', 'fy-fleet' ) . '</span></strong>'
						. '</div>';
				}
			}
			echo '</div></details>';
		}

		echo '</div>';
	}

	/**
	 * Replace Woo's catalog / product price (crew + deposit due today) with
	 * the same listed From the fleet cards show (boat + crew + fuel).
	 */
	public static function listed_price_html( $html, $product ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return $html;
		}
		if ( ( function_exists( 'is_cart' ) && is_cart() ) || ( function_exists( 'is_checkout' ) && is_checkout() ) ) {
			return $html;
		}
		if ( ! $product || ! is_object( $product ) || ! method_exists( $product, 'get_id' ) ) {
			return $html;
		}
		$product_id = (int) $product->get_id();
		if ( method_exists( $product, 'is_type' ) && $product->is_type( 'variation' ) && method_exists( $product, 'get_parent_id' ) ) {
			$product_id = (int) $product->get_parent_id();
		}
		$yacht_id = (int) get_post_meta( $product_id, '_fy_yacht_id', true );
		if ( $yacht_id < 1 || ! class_exists( 'FY_Fleet_Pricing' ) ) {
			return $html;
		}
		$from = FY_Fleet_Pricing::display_from_price( $yacht_id );
		if ( ! $from || $from['amount'] <= 0 ) {
			return $html;
		}
		$unit = FY_Fleet_Pricing::display_from_unit( $yacht_id, $from );
		$label = '$' . number_format( $from['amount'] );
		if ( $unit ) {
			$label .= ' ' . $unit;
		}
		return '<span class="fy-listed-price woocommerce-Price-amount amount">'
			. '<span class="fy-listed-price__from">' . esc_html__( 'From', 'fy-fleet' ) . '</span> '
			. '<bdi>' . esc_html( $label ) . '</bdi>'
			. '</span>';
	}

	/** Swap the stock related-products block for the carousel, on product pages only. */
	public static function swap_related_products() {
		if ( ! function_exists( 'is_product' ) || ! is_product() ) {
			return;
		}
		remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
		add_action( 'woocommerce_after_single_product_summary', array( __CLASS__, 'output_related_carousel' ), 20 );

		// Loop-card titles: h2 → h3. WooCommerce hardcodes <h2> here, which
		// on a product page puts every OTHER yacht's name at the same outline
		// level as the page's own sections — and at 10 cards that's 10 h2s
		// naming competing entities on a page whose h1 is one specific yacht.
		// These cards are items INSIDE the "Feeling Yachty Experiences"
		// section, so they belong one level below its heading. Scoped to
		// product pages, and driven off the shared loop hook so it applies
		// whether the row is drawn by WooCommerce or by Elementor.
		remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
		add_action( 'woocommerce_shop_loop_item_title', array( __CLASS__, 'loop_product_title_h3' ), 10 );
	}

	/**
	 * WooCommerce's loop title, emitted as an h3 instead of an h2.
	 *
	 * wp_kses_post() rather than esc_html(): these titles hold curly quotes
	 * as HTML entities (“FANTASEA”), and escaping them again would print the
	 * raw &#8220; on the card. This matches how WooCommerce core outputs it,
	 * minus any unsafe markup.
	 */
	public static function loop_product_title_h3() {
		echo '<h3 class="' . esc_attr( apply_filters( 'woocommerce_product_loop_title_classes', 'woocommerce-loop-product__title' ) ) . '">'
			. wp_kses_post( get_the_title() ) . '</h3>';
	}

	public static function experiences_heading() {
		return __( 'Feeling Yachty Experiences', 'fy-fleet' );
	}

	/** How many related cards render immediately vs. wait behind lazy-load. */
	const RELATED_INITIAL  = 10;
	const RELATED_POOL_MAX = 40;

	/**
	 * The yachts this carousel offers, pulled ONCE so the visible cards and
	 * the lazy-load queue come from one consistent list — wc_get_related_products()
	 * re-shuffles on every call, so querying twice could repeat a yacht
	 * that's already on screen or skip one entirely.
	 *
	 * Starts from WooCommerce's own related-products logic, then tops up from
	 * the same CITY, because relying on WooCommerce alone leaves this empty
	 * for most of the fleet: sync_product() sets every yacht product to
	 * catalog_visibility 'hidden' (deliberately — they'd otherwise clutter
	 * the shop), and both WooCommerce's related query and its own related.php
	 * filter hidden products out. Same-city yachts are also simply the most
	 * useful suggestion here.
	 */
	private static function related_pool( $product_id ) {
		$product_id = (int) $product_id;
		$pool       = array();

		foreach ( (array) wc_get_related_products( $product_id, self::RELATED_POOL_MAX, array( $product_id ) ) as $id ) {
			$id = (int) $id;
			if ( $id && $id !== $product_id && 'publish' === get_post_status( $id ) ) {
				$pool[ $id ] = $id;
			}
		}

		if ( count( $pool ) >= self::RELATED_INITIAL ) {
			return array_values( $pool );
		}

		$yacht_id = (int) get_post_meta( $product_id, '_fy_yacht_id', true );
		if ( ! $yacht_id ) {
			return array_values( $pool );
		}
		$terms = get_the_terms( $yacht_id, 'fy_yacht_cat' );
		if ( ! $terms || is_wp_error( $terms ) ) {
			return array_values( $pool );
		}
		$term = reset( $terms );

		$siblings = get_posts(
			array(
				'post_type'        => FY_Fleet_CPT::POST_TYPE,
				'post_status'      => 'publish',
				'posts_per_page'   => self::RELATED_POOL_MAX,
				'fields'           => 'ids',
				'post__not_in'     => array( $yacht_id ),
				'orderby'          => 'rand',
				'suppress_filters' => false,
				'tax_query'        => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					array(
						'taxonomy' => 'fy_yacht_cat',
						'field'    => 'term_id',
						'terms'    => $term->term_id,
					),
				),
			)
		);

		foreach ( $siblings as $sibling_id ) {
			if ( count( $pool ) >= self::RELATED_POOL_MAX ) {
				break;
			}
			$sibling_product = self::get_product_id( $sibling_id );
			if ( $sibling_product && $sibling_product !== $product_id
				&& ! isset( $pool[ $sibling_product ] )
				&& 'publish' === get_post_status( $sibling_product )
			) {
				$pool[ $sibling_product ] = $sibling_product;
			}
		}

		return array_values( $pool );
	}

	/**
	 * Renders one related-product card, matching WooCommerce's own loop markup.
	 *
	 * Gated on published status rather than is_visible(): yacht products are
	 * catalog-hidden on purpose, but they're real public pages with their own
	 * URLs, and they're exactly what this carousel exists to show.
	 */
	private static function render_related_card( $id ) {
		$product = wc_get_product( $id );
		if ( ! $product || 'publish' !== get_post_status( $id ) || post_password_required( $id ) ) {
			return;
		}
		$post_object = get_post( $id );
		// setup_postdata() fires 'the_post', which is what lets WooCommerce
		// populate the $product global that content-product.php reads.
		setup_postdata( $GLOBALS['post'] =& $post_object ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride -- matches WooCommerce's own related.php
		wc_get_template_part( 'content', 'product' );
	}

	/** [fy_saved_yachts] — the same section, placeable anywhere. */
	public static function saved_yachts_shortcode() {
		ob_start();
		self::output_saved_yachts();
		return ob_get_clean();
	}

	/**
	 * "Your Saved Yachts" — the visitor's own shortlist, rendered on the
	 * product page.
	 *
	 * The list itself lives in the browser's localStorage (so it works with
	 * no account and survives page caching), and is filled in by
	 * assets/fleet.js from the SAME fy_saved_summary endpoint the popup and
	 * the account portal use — one source of truth, so this can never drift
	 * out of sync with the hearts on the fleet grid.
	 *
	 * The heading and description are printed server-side and always
	 * present, so the section is crawlable and self-explanatory even though
	 * its contents are per-visitor. The whole block hides itself when the
	 * shortlist is empty (fleet.js), rather than showing an empty shell.
	 */
	public static function output_saved_yachts() {
		if ( ! class_exists( 'FY_Fleet_Render' ) ) {
			return;
		}
		$fleet_url = home_url( '/miami-yacht-rental/' );
		if ( class_exists( 'FY_Fleet_Account' ) && is_user_logged_in() ) {
			$fleet_url = FY_Fleet_Account::region_fleet_url( get_current_user_id() ); // Panama accounts go to the Panama fleet.
		}
		?>
		<section class="fy-saved-section" id="fy-saved-yachts" hidden aria-labelledby="fy-saved-section-title">
			<div class="fy-saved-section__head">
				<h2 class="fy-saved-section__title" id="fy-saved-section-title">❤️ <?php esc_html_e( 'Your Saved Yachts', 'fy-fleet' ); ?></h2>
				<p class="fy-saved-section__desc"><?php esc_html_e( 'The yachts you saved while browsing our Miami and Panama fleet — compare them side by side, then pick the one for your charter.', 'fy-fleet' ); ?></p>
			</div>
			<ul class="fy-saved-section__grid"></ul>
			<div class="fy-saved-section__foot">
				<a class="fy-saved-section__browse" href="<?php echo esc_url( $fleet_url ); ?>">🛥️ <?php esc_html_e( 'Browse the full fleet', 'fy-fleet' ); ?></a>
			</div>
		</section>
		<?php
	}

	public static function output_related_carousel() {
		if ( ! is_product() ) {
			return;
		}
		$product_id = get_the_ID();
		$pool       = self::related_pool( $product_id );
		if ( empty( $pool ) ) {
			return;
		}

		$visible   = array_slice( $pool, 0, self::RELATED_INITIAL );
		$remaining = array_values( array_slice( $pool, self::RELATED_INITIAL ) );
		// This render replaces WooCommerce's own related-products template
		// entirely, so its 'woocommerce_product_related_products_heading'
		// filter never fires here — nothing else is left hooked to it either.
		$heading = self::experiences_heading();
		?>
		<section class="related products fy-related-carousel"
			<?php if ( ! empty( $remaining ) ) : ?>
			data-fy-queue="<?php echo esc_attr( wp_json_encode( $remaining ) ); ?>"
			data-fy-nonce="<?php echo esc_attr( wp_create_nonce( 'fy_related_lazyload' ) ); ?>"
			<?php endif; ?>
		>
			<h2><?php echo esc_html( $heading ); ?></h2>
			<p class="fy-related-hint">👉 <?php esc_html_e( 'Swipe to see more experiences', 'fy-fleet' ); ?></p>
			<ul class="products columns-4">
				<?php
				foreach ( $visible as $related_id ) {
					self::render_related_card( $related_id );
				}
				wp_reset_postdata();
				if ( ! empty( $remaining ) ) :
					?>
					<li class="fy-related-sentinel" aria-hidden="true"></li>
				<?php endif; ?>
			</ul>
		</section>
		<?php
	}

	/** Renders more cards for the carousel above, one small batch at a time. */
	public static function ajax_load_related() {
		// Checked but deliberately NOT fatal. A page cache serves the same
		// HTML — nonce included — to every visitor, so a cached nonce is
		// routinely stale or belongs to another session, and dying here would
		// silently stop lazy-loading for real customers. Nothing is written
		// and nothing private is exposed: this returns the same public
		// product-card markup the page already renders, and render_related_card()
		// re-checks published status and password protection for every id.
		check_ajax_referer( 'fy_related_lazyload', 'nonce', false );

		$ids = isset( $_POST['ids'] ) ? array_map( 'intval', (array) wp_unslash( $_POST['ids'] ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- intval() is the sanitization
		$ids = array_slice( array_filter( $ids ), 0, self::RELATED_POOL_MAX );
		if ( empty( $ids ) ) {
			wp_send_json_success( array( 'html' => '' ) );
		}

		ob_start();
		foreach ( $ids as $id ) {
			self::render_related_card( $id );
		}
		wp_reset_postdata();
		wp_send_json_success( array( 'html' => ob_get_clean() ) );
	}

	/** Marks a description as still auto-managed; removing it = hands off. */
	const AUTO_MARK = '<!--fy-auto-->';

	public static function default_description_stack() {
		// Deposit dropped on purpose — see render_product_layout().
		return self::AUTO_MARK . "\n[fy_yacht_layout]\n[fy_yacht_reviews]\n[fy_yacht_marina]";
	}

	/** Yacht behind a shortcode: explicit yacht="", else current yacht/product. */
	private static function detect_yacht_id( $atts ) {
		$yacht_id = isset( $atts['yacht'] ) ? intval( $atts['yacht'] ) : 0;
		if ( ! $yacht_id && is_singular( FY_Fleet_CPT::POST_TYPE ) ) {
			$yacht_id = get_the_ID();
		}
		if ( ! $yacht_id && is_singular( 'product' ) ) {
			$yacht_id = (int) get_post_meta( get_the_ID(), '_fy_yacht_id', true );
		}
		return ( $yacht_id && FY_Fleet_CPT::POST_TYPE === get_post_type( $yacht_id ) ) ? $yacht_id : 0;
	}

	public static function section_shortcode( $atts, $content = '', $tag = '' ) {
		$atts     = shortcode_atts( array( 'yacht' => 0 ), $atts, $tag );
		$yacht_id = self::detect_yacht_id( $atts );
		if ( ! $yacht_id ) {
			return '';
		}
		switch ( $tag ) {
			case 'fy_yacht_special':
				return self::part_special( $yacht_id );
			case 'fy_yacht_specs':
				return self::part_specs( $yacht_id );
			case 'fy_yacht_hours':
				return self::part_hours( $yacht_id );
			case 'fy_yacht_addons':
				return self::part_addons( $yacht_id );
			case 'fy_yacht_location':
				return self::part_location( $yacht_id );
			case 'fy_yacht_deposit':
				return self::part_deposit( $yacht_id );
			case 'fy_yacht_reviews':
				return class_exists( 'FY_Fleet_Reviews' ) ? FY_Fleet_Reviews::render( $yacht_id ) : '';
			case 'fy_yacht_marina':
				return class_exists( 'FY_Fleet_Marina' ) ? FY_Fleet_Marina::render( $yacht_id ) : '';
		}
		return '';
	}

	public static function layout_shortcode( $atts ) {
		$atts     = shortcode_atts( array( 'yacht' => 0 ), $atts, 'fy_yacht_layout' );
		$yacht_id = self::detect_yacht_id( $atts );
		if ( ! $yacht_id ) {
			return '';
		}
		return self::render_product_layout( $yacht_id );
	}

	public static function details_tabs_shortcode( $atts ) {
		$atts     = shortcode_atts( array( 'yacht' => 0 ), $atts, 'fy_yacht_details' );
		$yacht_id = self::detect_yacht_id( $atts );
		if ( ! $yacht_id ) {
			return '';
		}
		return self::render_details_tabs( $yacht_id );
	}

	/**
	 * [fy_yacht_details] — Special / Yacht Specs / Hours / Location as tabs.
	 * Each panel reuses the exact same part_*() method as the flat stack, so
	 * the content is always identical to what the visualizer actually has
	 * saved for this yacht — a tab only appears when that section has real
	 * data (e.g. no Location tab for a yacht with no marina set).
	 */
	public static function render_details_tabs( $yacht_id ) {
		$tabs = array(
			array(
				'label' => __( 'Special', 'fy-fleet' ),
				'icon'  => '✨',
				'html'  => self::part_special( $yacht_id ),
			),
			array(
				'label' => __( 'Yacht Specs', 'fy-fleet' ),
				'icon'  => '⛵',
				'html'  => self::part_specs( $yacht_id ),
			),
			array(
				'label' => __( 'Hours', 'fy-fleet' ),
				'icon'  => '⏱️',
				'html'  => self::part_hours( $yacht_id ),
			),
			array(
				'label' => __( 'Location', 'fy-fleet' ),
				'icon'  => '📍',
				'html'  => self::part_location( $yacht_id ),
			),
		);
		$tabs = array_values(
			array_filter(
				$tabs,
				function ( $tab ) {
					return '' !== trim( $tab['html'] );
				}
			)
		);
		if ( empty( $tabs ) ) {
			return '';
		}

		$uid = 'fy-dt-' . $yacht_id . '-' . wp_rand( 1000, 9999 );

		$buttons = '';
		$panels  = '';
		foreach ( $tabs as $i => $tab ) {
			$active   = 0 === $i;
			$panel_id = $uid . '-panel-' . $i;
			$tab_id   = $uid . '-tab-' . $i;
			$buttons .= '<button type="button" id="' . esc_attr( $tab_id ) . '" class="fy-dt-tab' . ( $active ? ' fy-dt-tab--active' : '' ) . '" '
				. 'role="tab" aria-selected="' . ( $active ? 'true' : 'false' ) . '" aria-controls="' . esc_attr( $panel_id ) . '" data-fy-dt-tab>'
				. '<span aria-hidden="true">' . esc_html( $tab['icon'] ) . '</span> ' . esc_html( $tab['label'] ) . '</button>';
			$panels  .= '<div id="' . esc_attr( $panel_id ) . '" class="fy-dt-panel' . ( $active ? ' fy-dt-panel--active' : '' ) . '" '
				. 'role="tabpanel" aria-labelledby="' . esc_attr( $tab_id ) . '"' . ( $active ? '' : ' hidden' ) . '>' . $tab['html'] . '</div>';
		}

		return '<div class="fy-dt" data-fy-dt>'
			. '<span class="fy-dt-kicker">⚓ ' . esc_html__( 'Feeling Yachty Details', 'fy-fleet' ) . '</span>'
			. '<h2 class="fy-dt-heading">' . esc_html__( 'Everything you need for your yacht experience', 'fy-fleet' ) . '</h2>'
			. '<p class="fy-dt-sub">' . esc_html__( 'Review the yacht features, charter duration, optional upgrades, pickup area and deposit information before booking.', 'fy-fleet' ) . '</p>'
			. '<div class="fy-dt-tabs" role="tablist">' . $buttons . '</div>'
			. '<div class="fy-dt-panels">' . $panels . '</div>'
			. '</div>';
	}

	/**
	 * On a yacht-backed product page, swap the stored description for a live
	 * one generated from today's yacht data. The stored copy (written on each
	 * yacht save) remains the fallback for feeds, search and other plugins.
	 */
	public static function live_product_description( $content ) {
		if ( is_admin() || ! is_singular( 'product' ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}
		// Descriptions carrying the [fy_yacht_*] shortcodes render themselves,
		// in whatever order the owner arranged them — hands off. Only legacy
		// copies (rendered HTML stored before the shortcode stack) are swapped
		// for a live build.
		if ( false !== strpos( $content, '[fy_yacht_' ) ) {
			return $content;
		}
		$yacht_id = (int) get_post_meta( get_the_ID(), '_fy_yacht_id', true );
		if ( ! $yacht_id || FY_Fleet_CPT::POST_TYPE !== get_post_type( $yacht_id ) ) {
			return $content;
		}
		return self::build_product_description( $yacht_id );
	}

	/**
	 * [fy_yacht_info] — the same card info block anywhere (Elementor, pages).
	 * Detects the yacht automatically on yacht/product pages, or takes
	 * [fy_yacht_info yacht="123"] explicitly.
	 */
	public static function yacht_info_shortcode( $atts ) {
		$atts     = shortcode_atts( array( 'yacht' => 0 ), $atts, 'fy_yacht_info' );
		$yacht_id = intval( $atts['yacht'] );

		if ( ! $yacht_id && is_singular( FY_Fleet_CPT::POST_TYPE ) ) {
			$yacht_id = get_the_ID();
		}
		if ( ! $yacht_id && is_singular( 'product' ) ) {
			$yacht_id = (int) get_post_meta( get_the_ID(), '_fy_yacht_id', true );
		}
		if ( ! $yacht_id || FY_Fleet_CPT::POST_TYPE !== get_post_type( $yacht_id ) ) {
			return '';
		}
		return self::build_product_description( $yacht_id );
	}

	/** One-click refresh of every stored product copy (after global changes). */
	public static function handle_sync_all() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		check_admin_referer( 'fy_sync_products' );

		$count = self::sync_all();

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'products.sync', sprintf( 'Re-synced %d yacht products (descriptions, deposit prices, images)', $count ) );
		}

		wp_safe_redirect(
			add_query_arg(
				array( 'page' => 'fy-fleet-visualizer', 'post_type' => FY_Fleet_CPT::POST_TYPE, 'fy_synced' => $count ),
				admin_url( 'edit.php' )
			)
		);
		exit;
	}

	/**
	 * Re-point any yacht's "Book Experience" button that's still a stale copy
	 * of its own product page — right slug, wrong city segment, cached back
	 * when fill_defaults() ran before the yacht had a city term (or before
	 * this migration ran and its term changed). Never touches a button URL
	 * that was pointed somewhere else on purpose.
	 *
	 * @return int Number of yachts corrected.
	 */
	public static function fix_city_button_urls() {
		$yacht_ids = get_posts(
			array(
				'post_type'      => FY_Fleet_CPT::POST_TYPE,
				'post_status'    => array( 'publish', 'draft', 'pending' ),
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);

		$home  = home_url( '/' );
		$fixed = 0;

		foreach ( $yacht_ids as $yacht_id ) {
			$product_id = self::get_product_id( $yacht_id );
			if ( ! $product_id ) {
				continue;
			}
			$product = get_post( $product_id );
			$current = trim( (string) get_post_meta( $yacht_id, '_fy_button_url', true ) );
			$correct = get_permalink( $product_id );
			if ( ! $product || '' === $current || ! $correct || $correct === $current ) {
				continue;
			}

			// Same product slug, different city segment = a stale copy of
			// this exact page. Anything else — an external link, a
			// different page entirely — is left exactly as it is.
			$expected_tail = '/' . $product->post_name . '/';
			$current_tail  = substr( rtrim( $current, '/' ) . '/', -strlen( $expected_tail ) );
			if ( 0 !== strpos( $current, $home ) || $current_tail !== $expected_tail ) {
				continue;
			}

			update_post_meta( $yacht_id, '_fy_button_url', $correct );
			$fixed++;
		}

		return $fixed;
	}

	/** Admin action behind the "Fix mismatched city links" button. */
	public static function handle_fix_city_urls() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		check_admin_referer( 'fy_fix_city_urls' );

		$fixed = self::fix_city_button_urls();

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'products.city_urls_fixed', sprintf( 'Repointed %d stale "Book Experience" links to their yacht\'s current city URL', $fixed ) );
		}

		wp_safe_redirect(
			add_query_arg(
				array( 'page' => 'fy-fleet-visualizer', 'post_type' => FY_Fleet_CPT::POST_TYPE, 'fy_city_urls_fixed' => $fixed ),
				admin_url( 'edit.php' )
			)
		);
		exit;
	}

	/** Loose title match: case, spacing, quote style and dashes all ignored. */
	private static function match_key( $title ) {
		$key = wp_strip_all_tags( (string) $title );
		$key = str_replace( array( '“', '”', '„', '‟', '"', '’', '‘', '`' ), '', $key );
		$key = str_replace( array( '–', '—' ), '-', $key );
		$key = strtolower( $key );
		$key = preg_replace( '/[^a-z0-9]+/', '', $key );
		return $key;
	}

	/**
	 * Pair yacht cards with WooCommerce products that already exist, matching
	 * on title. Products made by hand (before the bridge was wired up) never
	 * carry the link, so their [fy_yacht_*] blocks render empty. This joins
	 * them WITHOUT creating anything or touching either side's content.
	 *
	 * @return array{linked:int,unmatched:int}
	 */
	public static function link_existing_products() {
		$products = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => -1,
			)
		);
		$by_title = array();
		foreach ( $products as $product ) {
			// Never steal a product that already belongs to another yacht.
			$owner = (int) get_post_meta( $product->ID, '_fy_yacht_id', true );
			if ( $owner && FY_Fleet_CPT::POST_TYPE === get_post_type( $owner ) ) {
				continue;
			}
			$key = self::match_key( $product->post_title );
			if ( '' !== $key && ! isset( $by_title[ $key ] ) ) {
				$by_title[ $key ] = $product->ID;
			}
		}

		$yachts = get_posts(
			array(
				'post_type'      => FY_Fleet_CPT::POST_TYPE,
				'post_status'    => array( 'publish', 'draft', 'pending' ),
				'posts_per_page' => -1,
			)
		);

		$linked    = 0;
		$unmatched = 0;
		foreach ( $yachts as $yacht ) {
			if ( self::get_product_id( $yacht->ID ) ) {
				continue; // Already paired.
			}
			$key = self::match_key( $yacht->post_title );
			if ( '' === $key || empty( $by_title[ $key ] ) ) {
				$unmatched++;
				continue;
			}
			$product_id = $by_title[ $key ];
			unset( $by_title[ $key ] ); // One product per yacht.

			update_post_meta( $yacht->ID, '_fy_product_id', $product_id );
			update_post_meta( $product_id, '_fy_yacht_id', $yacht->ID );
			$permalink = get_permalink( $product_id );
			if ( $permalink ) {
				update_post_meta( $yacht->ID, '_fy_button_url', $permalink );
			}
			self::sync_product( $yacht->ID, $yacht );
			$linked++;
		}

		return array( 'linked' => $linked, 'unmatched' => $unmatched );
	}

	/** Save the hand-picked yacht → product pairs from the Match Products tab. */
	public static function handle_save_links() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		check_admin_referer( 'fy_save_links' );

		$map  = isset( $_POST['fy_link'] ) && is_array( $_POST['fy_link'] ) ? wp_unslash( $_POST['fy_link'] ) : array();
		$sync = ! empty( $_POST['fy_sync_after'] );

		$changed = 0;
		foreach ( $map as $yacht_id => $product_id ) {
			$yacht_id   = intval( $yacht_id );
			$product_id = intval( $product_id );
			if ( ! $yacht_id || FY_Fleet_CPT::POST_TYPE !== get_post_type( $yacht_id ) ) {
				continue;
			}

			$current = self::get_product_id( $yacht_id );
			if ( $current === $product_id ) {
				continue; // Nothing to do.
			}

			// Unlink.
			if ( ! $product_id ) {
				if ( $current ) {
					delete_post_meta( $current, '_fy_yacht_id' );
				}
				delete_post_meta( $yacht_id, '_fy_product_id' );
				$changed++;
				continue;
			}

			if ( 'product' !== get_post_type( $product_id ) ) {
				continue;
			}

			// Moving a product off another yacht: clear that yacht's link first,
			// so a product is never claimed by two yachts at once.
			$previous_owner = (int) get_post_meta( $product_id, '_fy_yacht_id', true );
			if ( $previous_owner && $previous_owner !== $yacht_id ) {
				delete_post_meta( $previous_owner, '_fy_product_id' );
			}
			// And release whatever this yacht used to point at.
			if ( $current && $current !== $product_id ) {
				delete_post_meta( $current, '_fy_yacht_id' );
			}

			update_post_meta( $yacht_id, '_fy_product_id', $product_id );
			update_post_meta( $product_id, '_fy_yacht_id', $yacht_id );

			$permalink = get_permalink( $product_id );
			if ( $permalink ) {
				update_post_meta( $yacht_id, '_fy_button_url', $permalink );
			}
			if ( $sync ) {
				self::sync_product( $yacht_id );
			}
			$changed++;
		}

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'products.matched', sprintf( '%d yacht/product matches saved by hand%s', $changed, $sync ? ' (products updated)' : ' (link only)' ) );
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'       => 'fy-fleet-visualizer',
					'post_type'  => FY_Fleet_CPT::POST_TYPE,
					'tab'        => 'link',
					'fy_matched' => $changed,
				),
				admin_url( 'edit.php' )
			)
		);
		exit;
	}

	public static function handle_link_products() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		check_admin_referer( 'fy_link_products' );

		$result = self::link_existing_products();

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'products.linked', sprintf( 'Linked %d yachts to existing products (%d still unmatched)', $result['linked'], $result['unmatched'] ) );
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'         => 'fy-fleet-visualizer',
					'post_type'    => FY_Fleet_CPT::POST_TYPE,
					'fy_linked'    => $result['linked'],
					'fy_unmatched' => $result['unmatched'],
				),
				admin_url( 'edit.php' )
			)
		);
		exit;
	}

	/**
	 * Generic signed POST to the configured n8n webhook. Used for bookings,
	 * ticket messages, and anything else the suite pushes out.
	 *
	 * @return bool Delivered (HTTP 2xx).
	 */
	public static function post_webhook( $payload ) {
		$opts = FY_Fleet_Settings::get_booking();
		$url  = isset( $opts['webhook_url'] ) ? trim( (string) $opts['webhook_url'] ) : '';
		if ( '' === $url ) {
			return false;
		}

		$body      = wp_json_encode( $payload );
		$secret    = isset( $opts['webhook_secret'] ) ? (string) $opts['webhook_secret'] : '';
		$signature = $secret ? hash_hmac( 'sha256', $body, $secret ) : '';

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => 8,
				'headers' => array(
					'Content-Type'   => 'application/json',
					// Same HMAC under both names: X-FY-Signature is the
					// original; X-Signature is what the n8n workflow expects.
					'X-FY-Signature' => $signature,
					'X-Signature'    => $signature,
				),
				'body'    => $body,
			)
		);

		return ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) < 300;
	}

	/**
	 * POST the full booking payload to the configured webhook (n8n, Make, GHL).
	 * Sent once per order; signed with an HMAC so the receiver can verify us.
	 */
	/** The /fy/v1/customers row for one email, or null — used in webhooks. */
	public static function customer_stats( $email ) {
		if ( ! class_exists( 'FY_Fleet_Customers' ) || '' === trim( (string) $email ) ) {
			return null;
		}
		$email = strtolower( trim( $email ) );
		foreach ( FY_Fleet_Customers::get_customers() as $customer ) {
			if ( strtolower( trim( (string) $customer['email'] ) ) === $email ) {
				return $customer;
			}
		}
		return null;
	}

	/** Queue send_booking_webhook() onto WP-Cron so checkout never waits on it. */
	public static function schedule_booking_webhook( $order_id ) {
		if ( ! wp_next_scheduled( 'fy_fleet_send_booking_webhook', array( $order_id ) ) ) {
			wp_schedule_single_event( time(), 'fy_fleet_send_booking_webhook', array( $order_id ) );
		}
	}

	public static function send_booking_webhook( $order_id ) {
		$opts = FY_Fleet_Settings::get_booking();
		$url  = isset( $opts['webhook_url'] ) ? trim( (string) $opts['webhook_url'] ) : '';
		if ( '' === $url ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order || 'yes' === $order->get_meta( '_fy_webhook_sent' ) ) {
			return;
		}

		// FULL records, mirroring the /fy/v1/bookings REST shape field for
		// field — the receiving n8n workflow gets everything the API exposes.
		$bookings = array();
		foreach ( $order->get_items() as $item ) {
			$date          = $item->get_meta( '_fy_date' );
			$item_yacht_id = (int) $item->get_meta( '_fy_yacht_id' );
			// Native pure-Woo orders carry the yacht link + money facts but no
			// date (it is scheduled after checkout) — still a charter order.
			if ( ! $date && ! $item_yacht_id ) {
				continue;
			}
			$addons   = json_decode( (string) $item->get_meta( '_fy_addons_raw' ), true );
			$duration = $item->get_meta( '_fy_duration' );
			$occasion = $item->get_meta( '_fy_occasion' );
			$notes    = $item->get_meta( '_fy_notes' );
			$marina   = $item->get_meta( '_fy_marina' );
			$yacht_id = (int) $item->get_meta( '_fy_yacht_id' );

			$bookings[] = array(
				'order_id'       => $order->get_id(),
				'order_no'       => $order->get_order_number(),
				'order_created'  => $order->get_date_created() ? $order->get_date_created()->date( 'Y-m-d H:i:s' ) : '',
				'status'         => $order->get_status(),
				'yacht'          => $item->get_name(),
				'yacht_id'       => $yacht_id,
				'yacht_capacity' => $yacht_id ? FY_Fleet_CPT::capacity( $yacht_id ) : null,
				'date'           => $date ? $date : null,
				'time'           => $item->get_meta( '_fy_time' ),
				'duration'       => $duration ? $duration : $item->get_meta( __( 'Charter length', 'fy-fleet' ) ),
				'hours'          => (float) $item->get_meta( '_fy_hours' ),
				'guests'         => (int) $item->get_meta( '_fy_guests' ),
				'occasion'       => $occasion ? $occasion : $item->get_meta( __( 'Occasion', 'fy-fleet' ) ),
				'notes'          => $notes ? $notes : $item->get_meta( __( 'Special requests', 'fy-fleet' ) ),
				'marina'         => $marina ? $marina : $item->get_meta( __( 'Departure marina', 'fy-fleet' ) ),
				'total'          => (float) $item->get_meta( '_fy_charter_total' ),
				'booking_charge' => (float) $item->get_meta( '_fy_booking_charge' ),
				'crew_fee'       => (float) $item->get_meta( '_fy_crew_fee' ),
				'fuel_fee'       => (float) $item->get_meta( '_fy_fuel_fee' ),
				'service_fee'    => (float) $item->get_meta( '_fy_service_fee' ),
				'deposit'        => (float) $item->get_meta( '_fy_deposit' ),
				'balance'        => (float) $item->get_meta( '_fy_balance' ),
				'addons'         => is_array( $addons ) ? $addons : array(),
				'confirmed'      => class_exists( 'FY_Fleet_Checkout' ) && FY_Fleet_Checkout::order_confirmed( $order ),
				'edit_url'       => $order->get_edit_order_url(),
			);
		}
		if ( empty( $bookings ) ) {
			return; // Not a charter order.
		}

		$payload = array(
			'event'    => 'booking.paid',
			'order_id' => $order->get_id(),
			'order_no' => $order->get_order_number(),
			'status'   => $order->get_status(),
			'customer' => array(
				'name'      => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
				'email'     => $order->get_billing_email(),
				'phone'     => $order->get_billing_phone(),
				'address_1' => $order->get_billing_address_1(),
				'address_2' => $order->get_billing_address_2(),
				'city'      => $order->get_billing_city(),
				'state'     => $order->get_billing_state(),
				'postcode'  => $order->get_billing_postcode(),
				'country'   => $order->get_billing_country(),
			),
			// Aggregate history in the /fy/v1/customers shape (LTV, repeat…).
			'customer_stats'          => self::customer_stats( $order->get_billing_email() ),
			'bareboat_form_confirmed' => class_exists( 'FY_Fleet_Checkout' ) && FY_Fleet_Checkout::order_confirmed( $order ),
			'bookings' => $bookings,
			'sent_at'  => gmdate( 'c' ),
		);

		$body      = wp_json_encode( $payload );
		$secret    = isset( $opts['webhook_secret'] ) ? (string) $opts['webhook_secret'] : '';
		$signature = $secret ? hash_hmac( 'sha256', $body, $secret ) : '';

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => 8,
				'headers' => array(
					'Content-Type'   => 'application/json',
					'X-FY-Signature' => $signature,
					'X-Signature'    => $signature,
				),
				'body'    => $body,
			)
		);

		$ok = ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) < 300;
		if ( $ok ) {
			$order->update_meta_data( '_fy_webhook_sent', 'yes' );
			$order->save();
		}

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add(
				$ok ? 'webhook.sent' : 'webhook.failed',
				sprintf( 'Order #%s → %s', $order->get_order_number(), $ok ? 'delivered' : ( is_wp_error( $response ) ? $response->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code( $response ) ) ),
				array( 'url' => $url, 'order' => $order->get_id() )
			);
		}
	}

	public static function active() {
		return class_exists( 'WooCommerce' );
	}

	public static function declare_hpos_compatibility() {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', FY_FLEET_FILE, true );
		}
	}

	/* ------------------------------------------------------------------
	 * Pretty URLs — yacht products live at /{url-base}/{yacht-name}/
	 * instead of WooCommerce's default /product/{slug}/.
	 * ---------------------------------------------------------------- */

	/**
	 * One rewrite rule per city (fy_yacht_cat term) — each city gets its own
	 * URL namespace automatically (e.g. /miami-yacht-rentals/, /panama-yacht-
	 * rentals/, or whatever a newly-created import city is called), so a
	 * fresh city created via Import Spreadsheet never shares Miami's path.
	 * Plus a fallback rule for the fleet-wide default base, for any yacht
	 * with no city term at all.
	 */
	public static function add_pretty_url_rewrite() {
		if ( ! class_exists( 'FY_Fleet_CPT' ) || ! taxonomy_exists( 'fy_yacht_cat' ) ) {
			return;
		}
		$bases = array( FY_Fleet_CPT::get_url_base() );

		$terms = get_terms( array( 'taxonomy' => 'fy_yacht_cat', 'hide_empty' => false ) );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$bases[] = $term->slug;
			}
		}

		foreach ( array_unique( $bases ) as $base ) {
			if ( '' === $base || fy_fleet_is_reserved_front_slug( $base ) ) {
				continue;
			}
			add_rewrite_rule( '^' . preg_quote( $base, '/' ) . '/([^/]+)/?$', 'index.php?product=$matches[1]', 'top' );
		}
	}

	/**
	 * Rebuild rewrite rules once after this update — a rule added above only
	 * takes effect after a flush. Flushed directly rather than by setting
	 * fy_fleet_flush_needed, because FY_Fleet_CPT::maybe_flush() (which
	 * consumes that flag) is hooked to admin_init BEFORE this is, so the
	 * flag would not be picked up until the following page load.
	 */
	public static function maybe_flush_pretty_url_rewrite() {
		if ( fy_fleet_is_plugin_admin_screen() ) {
			return;
		}
		if ( '1' !== get_option( 'fy_yacht_pretty_url_added' ) ) {
			update_option( 'fy_yacht_pretty_url_added', '1' );
			flush_rewrite_rules();
		}
	}

	/**
	 * Safety net for the pretty-URL rule above.
	 *
	 * The rule claims /{city}/{slug}/ for PRODUCTS, but the same URL shape
	 * previously belonged to the yacht CPT — and a yacht's slug is not
	 * always identical to its product's (WordPress de-duplicates slugs per
	 * post type, so "happy-place" vs "happy-place-2" happens). Without this,
	 * such an old link would 404 instead of resolving.
	 *
	 * So: if the URL resolved to a product that does not exist, but a YACHT
	 * with that slug does, hand the request to the yacht — which then 301s
	 * to its real product via FY_Fleet_CPT::redirect_yacht_page().
	 */
	public static function fallback_pretty_url( $query_vars ) {
		if ( is_admin() || fy_fleet_is_plugin_admin_screen() || empty( $query_vars['product'] ) || ! class_exists( 'FY_Fleet_CPT' ) ) {
			return $query_vars;
		}
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		if ( preg_match( '#/(wp-admin|wp-login\.php|wp-json|xmlrpc\.php)(/|$)#i', $uri ) ) {
			return $query_vars;
		}
		$slug = $query_vars['product'];
		if ( get_page_by_path( $slug, OBJECT, 'product' ) ) {
			return $query_vars; // Normal case — the product exists.
		}
		if ( get_page_by_path( $slug, OBJECT, FY_Fleet_CPT::POST_TYPE ) ) {
			unset( $query_vars['product'] );
			$query_vars['post_type']              = FY_Fleet_CPT::POST_TYPE;
			$query_vars['name']                   = $slug;
			$query_vars[ FY_Fleet_CPT::POST_TYPE ] = $slug;
		}
		return $query_vars;
	}

	/** This yacht's own URL base: its city's slug, or the fleet-wide default if it has none. */
	private static function yacht_url_base( $yacht_id ) {
		/*
		 * Must resolve to exactly what FY_Fleet_CPT::resolve_permalink() gives
		 * the YACHT page, or the two disagree and the pair redirect at each
		 * other forever: the yacht page 301s to its product, the product's
		 * permalink points back at a different base, and the browser loops.
		 *
		 * That happened whenever the configured base was a literal city slug:
		 * this method always used the yacht's own category, while the yacht
		 * page used the literal base — so every yacht NOT in that one category
		 * (e.g. all of Panama, under the "miami-yacht-rentals" default) became
		 * unreachable. Honour the configured base first; only fall back to the
		 * category slug when the base actually asks for it via %fleet%.
		 */
		$base = class_exists( 'FY_Fleet_CPT' ) ? FY_Fleet_CPT::get_url_base() : '%fleet%';
		if ( false === strpos( $base, '%fleet%' ) ) {
			return $base;
		}

		$slug  = 'yachts';
		$terms = get_the_terms( $yacht_id, 'fy_yacht_cat' );
		if ( $terms && ! is_wp_error( $terms ) && ! empty( $terms ) ) {
			$term = reset( $terms );
			$slug = $term->slug;
		}
		return str_replace( '%fleet%', $slug, $base );
	}

	/** Yacht-linked products use their city's URL base instead of /product/{slug}/. */
	public static function yacht_product_permalink( $permalink, $post ) {
		if ( ! $post || 'product' !== $post->post_type ) {
			return $permalink;
		}
		$yacht_id = (int) get_post_meta( $post->ID, '_fy_yacht_id', true );
		if ( ! $yacht_id ) {
			return $permalink;
		}
		return home_url( '/' . self::yacht_url_base( $yacht_id ) . '/' . $post->post_name . '/' );
	}

	/* ------------------------------------------------------------------
	 * Product sync
	 * ---------------------------------------------------------------- */

	public static function get_product_id( $yacht_id ) {
		$product_id = (int) get_post_meta( $yacht_id, '_fy_product_id', true );
		if ( $product_id && 'product' === get_post_type( $product_id ) && 'trash' !== get_post_status( $product_id ) ) {
			return $product_id;
		}
		return 0;
	}

	/**
	 * Smart defaults on save, so a new yacht is fully wired with zero extra clicks:
	 *
	 *  - Button URL: if empty, filled with the yacht's WooCommerce PRODUCT
	 *    page URL (created on the spot if missing) — where the shortcode
	 *    description stack renders and native Add to Cart handles the sale.
	 *    Never overwrites a URL you typed yourself, so the 48 existing
	 *    yachts keep their current links.
	 *  - Featured image: if only an Image URL is set, the photo is pulled
	 *    into the Media Library once and set as the featured image — which
	 *    then flows to the WooCommerce product, checkout thumbnails and
	 *    social sharing automatically.
	 */
	public static function fill_defaults( $yacht_id, $yacht = null, $sideload = true ) {
		if ( wp_is_post_revision( $yacht_id ) || wp_is_post_autosave( $yacht_id ) ) {
			return;
		}
		$yacht = $yacht ? $yacht : get_post( $yacht_id );
		if ( ! $yacht || FY_Fleet_CPT::POST_TYPE !== $yacht->post_type || 'auto-draft' === $yacht->post_status ) {
			return;
		}

		// 1. Button URL default → the yacht's WOOCOMMERCE PRODUCT page, where
		// the shortcode description stack renders and native Woo checkout
		// handles the purchase. (Owner's call: everything buys through Woo.)
		//
		// Cached once and never overwritten after — which is exactly the
		// trap: the product's URL includes the yacht's CITY term
		// (yacht_url_base()), and if this runs before that term is actually
		// assigned (e.g. a bulk import that publishes the post, then tags
		// it), it permanently caches a URL built from no term at all —
		// silently falling back to a hardcoded default city. ~60 yachts from
		// the last bulk import ended up stuck pointing at the WRONG city's
		// URL this way, a real broken "Book Experience" link, not just a
		// cosmetic one. Leaving the field empty until a term exists is safe
		// — an empty button URL is obviously incomplete; a wrong one looks
		// fine and quietly breaks for customers.
		$has_city_term = get_the_terms( $yacht_id, 'fy_yacht_cat' );
		$has_city_term = $has_city_term && ! is_wp_error( $has_city_term ) && ! empty( $has_city_term );
		if ( 'publish' === $yacht->post_status
			&& '' === trim( (string) get_post_meta( $yacht_id, '_fy_button_url', true ) )
			&& $has_city_term
		) {
			$product_id = self::get_product_id( $yacht_id );
			if ( ! $product_id ) {
				$product_id = self::sync_product( $yacht_id, $yacht );
			}
			$permalink = $product_id ? get_permalink( $product_id ) : '';
			if ( $permalink ) {
				update_post_meta( $yacht_id, '_fy_button_url', $permalink );
			}
		}

		// 2. Featured image from the Image URL field (one attempt per URL, so a
		// broken link can't slow down every save; retried if the URL changes).
		if ( $sideload && ! has_post_thumbnail( $yacht_id ) ) {
			$image_url = trim( (string) get_post_meta( $yacht_id, '_fy_image_url', true ) );
			if ( '' !== $image_url && get_post_meta( $yacht_id, '_fy_image_sideloaded', true ) !== md5( $image_url ) ) {
				update_post_meta( $yacht_id, '_fy_image_sideloaded', md5( $image_url ) );

				require_once ABSPATH . 'wp-admin/includes/media.php';
				require_once ABSPATH . 'wp-admin/includes/file.php';
				require_once ABSPATH . 'wp-admin/includes/image.php';

				$attachment_id = media_sideload_image( $image_url, $yacht_id, get_the_title( $yacht ), 'id' );
				if ( ! is_wp_error( $attachment_id ) ) {
					set_post_thumbnail( $yacht_id, $attachment_id );
				} elseif ( class_exists( 'FY_Fleet_Log' ) ) {
					FY_Fleet_Log::add( 'image.failed', sprintf( 'Could not import image for "%s": %s', get_the_title( $yacht ), $attachment_id->get_error_message() ) );
				}
			}
		}
	}

	/**
	 * Download every photo URL for a yacht into the Media Library and make
	 * them that yacht's own gallery ([fy_yacht_gallery] renders them when no
	 * shared gallery is assigned), plus the WooCommerce product's gallery.
	 * The first photo becomes the featured image on both the yacht card and
	 * the product.
	 *
	 * Already-imported URLs are skipped (tracked by hash) so re-running an
	 * import doesn't re-download or duplicate Media Library attachments.
	 *
	 * Resumable: pass $offset to continue part-way through a yacht's photo
	 * list, and $budget_seconds to stop cleanly once that much wall time has
	 * been spent. A yacht with 145 photos would otherwise mean 145 sequential
	 * downloads from an external host inside ONE request — comfortably past
	 * most hosts' PHP timeout, which surfaces as a 502.
	 *
	 * @param int   $yacht_id       Yacht post ID.
	 * @param array $urls           Photo URLs, in order — first URL = featured image.
	 * @param int   $offset         Index to resume from (0 = start fresh).
	 * @param float $budget_seconds Stop after this much time; 0 = no limit.
	 * @return array{ids:int[],next_offset:int,done:bool,total:int}
	 */
	/**
	 * Descriptive alt text for an imported photo, built from the yacht's own
	 * data ("Hurricane — 26ft yacht charter in Miami").
	 *
	 * Sideloaded images arrive with an empty alt, which is both an
	 * accessibility gap and a missed image-search signal — and it's not
	 * something an SEO plugin can fill in, because only this plugin knows the
	 * size and the city. Never overwrites alt text set by hand.
	 */
	public static function set_image_alt( $attachment_id, $yacht_id ) {
		if ( ! $attachment_id || ! $yacht_id ) {
			return;
		}
		if ( '' !== trim( (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) ) ) {
			return;
		}

		$parts = array( get_the_title( $yacht_id ) );
		$size  = (int) get_post_meta( $yacht_id, '_fy_size_ft', true );
		if ( $size ) {
			/* translators: %d: length in feet */
			$parts[] = sprintf( __( '%dft yacht charter', 'fy-fleet' ), $size );
		} else {
			$parts[] = __( 'yacht charter', 'fy-fleet' );
		}

		$terms = get_the_terms( $yacht_id, 'fy_yacht_cat' );
		if ( $terms && ! is_wp_error( $terms ) ) {
			$term  = reset( $terms );
			$city  = class_exists( 'FY_Fleet_Pages' ) ? FY_Fleet_Pages::readable_term_name( $term ) : $term->name;
			$parts[] = sprintf( __( 'in %s', 'fy-fleet' ), $city );
		}

		update_post_meta( $attachment_id, '_wp_attachment_image_alt', implode( ' — ', array_slice( $parts, 0, 2 ) ) . ( isset( $parts[2] ) ? ' ' . $parts[2] : '' ) );
	}

	public static function import_gallery_images( $yacht_id, array $urls, $offset = 0, $budget_seconds = 0 ) {
		$urls   = array_values( array_filter( array_map( 'trim', $urls ) ) );
		$total  = count( $urls );
		$offset = max( 0, (int) $offset );

		$stored = get_post_meta( $yacht_id, '_fy_gallery_image_ids', true );
		$stored = is_array( $stored ) ? array_values( array_filter( array_map( 'intval', $stored ) ) ) : array();

		if ( 0 === $total ) {
			return array( 'ids' => $stored, 'next_offset' => 0, 'done' => true, 'total' => 0 );
		}

		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$known_hashes = get_post_meta( $yacht_id, '_fy_gallery_source_hashes', true );
		$known_hashes = is_array( $known_hashes ) ? $known_hashes : array();

		$title = get_the_title( $yacht_id );
		// Resuming mid-yacht keeps what previous chunks already collected;
		// starting fresh (offset 0) rebuilds the list from this run.
		$ids     = ( $offset > 0 ) ? $stored : array();
		$started = microtime( true );
		$index   = $offset;

		while ( $index < $total ) {
			$url  = $urls[ $index ];
			$hash = md5( $url );
			$index++;

			if ( isset( $known_hashes[ $hash ] ) ) {
				// Already imported — reuse the existing attachment if it's
				// still around; otherwise fall through and re-download.
				$existing = (int) $known_hashes[ $hash ];
				if ( $existing && 'attachment' === get_post_type( $existing ) ) {
					$ids[] = $existing;
					continue;
				}
			}

			$attachment_id = media_sideload_image( $url, $yacht_id, $title, 'id' );
			if ( is_wp_error( $attachment_id ) ) {
				if ( class_exists( 'FY_Fleet_Log' ) ) {
					FY_Fleet_Log::add( 'image.failed', sprintf( 'Could not import gallery photo for "%s": %s', $title, $attachment_id->get_error_message() ), array( 'url' => $url ) );
				}
			} else {
				$known_hashes[ $hash ] = $attachment_id;
				$ids[]                 = $attachment_id;
				self::set_image_alt( $attachment_id, $yacht_id );
			}

			// Out of time — save what we have and let the caller resume.
			if ( $budget_seconds > 0 && ( microtime( true ) - $started ) >= $budget_seconds ) {
				break;
			}
		}

		$ids = array_values( array_unique( $ids ) );

		update_post_meta( $yacht_id, '_fy_gallery_source_hashes', $known_hashes );
		update_post_meta( $yacht_id, '_fy_gallery_image_ids', $ids );

		if ( ! empty( $ids ) ) {
			set_post_thumbnail( $yacht_id, $ids[0] );
		}

		self::push_gallery_to_product( $yacht_id, $ids );

		return array(
			'ids'         => $ids,
			'next_offset' => $index,
			'done'        => $index >= $total,
			'total'       => $total,
		);
	}

	/** Mirror a yacht's gallery (and featured image) onto its WooCommerce product. */
	public static function push_gallery_to_product( $yacht_id, $ids = null ) {
		if ( null === $ids ) {
			$ids = get_post_meta( $yacht_id, '_fy_gallery_image_ids', true );
			$ids = is_array( $ids ) ? $ids : array();
		}
		$product_id = self::get_product_id( $yacht_id );
		if ( ! $product_id ) {
			return;
		}
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return;
		}
		if ( ! empty( $ids ) ) {
			$product->set_image_id( $ids[0] );
			$product->set_gallery_image_ids( array_slice( $ids, 1 ) );
		} else {
			$product->set_gallery_image_ids( array() );
		}
		$product->save();
	}

	/**
	 * Create or update the WooCommerce product backing a yacht.
	 *
	 * @return int Product ID, or 0 on failure.
	 */
	public static function sync_product( $yacht_id, $yacht = null ) {
		if ( ! self::active() ) {
			return 0;
		}
		if ( wp_is_post_revision( $yacht_id ) || wp_is_post_autosave( $yacht_id ) ) {
			return 0;
		}
		$yacht = $yacht ? $yacht : get_post( $yacht_id );
		if ( ! $yacht || FY_Fleet_CPT::POST_TYPE !== $yacht->post_type ) {
			return 0;
		}
		if ( 'auto-draft' === $yacht->post_status ) {
			return 0;
		}

		$product_id = self::get_product_id( $yacht_id );
		$price      = (float) get_post_meta( $yacht_id, '_fy_price', true );
		$deposit    = FY_Fleet_Pricing::deposit_for( $price );

		$rows          = get_post_meta( $yacht_id, '_fy_pricing', true );
		$duration_rows = array();
		foreach ( (array) $rows as $row ) {
			if ( isset( $row['type'] ) && 'price' === $row['type'] && '' !== trim( (string) ( $row['duration'] ?? '' ) ) ) {
				$duration_rows[] = $row;
			}
		}
		// A yacht with real bookable durations gets a WooCommerce VARIABLE
		// product — one variation per duration (Charter Duration attribute),
		// so the site's product-page booking widget (built around WooCommerce
		// product variations) works the same for these as for every other
		// yacht. A yacht with no duration rows yet falls back to a simple
		// product priced at its starting rate, same as before.
		$make_variable = ! empty( $duration_rows );

		if ( $product_id ) {
			$product = wc_get_product( $product_id );
			$is_variable = $product && $product->is_type( 'variable' );
			if ( $make_variable && ! $is_variable ) {
				wp_set_object_terms( $product_id, 'variable', 'product_type' );
				$product = new WC_Product_Variable( $product_id );
			} elseif ( ! $make_variable && $is_variable ) {
				foreach ( $product->get_children() as $orphaned_variation_id ) {
					wp_delete_post( $orphaned_variation_id, true );
				}
				wp_set_object_terms( $product_id, 'simple', 'product_type' );
				$product = new WC_Product_Simple( $product_id );
			}
		} else {
			$product = $make_variable ? new WC_Product_Variable() : new WC_Product_Simple();
		}
		if ( ! $product ) {
			$product = $make_variable ? new WC_Product_Variable() : new WC_Product_Simple();
		}

		$product->set_name( $yacht->post_title );
		// Published yacht → published product. Unpublished yacht → only HIDE a
		// live product (private); a product someone is still drafting keeps its
		// draft status instead of being hijacked to private. A BRAND-NEW product
		// must always get an explicit status — WooCommerce falls back to
		// 'publish' for an empty one, which would put a live buy page behind a
		// draft yacht (e.g. fresh Duplicates).
		if ( 'publish' === $yacht->post_status ) {
			$product->set_status( 'publish' );
		} elseif ( ! $product_id ) {
			$product->set_status( 'private' );
		} elseif ( 'publish' === $product->get_status() ) {
			$product->set_status( 'private' );
		}
		$product->set_catalog_visibility( 'hidden' );
		$product->set_virtual( true );
		$product->set_sold_individually( true );
		// These are bookable services, not counted inventory — always
		// purchasable regardless of the store's default stock settings.
		$product->set_manage_stock( false );
		$product->set_stock_status( 'instock' );

		if ( $make_variable ) {
			// A failure here (attribute/taxonomy creation, term insert) must
			// not stop the product from saving at all — fall back to a
			// simple starting price so the yacht still has a working
			// product; log it so it's visible instead of silently missing.
			try {
				self::set_variation_attributes( $product, $yacht_id, $duration_rows );
			} catch ( \Throwable $e ) {
				$make_variable = false;
				$product->set_regular_price( $deposit > 0 ? $deposit : $price );
				$product->set_price( $deposit > 0 ? $deposit : $price );
				if ( class_exists( 'FY_Fleet_Log' ) ) {
					FY_Fleet_Log::add( 'variations.failed', sprintf( 'Could not set up variations for yacht #%d, fell back to a simple price: %s', $yacht_id, $e->getMessage() ) );
				}
			}
		} else {
			$product->set_regular_price( $deposit > 0 ? $deposit : $price );
			$product->set_price( $deposit > 0 ? $deposit : $price );
		}

		// The excerpt is what Rank Math (and Facebook/WhatsApp) fall back to
		// for the description. It used to be the price note — blank on almost
		// every yacht — so they fell through to the page CONTENT, which is
		// the shortcode stack, and every yacht described itself as
		// "[fy_yacht_layout] [fy_yacht_reviews] [fy_yacht_marina]". Lead with
		// the unique description written for this yacht at import.
		$short_desc = trim( (string) get_post_meta( $yacht_id, '_fy_special_desc', true ) );
		if ( '' === $short_desc ) {
			$short_desc = trim( (string) get_post_meta( $yacht_id, '_fy_price_note', true ) );
		}
		$product->set_short_description( $short_desc );
		// The product description is the [fy_yacht_*] shortcode stack — visible
		// and re-orderable right in the product editor. Empty, marker-carrying
		// and legacy rendered-HTML descriptions are (re)set to the stack; a
		// stack the owner customised (marker removed, shortcodes kept) is left
		// exactly as they arranged it.
		$existing = $product_id ? (string) $product->get_description( 'edit' ) : '';
		if ( false !== strpos( $existing, self::AUTO_MARK ) || false === strpos( $existing, '[fy_yacht_' ) ) {
			$product->set_description( self::default_description_stack() );
		}

		$thumb_id = get_post_thumbnail_id( $yacht_id );
		if ( $thumb_id ) {
			$product->set_image_id( $thumb_id );
		}

		// Yacht's own photo gallery → the product gallery, set on this same
		// $product object so it's included in the single save() below
		// instead of triggering a second product save (which would fire
		// save_post_product — and everything hooked to it — twice per sync).
		// Only pushed once the yacht has actually declared a gallery state
		// (an array, even an empty one) — a yacht that has never touched
		// this field leaves the product's own gallery untouched.
		$gallery_ids = get_post_meta( $yacht_id, '_fy_gallery_image_ids', true );
		if ( is_array( $gallery_ids ) && ! empty( $gallery_ids ) ) {
			$product->set_image_id( $gallery_ids[0] );
			$product->set_gallery_image_ids( array_slice( $gallery_ids, 1 ) );
		} elseif ( is_array( $gallery_ids ) ) {
			$product->set_gallery_image_ids( array() );
		}

		$new_id = $product->save();
		if ( ! $new_id ) {
			return 0;
		}

		update_post_meta( $new_id, '_fy_yacht_id', $yacht_id );
		update_post_meta( $yacht_id, '_fy_product_id', $new_id );

		if ( $make_variable ) {
			try {
				self::sync_variations( $new_id, $yacht_id, $duration_rows );
			} catch ( \Throwable $e ) {
				if ( class_exists( 'FY_Fleet_Log' ) ) {
					FY_Fleet_Log::add( 'variations.failed', sprintf( 'Could not rebuild variations for product #%d: %s', $new_id, $e->getMessage() ) );
				}
			}
		}

		return $new_id;
	}

	/**
	 * Global product attribute taxonomy, created on the fly if this store
	 * doesn't have it yet — "Charter Duration" and "Passenger Count" are
	 * shared across every yacht (matches how the site's product template
	 * expects #pa_charter-duration / #pa_passenger-count to exist).
	 *
	 * @return string The pa_{slug} taxonomy name.
	 */
	private static function ensure_global_attribute( $slug, $label ) {
		$taxonomy = wc_attribute_taxonomy_name( $slug );

		if ( ! taxonomy_exists( $taxonomy ) ) {
			if ( ! wc_attribute_taxonomy_id_by_name( $slug ) ) {
				wc_create_attribute(
					array(
						'name'         => $label,
						'slug'         => $slug,
						'type'         => 'select',
						'order_by'     => 'menu_order',
						'has_archives' => false,
					)
				);
			}
			// WooCommerce normally registers pa_* taxonomies on `init`, which
			// has already run earlier in this request (before this save_post
			// handler) — register it now too so it's usable immediately,
			// otherwise the terms/attribute below would fail silently.
			register_taxonomy(
				$taxonomy,
				apply_filters( 'woocommerce_taxonomy_objects_' . $taxonomy, array( 'product' ) ),
				apply_filters(
					'woocommerce_taxonomy_args_' . $taxonomy,
					array(
						'labels'       => array( 'name' => $label ),
						'hierarchical' => false,
						'show_ui'      => false,
						'query_var'    => true,
						'rewrite'      => false,
					)
				)
			);
		}

		return $taxonomy;
	}

	/** Term ID for a value in a global attribute taxonomy, creating it if needed. */
	private static function ensure_attribute_term( $taxonomy, $value ) {
		$value = trim( (string) $value );
		$term  = get_term_by( 'name', $value, $taxonomy );
		if ( $term && ! is_wp_error( $term ) ) {
			return (int) $term->term_id;
		}
		$created = wp_insert_term( $value, $taxonomy );
		if ( is_wp_error( $created ) ) {
			// Race with another process creating the same term — look it up again.
			$term = get_term_by( 'name', $value, $taxonomy );
			return ( $term && ! is_wp_error( $term ) ) ? (int) $term->term_id : 0;
		}
		return (int) $created['term_id'];
	}

	/**
	 * Sets the parent product's two attributes: Charter Duration (the real
	 * variation axis — one term per duration row) and Passenger Count
	 * (informational only, up to this yacht's capacity — does NOT fork
	 * variations, since guest count never changes the price).
	 */
	private static function set_variation_attributes( $product, $yacht_id, $duration_rows ) {
		$duration_tax = self::ensure_global_attribute( 'charter-duration', __( 'Charter Duration', 'fy-fleet' ) );
		$duration_ids = array();
		foreach ( $duration_rows as $row ) {
			$duration_ids[] = self::ensure_attribute_term( $duration_tax, $row['duration'] );
		}
		$duration_ids = array_values( array_unique( array_filter( $duration_ids ) ) );

		$passenger_tax = self::ensure_global_attribute( 'passenger-count', __( 'Passenger Count', 'fy-fleet' ) );
		// Capped — a megayacht's real capacity can run into the hundreds,
		// which would otherwise mean that many wp_insert_term() calls (one
		// DB write each) on every single sync. Past this, the dropdown
		// switches from "every number" to a round-number scale, which is
		// plenty for a passenger-count selector that doesn't affect price.
		$capacity      = max( 1, min( 40, FY_Fleet_CPT::capacity( $yacht_id ) ) );
		$passenger_ids = array();
		for ( $i = 1; $i <= $capacity; $i++ ) {
			$passenger_ids[] = self::ensure_attribute_term( $passenger_tax, (string) $i );
		}
		$passenger_ids = array_values( array_unique( array_filter( $passenger_ids ) ) );

		// A taxonomy-backed attribute with id 0 would be silently treated as
		// a free-text custom attribute, whose "options" are strings rather
		// than term IDs — producing variations that never match. Fail loudly
		// instead so sync_product()'s catch falls back to a simple product.
		$duration_attr_id  = wc_attribute_taxonomy_id_by_name( 'charter-duration' );
		$passenger_attr_id = wc_attribute_taxonomy_id_by_name( 'passenger-count' );
		if ( ! $duration_attr_id || empty( $duration_ids ) ) {
			throw new RuntimeException( 'Charter Duration attribute taxonomy is unavailable.' );
		}

		$duration_attr = new WC_Product_Attribute();
		$duration_attr->set_id( $duration_attr_id );
		$duration_attr->set_name( $duration_tax );
		$duration_attr->set_options( $duration_ids );
		$duration_attr->set_position( 0 );
		$duration_attr->set_visible( true );
		$duration_attr->set_variation( true );

		$attributes = array( $duration_attr );

		// Passenger Count is a nice-to-have selector, not required for
		// pricing — include it only when its taxonomy resolved cleanly.
		if ( $passenger_attr_id && ! empty( $passenger_ids ) ) {
			$passenger_attr = new WC_Product_Attribute();
			$passenger_attr->set_id( $passenger_attr_id );
			$passenger_attr->set_name( $passenger_tax );
			$passenger_attr->set_options( $passenger_ids );
			$passenger_attr->set_position( 1 );
			$passenger_attr->set_visible( true );
			// Selectable on the booking form. Marked as a variation attribute
			// so it renders as a DROPDOWN rather than a row in the spec table
			// — but every variation leaves it as "Any", so guest count never
			// multiplies the variation count or changes the price. Without
			// this the customer could never state their party size.
			$passenger_attr->set_variation( true );
			$attributes[] = $passenger_attr;
		}

		$product->set_attributes( $attributes );
	}

	/**
	 * Rebuilds every variation for a yacht's product from its current Hours
	 * & Pricing rows. Each variation is priced at crew + hourly boat deposit
	 * for that duration's hours (plus a percent boat deposit over $1,400).
	 * Crew is a reservation fee. Only deposits are credited against the boat
	 * — see FY_Fleet_Pricing::quote() / dock_balance() for the same math.
	 * Existing variations are deleted and recreated each sync rather than
	 * diffed, since the row set is small and this keeps stale durations
	 * (removed from Hours & Pricing) from lingering as orphaned variations.
	 */
	private static function sync_variations( $product_id, $yacht_id, $duration_rows ) {
		$duration_tax = wc_attribute_taxonomy_name( 'charter-duration' );

		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			return;
		}

		foreach ( $product->get_children() as $existing_variation_id ) {
			wp_delete_post( $existing_variation_id, true );
		}

		foreach ( $duration_rows as $row ) {
			// One bad row (e.g. a duration label hours_from_label() can't
			// parse, or a WC validation exception on save) must not fatal
			// the whole import batch — skip it and keep going.
			try {
				$hours = FY_Fleet_Pricing::hours_from_label( $row['duration'] );
				if ( $hours <= 0 ) {
					continue;
				}
				// Crew + hourly boat deposit for the hours booked — no
				// service fee — plus, when this duration's boat cost tops
				// $1,400, a 20% deposit on the boat. Charged-today dollars
				// stay the same. Dock credits deposits only, not crew.
				$boat      = (float) $row['price'];
				$crew_rate = FY_Fleet_Pricing::crew_rate_for_boat( $yacht_id, $boat );
				$fuel_rate = FY_Fleet_Pricing::fuel_rate_for_boat( $yacht_id, $boat );
				$price     = round(
					( ( $crew_rate + $fuel_rate ) * $hours )
					+ FY_Fleet_Pricing::charter_deposit_for_boat( $boat ),
					2
				);

				$variation = new WC_Product_Variation();
				$variation->set_parent_id( $product_id );
				// Duration is pinned; passenger count is left EMPTY, which is
				// WooCommerce's "Any …" — one variation per duration serves
				// every guest count, so 6 durations stay 6 variations instead
				// of exploding into 6 × capacity.
				$variation->set_attributes(
					array(
						$duration_tax                                     => sanitize_title( $row['duration'] ),
						wc_attribute_taxonomy_name( 'passenger-count' )   => '',
					)
				);
				$variation->set_regular_price( (string) $price );
				$variation->set_price( (string) $price );
				$variation->set_virtual( true );
				$variation->set_manage_stock( false );
				$variation->set_stock_status( 'instock' );
				$variation->save();
			} catch ( \Throwable $e ) {
				if ( class_exists( 'FY_Fleet_Log' ) ) {
					FY_Fleet_Log::add( 'variation.failed', sprintf( 'Could not create "%s" variation for product #%d: %s', $row['duration'], $product_id, $e->getMessage() ) );
				}
			}
		}

		// Recalculate the parent's cached price range (min/max across variations).
		WC_Product_Variable::sync( $product_id );
		wc_delete_product_transients( $product_id );
	}

	/** The full yacht card as product-description HTML — tabs + the rest, stacked. */
	public static function build_product_description( $yacht_id ) {
		return self::render_details_tabs( $yacht_id )
			. self::part_deposit( $yacht_id )
			. ( class_exists( 'FY_Fleet_Reviews' ) ? FY_Fleet_Reviews::render( $yacht_id ) : '' )
			. ( class_exists( 'FY_Fleet_Marina' ) ? FY_Fleet_Marina::render( $yacht_id ) : '' );
	}

	/**
	 * [fy_yacht_layout] — the two-row product block.
	 *
	 *   row 1:  Yacht Specifications  |  Charter Hours
	 *   row 2:  the map, spanning both columns
	 *
	 * Replaces the hand-built four-card grid: Charter Hours takes the slot
	 * Departure Area used to hold, the map gets the full second row, and
	 * Deposit Information is gone — the payment summary on the booking form
	 * already answers that, so repeating it here only invited the wrong
	 * reading of what's charged today.
	 *
	 * A card is skipped entirely when its yacht has no data for it, so a
	 * yacht with no marina set doesn't render an empty map frame.
	 */
	public static function render_product_layout( $yacht_id ) {
		$card = 'background:#fff;border:1px solid rgba(37,99,235,.16);border-radius:16px;padding:18px 20px';
		$head = 'margin:0 0 12px;font-size:18px;font-weight:900;color:#172033';

		$specs    = self::part_specs( $yacht_id );
		$hours    = self::part_hours( $yacht_id );
		$location = self::part_location( $yacht_id, true );

		$html = '<div class="fy-yacht-layout" style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin:0 0 22px">';

		if ( $specs ) {
			$html .= '<div class="fy-yl-card" style="' . $card . '">'
				. '<h3 style="' . $head . '">🛥️ ' . esc_html__( 'Yacht Specifications', 'fy-fleet' ) . '</h3>'
				. $specs . '</div>';
		}

		// part_hours prints its own "Hours & Pricing" heading, so this card
		// deliberately adds none — two headings looked like a bug.
		if ( $hours ) {
			$html .= '<div class="fy-yl-card" style="' . $card . '">' . $hours . '</div>';
		}

		if ( $location ) {
			$html .= '<div class="fy-yl-card fy-yl-wide" style="' . $card . ';grid-column:1/-1">'
				. '<h3 style="' . $head . '">📍 ' . esc_html__( 'Departure Area', 'fy-fleet' ) . '</h3>'
				. $location . '</div>';
		}

		$html .= '</div>';

		// A crawlable link back to this yacht's city hub. Every yacht page
		// pointing at its city (and the hub listing every yacht) is what turns
		// 180 loose pages into one connected topic — a relationship no SEO
		// plugin can build for us, because only this plugin knows which city
		// a yacht belongs to.
		$terms = get_the_terms( $yacht_id, 'fy_yacht_cat' );
		if ( $terms && ! is_wp_error( $terms ) ) {
			$term = reset( $terms );
			$link = get_term_link( $term );
			if ( $link && ! is_wp_error( $link ) ) {
				$city  = class_exists( 'FY_Fleet_Pages' ) ? FY_Fleet_Pages::readable_term_name( $term ) : $term->name;
				$html .= '<p class="fy-city-link" style="margin:0 0 22px;font-size:14px;color:#526079">'
					. '⚓ <a href="' . esc_url( $link ) . '" style="font-weight:700;color:#1E40AF">'
					. sprintf(
						/* translators: %s: city name */
						esc_html__( 'See every yacht in our %s fleet', 'fy-fleet' ),
						esc_html( $city )
					)
					. '</a></p>';
			}
		}

		// One column on phones. Inlined because the product description is
		// stored as post content and rendered outside our stylesheet.
		$html .= '<style>@media(max-width:782px){.fy-yacht-layout{grid-template-columns:1fr!important}}</style>';

		return $html;
	}

	/** [fy_yacht_special] — the staff-written intro, styled as a hero callout. */
	public static function part_special( $yacht_id ) {
		$text = trim( (string) get_post_meta( $yacht_id, '_fy_special_desc', true ) );
		if ( '' === $text ) {
			return '';
		}
		$body = wpautop( wp_kses_post( $text ) );
		$body = str_replace( '<p>', '<p style="margin:0 0 .65em;font-size:17px;line-height:1.75;color:#172033;font-weight:500">', $body );

		return '<div style="margin:0 0 24px;padding:20px 24px;border:1px solid rgba(124,58,237,.18);border-left:6px solid #E45C9C;border-radius:18px;'
			. 'background:linear-gradient(120deg,#ffffff,#FFF5FA 55%,#F3E8FF);box-shadow:0 10px 26px rgba(91,33,182,.09)">'
			. '<span style="display:block;margin-bottom:8px;font-size:11px;font-weight:900;letter-spacing:.07em;text-transform:uppercase;color:#C94386">⚓ '
			. esc_html__( 'Feeling Yachty', 'fy-fleet' ) . '</span>'
			. $body . '</div>';
	}

	/** [fy_yacht_specs] — best-for line + size/guests/price/year/brand/rating pills. */
	public static function part_specs( $yacht_id ) {
		$size    = get_post_meta( $yacht_id, '_fy_size_ft', true );
		$price   = (float) get_post_meta( $yacht_id, '_fy_price', true );
		$note    = get_post_meta( $yacht_id, '_fy_price_note', true );
		$year    = get_post_meta( $yacht_id, '_fy_year', true );
		$brand   = get_post_meta( $yacht_id, '_fy_brand', true );
		$model   = get_post_meta( $yacht_id, '_fy_model', true );
		$captain = get_post_meta( $yacht_id, '_fy_captain_included', true );
		$rating  = get_post_meta( $yacht_id, '_fy_rating', true );

		$pill  = 'display:inline-block;padding:10px 16px;border:1.5px solid rgba(37,99,235,.18);border-radius:14px;'
			. 'background:linear-gradient(160deg,#ffffff,#F3F7FF);color:#172033;font-weight:800;font-size:14px;'
			. 'box-shadow:0 4px 12px rgba(23,32,51,.05);margin:0 8px 8px 0';
		$pills = array();
		if ( $brand || $model ) {
			$pills[] = '<span style="' . $pill . '">⛵ ' . esc_html( trim( $brand . ' ' . $model ) ) . '</span>';
		}
		if ( $size ) {
			$pills[] = '<span style="' . $pill . '">📏 ' . esc_html( $size ) . ' ft</span>';
		}
		if ( $year ) {
			$pills[] = '<span style="' . $pill . '">📅 ' . esc_html( $year ) . '</span>';
		}
		$capacity = FY_Fleet_CPT::capacity( $yacht_id );
		if ( $capacity > 0 ) {
			$pills[] = '<span style="' . $pill . '">👥 ' . sprintf( esc_html__( 'Up to %d guests', 'fy-fleet' ), $capacity ) . '</span>';
		}
		if ( $captain ) {
			$pills[] = '<span style="' . $pill . '">⚓ ' . esc_html__( 'Captain included', 'fy-fleet' ) . '</span>';
		}
		if ( '' !== $rating && (float) $rating > 0 ) {
			$pills[] = '<span style="' . $pill . '">⭐ ' . esc_html( number_format( (float) $rating, 1 ) ) . '</span>';
		}
		if ( $price > 0 ) {
			$pill_from  = FY_Fleet_Pricing::display_from_price( $yacht_id );
			$pill_price = $pill_from ? $pill_from['amount'] : $price;
			$price_unit = $pill_from ? FY_Fleet_Pricing::display_from_unit( $yacht_id, $pill_from ) : '';
			$pills[] = '<span style="' . $pill . ';border-color:rgba(228,92,156,.35);background:linear-gradient(160deg,#ffffff,#FFF4F9)">💵 <span style="color:#C94386">'
				. sprintf( esc_html__( 'From $%s', 'fy-fleet' ), number_format( $pill_price ) )
				. ( $price_unit ? ' ' . esc_html( $price_unit ) : '' ) . '</span>'
				. ( $note ? ' <span style="font-weight:600;color:#526079;font-size:12px">(' . esc_html( $note ) . ')</span>' : '' ) . '</span>';
		}

		$html = '';
		if ( $pills ) {
			$html .= '<div style="margin:0 0 22px">' . implode( '', $pills ) . '</div>';
		}
		return $html;
	}

	/** [fy_yacht_hours] — every duration and total price, split by day headings. */
	public static function part_hours( $yacht_id ) {
		$rows = get_post_meta( $yacht_id, '_fy_pricing', true );
		if ( ! is_array( $rows ) || empty( $rows ) ) {
			return '';
		}

		$row_style = 'display:flex;justify-content:space-between;gap:12px;padding:11px 15px;margin:0 0 7px;'
			. 'border:1px solid rgba(37,99,235,.14);border-radius:12px;background:#ffffff;box-shadow:0 3px 10px rgba(23,32,51,.04)';

		$html = '<h3 style="margin:0 0 12px;font-size:18px;font-weight:900;color:#172033">⏱️ ' . esc_html__( 'Hours & Pricing', 'fy-fleet' ) . '</h3>';
		foreach ( $rows as $row ) {
			$type = isset( $row['type'] ) ? $row['type'] : 'price';
			if ( 'heading' === $type ) {
				$html .= '<p style="margin:14px 0 8px;padding:7px 12px;border-radius:10px;background:#EFF6FF;color:#1E40AF;'
					. 'font-size:12px;font-weight:900;letter-spacing:.05em;text-transform:uppercase;text-align:center">📅 ' . esc_html( $row['text'] ) . '</p>';
			} elseif ( 'note' === $type ) {
				$html .= '<p style="margin:0 0 7px;padding:8px 12px;border-radius:10px;background:#F3E8FF;color:#5B21B6;font-size:13px;font-weight:700;text-align:center">' . esc_html( $row['text'] ) . '</p>';
			} else {
				$boat   = (float) $row['price'];
				$hours  = FY_Fleet_Pricing::hours_from_label( isset( $row['duration'] ) ? $row['duration'] : '' );
				$listed = FY_Fleet_Pricing::listed_total( $yacht_id, $boat, $hours );
				$html  .= '<div style="' . $row_style . '"><span style="font-weight:800;color:#172033">' . esc_html( $row['duration'] ) . '</span>'
					. '<span style="font-weight:900;color:#C94386">$' . esc_html( number_format( $listed ) )
					. ' <span style="font-weight:700;color:#94a3b8;font-size:11px;text-transform:uppercase">' . esc_html__( 'boat + crew + fuel', 'fy-fleet' ) . '</span></span></div>';
			}
		}
		// Same rates quote() / sync_variations() charge. Yacht overrides
		// replace the fleet bands; otherwise use the live $800 / $1,400
		// settings so this note cannot drift from Checkout & Integrations.
		$crew_lock  = get_post_meta( $yacht_id, '_fy_crew_rate', true );
		$fuel_lock  = get_post_meta( $yacht_id, '_fy_fuel_rate', true );
		$crew_under = FY_Fleet_Settings::get_crew_rate_under();
		$crew_over  = FY_Fleet_Settings::get_crew_rate();
		$fuel_low   = FY_Fleet_Settings::get_fuel_rate_under();
		$fuel_rate  = FY_Fleet_Settings::get_fuel_rate();
		$crew_line  = FY_Fleet_Settings::get_charter_deposit_threshold();
		$fuel_line  = FY_Fleet_Settings::get_fuel_threshold();
		$html      .= '<p style="margin:0 0 7px;padding:8px 12px;border-radius:10px;background:#F3E8FF;color:#5B21B6;font-size:12.5px;font-weight:700;text-align:center">'
			. esc_html__( 'Prices above are boat + crew + fuel.', 'fy-fleet' ) . ' ';
		// Describe each rate on its own: a yacht may override only crew or
		// only fuel, and the non-overridden one still follows the fleet
		// bands — claiming a single flat rate for it would state the wrong
		// price for boats under the threshold.
		$sentences = array();
		if ( '' !== $crew_lock ) {
			$sentences[] = sprintf(
				/* translators: %s: crew $/hr */
				__( 'This yacht uses $%s/hr crew on every duration.', 'fy-fleet' ),
				number_format( (float) $crew_lock )
			);
		} elseif ( $crew_under > 0 || $crew_over > 0 ) {
			$sentences[] = sprintf(
				/* translators: 1: crew under line, 2: crew over line, 3: $1,400 line */
				__( 'Crew is $%1$s/hr at or under $%3$s and $%2$s/hr over $%3$s.', 'fy-fleet' ),
				number_format( $crew_under ),
				number_format( $crew_over ),
				number_format( $crew_line )
			);
		}
		if ( '' !== $fuel_lock ) {
			$locked_fuel = (float) $fuel_lock;
			$sentences[] = sprintf(
				/* translators: %s: fuel $/hr */
				__( 'This yacht uses $%s/hr fuel on every duration.', 'fy-fleet' ),
				number_format( $locked_fuel, abs( $locked_fuel - (int) $locked_fuel ) > 0.001 ? 2 : 0 )
			);
		} elseif ( $fuel_rate > 0 || $fuel_low > 0 ) {
			$sentences[] = sprintf(
				/* translators: 1: fuel under $800, 2: fuel over $800, 3: $800 line */
				__( 'Fuel is $%1$s/hr at or under $%3$s and $%2$s/hr over $%3$s.', 'fy-fleet' ),
				number_format( $fuel_low, abs( $fuel_low - (int) $fuel_low ) > 0.001 ? 2 : 0 ),
				number_format( $fuel_rate ),
				number_format( $fuel_line )
			);
		}
		if ( ! empty( $sentences ) ) {
			$sentences[] = __( 'If you cancel, the fuel charge is taken as a deposit.', 'fy-fleet' );
			$html       .= esc_html( implode( ' ', $sentences ) );
		}
		$html .= '</p>';
		if ( '' === $crew_lock && '' === $fuel_lock ) {
			$html .= '<p style="margin:0 0 7px;padding:8px 12px;border-radius:10px;background:#FFF1F7;color:#9D2463;font-size:12.5px;font-weight:700;text-align:center">'
				. esc_html( FY_Fleet_Settings::threshold_rule_text() )
				. '</p>';
		}
		$html .= '<div style="margin-bottom:22px"></div>';
		return $html;
	}

	/** [fy_yacht_addons] — extras available on this yacht with pricing. */
	public static function part_addons( $yacht_id ) {
		$addons = FY_Fleet_Pricing::addons_for_yacht( $yacht_id );
		if ( empty( $addons ) ) {
			return '';
		}
		$html = '<h3 style="margin:0 0 12px;font-size:18px;font-weight:900;color:#172033">🎉 ' . esc_html__( 'Add to your experience', 'fy-fleet' ) . '</h3><div style="margin:0 0 22px">';
		foreach ( $addons as $addon ) {
			$unit  = 'hour' === $addon['unit'] ? esc_html__( ' / hour', 'fy-fleet' ) : '';
			$html .= '<div style="display:flex;justify-content:space-between;gap:12px;padding:10px 15px;margin:0 0 7px;'
				. 'border:1px solid rgba(228,92,156,.2);border-radius:12px;background:linear-gradient(160deg,#ffffff,#FFF9FC)">'
				. '<span style="font-weight:800;color:#172033">' . esc_html( $addon['label'] )
				. ( ! empty( $addon['note'] ) ? ' <em style="font-weight:600;color:#94a3b8;font-size:12px">(' . esc_html( $addon['note'] ) . ')</em>' : '' ) . '</span>'
				. '<span style="font-weight:900;color:#C94386;white-space:nowrap">$' . esc_html( number_format( (float) $addon['price'] ) ) . $unit . '</span></div>';
		}
		$html .= '</div>';
		return $html;
	}

	/** [fy_yacht_location] — departure marina line (name + address). */
	/**
	 * @param bool $full_width Let the map fill its container instead of
	 *                         stopping at 640px — used when it spans the
	 *                         whole second row of the product layout.
	 */
	public static function part_location( $yacht_id, $full_width = false ) {
		if ( ! class_exists( 'FY_Fleet_Marina' ) ) {
			return '';
		}
		$marina = FY_Fleet_Marina::for_yacht( $yacht_id );
		if ( ! $marina || ! $marina['title'] ) {
			return '';
		}
		$html = '<p style="margin:0 0 14px;padding:12px 16px;border:1px solid rgba(37,99,235,.18);border-radius:13px;'
			. 'background:linear-gradient(160deg,#ffffff,#EFF6FF);font-size:14px;color:#172033"><strong style="color:#1E40AF">📍 '
			. esc_html__( 'Departs from:', 'fy-fleet' ) . '</strong> ' . esc_html( $marina['title'] )
			. ( ! empty( $marina['address'] ) ? ' <span style="color:#526079">— ' . esc_html( $marina['address'] ) . '</span>' : '' ) . '</p>';

		if ( ! empty( $marina['embed'] ) ) {
			$map_style = $full_width
				? 'width:100%;height:340px'
				: 'width:100%;max-width:640px;height:280px';
			$html .= '<iframe src="' . esc_url( $marina['embed'] ) . '" style="' . esc_attr( $map_style ) . ';border:1px solid rgba(37,99,235,.18);border-radius:13px;margin:0 0 10px" loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="' . esc_attr( $marina['title'] ) . '"></iframe>';
		}
		if ( ! empty( $marina['google'] ) ) {
			$html .= '<p style="margin:0 0 18px"><a href="' . esc_url( $marina['google'] ) . '" target="_blank" rel="noopener" style="font-size:13px;font-weight:700;color:#1E40AF">🗺️ ' . esc_html__( 'Open in Google Maps', 'fy-fleet' ) . '</a></p>';
		}

		return $html;
	}

	/** [fy_yacht_deposit] — the reserve/payment line. */
	public static function part_deposit( $yacht_id ) {
		$price = (float) get_post_meta( $yacht_id, '_fy_price', true );
		if ( $price <= 0 ) {
			return '';
		}

		$deposit_type = FY_Fleet_Settings::get_deposit_type();

		if ( 'crew_fuel' === $deposit_type ) {
			$has_crew = FY_Fleet_Settings::get_crew_rate() > 0 || FY_Fleet_Settings::get_crew_rate_under() > 0
				|| ( '' !== get_post_meta( $yacht_id, '_fy_crew_rate', true ) && (float) get_post_meta( $yacht_id, '_fy_crew_rate', true ) > 0 );
			$has_fuel = FY_Fleet_Settings::get_fuel_rate() > 0 || FY_Fleet_Settings::get_fuel_rate_under() > 0
				|| ( '' !== get_post_meta( $yacht_id, '_fy_fuel_rate', true ) && (float) get_post_meta( $yacht_id, '_fy_fuel_rate', true ) > 0 );
			if ( ! $has_crew && ! $has_fuel ) {
				return '';
			}
			return '<p style="margin:0 0 10px;padding:13px 16px;border-left:5px solid #E45C9C;border-radius:12px;background:#FFF7FB;'
				. 'font-size:14px;font-weight:700;color:#172033">✅ '
				. esc_html__( 'Reserve online — crew + fuel for your hours are charged now.', 'fy-fleet' )
				. ' ' . esc_html( FY_Fleet_Settings::threshold_rule_text() )
				. '</p>';
		}

		if ( 'full' === $deposit_type ) {
			$crew_rate = FY_Fleet_Pricing::yacht_rate_or_default( $yacht_id, '_fy_crew_rate', FY_Fleet_Settings::get_crew_rate() );
			$fuel_rate = FY_Fleet_Pricing::yacht_rate_or_default( $yacht_id, '_fy_fuel_rate', FY_Fleet_Settings::get_fuel_rate() );
			$parts     = array( esc_html__( 'boat', 'fy-fleet' ) );
			if ( $crew_rate > 0 ) {
				$parts[] = esc_html__( 'crew', 'fy-fleet' );
			}
			if ( $fuel_rate > 0 ) {
				$parts[] = esc_html__( 'fuel', 'fy-fleet' );
			}
			return '<p style="margin:0 0 10px;padding:13px 16px;border-left:5px solid #E45C9C;border-radius:12px;background:#FFF7FB;'
				. 'font-size:14px;font-weight:700;color:#172033">✅ '
				. sprintf(
					/* translators: %s: comma-separated list of what's included, e.g. "boat, crew, boat deposit" */
					esc_html__( 'Reserve online — the full charter cost (%s) is charged now. Nothing due at the dock.', 'fy-fleet' ),
					esc_html( implode( ', ', $parts ) )
				) . '</p>';
		}

		$deposit = FY_Fleet_Pricing::deposit_for( $price );
		if ( $deposit <= 0 ) {
			return '';
		}
		return '<p style="margin:0 0 10px;padding:13px 16px;border-left:5px solid #E45C9C;border-radius:12px;background:#FFF7FB;'
			. 'font-size:14px;font-weight:700;color:#172033">✅ '
			. sprintf( esc_html__( 'Reserve online with a $%s deposit — the balance is paid in person at the dock before departure.', 'fy-fleet' ), esc_html( number_format( $deposit ) ) ) . '</p>';
	}

	public static function on_yacht_trashed( $post_id ) {
		if ( FY_Fleet_CPT::POST_TYPE !== get_post_type( $post_id ) ) {
			return;
		}
		$product_id = self::get_product_id( $post_id );
		if ( $product_id ) {
			$product = wc_get_product( $product_id );
			if ( $product ) {
				$product->set_status( 'private' );
				$product->save();
			}
		}
	}

	/**
	 * Runs once, automatically, the first time an admin page loads after
	 * this version is active — rolls the new [fy_yacht_details] tabs out to
	 * every existing yacht without the owner needing to click "Sync All
	 * Products". Never runs on the public site, so a real visitor never
	 * waits on it. Safe to leave in place: the option guard means it only
	 * ever actually calls sync_all() once.
	 */
	public static function maybe_auto_sync_details_tabs() {
		if ( fy_fleet_is_plugin_admin_screen() ) {
			return;
		}
		if ( get_option( 'fy_fleet_details_tabs_synced' ) ) {
			return;
		}
		self::sync_all();
		update_option( 'fy_fleet_details_tabs_synced', 1 );
	}

	/**
	 * Rebuild every yacht: defaults (button URL, featured image) + product.
	 *
	 * Image imports are held to a ~20-second budget per run so the request
	 * can't time out on slow hosts; yachts whose images were skipped are
	 * picked up on the next click, since the attempt marker is only written
	 * when an import is actually tried.
	 *
	 * @return int How many products were synced.
	 */
	public static function sync_all() {
		$count   = 0;
		$started = microtime( true );
		$yachts  = get_posts(
			array(
				'post_type'      => FY_Fleet_CPT::POST_TYPE,
				'post_status'    => array( 'publish', 'draft', 'pending' ),
				'posts_per_page' => -1,
			)
		);
		foreach ( $yachts as $yacht ) {
			$sideload = ( microtime( true ) - $started ) < 20;
			self::fill_defaults( $yacht->ID, $yacht, $sideload );
			if ( self::sync_product( $yacht->ID, $yacht ) ) {
				$count++;
			}
		}
		return $count;
	}

	/* ------------------------------------------------------------------
	 * Cart & order
	 * ---------------------------------------------------------------- */

	/**
	 * Add a validated quote to the cart.
	 *
	 * @param array $quote Result of FY_Fleet_Pricing::quote().
	 * @return string|WP_Error Cart item key.
	 */
	public static function add_quote_to_cart( $quote ) {
		if ( ! self::active() || ! WC()->cart ) {
			return new WP_Error( 'fy_no_woo', __( 'WooCommerce is not available.', 'fy-fleet' ) );
		}

		$product_id = self::get_product_id( $quote['yacht_id'] );
		if ( ! $product_id ) {
			$product_id = self::sync_product( $quote['yacht_id'] );
		}
		if ( ! $product_id ) {
			return new WP_Error( 'fy_no_product', __( 'This yacht is not set up for online booking yet.', 'fy-fleet' ) );
		}

		$key = WC()->cart->add_to_cart( $product_id, 1, 0, array(), array( 'fy_booking' => $quote ) );
		if ( ! $key ) {
			return new WP_Error( 'fy_cart_failed', __( 'The booking could not be added to the cart.', 'fy-fleet' ) );
		}
		return $key;
	}

	/**
	 * The plugin's own charter date + start time inputs.
	 *
	 * These were previously supplied by the theme, which made the booking UI
	 * depend on markup outside this plugin — and on the live site that markup
	 * turned out to be duplicated per breakpoint, leaving a stray "Select
	 * Date" box on phones that no amount of hiding reliably caught.
	 *
	 * Rendering them here means the theme's copies can simply be deleted: the
	 * pickers keep working. Names are fy_booking_date / fy_charter_start_time
	 * so an empty plugin copy cannot overwrite the theme's booking_date /
	 * charter_start_time in $_POST (PHP last-wins). keep_unique() reads the
	 * theme names first, then these.
	 *
	 * They carry no id — the theme may still be rendering one — and are hidden
	 * by default, since assets/theme/booking-ui.js provides the visible UI.
	 * Without JavaScript they become visible as ordinary fields, so the page
	 * degrades to a plain date box and dropdown rather than losing the ability
	 * to pick a date at all.
	 */
	public static function render_schedule_fields() {
		if ( ! function_exists( 'is_product' ) || ! is_product() ) {
			return;
		}
		if ( ! (int) get_post_meta( get_the_ID(), '_fy_yacht_id', true ) ) {
			return;   // not a yacht — leave ordinary products alone.
		}

		// 6:00 AM through 2:00 AM, on the half hour: the operating window
		// product-express.js already enforces on the theme's own list.
		$slots = array();
		for ( $m = 6 * 60; $m <= 26 * 60; $m += 30 ) {
			$mins   = $m % ( 24 * 60 );
			$hour   = (int) floor( $mins / 60 );
			$minute = $mins % 60;
			$suffix = $hour < 12 ? 'am' : 'pm';
			$h12    = $hour % 12;
			if ( 0 === $h12 ) {
				$h12 = 12;
			}
			$slots[] = $h12 . ':' . str_pad( (string) $minute, 2, '0', STR_PAD_LEFT ) . ' ' . $suffix;
		}
		?>
		<div class="fy-native-schedule" data-fy-native-schedule="1">
			<p class="fy-native-schedule__row">
				<label><?php esc_html_e( 'Charter date', 'fy-fleet' ); ?>
					<input type="date" name="fy_booking_date" value="" autocomplete="off">
				</label>
			</p>
			<p class="fy-native-schedule__row">
				<label><?php esc_html_e( 'Start time', 'fy-fleet' ); ?>
					<select name="fy_charter_start_time">
						<option value=""><?php esc_html_e( 'Choose an option', 'fy-fleet' ); ?></option>
						<?php foreach ( $slots as $slot ) : ?>
							<option value="<?php echo esc_attr( $slot ); ?>"><?php echo esc_html( $slot ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
			</p>
		</div>
		<?php
	}

	/**
	 * First non-empty POST value among the given keys.
	 * Arrays (duplicate name= fields) are scanned for the first real string.
	 */
	private static function post_schedule_value( $keys ) {
		foreach ( (array) $keys as $key ) {
			if ( empty( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				continue;
			}
			$raw = wp_unslash( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
			if ( is_array( $raw ) ) {
				foreach ( $raw as $piece ) {
					$piece = sanitize_text_field( (string) $piece );
					if ( '' !== $piece ) {
						return $piece;
					}
				}
				continue;
			}
			$piece = sanitize_text_field( (string) $raw );
			if ( '' !== $piece ) {
				return $piece;
			}
		}
		return '';
	}

	/** Stop two different bookings of the same yacht from merging into one line. */
	public static function keep_unique( $cart_item_data, $product_id, $variation_id ) {
		if ( isset( $cart_item_data['fy_booking'] ) ) {
			$cart_item_data['fy_unique'] = md5( wp_json_encode( $cart_item_data['fy_booking'] ) . microtime() );
		}

		/*
		 * Carry the date and start time picked on the PRODUCT PAGE into the
		 * cart.
		 *
		 * Adding to cart from a product page doesn't build an fy_booking
		 * array — that only exists for the plugin's own booking shortcode —
		 * so without this the two fields the customer just filled in were
		 * read by nothing and thrown away at checkout, and the order said
		 * "Charter date: Scheduled with our team after checkout" even though
		 * they had chosen one. Everything downstream (bookings calendar,
		 * confirmation email, the SMS {date}/{time} tokens, My Charters) reads
		 * _fy_date/_fy_time, so capturing it here is what makes those work for
		 * a native WooCommerce checkout.
		 *
		 * phpcs:disable WordPress.Security.NonceVerification.Missing --
		 * WooCommerce's own add-to-cart handler owns this request; these are
		 * two display-only strings, sanitized here and re-read from the cart,
		 * never trusted for pricing.
		 */
		$date = self::post_schedule_value( array( 'booking_date', 'fy_booking_date' ) );
		// Store ISO only — anything else means a datepicker wrote a
		// display format we can't reliably compare against later.
		if ( $date && preg_match( '/^\d{4}-\d{2}-\d{2}$/', substr( $date, 0, 10 ) ) ) {
			$cart_item_data['fy_date'] = substr( $date, 0, 10 );
		}
		$time = self::post_schedule_value( array( 'charter_start_time', 'fy_charter_start_time' ) );
		if ( $time ) {
			$cart_item_data['fy_time'] = $time;
		}
		// phpcs:enable

		// Two charters of the same yacht on different dates are different
		// lines, not quantity 2 of one line.
		if ( isset( $cart_item_data['fy_date'] ) || isset( $cart_item_data['fy_time'] ) ) {
			$cart_item_data['fy_schedule_key'] = md5(
				( isset( $cart_item_data['fy_date'] ) ? $cart_item_data['fy_date'] : '' ) . '|' .
				( isset( $cart_item_data['fy_time'] ) ? $cart_item_data['fy_time'] : '' )
			);
		}

		return $cart_item_data;
	}

	/**
	 * Cart line keys whose price was set here and already contains the
	 * add-on share, so FY_Fleet_Addons::apply_price must not add it again.
	 *
	 * @var array<string,bool>
	 */
	protected static $addon_priced_keys = array();

	/** Whether apply_deposit_price() already folded the add-on share into this line. */
	public static function line_includes_addons( $key ) {
		return ! empty( self::$addon_priced_keys[ $key ] );
	}

	/** Charge the deposit, not the product's static price. */
	public static function apply_deposit_price( $cart ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
			return;
		}
		// set_price() is idempotent, so this is safe to run on every pass —
		// guarding on did_action() would skip legitimate recalculations.
		foreach ( $cart->get_cart() as $key => $item ) {
			if ( ! empty( $item['fy_booking']['deposit'] ) ) {
				// quote() already folds the online add-on share into deposit.
				self::$addon_priced_keys[ $key ] = true;
				$item['data']->set_price( (float) $item['fy_booking']['deposit'] );
				continue;
			}
			$product_id = ! empty( $item['product_id'] ) ? (int) $item['product_id'] : 0;
			$yacht_id   = $product_id ? (int) get_post_meta( $product_id, '_fy_yacht_id', true ) : 0;
			if ( $yacht_id < 1 || ! class_exists( 'FY_Fleet_Pricing' ) ) {
				continue;
			}
			$hours         = self::hours_from_cart_item( $item );
			$duration_slug = self::duration_slug_from_cart_item( $item );
			$row           = $duration_slug ? FY_Fleet_Pricing::row_for_duration_slug( $yacht_id, $duration_slug ) : null;
			if ( ! $row && $hours > 0 ) {
				$row = FY_Fleet_Pricing::row_for_hours( $yacht_id, $hours );
			}
			$boat = ( $hours > 0 ) ? FY_Fleet_Pricing::boat_for_choice( $yacht_id, $hours, $row ) : 0.0;
			if ( $boat <= 0 || $hours <= 0 ) {
				continue;
			}
			$suite_now = FY_Fleet_Pricing::charged_today( $yacht_id, $boat, $hours );
			$addons_now = 0.0;
			if ( class_exists( 'FY_Fleet_Addons' ) && ! empty( $item[ FY_Fleet_Addons::CART_KEY ]['total'] ) ) {
				$ratio      = class_exists( 'FY_Fleet_Settings' ) ? FY_Fleet_Settings::get_addon_deposit_ratio() : 0.5;
				$addons_now = round( (float) $item[ FY_Fleet_Addons::CART_KEY ]['total'] * $ratio, 2 );
			}
			self::$addon_priced_keys[ $key ] = true;
			$item['data']->set_price( $suite_now + $addons_now );
		}
	}

	public static function sold_individually( $individually, $product ) {
		if ( ! $product ) {
			return $individually;
		}
		if ( get_post_meta( $product->get_id(), '_fy_yacht_id', true ) ) {
			return true;
		}
		// Variations carry no yacht link of their own — it lives on the
		// parent product, so check there too.
		$parent_id = is_callable( array( $product, 'get_parent_id' ) ) ? (int) $product->get_parent_id() : 0;
		if ( $parent_id && get_post_meta( $parent_id, '_fy_yacht_id', true ) ) {
			return true;
		}
		return $individually;
	}

	/** Human-readable booking details in cart/checkout. */
	public static function cart_item_meta( $item_data, $cart_item ) {
		if ( empty( $cart_item['fy_booking'] ) ) {
			/*
			 * Product-page bookings have no fy_booking array, so without this
			 * the cart and checkout listed only Charter Duration and Passenger
			 * Count — the customer paid without ever seeing the date and time
			 * they had picked confirmed back to them. keep_unique() stores
			 * both on the cart item; show them in the same place the
			 * shortcode flow shows its own.
			 */
			if ( ! empty( $cart_item['fy_date'] ) ) {
				$item_data[] = array(
					'key'   => __( 'Date', 'fy-fleet' ),
					'value' => self::format_date( $cart_item['fy_date'] ),
				);
			}
			if ( ! empty( $cart_item['fy_time'] ) ) {
				$item_data[] = array(
					'key'   => __( 'Start time', 'fy-fleet' ),
					'value' => $cart_item['fy_time'],
				);
			}
			return $item_data;
		}
		$b = $cart_item['fy_booking'];

		$item_data[] = array( 'key' => __( 'Date', 'fy-fleet' ), 'value' => self::format_date( $b['date'] ) );
		if ( ! empty( $b['time'] ) ) {
			$item_data[] = array( 'key' => __( 'Start time', 'fy-fleet' ), 'value' => $b['time'] );
		}
		$item_data[] = array( 'key' => __( 'Charter', 'fy-fleet' ), 'value' => $b['duration'] );
		$item_data[] = array( 'key' => __( 'Guests', 'fy-fleet' ), 'value' => $b['guests'] );
		if ( ! empty( $b['marina'] ) ) {
			$item_data[] = array( 'key' => __( '📍 Departure marina', 'fy-fleet' ), 'value' => $b['marina'] );
		}

		if ( ! empty( $b['charter'] ) ) {
			$item_data[] = array( 'key' => __( 'Booking', 'fy-fleet' ), 'value' => wp_strip_all_tags( wc_price( $b['charter'] ) ) );
		}
		if ( ! empty( $b['crew_total'] ) ) {
			$item_data[] = array( 'key' => __( 'Crew', 'fy-fleet' ), 'value' => wp_strip_all_tags( wc_price( $b['crew_total'] ) ) );
		}
		if ( ! empty( $b['fuel_total'] ) ) {
			$item_data[] = array( 'key' => __( 'Fuel', 'fy-fleet' ), 'value' => wp_strip_all_tags( wc_price( $b['fuel_total'] ) ) );
		}
		if ( ! empty( $b['service_fee'] ) ) {
			$item_data[] = array( 'key' => __( 'Service fee', 'fy-fleet' ), 'value' => wp_strip_all_tags( wc_price( $b['service_fee'] ) ) );
		}

		if ( ! empty( $b['addons'] ) ) {
			$lines = array();
			foreach ( $b['addons'] as $addon ) {
				$label = $addon['label'];
				if ( $addon['qty'] > 1 ) {
					$label .= ' ×' . $addon['qty'];
				}
				$lines[] = $label . ' — ' . wp_strip_all_tags( wc_price( $addon['total'] ) );
			}
			$item_data[] = array( 'key' => __( 'Add-ons', 'fy-fleet' ), 'value' => implode( '<br>', $lines ) );
		}
		if ( ! empty( $b['surcharge'] ) ) {
			$item_data[] = array( 'key' => __( 'Weekend surcharge', 'fy-fleet' ), 'value' => wp_strip_all_tags( wc_price( $b['surcharge'] ) ) );
		}
		if ( ! empty( $b['occasion'] ) ) {
			$item_data[] = array( 'key' => __( 'Occasion', 'fy-fleet' ), 'value' => $b['occasion'] );
		}

		$full_payment = empty( $b['balance'] );
		if ( ! $full_payment ) {
			$item_data[] = array(
				'key'   => __( 'Full charter price', 'fy-fleet' ),
				'value' => wp_strip_all_tags( wc_price( $b['total'] ) ),
			);
		}
		$item_data[] = array(
			'key'   => $full_payment ? __( '✅ Charged today (paid in full)', 'fy-fleet' ) : __( '✅ Deposit charged today', 'fy-fleet' ),
			'value' => wp_strip_all_tags( wc_price( $b['deposit'] ) ),
		);
		if ( ! $full_payment ) {
			$item_data[] = array(
				'key'   => __( '⚓ Balance due at the dock', 'fy-fleet' ),
				'value' => wp_strip_all_tags( wc_price( $b['balance'] ) ) . ' — ' . __( 'not charged now', 'fy-fleet' ),
			);
		}

		return $item_data;
	}

	/** Persist booking details onto the order line item. */
	/**
	 * Charter hours for a native (non-booking-form) cart line, read off the
	 * chosen "Charter Duration" variation. Attribute values arrive as term
	 * slugs ("5-hours", "pay-for-4-hours-get-5-hours-total"), so hyphens are
	 * turned back into spaces before parsing.
	 *
	 * @return float Hours, or 0 when the line has no duration attribute.
	 */
	/**
	 * Guest count chosen on a native cart line, from the Passenger Count
	 * attribute. 0 when the line has none.
	 */
	private static function guests_from_cart_item( $values ) {
		$variation = ( isset( $values['variation'] ) && is_array( $values['variation'] ) ) ? $values['variation'] : array();
		foreach ( $variation as $key => $value ) {
			if ( false !== stripos( (string) $key, 'passenger-count' ) ) {
				$guests = (int) preg_replace( '/[^0-9]/', '', (string) $value );
				if ( $guests > 0 ) {
					return $guests;
				}
			}
		}
		return 0;
	}

	private static function hours_from_cart_item( $values ) {
		$variation = ( isset( $values['variation'] ) && is_array( $values['variation'] ) ) ? $values['variation'] : array();

		foreach ( $variation as $key => $value ) {
			if ( false === stripos( (string) $key, 'charter-duration' ) ) {
				continue;
			}
			$label = str_replace( array( '-', '_' ), ' ', (string) $value );
			$hours = FY_Fleet_Pricing::hours_from_label( $label );
			if ( $hours > 0 ) {
				return $hours;
			}
		}

		// Variation chosen but attributes not in the cart array (some themes
		// / REST paths) — read them off the variation product itself.
		$variation_id = ! empty( $values['variation_id'] ) ? (int) $values['variation_id'] : 0;
		if ( $variation_id ) {
			$variation_product = wc_get_product( $variation_id );
			if ( $variation_product ) {
				foreach ( $variation_product->get_attributes() as $key => $value ) {
					if ( false === stripos( (string) $key, 'charter-duration' ) ) {
						continue;
					}
					$label = str_replace( array( '-', '_' ), ' ', (string) $value );
					$hours = FY_Fleet_Pricing::hours_from_label( $label );
					if ( $hours > 0 ) {
						return $hours;
					}
				}
			}
		}

		return 0.0;
	}

	/**
	 * The Charter Duration variation's own attribute slug for a cart item —
	 * e.g. "3-hours" — exactly as FY_Fleet_Woo::sync_variations() slugged
	 * the pricing row when it built that variation. Reading it back lets
	 * order_line_meta() look up the SAME row instead of re-deriving the
	 * boat cost from _fy_price * hours, which is wrong on any yacht whose
	 * _fy_price is a flat/package price rather than a true hourly rate.
	 */
	private static function duration_slug_from_cart_item( $values ) {
		$variation = ( isset( $values['variation'] ) && is_array( $values['variation'] ) ) ? $values['variation'] : array();
		foreach ( $variation as $key => $value ) {
			if ( false !== stripos( (string) $key, 'charter-duration' ) && '' !== (string) $value ) {
				return (string) $value;
			}
		}

		$variation_id = ! empty( $values['variation_id'] ) ? (int) $values['variation_id'] : 0;
		if ( $variation_id ) {
			$variation_product = wc_get_product( $variation_id );
			if ( $variation_product ) {
				foreach ( $variation_product->get_attributes() as $key => $value ) {
					if ( false !== stripos( (string) $key, 'charter-duration' ) && '' !== (string) $value ) {
						return (string) $value;
					}
				}
			}
		}

		return '';
	}

	public static function order_line_meta( $item, $cart_item_key, $values, $order ) {
		if ( empty( $values['fy_booking'] ) ) {
			// Native WooCommerce add-to-cart of a yacht product: there is no
			// date picker, but the money facts ARE known — write them so the
			// n8n webhook, branded emails, customer portal and thank-you page
			// all treat this as a charter order. The date is arranged with the
			// team after checkout (GHL bareboat form / WhatsApp).
			$product_id = ! empty( $values['product_id'] ) ? (int) $values['product_id'] : 0;
			$yacht_id   = $product_id ? (int) get_post_meta( $product_id, '_fy_yacht_id', true ) : 0;
			if ( ! $yacht_id || FY_Fleet_CPT::POST_TYPE !== get_post_type( $yacht_id ) ) {
				return;
			}
			// What the card was actually charged: the Charter Duration
			// variation's price = crew + hourly boat deposit for the hours.
			$deposit = (float) $item->get_total();

			// Rebuild the full charter cost from the hours the customer
			// picked. _fy_price is an HOURLY RATE on some yachts but a flat
			// package price on others — using it as a multiplier on those
			// would report a wildly inflated balance (a real case: $17,480
			// "due at the dock" on a charter that really owed $3,680).
			// Reading the exact pricing row the chosen variation was built
			// from (same lookup FY_Fleet_Pricing::rows_by_duration_slug()
			// gives the on-page summary) is right regardless of which kind
			// of rate this yacht has.
			$hours         = self::hours_from_cart_item( $values );
			$duration_slug = self::duration_slug_from_cart_item( $values );
			$row           = $duration_slug ? FY_Fleet_Pricing::row_for_duration_slug( $yacht_id, $duration_slug ) : null;
			if ( ! $row && $hours > 0 ) {
				$row = FY_Fleet_Pricing::row_for_hours( $yacht_id, $hours );
			}

			// Add-ons ride along: their full cost is part of the charter
			// total, while only the online share sits inside $deposit.
			$addons_total = ! empty( $values[ FY_Fleet_Addons::CART_KEY ]['total'] )
				? (float) $values[ FY_Fleet_Addons::CART_KEY ]['total']
				: 0.0;

			if ( $hours > 0 ) {
				$boat      = FY_Fleet_Pricing::boat_for_choice( $yacht_id, $hours, $row );
				$crew_rate = FY_Fleet_Pricing::crew_rate_for_boat( $yacht_id, $boat );
				$fuel_rate = FY_Fleet_Pricing::fuel_rate_for_boat( $yacht_id, $boat );
				$crew      = round( $crew_rate * $hours, 2 );
				$fuel      = round( $fuel_rate * $hours, 2 );
			} else {
				$boat  = 0;
				$crew  = 0;
				$fuel  = 0;
			}
			$addons_now  = class_exists( 'FY_Fleet_Settings' )
				? round( $addons_total * FY_Fleet_Settings::get_addon_deposit_ratio(), 2 )
				: round( $addons_total * 0.5, 2 );
			$reservation = FY_Fleet_Pricing::charter_deposit_for_boat( $boat );
			// Crew is charged online and never credited at the dock, so the
			// full charter price must include it — otherwise the split shown
			// to the guest (charged today + due at dock) would not add up to
			// this headline figure.
			$total       = $boat + $crew + $addons_total;
			$balance     = FY_Fleet_Pricing::dock_balance( $boat, $fuel, $reservation, $addons_total, $addons_now, 0 );
			if ( $total < $deposit ) {
				$total = $deposit;
			}

			$item->add_meta_data( '_fy_yacht_id', $yacht_id, true );
			$item->add_meta_data( '_fy_charter_total', $total, true );
			$item->add_meta_data( '_fy_deposit', $deposit, true );
			$item->add_meta_data( '_fy_balance', $balance, true );
			if ( $hours > 0 ) {
				$item->add_meta_data( '_fy_hours', $hours, true );
				$item->add_meta_data( '_fy_booking_charge', $boat, true );
				$item->add_meta_data( '_fy_crew_fee', $crew, true );
				$item->add_meta_data( '_fy_fuel_fee', $fuel, true );
				if ( $fuel > 0 ) {
					$item->add_meta_data( __( 'Fuel', 'fy-fleet' ), '$' . number_format( $fuel, 2 ), true );
				}
				$duration_label = ( $row && ! empty( $row['duration'] ) )
					? $row['duration']
					: sprintf( _n( '%s Hour', '%s Hours', (int) $hours, 'fy-fleet' ), $hours );
				$item->add_meta_data( '_fy_duration', $duration_label, true );
				$item->add_meta_data( __( 'Charter length', 'fy-fleet' ), $duration_label, true );

				if ( $reservation > 0 ) {
					$item->add_meta_data( '_fy_reservation_deposit', $reservation, true );
					$item->add_meta_data( __( 'Boat deposit (20% / premium — credited at dock)', 'fy-fleet' ), '$' . number_format( $reservation, 2 ), true );
				}
			}

			// Party size, from the Passenger Count dropdown. The plugin's own
			// booking form records this further down from $b['guests']; a
			// native WooCommerce checkout has to read it off the variation, or
			// the crew has no idea how many people to expect.
			$guests = self::guests_from_cart_item( $values );
			if ( $guests > 0 ) {
				$item->add_meta_data( '_fy_guests', $guests, true );
				$item->add_meta_data( __( 'Guests', 'fy-fleet' ), $guests, true );
			}
			if ( class_exists( 'FY_Fleet_Marina' ) ) {
				$marina = FY_Fleet_Marina::for_yacht( $yacht_id );
				if ( $marina && ! empty( $marina['title'] ) ) {
					$item->add_meta_data( '_fy_marina', $marina['title'], true );
					$item->add_meta_data( __( 'Departure marina', 'fy-fleet' ), $marina['title'], true );
				}
			}
			/*
			 * The date/time the customer picked on the product page, carried
			 * here by keep_unique(). Machine-readable keys first — the
			 * bookings dashboard, calendar, emails and the Twilio {date} /
			 * {time} tokens all read _fy_date and _fy_time, and a native
			 * WooCommerce checkout is the only path that reaches this branch.
			 * Falls back to the old "we'll schedule it" line only when no date
			 * genuinely came through, so a yacht page without those fields
			 * behaves exactly as it did before.
			 */
			$sched_date = ! empty( $values['fy_date'] ) ? $values['fy_date'] : '';
			$sched_time = ! empty( $values['fy_time'] ) ? $values['fy_time'] : '';

			if ( $sched_date ) {
				$item->add_meta_data( '_fy_date', $sched_date, true );
				$item->add_meta_data( __( 'Charter date', 'fy-fleet' ), self::format_date( $sched_date ), true );
			}
			if ( $sched_time ) {
				$item->add_meta_data( '_fy_time', $sched_time, true );
				$item->add_meta_data( __( 'Start time', 'fy-fleet' ), $sched_time, true );
			}
			if ( ! $sched_date ) {
				$item->add_meta_data( __( 'Charter date', 'fy-fleet' ), __( 'Scheduled with our team after checkout', 'fy-fleet' ), true );
			}
			return;
		}
		$b = $values['fy_booking'];

		// Machine-readable, for the bookings dashboard and calendar.
		$item->add_meta_data( '_fy_yacht_id', $b['yacht_id'], true );
		$item->add_meta_data( '_fy_date', $b['date'], true );
		$item->add_meta_data( '_fy_time', $b['time'], true );
		$item->add_meta_data( '_fy_hours', $b['hours'], true );
		$item->add_meta_data( '_fy_duration', $b['duration'], true );
		$item->add_meta_data( '_fy_occasion', $b['occasion'], true );
		$item->add_meta_data( '_fy_notes', $b['notes'], true );
		$item->add_meta_data( '_fy_charter_total', $b['total'], true );
		$item->add_meta_data( '_fy_deposit', $b['deposit'], true );
		$item->add_meta_data( '_fy_balance', $b['balance'], true );
		$item->add_meta_data( '_fy_guests', $b['guests'], true );
		$item->add_meta_data( '_fy_addons_raw', wp_json_encode( $b['addons'] ), true );
		$item->add_meta_data( '_fy_booking_charge', isset( $b['charter'] ) ? $b['charter'] : 0, true );
		$item->add_meta_data( '_fy_crew_fee', isset( $b['crew_total'] ) ? $b['crew_total'] : 0, true );
		$item->add_meta_data( '_fy_fuel_fee', isset( $b['fuel_total'] ) ? $b['fuel_total'] : 0, true );
		if ( ! empty( $b['fuel_total'] ) ) {
			$item->add_meta_data( __( 'Fuel', 'fy-fleet' ), wp_strip_all_tags( wc_price( $b['fuel_total'] ) ), true );
		}
		$item->add_meta_data( '_fy_service_fee', isset( $b['service_fee'] ) ? $b['service_fee'] : 0, true );

		// Customer-visible, shown on the order and in emails.
		$item->add_meta_data( __( 'Charter date', 'fy-fleet' ), self::format_date( $b['date'] ), true );
		if ( ! empty( $b['time'] ) ) {
			$item->add_meta_data( __( 'Start time', 'fy-fleet' ), $b['time'], true );
		}
		$item->add_meta_data( __( 'Charter length', 'fy-fleet' ), $b['duration'], true );
		$item->add_meta_data( __( 'Guests', 'fy-fleet' ), $b['guests'], true );
		if ( ! empty( $b['marina'] ) ) {
			$item->add_meta_data( '_fy_marina', $b['marina'], true );
			$item->add_meta_data( __( 'Departure marina', 'fy-fleet' ), $b['marina'], true );
		}

		if ( ! empty( $b['addons'] ) ) {
			$lines = array();
			foreach ( $b['addons'] as $addon ) {
				$lines[] = $addon['label'] . ( $addon['qty'] > 1 ? ' x' . $addon['qty'] : '' );
			}
			$item->add_meta_data( __( 'Add-ons', 'fy-fleet' ), implode( ', ', $lines ), true );
		}
		if ( ! empty( $b['occasion'] ) ) {
			$item->add_meta_data( __( 'Occasion', 'fy-fleet' ), $b['occasion'], true );
		}
		if ( ! empty( $b['notes'] ) ) {
			$item->add_meta_data( __( 'Special requests', 'fy-fleet' ), $b['notes'], true );
		}

		$item->add_meta_data( __( 'Full charter price', 'fy-fleet' ), wp_strip_all_tags( wc_price( $b['total'] ) ), true );
		$item->add_meta_data( empty( $b['balance'] ) ? __( 'Paid in full today', 'fy-fleet' ) : __( 'Deposit paid today', 'fy-fleet' ), wp_strip_all_tags( wc_price( $b['deposit'] ) ), true );
		$item->add_meta_data( __( 'Balance due at the dock', 'fy-fleet' ), wp_strip_all_tags( wc_price( $b['balance'] ) ), true );
	}

	/**
	 * Charter totals across every booking line in the cart.
	 *
	 * @return array{charter:float,deposit:float,balance:float,count:int}
	 */
	public static function cart_totals() {
		$totals = array( 'charter' => 0.0, 'deposit' => 0.0, 'balance' => 0.0, 'count' => 0 );

		if ( ! self::active() || ! WC()->cart ) {
			return $totals;
		}

		foreach ( WC()->cart->get_cart() as $item ) {
			if ( ! empty( $item['fy_booking'] ) ) {
				$booking            = $item['fy_booking'];
				$totals['charter'] += isset( $booking['total'] ) ? (float) $booking['total'] : 0;
				$totals['deposit'] += isset( $booking['deposit'] ) ? (float) $booking['deposit'] : 0;
				$totals['balance'] += isset( $booking['balance'] ) ? (float) $booking['balance'] : 0;
				$totals['count']++;
				continue;
			}

			// Native add-to-cart of a yacht-backed product: the line total IS
			// what's charged now (crew + hourly boat deposit for the hours).
			// Dock credits deposits only — crew is a reservation fee.
			$product_id = ! empty( $item['product_id'] ) ? (int) $item['product_id'] : 0;
			$yacht_id   = $product_id ? (int) get_post_meta( $product_id, '_fy_yacht_id', true ) : 0;
			if ( ! $yacht_id ) {
				continue;
			}
			$deposit = isset( $item['line_total'] ) ? (float) $item['line_total'] : 0;
			$hours   = self::hours_from_cart_item( $item );
			$slug    = self::duration_slug_from_cart_item( $item );
			$row     = ( $slug && class_exists( 'FY_Fleet_Pricing' ) )
				? FY_Fleet_Pricing::row_for_duration_slug( $yacht_id, $slug )
				: null;
			if ( ! $row && $hours > 0 && class_exists( 'FY_Fleet_Pricing' ) ) {
				$row = FY_Fleet_Pricing::row_for_hours( $yacht_id, $hours );
			}
			$boat = class_exists( 'FY_Fleet_Pricing' )
				? FY_Fleet_Pricing::boat_for_choice( $yacht_id, $hours, $row )
				: 0.0;
			$addons_total = ! empty( $item[ FY_Fleet_Addons::CART_KEY ]['total'] )
				? (float) $item[ FY_Fleet_Addons::CART_KEY ]['total']
				: 0.0;
			$addons_now   = class_exists( 'FY_Fleet_Settings' )
				? round( $addons_total * FY_Fleet_Settings::get_addon_deposit_ratio(), 2 )
				: round( $addons_total * 0.5, 2 );
			$fuel         = 0.0;
			$crew         = 0.0;
			$reservation  = 0.0;
			if ( class_exists( 'FY_Fleet_Pricing' ) ) {
				$fuel_rate   = FY_Fleet_Pricing::fuel_rate_for_boat( $yacht_id, $boat );
				$crew_rate   = FY_Fleet_Pricing::crew_rate_for_boat( $yacht_id, $boat );
				$fuel        = $hours > 0 ? round( $fuel_rate * $hours, 2 ) : 0.0;
				$crew        = $hours > 0 ? round( $crew_rate * $hours, 2 ) : 0.0;
				$reservation = FY_Fleet_Pricing::charter_deposit_for_boat( $boat );
			}
			// Crew is paid online and never credited at the dock, so the full
			// charter price includes it — deposit + balance must equal total.
			$total        = $boat + $crew + $addons_total;
			if ( $total < $deposit ) {
				$total = $deposit;
			}
			$totals['charter'] += $total;
			$totals['deposit'] += $deposit;
			$totals['balance'] += class_exists( 'FY_Fleet_Pricing' )
				? FY_Fleet_Pricing::dock_balance( $boat, $fuel, $reservation, $addons_total, $addons_now, 0 )
				: max( 0, $boat - $fuel - $reservation ) + max( 0, $addons_total - $addons_now );
			$totals['count']++;
		}

		return $totals;
	}

	/** Kept for readability elsewhere. */
	public static function cart_balance() {
		$totals = self::cart_totals();
		return $totals['balance'];
	}

	public static function balance_row() {
		$totals = self::cart_totals();
		if ( $totals['count'] < 1 ) {
			return;
		}
		?>
		<tr class="fy-charter-total-row">
			<th><?php esc_html_e( 'Full charter price', 'fy-fleet' ); ?></th>
			<td data-title="<?php esc_attr_e( 'Full charter price', 'fy-fleet' ); ?>">
				<?php echo wp_kses_post( wc_price( $totals['charter'] ) ); ?>
			</td>
		</tr>
		<?php if ( $totals['balance'] > 0 ) : ?>
		<tr class="fy-balance-row">
			<th><?php esc_html_e( 'Balance due at the dock', 'fy-fleet' ); ?></th>
			<td data-title="<?php esc_attr_e( 'Balance due at the dock', 'fy-fleet' ); ?>">
				<strong><?php echo wp_kses_post( wc_price( $totals['balance'] ) ); ?></strong>
				<small style="display:block;opacity:.75"><?php esc_html_e( 'Paid in person before departure — not charged now.', 'fy-fleet' ); ?></small>
			</td>
		</tr>
		<?php endif; ?>
		<?php
	}

	/**
	 * The deposit and the dock balance shown side by side, so there is no doubt
	 * about what the card is charged today versus what is still owed.
	 */
	public static function payment_split_panel() {
		$totals = self::cart_totals();
		if ( $totals['count'] < 1 || $totals['charter'] <= 0 ) {
			return;
		}
		?>
		<?php self::split_css(); ?>
		<div class="fy-pay-split">
		<?php
		self::split_body( $totals['charter'], $totals['deposit'], $totals['balance'], false );
		echo '</div>';
	}

	/** Shared styles for the payment split, printed at most once per page. */
	private static function split_css() {
		static $printed = false;
		if ( $printed ) {
			return;
		}
		$printed = true;
		?>
			<style>
			.fy-pay-split{
				margin:0 0 22px;padding:16px 18px;border:1px solid rgba(124,58,237,.2);border-radius:18px;
				background:linear-gradient(160deg,#fff,#fff5fa 55%,#F3E8FF);
				box-shadow:0 10px 26px rgba(91,33,182,.08);
				font-family:ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;color:#172033;
			}
			.fy-pay-split *{box-sizing:border-box}
			.fy-pay-split-top{
				display:flex;justify-content:space-between;align-items:baseline;gap:10px;
				padding-bottom:10px;margin-bottom:12px;border-bottom:1px solid rgba(124,58,237,.18);
			}
			.fy-pay-split-top span{font-size:12px;font-weight:900;letter-spacing:.04em;text-transform:uppercase;color:#526079}
			.fy-pay-split-top strong{font-size:21px;font-weight:950;letter-spacing:-.02em}
			.fy-pay-split-grid{display:grid;grid-template-columns:1fr auto 1fr;align-items:stretch;gap:9px}
			.fy-pay-col{
				display:flex;flex-direction:column;gap:4px;padding:13px 12px;border-radius:14px;text-align:center;min-width:0;
			}
			.fy-pay-col.is-now{border:2px solid #E45C9C;background:#fff;box-shadow:0 8px 20px rgba(228,92,156,.16)}
			.fy-pay-col.is-later{border:2px dashed rgba(124,58,237,.36);background:rgba(255,255,255,.6)}
			.fy-pay-label{font-size:10.5px;font-weight:950;letter-spacing:.045em;text-transform:uppercase;color:#5B21B6;line-height:1.25}
			.fy-pay-col.is-now .fy-pay-label{color:#C94386}
			.fy-pay-amount{font-size:clamp(22px,4.5vw,30px);font-weight:950;letter-spacing:-.03em;line-height:1.05;overflow-wrap:anywhere}
			.fy-pay-col.is-now .fy-pay-amount{color:#C94386}
			.fy-pay-note{font-size:10.5px;font-weight:800;color:#526079;line-height:1.4}
			.fy-pay-plus{align-self:center;font-size:17px;font-weight:950;color:#526079}
			.fy-pay-policy{
				margin-top:12px;padding-top:11px;border-top:1px dashed rgba(124,58,237,.24);
			}
			.fy-pay-policy strong{font-size:11px;font-weight:950;letter-spacing:.04em;text-transform:uppercase;color:#5B21B6}
			.fy-pay-policy ul{margin:6px 0 0;padding-left:18px}
			.fy-pay-policy li{font-size:11px;font-weight:700;color:#526079;line-height:1.55;margin-bottom:3px}
			@media(max-width:480px){
				.fy-pay-split-grid{grid-template-columns:1fr;gap:8px}
				.fy-pay-plus{display:none}
			}
			</style>
		<?php
	}

	/**
	 * The three figures, side by side.
	 *
	 * @param bool $paid Whether the deposit has already been taken.
	 */
	private static function split_body( $charter, $deposit, $balance, $paid = false ) {
		$full_payment = $balance <= 0;
		?>
			<?php if ( ! $full_payment ) : ?>
			<div class="fy-pay-split-top">
				<span><?php esc_html_e( 'Full charter price', 'fy-fleet' ); ?></span>
				<strong><?php echo wp_kses_post( wc_price( $charter ) ); ?></strong>
			</div>
			<?php endif; ?>

			<div class="fy-pay-split-grid">
				<div class="fy-pay-col is-now">
					<span class="fy-pay-label">✅
						<?php
						if ( $full_payment ) {
							echo $paid ? esc_html__( 'Paid in full', 'fy-fleet' ) : esc_html__( 'Charged today', 'fy-fleet' );
						} else {
							echo $paid ? esc_html__( 'Deposit paid', 'fy-fleet' ) : esc_html__( 'Charged today', 'fy-fleet' );
						}
						?>
					</span>
					<span class="fy-pay-amount"><?php echo wp_kses_post( wc_price( $deposit ) ); ?></span>
					<span class="fy-pay-note">
						<?php
						if ( $full_payment ) {
							esc_html_e( 'Boat, crew and deposit — nothing due at the dock', 'fy-fleet' );
						} else {
							echo $paid ? esc_html__( 'Your date is reserved', 'fy-fleet' ) : esc_html__( 'Deposit — this reserves your date', 'fy-fleet' );
						}
						?>
					</span>
				</div>
				<?php if ( ! $full_payment ) : ?>
				<span class="fy-pay-plus" aria-hidden="true">+</span>
				<div class="fy-pay-col is-later">
					<span class="fy-pay-label">⚓
						<?php echo $paid ? esc_html__( 'Bring to the dock', 'fy-fleet' ) : esc_html__( 'Due at the dock', 'fy-fleet' ); ?>
					</span>
					<span class="fy-pay-amount"><?php echo wp_kses_post( wc_price( $balance ) ); ?></span>
					<span class="fy-pay-note"><?php esc_html_e( 'Paid in person before departure', 'fy-fleet' ); ?></span>
				</div>
				<?php endif; ?>
			</div>

			<?php $policy = FY_Fleet_Settings::get_cancellation_lines(); ?>
			<?php if ( ! empty( $policy ) ) : ?>
				<div class="fy-pay-policy">
					<strong>🛡️ <?php esc_html_e( 'Cancellation policy', 'fy-fleet' ); ?></strong>
					<ul>
						<?php foreach ( $policy as $line ) : ?>
							<li><?php echo esc_html( $line ); ?></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>
		<?php
	}

	/** Remind the customer of the dock balance on the order-received page. */
	public static function thankyou_balance( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		$charter = 0.0;
		$balance = 0.0;
		$paid    = 0.0;
		foreach ( $order->get_items() as $item ) {
			if ( ! $item->get_meta( '_fy_date' ) && ! $item->get_meta( '_fy_yacht_id' ) ) {
				continue;
			}
			$charter += (float) $item->get_meta( '_fy_charter_total' );
			$balance += (float) $item->get_meta( '_fy_balance' );
			$paid    += (float) $item->get_meta( '_fy_deposit' );
		}

		if ( $charter <= 0 ) {
			return;
		}
		// Older orders have no _fy_deposit meta; derive from the split then.
		if ( $paid <= 0 ) {
			$paid = max( 0, $charter - $balance );
		}

		self::split_css();
		echo '<div class="fy-pay-split" style="max-width:640px">';
		self::split_body( $charter, $paid, $balance, true );
		echo '</div>';
	}

	public static function format_date( $date ) {
		$timestamp = strtotime( $date );
		return $timestamp ? date_i18n( 'D, M j, Y', $timestamp ) : $date;
	}
}
