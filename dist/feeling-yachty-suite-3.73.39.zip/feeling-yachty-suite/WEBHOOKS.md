# Feeling Yachty Command Center — Webhook Integration Spec
**For the n8n workflow builder. Requires plugin v2.6.0 or newer**
(check: WP Admin → Plugins → "Feeling Yachty Command Center" — the version is printed under the name. If the settings described below are missing, the site is on an older build — upload the latest zip first.)

---

## 1. Where the settings live (site owner does this)
**⚓ FY Command Center → Booking & Checkout → "Booking Webhook (n8n / automations)"**

| Field | Meaning |
|---|---|
| **Webhook URL** | Your n8n Webhook node's production URL. Paste it here. |
| **Signing secret** | Click **🎲 Generate** (creates `fy_` + 48 hex chars), **Save Changes**, then copy the string to n8n. Can also be typed manually. |

Direction: **WordPress → POST → n8n.** Nothing flows the other way for these events.

## 2. Events
One URL receives all three; route on the `event` field.

| `event` | Fires when | Sent |
|---|---|---|
| `booking.paid` | An order containing a charter reaches *processing* or *completed* | Once per order (guarded by order meta `_fy_webhook_sent`) |
| `ticket.created` | A customer opens a support ticket (incl. cancellation requests from the portal) | Every occurrence |
| `ticket.reply` | A customer replies on an existing ticket | Every occurrence |

Transport details: `Content-Type: application/json`, request timeout **8 s**, **no automatic retries** — a non-2xx response or timeout is recorded in *FY Command Center → Activity Log* (`webhook.failed`) but not re-sent. If you need guaranteed delivery, poll the REST endpoints below as a reconciliation job.

## 3. Signature (item 4 of your spec)
Every POST carries:

```
X-Signature:    <hex HMAC-SHA256 of the RAW request body, keyed with the Signing secret>
X-FY-Signature: <same value, legacy duplicate>
```

⚠️ The HMAC is computed over the **exact raw bytes** of the body. In n8n, enable **"Raw Body"** on the Webhook node and verify against that — re-serializing the parsed JSON can reorder/re-space and break the comparison.

n8n Code node verification:

```javascript
const crypto = require('crypto');
const secret   = 'PASTE_THE_SIGNING_SECRET_HERE';
const rawBody  = $input.first().json.rawBody ?? $input.first().binary?.data;
const received = $input.first().json.headers['x-signature'];
const expected = crypto.createHmac('sha256', secret)
                       .update(Buffer.isBuffer(rawBody) ? rawBody : String(rawBody))
                       .digest('hex');
if (received !== expected) throw new Error('Invalid webhook signature');
return $input.all();
```

## 4. Payloads — full records (item 3 of your spec)
Field-for-field the same shapes as the REST endpoints `/wp-json/fy/v1/bookings`, `/tickets`, `/customers`.

### `booking.paid`
```json
{
  "event": "booking.paid",
  "order_id": 1234,
  "order_no": "1234",
  "status": "processing",
  "customer": {
    "name": "Jane Doe",
    "email": "jane@example.com",
    "phone": "+1 305 555 0100",
    "address_1": "123 Ocean Dr",
    "address_2": "",
    "city": "Miami",
    "state": "FL",
    "postcode": "33139",
    "country": "US"
  },
  "customer_stats": {
    "name": "Jane Doe",
    "email": "jane@example.com",
    "phone": "+1 305 555 0100",
    "bookings": 2,
    "charter_total": 2900.0,
    "deposits_paid": 870.0,
    "balance_open": 840.0,
    "first_date": "2026-05-02",
    "last_date": "2026-08-14",
    "yachts": ["26ft Pink Bayliner “Fendi”", "50ft Azimut “COCO”"],
    "occasions": [],
    "form_ok": true
  },
  "bareboat_form_confirmed": true,
  "bookings": [
    {
      "order_id": 1234,
      "order_no": "1234",
      "order_created": "2026-08-05 14:22:31",
      "status": "processing",
      "yacht": "26ft Pink Bayliner “Fendi”",
      "yacht_id": 87,
      "yacht_capacity": 13,
      "date": "2026-08-14",
      "time": "12:00 PM",
      "duration": "4 Hours",
      "hours": 4,
      "guests": 8,
      "occasion": "Bachelorette",
      "notes": "Pink decorations please",
      "marina": "Dinner Key Marina",
      "total": 1200.0,
      "deposit": 360.0,
      "balance": 840.0,
      "addons": [
        { "key": "jet-ski", "label": "Jet Ski", "unit": "hour", "price": 175, "qty": 1, "hours": 4, "total": 700 }
      ],
      "confirmed": true,
      "edit_url": "https://feelingyachty.com/wp-admin/post.php?post=1234&action=edit"
    }
  ],
  "sent_at": "2026-08-05T18:22:33+00:00"
}
```
`customer_stats` is `null` for a first-time email with no prior paid bookings.

### `ticket.created` / `ticket.reply`
```json
{
  "event": "ticket.created",
  "ticket_id": 456,
  "subject": "Can we add a bartender?",
  "department": "sales",
  "status": "open",
  "created": "2026-08-05 18:30:12",
  "customer": { "name": "Jane Doe", "email": "jane@example.com", "user_id": 12 },
  "customer_stats": { "…same shape as above…": "or null" },
  "order_id": 1234,
  "message": "Hi! We'd love to add a bartender to our booking…",
  "replies": [
    { "from": "customer", "author": "Jane Doe", "message": "Hi! We'd love to add…", "date_gmt": "2026-08-05 18:30:12" }
  ],
  "admin_url": "https://feelingyachty.com/wp-admin/edit.php?post_type=fy_yacht&page=fy-fleet-inbox&ticket=456",
  "sent_at": "2026-08-05T18:30:13+00:00"
}
```
`department` values: `sales` · `billing` · `cancellations` · `support`. `status`: `open` · `answered` · `closed`. `replies[].from`: `customer` or `staff` — on `ticket.reply` the array contains the **entire thread**, newest last.

## 5. REST endpoints (pull/backfill, Basic auth with a WordPress Application Password)
```
GET /wp-json/fy/v1/bookings?from=2026-08-01&to=2026-08-31
GET /wp-json/fy/v1/tickets
GET /wp-json/fy/v1/customers
GET /wp-json/fy/v1/yachts
```

## 6. End-to-end test
1. Owner pastes your n8n URL + generates/saves the secret, sends you the secret.
2. Place a Stripe test-mode booking (card `4242 4242 4242 4242`).
3. Within seconds n8n receives `booking.paid`; verify the signature; check *Activity Log* on the WP side shows `webhook.sent`.
4. Open a ticket from My Account → Support → `ticket.created` arrives.
