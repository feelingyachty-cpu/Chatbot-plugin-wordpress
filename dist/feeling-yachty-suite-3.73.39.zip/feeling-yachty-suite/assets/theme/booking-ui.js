/**
 * Feeling Yachty — app-style booking UI for the product page.
 *
 * Replaces the native date field and the three dropdowns (start time, charter
 * length, passenger count) with swipeable pill pickers and a stepper, and
 * turns the add-on checkboxes into toggle cards.
 *
 * DESIGN RULE, and the reason this file is safe: it is a SKIN, not a booking
 * engine. Every control here writes back to the original field and fires a
 * real "change" event, then hides the original. Nothing about pricing,
 * variation resolution, the jet-ski hour caps, or the server-side re-check at
 * add-to-cart is reimplemented — those all keep reading the same fields they
 * always did:
 *
 *   #booking_date          date (ISO YYYY-MM-DD, which applyTimeRules expects)
 *   #charter_start_time    <select>, options disabled by product-express.js
 *                          when a slot has already passed in Miami today
 *   #pa_charter-duration   WooCommerce variation attribute — drives the price
 *   #pa_passenger-count    WooCommerce variation attribute
 *   .fy-addon__check       add-on checkboxes, named fy_addons[key][on]
 *
 * Sync runs BOTH ways: the pills write to the field, and a cheap poll mirrors
 * the field's state (including options WooCommerce or product-express.js has
 * disabled or rebuilt) back onto the pills. That poll is the same technique
 * product-express.js and addons.js already use, and for the same reason —
 * themed dropdowns and datepickers routinely change a value without firing an
 * event.
 */
( function ( $ ) {
	'use strict';

	if ( ! document.body || ! document.body.classList.contains( 'single-product' ) ) {
		return;
	}

	var DAYS_AHEAD = 365;   // a full year, now that months are navigable
	var DOW = [ 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat' ];
	var MONTHS = [ 'January', 'February', 'March', 'April', 'May', 'June', 'July',
		'August', 'September', 'October', 'November', 'December' ];

	/** Miami's own date — the clock the boat actually leaves on. Matches product-express.js. */
	function miamiToday() {
		return new Intl.DateTimeFormat( 'en-CA', {
			timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit'
		} ).format( new Date() );
	}

	function isoOf( d ) {
		var m = String( d.getMonth() + 1 );
		var day = String( d.getDate() );
		return d.getFullYear() + '-' + ( m.length < 2 ? '0' + m : m ) + '-' + ( day.length < 2 ? '0' + day : day );
	}

	/** Parse an ISO date as LOCAL midnight — never new Date(iso), which is UTC and can shift a day. */
	function fromIso( iso ) {
		var p = String( iso ).slice( 0, 10 ).split( '-' );
		if ( 3 !== p.length ) { return null; }
		var d = new Date( parseInt( p[ 0 ], 10 ), parseInt( p[ 1 ], 10 ) - 1, parseInt( p[ 2 ], 10 ) );
		return isNaN( d.getTime() ) ? null : d;
	}

	/** A horizontally scrollable strip with a heading, swipe hint and arrows. */
	function strip( title, cls ) {
		var $sec = $( '<section class="fy-bui-sec"></section>' ).addClass( cls || '' );
		var $head = $( '<div class="fy-bui-sec__head"></div>' );
		$head.append( $( '<h3 class="fy-bui-sec__title"></h3>' ).text( title ) );
		var $hint = $( '<span class="fy-bui-swipe" aria-hidden="true">Swipe ›</span>' );
		$head.append( $hint );
		$sec.append( $head );

		var $rail = $( '<div class="fy-bui-rail"></div>' );
		var $track = $( '<div class="fy-bui-track" role="group"></div>' ).attr( 'aria-label', title );
		var $prev = $( '<button type="button" class="fy-bui-arrow fy-bui-arrow--prev" aria-label="Scroll back">◀</button>' );
		var $next = $( '<button type="button" class="fy-bui-arrow fy-bui-arrow--next" aria-label="Scroll forward">▶</button>' );
		$rail.append( $prev, $track, $next );
		$sec.append( $rail );

		function page( dir ) {
			var el = $track[ 0 ];
			el.scrollLeft += dir * Math.max( 160, Math.round( el.clientWidth * 0.8 ) );
			setTimeout( arrows, 220 );
		}
		$prev.on( 'click', function () { page( -1 ); } );
		$next.on( 'click', function () { page( 1 ); } );

		function arrows() {
			var el = $track[ 0 ];
			if ( ! el ) { return; }
			var overflows = el.scrollWidth > el.clientWidth + 2;
			var atStart = el.scrollLeft <= 2;
			var atEnd = el.scrollLeft + el.clientWidth >= el.scrollWidth - 2;
			$prev.toggleClass( 'is-hidden', ! overflows || atStart );
			$next.toggleClass( 'is-hidden', ! overflows || atEnd );
			$hint.toggleClass( 'is-hidden', ! overflows || atEnd );
		}
		$track.on( 'scroll', arrows );
		$( window ).on( 'resize', arrows );
		setTimeout( arrows, 60 );
		setTimeout( arrows, 600 );

		$sec.data( 'track', $track );
		$sec.data( 'arrows', arrows );
		return $sec;
	}

	/**
	 * Centre a pill inside its own strip, without scrolling the page.
	 *
	 * Applied as a delta from live rects rather than offsetLeft: offsetLeft is
	 * relative to the nearest positioned ancestor (the rail), and the rail's
	 * width changes as the scroll arrows collapse and reappear, so an absolute
	 * figure computed before that reflow lands short.
	 */
	function reveal( $track, $pill ) {
		if ( ! $track || ! $track.length || ! $pill || ! $pill.length ) { return; }
		var t = $track[ 0 ], p = $pill[ 0 ];
		if ( ! t.getBoundingClientRect || ! p.getBoundingClientRect ) { return; }
		var tr = t.getBoundingClientRect(), pr = p.getBoundingClientRect();
		t.scrollLeft += ( pr.left - tr.left ) - ( tr.width / 2 ) + ( pr.width / 2 );
	}

	/* ------------------------------------------------------------------
	 * Date
	 * ---------------------------------------------------------------- */
	function buildDate( $field ) {
		var $sec = strip( 'Date', 'fy-bui-sec--date' );
		var $track = $sec.data( 'track' );
		// The month strip below is also a .fy-bui-track inside this same
		// section, so tag the day track to keep the two unambiguous for any
		// selector that goes looking for one of them.
		$track.addClass( 'fy-bui-days__track' );

		/*
		 * Month strip: the same swipeable row of pills as the days, sitting
		 * above them. Picking a month scrolls the day strip to the 1st of that
		 * month rather than selecting a date — the date is still a day choice,
		 * this is just navigation. Scrolling the days highlights the month
		 * being looked at, so the two always agree.
		 */
		var $monthRail = $( '<div class="fy-bui-rail fy-bui-months"></div>' );
		var $monthTrack = $( '<div class="fy-bui-track fy-bui-months__track" role="group" aria-label="Choose month"></div>' );
		var $mPrev = $( '<button type="button" class="fy-bui-arrow fy-bui-arrow--prev" aria-label="Earlier months">◀</button>' );
		var $mNext = $( '<button type="button" class="fy-bui-arrow fy-bui-arrow--next" aria-label="Later months">▶</button>' );
		$monthRail.append( $mPrev, $monthTrack, $mNext );
		$sec.find( '.fy-bui-sec__head' ).after( $monthRail );

		function monthArrows() {
			var el = $monthTrack[ 0 ];
			if ( ! el ) { return; }
			var over = el.scrollWidth > el.clientWidth + 2;
			$mPrev.toggleClass( 'is-hidden', ! over || el.scrollLeft <= 2 );
			$mNext.toggleClass( 'is-hidden', ! over || el.scrollLeft + el.clientWidth >= el.scrollWidth - 2 );
		}
		function monthPage( dir ) {
			var el = $monthTrack[ 0 ];
			el.scrollLeft += dir * Math.max( 140, Math.round( el.clientWidth * 0.8 ) );
			setTimeout( monthArrows, 220 );
		}
		$mPrev.on( 'click', function () { monthPage( -1 ); } );
		$mNext.on( 'click', function () { monthPage( 1 ); } );
		$monthTrack.on( 'scroll', monthArrows );
		$( window ).on( 'resize', monthArrows );

		var todayIso = miamiToday();
		var start = fromIso( todayIso ) || new Date();
		var pills = [];

		for ( var i = 0; i < DAYS_AHEAD; i++ ) {
			var d = new Date( start.getFullYear(), start.getMonth(), start.getDate() + i );
			var iso = isoOf( d );
			var $p = $( '<button type="button" class="fy-bui-pill fy-bui-pill--day"></button>' )
				.attr( 'data-value', iso )
				.attr( 'aria-pressed', 'false' )
				.append( $( '<span class="fy-bui-pill__dow"></span>' ).text( DOW[ d.getDay() ] ) )
				.append( $( '<span class="fy-bui-pill__num"></span>' ).text( d.getDate() ) );
			$p.data( 'month', d.getMonth() ).data( 'year', d.getFullYear() );
			$track.append( $p );
			pills.push( $p );
		}

		// One pill per distinct month covered by the day range.
		var seenMonths = {};
		for ( var mi = 0; mi < pills.length; mi++ ) {
			var mKey = pills[ mi ].data( 'year' ) + '-' + pills[ mi ].data( 'month' );
			if ( seenMonths[ mKey ] ) { continue; }
			seenMonths[ mKey ] = true;
			$monthTrack.append(
				$( '<button type="button" class="fy-bui-pill fy-bui-month-pill"></button>' )
					.attr( 'data-mkey', mKey )
					.attr( 'aria-pressed', 'false' )
					.text( MONTHS[ pills[ mi ].data( 'month' ) ] + ' ' + pills[ mi ].data( 'year' ) )
			);
		}
		setTimeout( monthArrows, 60 );
		setTimeout( monthArrows, 600 );

		/** Highlight a month pill, and keep it in view within its own strip. */
		function showMonthFor( $p ) {
			var key = $p.data( 'year' ) + '-' + $p.data( 'month' );
			var $active = null;
			$monthTrack.find( '.fy-bui-month-pill' ).each( function () {
				var on = $( this ).attr( 'data-mkey' ) === key;
				$( this ).toggleClass( 'is-active', on ).attr( 'aria-pressed', on ? 'true' : 'false' );
				if ( on ) { $active = $( this ); }
			} );
			if ( $active ) { reveal( $monthTrack, $active ); }
		}
		showMonthFor( pills[ 0 ] );

		// Jump the day strip to the first day of the chosen month.
		$monthTrack.on( 'click', '.fy-bui-month-pill', function () {
			var key = $( this ).attr( 'data-mkey' );
			var found = null;
			for ( var j = 0; j < pills.length; j++ ) {
				if ( pills[ j ].data( 'year' ) + '-' + pills[ j ].data( 'month' ) === key ) {
					found = pills[ j ];
					break;
				}
			}
			if ( ! found ) { return; }

			/*
			 * Left-align the 1st of the month.
			 *
			 * Measured with rects and applied as a DELTA, not an absolute
			 * offsetLeft: scrolling away from the start makes the previously
			 * collapsed "◀" arrow appear, which widens the rail and shifts
			 * every pill left by roughly an arrow's width — after the position
			 * was calculated. That reflow landed every jump one day early, on
			 * the last day of the previous month. A delta re-measured against
			 * live geometry can't drift, and a second pass on the next frame
			 * absorbs the arrow's own reflow.
			 */
			var t = $track[ 0 ];
			function alignTo( el ) {
				t.scrollLeft += el.getBoundingClientRect().left - t.getBoundingClientRect().left;
			}
			alignTo( found[ 0 ] );
			if ( window.requestAnimationFrame ) {
				window.requestAnimationFrame( function () { alignTo( found[ 0 ] ); } );
			} else {
				setTimeout( function () { alignTo( found[ 0 ] ); }, 30 );
			}

			// Set the highlight from the pill that was actually asked for, and
			// do it AFTER the scroll so the day-scroll handler (which derives
			// the month from whatever is leftmost) can't race ahead of it.
			showMonthFor( found );
			$sec.data( 'arrows' )();
		} );

		// Month highlight follows the leftmost fully-visible day as you swipe.
		$track.on( 'scroll', function () {
			var el = $track[ 0 ];
			for ( var j = 0; j < pills.length; j++ ) {
				if ( pills[ j ][ 0 ].offsetLeft + pills[ j ][ 0 ].offsetWidth > el.scrollLeft + 4 ) {
					showMonthFor( pills[ j ] );
					break;
				}
			}
		} );

		$track.on( 'click', '.fy-bui-pill', function () {
			var val = $( this ).attr( 'data-value' );
			$field.val( val ).trigger( 'change' ).trigger( 'input' );
			sync();
		} );

		function sync() {
			var cur = String( $field.val() || '' ).slice( 0, 10 );
			var $active = null;
			$track.find( '.fy-bui-pill' ).each( function () {
				var on = $( this ).attr( 'data-value' ) === cur;
				$( this ).toggleClass( 'is-active', on ).attr( 'aria-pressed', on ? 'true' : 'false' );
				if ( on ) { $active = $( this ); }
			} );
			if ( $active ) { showMonthFor( $active ); }
			return $active;
		}

		$sec.data( 'sync', sync );
		$sec.data( 'reveal', function () { reveal( $track, sync() ); } );
		return $sec;
	}

	/* ------------------------------------------------------------------
	 * A pill strip driven by a <select> (start time, charter length)
	 * ---------------------------------------------------------------- */
	function buildFromSelect( $sel, title, cls, opts ) {
		opts = opts || {};
		var $sec = strip( title, cls );
		var $track = $sec.data( 'track' );
		var signature = '';

		function optionLabel( $o ) {
			var t = $.trim( $o.text() );
			if ( opts.trimHours ) {
				// "3 Hours" stays; a slug-ish "3-hours" becomes "3 Hours".
				t = t.replace( /[-_]/g, ' ' ).replace( /\s+/g, ' ' );
			}
			return t;
		}

		/**
		 * Sort key for a start time, in "charter day" order rather than clock
		 * order. Charters run 6:00 AM through 2:00 AM the next morning, so the
		 * after-midnight slots belong at the END of the strip, not the start —
		 * in plain clock order the very first thing a customer saw was
		 * "12:00 am", which reads as broken when charters actually begin at 6am.
		 * Presentation only: the <select> keeps WooCommerce's own order.
		 */
		function charterDayKey( label ) {
			var m = String( label ).match( /(\d{1,2})\s*:\s*(\d{2})\s*([ap])\.?\s*m\.?/i );
			if ( ! m ) { return null; }
			var h = parseInt( m[ 1 ], 10 ) % 12;
			if ( /p/i.test( m[ 3 ] ) ) { h += 12; }
			var mins = h * 60 + parseInt( m[ 2 ], 10 );
			return mins >= 360 ? mins : mins + 1440;   // 06:00 opens the day
		}

		/** Rebuild pills only when the option list itself actually changed. */
		function build() {
			var sig = [];
			$sel.first().find( 'option' ).each( function () {
				sig.push( $( this ).attr( 'value' ) + '|' + $.trim( $( this ).text() ) + '|' + ( $( this ).prop( 'disabled' ) ? 1 : 0 ) );
			} );
			var joined = sig.join( '~' );
			if ( joined === signature ) { return false; }
			signature = joined;

			var items = [];
			$sel.first().find( 'option' ).each( function ( i ) {
				var $o = $( this );
				var val = $o.attr( 'value' );
				if ( ! val ) { return; }   // the "Choose an option" placeholder
				var label = optionLabel( $o );
				var key = opts.charterDayOrder ? charterDayKey( label ) : null;
				items.push( {
					value: val,
					label: label,
					disabled: $o.prop( 'disabled' ),
					key: ( null === key ) ? ( i + 100000 ) : key   // unparseable labels keep their original place
				} );
			} );
			if ( opts.charterDayOrder ) {
				items.sort( function ( a, b ) { return a.key - b.key; } );
			}

			$track.empty();
			items.forEach( function ( it ) {
				var $p = $( '<button type="button" class="fy-bui-pill"></button>' )
					.attr( 'data-value', it.value )
					.attr( 'aria-pressed', 'false' )
					.text( it.label );
				if ( it.disabled ) {
					// Already-passed start times: visible but unpickable, so the
					// customer can see the slot exists rather than wondering
					// where it went.
					$p.prop( 'disabled', true ).addClass( 'is-disabled' )
						.attr( 'title', 'This time has already passed today' );
				}
				$track.append( $p );
			} );
			$sec.data( 'arrows' )();
			return true;
		}

		$track.on( 'click', '.fy-bui-pill', function () {
			if ( $( this ).prop( 'disabled' ) ) { return; }
			$sel.val( $( this ).attr( 'data-value' ) ).trigger( 'change' );
			sync();
		} );

		function sync() {
			var cur = $sel.val();
			var $active = null;
			$track.find( '.fy-bui-pill' ).each( function () {
				var on = !! cur && $( this ).attr( 'data-value' ) === cur;
				$( this ).toggleClass( 'is-active', on ).attr( 'aria-pressed', on ? 'true' : 'false' );
				if ( on ) { $active = $( this ); }
			} );
			return $active;
		}

		$sec.data( 'build', build );
		$sec.data( 'sync', function () { build(); return sync(); } );
		$sec.data( 'reveal', function () { reveal( $track, sync() ); } );
		build();
		sync();
		return $sec;
	}

	/* ------------------------------------------------------------------
	 * Guests — a stepper over whatever options the select actually has
	 * ---------------------------------------------------------------- */
	function buildGuests( $sel ) {
		var $sec = $( '<section class="fy-bui-sec fy-bui-sec--guests"></section>' );
		$sec.append( '<div class="fy-bui-sec__head"><h3 class="fy-bui-sec__title">Guests</h3></div>' );

		var $step = $( '<div class="fy-bui-stepper"></div>' );
		var $minus = $( '<button type="button" class="fy-bui-step fy-bui-step--minus" aria-label="Fewer guests">−</button>' );
		var $plus = $( '<button type="button" class="fy-bui-step fy-bui-step--plus" aria-label="More guests">+</button>' );
		var $val = $( '<div class="fy-bui-stepper__val"><strong class="fy-bui-stepper__num"></strong><span class="fy-bui-stepper__unit">guests</span></div>' );
		$step.append( $minus, $val, $plus );
		$sec.append( $step );

		// WooCommerce refuses add-to-cart until every attribute is chosen, and
		// guest count is one of them. The old dropdown said "Choose an option";
		// a stepper showing "—" doesn't read as something you still have to do,
		// so say it plainly until a number is picked.
		var $hint = $( '<p class="fy-bui-hint">Tap + to choose how many guests</p>' );
		$sec.append( $hint );

		/**
		 * WooCommerce returns attribute terms in term order, which for a
		 * numeric attribute is alphabetical: 1, 10, 11, 12, 13, 2, 3…
		 * Stepping in that order would send "+" from 1 straight to 10, so
		 * sort numerically whenever every value is a number. Only the ORDER
		 * shown is changed — each option is still selected by its own value,
		 * and the underlying <select> is left exactly as WooCommerce built it.
		 */
		function values() {
			var out = [];
			$sel.first().find( 'option' ).each( function () {
				var v = $( this ).attr( 'value' );
				if ( v ) { out.push( { value: v, label: $.trim( $( this ).text() ) } ); }
			} );
			var allNumeric = out.length > 0 && out.every( function ( o ) {
				return '' !== o.value && ! isNaN( parseFloat( o.value ) ) && isFinite( o.value );
			} );
			if ( allNumeric ) {
				out.sort( function ( a, b ) { return parseFloat( a.value ) - parseFloat( b.value ); } );
			}
			return out;
		}

		/**
		 * Stepping writes the value immediately but announces it on a short
		 * debounce. Firing "change" on every click made WooCommerce re-resolve
		 * the variation once per press; holding + through a dozen guests
		 * queued a dozen overlapping async re-renders, and a stale one landing
		 * last could snap the count back to where it started. One change event
		 * per burst is both correct and far cheaper.
		 */
		var announce = null;
		function move( dir ) {
			var vals = values();
			if ( ! vals.length ) { return; }
			var cur = $sel.val();
			var idx = -1;
			for ( var i = 0; i < vals.length; i++ ) {
				if ( vals[ i ].value === cur ) { idx = i; break; }
			}
			// Nothing picked yet: + starts at the first option, − at the last.
			var next = ( idx === -1 ) ? ( dir > 0 ? 0 : vals.length - 1 ) : idx + dir;
			if ( next < 0 || next >= vals.length ) { return; }
			$sel.val( vals[ next ].value );
			sync();
			clearTimeout( announce );
			announce = setTimeout( function () {
				$sel.trigger( 'change' );
			}, 220 );
		}
		$minus.on( 'click', function () { move( -1 ); } );
		$plus.on( 'click', function () { move( 1 ); } );

		function sync() {
			var vals = values();
			var cur = $sel.val();
			var idx = -1;
			for ( var i = 0; i < vals.length; i++ ) {
				if ( vals[ i ].value === cur ) { idx = i; break; }
			}
			$val.find( '.fy-bui-stepper__num' ).text( idx === -1 ? '—' : vals[ idx ].label );
			$sec.toggleClass( 'is-empty', idx === -1 );
			$hint.prop( 'hidden', idx !== -1 );
			$minus.prop( 'disabled', idx <= 0 );
			$plus.prop( 'disabled', vals.length === 0 || ( idx !== -1 && idx >= vals.length - 1 ) );
			return null;
		}

		$sec.data( 'sync', sync );
		$sec.data( 'reveal', function () {} );
		sync();
		return $sec;
	}

	/* ------------------------------------------------------------------
	 * Add-ons — turn each qty/hours <select> into a stepper.
	 * The checkbox itself becomes a switch purely in CSS, so the label click
	 * target, the name attribute and addons.js's own handlers are untouched.
	 * ---------------------------------------------------------------- */
	function stepperize( $sel, unitText ) {
		if ( ! $sel.length || $sel.data( 'fy-bui-stepped' ) ) { return; }
		$sel.data( 'fy-bui-stepped', true );

		var $step = $( '<div class="fy-bui-stepper fy-bui-stepper--sm"></div>' );
		var $minus = $( '<button type="button" class="fy-bui-step fy-bui-step--minus" aria-label="Decrease">−</button>' );
		var $plus = $( '<button type="button" class="fy-bui-step fy-bui-step--plus" aria-label="Increase">+</button>' );
		var $val = $( '<div class="fy-bui-stepper__val"><strong class="fy-bui-stepper__num"></strong><span class="fy-bui-stepper__unit"></span></div>' );
		$val.find( '.fy-bui-stepper__unit' ).text( unitText || '' );
		$step.append( $minus, $val, $plus );
		$sel.addClass( 'fy-bui-hidden-select' ).after( $step );

		function opts() {
			return $sel.first().find( 'option' ).map( function () { return $( this ).attr( 'value' ); } ).get();
		}
		function move( dir ) {
			var vals = opts();
			var idx = vals.indexOf( String( $sel.val() ) );
			var next = ( idx === -1 ? 0 : idx + dir );
			if ( next < 0 || next >= vals.length ) { return; }
			$sel.val( vals[ next ] ).trigger( 'change' );
			sync();
		}
		$minus.on( 'click', function () { move( -1 ); } );
		$plus.on( 'click', function () { move( 1 ); } );

		function sync() {
			var vals = opts();
			var idx = vals.indexOf( String( $sel.val() ) );
			$val.find( '.fy-bui-stepper__num' ).text( idx === -1 ? ( vals[ 0 ] || '1' ) : vals[ idx ] );
			$minus.prop( 'disabled', idx <= 0 );
			$plus.prop( 'disabled', vals.length === 0 || idx >= vals.length - 1 );
		}
		$sel.on( 'change', sync );
		// addons.js REBUILDS this option list whenever the charter length
		// moves (the jet-ski cap changes with it) and does so WITHOUT firing a
		// change event — so "change" alone leaves the stepper's +/- disabled
		// state stuck at whatever the cap was on page load. syncAddonSteppers()
		// below re-runs this on the same tick as everything else.
		$sel.data( 'fy-bui-sync', sync );
		sync();
	}

	/** Re-read every add-on stepper against its select's CURRENT options. */
	function syncAddonSteppers() {
		$( '#fy-addons' ).find( '.fy-addon__hours-select, .fy-addon__qty-select' ).each( function () {
			var fn = $( this ).data( 'fy-bui-sync' );
			if ( fn ) { fn(); }
		} );
	}

	function decorateAddons() {
		var $wrap = $( '#fy-addons' );
		if ( ! $wrap.length ) { return; }
		$wrap.addClass( 'fy-bui-addons' );

		$wrap.find( '.fy-addon' ).each( function () {
			var $a = $( this );
			stepperize( $a.find( '.fy-addon__hours-select' ).first(), 'hours' );
			stepperize( $a.find( '.fy-addon__qty-select' ).first(), 'how many' );
			// Card reads as "on" the moment its switch does.
			var $chk = $a.find( '.fy-addon__check' );
			function state() { $a.toggleClass( 'is-on', $chk.is( ':checked' ) ); }
			$chk.on( 'change', state );
			state();
		} );
	}

	/* ------------------------------------------------------------------
	 * Assemble
	 * ---------------------------------------------------------------- */
	/**
	 * EVERY control for a field, not just the first.
	 *
	 * Page builders routinely output a separate copy of the same field for
	 * each breakpoint, all carrying the same id — and `#booking_date` matches
	 * only the first of those. That is why the old date box kept appearing on
	 * phones and nowhere else: the desktop copy was being hidden and the
	 * mobile one left alone. Worse, both copies post the same name, so the
	 * empty one could overwrite the date the customer had picked.
	 *
	 * Attribute selectors return all matches, so both the hiding and the
	 * value-writing below cover every copy.
	 */
	function fieldsFor( name ) {
		var names = [ name ];
		if ( name === 'booking_date' ) { names.push( 'fy_booking_date' ); }
		if ( name === 'charter_start_time' ) { names.push( 'fy_charter_start_time' ); }
		var sel = names.map( function ( n ) {
			return '[id="' + n + '"], [name="' + n + '"]';
		} ).join( ', ' );
		return $( sel ).filter( 'input, select, textarea' );
	}

	/**
	 * product-express.js addresses these two fields BY ID (#booking_date /
	 * #charter_start_time) for the past-start-time greying and the mobile
	 * native date picker. When the theme's own copies are removed and only
	 * the plugin's remain — those are deliberately id-less, to avoid clashing
	 * while both exist — nothing carries those ids and that logic would go
	 * quiet. Hand the id to the plugin's field only if no element already
	 * holds it, so the theme keeps priority whenever it is still present.
	 */
	function adoptIds() {
		[ 'booking_date', 'charter_start_time' ].forEach( function ( name ) {
			if ( document.getElementById( name ) ) { return; }
			var own = document.querySelector(
				'[data-fy-native-schedule] [name="' + name + '"], [data-fy-native-schedule] [name="fy_' + name + '"]'
			);
			if ( own ) { own.id = name; }
		} );
	}

	function init() {
		adoptIds();
		var $date = fieldsFor( 'booking_date' );
		var $time = fieldsFor( 'charter_start_time' );
		var $dur = fieldsFor( 'pa_charter-duration' ).add( $( '[name="attribute_pa_charter-duration"]' ) );
		var $pax = fieldsFor( 'pa_passenger-count' ).add( $( '[name="attribute_pa_passenger-count"]' ) );

		// Nothing to skin (a simple product, or the theme renders it
		// differently) — leave the page exactly as it was.
		if ( ! $date.length && ! $time.length && ! $dur.length ) { return; }
		if ( $( '#fy-bui' ).length ) { return; }

		var $ui = $( '<div class="fy-bui" id="fy-bui"></div>' );
		var secs = [];

		if ( $date.length ) {
			var $ds = buildDate( $date );
			$ui.append( $ds ); secs.push( $ds );
		}
		if ( $time.length ) {
			var $ts = buildFromSelect( $time, 'Start time', 'fy-bui-sec--time', { charterDayOrder: true } );
			$ui.append( $ts ); secs.push( $ts );
		}
		if ( $dur.length ) {
			var $ls = buildFromSelect( $dur, 'Charter length', 'fy-bui-sec--length', { trimHours: true } );
			$ui.append( $ls ); secs.push( $ls );
		}
		if ( $pax.length ) {
			var $gs = buildGuests( $pax );
			$ui.append( $gs ); secs.push( $gs );
		}

		// Anchor: directly above the variations table if there is one (that is
		// where the native fields live), else above the add-to-cart form.
		var $anchor = $( 'form.cart table.variations' ).first();
		if ( $anchor.length ) {
			$anchor.before( $ui );
		} else {
			var $form = $( 'form.cart' ).first();
			if ( ! $form.length ) { return; }
			$form.prepend( $ui );
		}

		// Hide the originals only once their replacements are on the page, so
		// a mid-build failure can never leave the customer with no controls at
		// all. They stay in the DOM and keep working — WooCommerce and
		// product-express.js are still reading and writing them, and a
		// display:none <select> still submits its value with the form.
		//
		// Only the rows actually replaced are hidden, never the whole
		// variations table: a yacht with a third attribute this file doesn't
		// skin must still leave that one pickable.
		/**
		 * Hide one replaced field, its label, and the wrapper holding both.
		 *
		 * The date and start-time fields come from the theme, whose markup we
		 * don't control — the first version walked up to the nearest <div>,
		 * which on the live site wrapped only the input and left the "Select
		 * Date" / "Charter Start Time" labels stranded above the new pickers.
		 * So: hide the field itself (a display:none control still posts its
		 * value, which is what WooCommerce reads), hide any label pointing at
		 * it, and hide the smallest shared ancestor of the two.
		 */
		/**
		 * Hide a replaced field, whatever the theme wrapped it in.
		 *
		 * Structure-agnostic on purpose. Earlier versions guessed at the
		 * markup — nearest <div>, then a list of likely row classes — and each
		 * guess missed a real layout: first the label survived, then the
		 * theme's styled wrapper survived as an empty box with a calendar icon
		 * in it, because only the <input> inside it had been hidden.
		 *
		 * Instead, climb as far up as the field is the ONLY form control in
		 * the container. That takes out the decorative wrapper and, when the
		 * label lives inside it, the label too — and it stops the moment the
		 * container holds anything else, so it can never swallow the variation
		 * selects or the add-to-cart button.
		 */
		function hideRow( $fields ) {
			if ( ! $fields || ! $fields.length ) { return; }
			// A page builder may render one copy per breakpoint — hide them all.
			$fields.each( function () { hideOne( $( this ) ); } );
		}

		function hideOne( $f ) {
			if ( ! $f || ! $f.length ) { return; }
			var field = $f[ 0 ];

			/*
			 * Everything that must survive. The climb below stops the moment
			 * swallowing the next ancestor would take one of these with it, so
			 * the customer can never lose the pickers, the price, the extras
			 * or the buy button no matter how the theme nests things.
			 */
			var protectedEls = [];
			$( '#fy-bui, #fy-addons, .fy-pay-summary, form.cart table.variations, ' +
			   'form.cart .single_add_to_cart_button, .woocommerce-variation-price' ).each( function () {
				protectedEls.push( this );
			} );
			function holdsProtected( el ) {
				for ( var i = 0; i < protectedEls.length; i++ ) {
					if ( el !== protectedEls[ i ] && el.contains( protectedEls[ i ] ) ) { return true; }
				}
				return false;
			}

			/*
			 * Climb as high as is safe, so the theme's whole field block goes —
			 * wrapper divs, the label, and any decoration around them.
			 *
			 * An earlier version stopped as soon as an ancestor held another
			 * form control, which on the live site left the "Select Date"
			 * caption and its empty calendar-icon box behind whenever the theme
			 * grouped them with anything else. Protecting a known list is
			 * sturdier than guessing which wrapper is "the row".
			 */
			var node = field;
			while ( node.parentElement ) {
				var parent = node.parentElement;
				if ( 'FORM' === parent.tagName || 'BODY' === parent.tagName ) { break; }
				if ( parent.id === 'fy-bui' || holdsProtected( parent ) ) { break; }
				node = parent;
			}
			$( node ).addClass( 'fy-bui-replaced-row' );

			// A label sitting OUTSIDE that container (a sibling, or pointing in
			// via for=) has to be taken out separately.
			var id = $f.attr( 'id' );
			if ( id ) { $( 'label[for="' + id + '"]' ).addClass( 'fy-bui-replaced-row' ); }
			$f.closest( 'label' ).addClass( 'fy-bui-replaced-row' );
			var $prev = $( node ).prev();
			if ( $prev.length && 'LABEL' === $prev[ 0 ].tagName ) {
				$prev.addClass( 'fy-bui-replaced-row' );
			}

			// Belt and braces: the control itself always goes. A display:none
			// field still posts its value, which is what WooCommerce reads.
			$f.addClass( 'fy-bui-replaced-row' );
		}
		hideRow( $date );
		hideRow( $time );
		hideRow( $dur );
		hideRow( $pax );

		// The arrival note product-express.js inserts after the time row would
		// otherwise be stranded next to a hidden field — move it under the new
		// start-time strip, where it is read at the moment a time is picked.
		function placeArrival() {
			var $note = $( '.fy-arrival-note' ).first();
			if ( ! $note.length || $note.data( 'fy-bui-moved' ) ) { return; }
			var $timeSec = $ui.find( '.fy-bui-sec--time' );
			if ( $timeSec.length ) {
				$timeSec.append( $note );
				$note.data( 'fy-bui-moved', true );
			}
		}
		placeArrival();
		setTimeout( placeArrival, 500 );
		setTimeout( placeArrival, 1500 );

		// Marks that the replacement pickers exist. The CSS uses it to hide
		// both the theme's fields and the plugin's own posting inputs — so if
		// this file never runs, those stay visible and the page still works.
		document.body.classList.add( 'fy-bui-active' );

		decorateAddons();
		setTimeout( decorateAddons, 800 );

		function syncAll() {
			for ( var i = 0; i < secs.length; i++ ) {
				var fn = secs[ i ].data( 'sync' );
				if ( fn ) { fn(); }
			}
			syncAddonSteppers();
		}

		// addons.js re-gates every add-on (and rebuilds the hours lists) after
		// a duration change, then announces the new totals — the earliest
		// reliable point at which the steppers are known to be stale.
		$( document.body ).on( 'fy_addons_changed', syncAddonSteppers );
		$( '#fy-addons' ).on( 'change', '.fy-addon__check, .fy-addon__variant', function () {
			setTimeout( syncAddonSteppers, 30 );
		} );

		// React to anything that changes the underlying fields — WooCommerce
		// rebuilding the variation dropdowns, product-express.js disabling
		// past start times, or a value written without an event.
		$( document.body ).on( 'change', '#booking_date, #charter_start_time, #pa_charter-duration, #pa_passenger-count', syncAll );
		$( 'form.cart' ).on( 'found_variation reset_data hide_variation woocommerce_update_variation_values', function () {
			setTimeout( syncAll, 60 );
		} );
		setInterval( syncAll, 1000 );

		// Centre whatever is already chosen (a returning customer, or a
		// pre-filled field) rather than leaving it scrolled off-screen.
		setTimeout( function () {
			for ( var i = 0; i < secs.length; i++ ) {
				var fn = secs[ i ].data( 'reveal' );
				if ( fn ) { fn(); }
			}
		}, 300 );

		syncAll();
	}

	$( function () {
		init();
		// The variations table and the add-ons panel are both injected by other
		// scripts that may not have run yet.
		setTimeout( init, 400 );
		setTimeout( init, 1200 );
	} );
} )( jQuery );
