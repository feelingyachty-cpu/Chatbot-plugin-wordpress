<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Customer portal, built on WooCommerce My Account (real logins, addresses and
 * password flows stay with Woo). Adds five tabs:
 *
 *   ⚓ My Charters       — CLIENT booking history: dates, balances and
 *                          one-click cancellation requests (routed to the
 *                          Inbox), plus the "leave a review" prompt once a
 *                          charter's date has passed.
 *   🛥️ My Yacht Bookings — OWNER booking history: a deliberately separate
 *                          tab (not a toggle on My Charters) so an owner who
 *                          also books yachts as a guest never has to wonder
 *                          which mode they're in. Logistics only — no guest
 *                          name/phone/email (Feeling Yachty stays the single
 *                          point of contact). Shown only to fy_yacht_owner.
 *   👤 My Profile        — photo, display name (shown on public reviews),
 *                          and claiming a past guest-checkout order.
 *   📄 My Documents      — signed forms/contracts staff attach to the customer.
 *   💬 Support           — the ticket system, by department.
 */
class FY_Fleet_Account {

	const EP_CHARTERS       = 'fy-charters';
	const EP_YACHT_BOOKINGS = 'fy-yacht-bookings';
	const EP_PROFILE        = 'fy-profile';
	const EP_DOCUMENTS      = 'fy-documents';
	const EP_SUPPORT        = 'fy-support';

	public static function init() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		add_action( 'init', array( __CLASS__, 'add_endpoints' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_flush' ) );
		add_filter( 'woocommerce_account_menu_items', array( __CLASS__, 'menu_items' ) );

		add_action( 'woocommerce_account_' . self::EP_CHARTERS . '_endpoint', array( __CLASS__, 'render_charters' ) );
		add_action( 'woocommerce_account_' . self::EP_YACHT_BOOKINGS . '_endpoint', array( __CLASS__, 'render_yacht_bookings' ) );
		add_action( 'woocommerce_account_' . self::EP_PROFILE . '_endpoint', array( __CLASS__, 'render_profile' ) );
		add_action( 'woocommerce_account_' . self::EP_DOCUMENTS . '_endpoint', array( __CLASS__, 'render_documents' ) );
		add_action( 'woocommerce_account_' . self::EP_SUPPORT . '_endpoint', array( __CLASS__, 'render_support' ) );

		add_action( 'wp_loaded', array( __CLASS__, 'handle_cancel_request' ) );
		add_action( 'wp_loaded', array( __CLASS__, 'handle_profile_save' ) );
		add_action( 'wp_loaded', array( __CLASS__, 'handle_claim_order' ) );
		add_action( 'wp_loaded', array( __CLASS__, 'handle_review_submit' ) );
		add_action( 'wp_loaded', array( __CLASS__, 'handle_block_date' ) );
		add_action( 'wp_loaded', array( __CLASS__, 'handle_unblock_date' ) );

		// Serve the uploaded profile photo in place of Gravatar wherever
		// get_avatar()/get_avatar_url() is called for that user — including
		// inside FY_Fleet_Reviews::render(), for free.
		add_filter( 'pre_get_avatar_data', array( __CLASS__, 'filter_avatar' ), 10, 2 );

		// Region at signup — which market a customer is in, for routing
		// ("Book a Yacht" below) and as the foundation for whatever
		// region-specific content/features come later.
		add_action( 'woocommerce_register_form', array( __CLASS__, 'render_region_field' ) );
		add_filter( 'woocommerce_registration_errors', array( __CLASS__, 'validate_region_field' ), 10, 3 );
		add_action( 'woocommerce_created_customer', array( __CLASS__, 'save_region_field' ) );

		// Staff attach documents on the user profile screen.
		add_action( 'show_user_profile', array( __CLASS__, 'profile_documents' ) );
		add_action( 'edit_user_profile', array( __CLASS__, 'profile_documents' ) );
		add_action( 'personal_options_update', array( __CLASS__, 'save_profile_documents' ) );
		add_action( 'edit_user_profile_update', array( __CLASS__, 'save_profile_documents' ) );
	}

	public static function add_endpoints() {
		add_rewrite_endpoint( self::EP_CHARTERS, EP_ROOT | EP_PAGES );
		add_rewrite_endpoint( self::EP_YACHT_BOOKINGS, EP_ROOT | EP_PAGES );
		add_rewrite_endpoint( self::EP_PROFILE, EP_ROOT | EP_PAGES );
		add_rewrite_endpoint( self::EP_DOCUMENTS, EP_ROOT | EP_PAGES );
		add_rewrite_endpoint( self::EP_SUPPORT, EP_ROOT | EP_PAGES );
	}

	public static function maybe_flush() {
		if ( '3' !== get_option( 'fy_portal_endpoints_v' ) ) {
			flush_rewrite_rules();
			update_option( 'fy_portal_endpoints_v', '3' );
		}
	}

	/** This user's own submitted/owned yacht IDs (post_author), publish only. */
	private static function owned_yacht_ids( $user_id ) {
		return get_posts(
			array(
				'post_type'      => FY_Fleet_CPT::POST_TYPE,
				'post_status'    => 'publish',
				'author'         => $user_id,
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);
	}

	/* ------------------------------------------------------------------
	 * Region (Miami / Panama) — captured at signup
	 * ---------------------------------------------------------------- */

	public static function render_region_field() {
		?>
		<p class="form-row form-row-wide">
			<label for="fy_region"><?php esc_html_e( 'Which city are you booking from?', 'fy-fleet' ); ?>&nbsp;<span class="required">*</span></label>
			<select name="fy_region" id="fy_region" class="woocommerce-Input woocommerce-Input--text input-text" required>
				<option value=""><?php esc_html_e( 'Choose one…', 'fy-fleet' ); ?></option>
				<option value="miami"><?php esc_html_e( 'Miami', 'fy-fleet' ); ?></option>
				<option value="panama"><?php esc_html_e( 'Panama', 'fy-fleet' ); ?></option>
			</select>
		</p>
		<?php
	}

	public static function validate_region_field( $errors, $username, $email ) {
		if ( empty( $_POST['fy_region'] ) || ! in_array( wp_unslash( $_POST['fy_region'] ), array( 'miami', 'panama' ), true ) ) {
			$errors->add( 'fy_region_error', __( 'Please choose Miami or Panama.', 'fy-fleet' ) );
		}
		return $errors;
	}

	public static function save_region_field( $customer_id ) {
		if ( ! empty( $_POST['fy_region'] ) ) {
			$region = sanitize_key( wp_unslash( $_POST['fy_region'] ) );
			if ( in_array( $region, array( 'miami', 'panama' ), true ) ) {
				update_user_meta( $customer_id, '_fy_region', $region );
			}
		}
	}

	/** 'miami' | 'panama' | '' (never set — pre-dates this field, or an admin-created account). */
	public static function region( $user_id ) {
		$region = get_user_meta( $user_id, '_fy_region', true );
		return in_array( $region, array( 'miami', 'panama' ), true ) ? $region : '';
	}

	/** Where the region-aware "Book a Yacht" button should send this user. */
	public static function region_fleet_url( $user_id ) {
		return 'panama' === self::region( $user_id )
			? home_url( '/panama-yacht-rentals/' )
			: home_url( '/miami-yacht-rental/' ); // Default to Miami — the flagship fleet, and correct for any pre-region account.
	}

	public static function menu_items( $items ) {
		$logout = isset( $items['customer-logout'] ) ? array( 'customer-logout' => $items['customer-logout'] ) : array();
		unset( $items['customer-logout'] );

		$items[ self::EP_CHARTERS ] = __( '⚓ My Charters', 'fy-fleet' );

		// Only an owner sees this tab at all — everyone else has no yachts
		// to show bookings for, and an empty tab is clutter, not a feature.
		$user = wp_get_current_user();
		if ( $user && in_array( 'fy_yacht_owner', (array) $user->roles, true ) ) {
			$items[ self::EP_YACHT_BOOKINGS ] = __( '🛥️ My Yacht Bookings', 'fy-fleet' );
		}

		$items[ self::EP_PROFILE ]   = __( '👤 My Profile', 'fy-fleet' );
		$items[ self::EP_DOCUMENTS ] = __( '📄 My Documents', 'fy-fleet' );
		$items[ self::EP_SUPPORT ]   = __( '💬 Support', 'fy-fleet' );

		return $items + $logout;
	}

	/** Shared neon styling for the portal tabs, printed once. */
	private static function styles() {
		static $done = false;
		if ( $done ) {
			return '';
		}
		$done = true;
		return '<style>
		.fy-acct{font-family:ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;color:#172033}
		.fy-acct-title{font-size:clamp(19px,2.6vw,25px);font-weight:950;letter-spacing:-.02em;margin:0 0 14px;
			background:linear-gradient(90deg,#C94386,#7C3AED,#2563EB);-webkit-background-clip:text;background-clip:text;color:transparent}
		.fy-acct-card{border:1px solid rgba(124,58,237,.16);border-radius:16px;background:linear-gradient(180deg,#fff,#fffafd);
			padding:16px 18px;margin-bottom:13px;box-shadow:0 8px 22px rgba(23,32,51,.06)}
		.fy-acct-row{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:center}
		.fy-acct-yacht{font-size:16px;font-weight:950;margin:0}
		.fy-acct-when{color:#526079;font-size:13px;font-weight:800;margin:2px 0 0}
		.fy-acct-money{display:flex;gap:14px;flex-wrap:wrap;margin-top:9px}
		.fy-acct-chip{padding:7px 12px;border-radius:11px;font-size:12px;font-weight:900}
		.fy-acct-chip.paid{background:#fff4f9;border:1.5px solid #E45C9C;color:#C94386}
		.fy-acct-chip.due{background:#F3E8FF;border:1.5px dashed rgba(124,58,237,.4);color:#5B21B6}
		.fy-acct-status{padding:4px 11px;border-radius:999px;font-size:11px;font-weight:900;text-transform:uppercase;letter-spacing:.04em}
		.fy-acct-status.s-processing{background:#eef6fc;color:#0a3d62}
		.fy-acct-status.s-completed{background:#edfaef;color:#14532d}
		.fy-acct-status.s-pending,.fy-acct-status.s-on-hold{background:#fdf6e3;color:#7a5a00}
		.fy-acct-cancel{margin-top:10px}
		.fy-acct-cancel button{background:none;border:1.5px solid #d63638;color:#d63638;border-radius:10px;
			padding:7px 13px;font-size:12px;font-weight:900;cursor:pointer}
		.fy-acct-cancel button:hover{background:#fdeced}
		.fy-acct-note{color:#526079;font-size:12px;font-weight:700;line-height:1.6}
		.fy-acct-doc{display:flex;align-items:center;gap:12px;padding:13px 15px;border:1px solid rgba(37,99,235,.16);
			border-radius:13px;background:linear-gradient(180deg,#fff,#EFF6FF);margin-bottom:9px;text-decoration:none}
		.fy-acct-doc-name{font-weight:900;color:#172033}
		.fy-acct-doc-date{margin-left:auto;color:#526079;font-size:12px;font-weight:700}
		.fy-tkt-new{border:1px solid rgba(124,58,237,.2);border-radius:16px;padding:16px;background:linear-gradient(160deg,#fff,#fff5fa);margin-bottom:18px}
		.fy-tkt-new label{display:block;font-size:11.5px;font-weight:950;text-transform:uppercase;letter-spacing:.05em;color:#5B21B6;margin:10px 0 4px}
		.fy-tkt-new input[type=text],.fy-tkt-new select,.fy-tkt-new textarea{width:100%;min-height:44px;border:1.5px solid #E6EAF3;border-radius:11px;padding:9px 12px;font:inherit}
		.fy-tkt-new textarea{min-height:90px}
		.fy-tkt-send{margin-top:12px;width:100%;min-height:52px;border:0;border-radius:13px;cursor:pointer;color:#fff;font:inherit;font-weight:950;font-size:14px;
			background:linear-gradient(105deg,#C94386,#7C3AED);box-shadow:0 8px 20px rgba(184,50,128,.28)}
		.fy-tkt-row{display:flex;gap:10px;align-items:center;padding:12px 14px;border:1px solid #E6EAF3;border-radius:12px;margin-bottom:8px;text-decoration:none;color:#172033}
		.fy-tkt-row:hover{border-color:rgba(124,58,237,.4)}
		.fy-tkt-dept{flex:none;font-size:10.5px;font-weight:900;padding:3px 9px;border-radius:999px;background:#F3E8FF;color:#5B21B6}
		.fy-tkt-subject{font-weight:900;flex:1;min-width:0}
		.fy-tkt-status{flex:none;font-size:10.5px;font-weight:900;text-transform:uppercase}
		.fy-tkt-status.st-open{color:#C94386}.fy-tkt-status.st-answered{color:#00a32a}.fy-tkt-status.st-closed{color:#787c82}
		.fy-msgf{margin:10px 0;padding:13px 15px;border-radius:13px;border:1px solid #E6EAF3;background:#fff}
		.fy-msgf.is-staff{background:linear-gradient(160deg,#fff,#FDF2F8);border-color:#F4D6E5}
		.fy-msgf-who{font-size:11.5px;font-weight:950;color:#C94386;margin-bottom:3px}
		.fy-msgf.is-staff .fy-msgf-who{color:#5B21B6}
		.fy-msgf-body{font-size:13.5px;line-height:1.6;color:#172033}
		.fy-msgf-when{font-size:10.5px;color:#787c82;margin-top:5px;font-weight:700}
		.fy-acct-card.has-thumb{display:flex;gap:16px;align-items:flex-start}
		.fy-acct-thumb{width:110px;height:110px;object-fit:cover;border-radius:12px;flex:none;border:2px solid #F4D6E5}
		.fy-acct-body{flex:1;min-width:0}
		@media(max-width:520px){.fy-acct-card.has-thumb{flex-direction:column}.fy-acct-thumb{width:100%;height:150px}}
		</style>';
	}

	/* ------------------------------------------------------------------
	 * My Charters
	 * ---------------------------------------------------------------- */

	/** Booking line items across the logged-in customer's orders. */
	private static function customer_bookings() {
		$user   = wp_get_current_user();
		$orders = wc_get_orders(
			array(
				'customer' => $user->ID ? $user->ID : $user->user_email,
				'limit'    => 50,
				'status'   => array( 'pending', 'processing', 'on-hold', 'completed' ),
			)
		);

		$bookings = array();
		foreach ( $orders as $order ) {
			foreach ( $order->get_items() as $item_id => $item ) {
				$date = $item->get_meta( '_fy_date' );
				if ( ! $date && ! $item->get_meta( '_fy_yacht_id' ) ) {
					continue;
				}
				$product    = $item->get_product();
				$bookings[] = array(
					'order'    => $order,
					'item_id'  => $item_id,
					'yacht'    => $item->get_name(),
					'yacht_id' => (int) $item->get_meta( '_fy_yacht_id' ),
					'image'    => $product && $product->get_image_id() ? wp_get_attachment_image_url( $product->get_image_id(), 'woocommerce_thumbnail' ) : '',
					'date'     => $date ? $date : __( 'Date to be scheduled', 'fy-fleet' ),
					'time'     => $item->get_meta( '_fy_time' ),
					'guests'   => $item->get_meta( '_fy_guests' ),
					'marina'   => $item->get_meta( '_fy_marina' ),
					'total'    => (float) $item->get_meta( '_fy_charter_total' ),
					'deposit'  => (float) $item->get_meta( '_fy_deposit' ),
					'balance'  => (float) $item->get_meta( '_fy_balance' ),
				);
			}
		}
		usort( $bookings, function ( $a, $b ) { return strcmp( $b['date'], $a['date'] ); } );
		return $bookings;
	}

	public static function render_charters() {
		echo self::styles(); // phpcs:ignore
		$bookings = self::customer_bookings();
		$policy   = FY_Fleet_Settings::get_cancellation_lines();
		?>
		<div class="fy-acct">
			<div class="fy-acct-row" style="margin-bottom:14px">
				<h2 class="fy-acct-title" style="margin:0">⚓ <?php esc_html_e( 'My Charters', 'fy-fleet' ); ?></h2>
				<a class="fy-sub-send" style="display:inline-block;width:auto;padding:11px 20px;text-decoration:none;text-align:center" href="<?php echo esc_url( self::region_fleet_url( get_current_user_id() ) ); ?>">🛥️ <?php esc_html_e( 'Book a Yacht', 'fy-fleet' ); ?></a>
			</div>

			<?php if ( isset( $_GET['fy_cancel_sent'] ) ) : ?>
				<div class="fy-acct-card" style="border-color:#00a32a">✅ <?php esc_html_e( 'Your cancellation request was sent. Our team will reply by email shortly.', 'fy-fleet' ); ?></div>
			<?php endif; ?>

			<?php if ( empty( $bookings ) ) : ?>
				<p><?php esc_html_e( 'No charters yet — your bookings appear here the moment your deposit is paid.', 'fy-fleet' ); ?></p>
			<?php else : ?>
				<?php foreach ( $bookings as $b ) : ?>
					<?php $status = $b['order']->get_status(); ?>
					<div class="fy-acct-card<?php echo $b['image'] ? ' has-thumb' : ''; ?>">
						<?php if ( $b['image'] ) : ?>
							<img class="fy-acct-thumb" src="<?php echo esc_url( $b['image'] ); ?>" alt="<?php echo esc_attr( $b['yacht'] ); ?>" loading="lazy">
						<?php endif; ?>
						<div class="fy-acct-body">
						<div class="fy-acct-row">
							<div>
								<p class="fy-acct-yacht"><?php echo esc_html( $b['yacht'] ); ?></p>
								<p class="fy-acct-when">📅 <?php echo esc_html( FY_Fleet_Woo::format_date( $b['date'] ) ); ?><?php echo $b['time'] ? esc_html( ' · ' . $b['time'] ) : ''; ?><?php echo $b['guests'] ? esc_html( ' · ' . $b['guests'] . ' ' . __( 'guests', 'fy-fleet' ) ) : ''; ?></p>
								<?php if ( $b['marina'] ) : ?>
									<p class="fy-acct-when">📍 <?php echo esc_html( $b['marina'] ); ?></p>
								<?php endif; ?>
							</div>
							<span class="fy-acct-status s-<?php echo esc_attr( $status ); ?>"><?php echo esc_html( wc_get_order_status_name( $status ) ); ?></span>
						</div>
						<div class="fy-acct-money">
							<span class="fy-acct-chip paid">✅ <?php printf( esc_html__( 'Deposit paid: %s', 'fy-fleet' ), wp_strip_all_tags( wc_price( $b['deposit'] ) ) ); ?></span>
							<?php if ( $b['balance'] > 0 && 'completed' !== $status ) : ?>
								<span class="fy-acct-chip due">⚓ <?php printf( esc_html__( 'Due at the dock: %s', 'fy-fleet' ), wp_strip_all_tags( wc_price( $b['balance'] ) ) ); ?></span>
							<?php endif; ?>
						</div>
						<?php $fy_date_ts = strtotime( $b['date'] ); // False for "to be scheduled" — those are always upcoming. ?>
						<?php if ( 'completed' !== $status && ( false === $fy_date_ts || $fy_date_ts >= strtotime( gmdate( 'Y-m-d' ) ) ) ) : ?>
							<form class="fy-acct-cancel" method="post" onsubmit="return confirm('<?php echo esc_js( __( 'Request cancellation of this charter? Our team will confirm by email.', 'fy-fleet' ) ); ?>');">
								<?php wp_nonce_field( 'fy_cancel_request', 'fy_cancel_nonce' ); ?>
								<input type="hidden" name="fy_cancel_order" value="<?php echo esc_attr( $b['order']->get_id() ); ?>">
								<button type="submit"><?php esc_html_e( 'Request cancellation', 'fy-fleet' ); ?></button>
							</form>
						<?php endif; ?>
						<?php self::render_review_block( $b ); ?>
						</div><!-- .fy-acct-body -->
					</div>
				<?php endforeach; ?>
			<?php endif; ?>

			<?php if ( ! empty( $policy ) ) : ?>
				<div class="fy-acct-card">
					<strong>🛡️ <?php esc_html_e( 'Cancellation policy', 'fy-fleet' ); ?></strong>
					<p class="fy-acct-note"><?php echo esc_html( implode( ' ', $policy ) ); ?></p>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Has this charter's date+time actually happened yet, in MIAMI's clock —
	 * not the server's, not the visitor's. A booking with no parseable time
	 * (older orders, or a date-only label) is treated as passed only once
	 * the whole day has elapsed, so "today, no time recorded" never counts
	 * as reviewable mid-charter.
	 */
	private static function charter_has_passed( $date, $time ) {
		if ( ! $date || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			return false; // "Date to be scheduled" — never eligible.
		}
		try {
			$tz  = new DateTimeZone( 'America/New_York' );
			$dt  = $time ? DateTime::createFromFormat( 'Y-m-d g:i A', $date . ' ' . trim( $time ), $tz ) : false;
			if ( ! $dt ) {
				$dt = new DateTime( $date . ' 23:59:59', $tz );
			}
			$now = new DateTime( 'now', $tz );
			return $dt < $now;
		} catch ( \Exception $e ) {
			return false;
		}
	}

	/** The "leave a review" prompt / form for one eligible booking row. */
	private static function render_review_block( $b ) {
		if ( ! $b['yacht_id'] || ! class_exists( 'FY_Fleet_Reviews' ) ) {
			return;
		}
		$order_id = $b['order']->get_id();
		if ( FY_Fleet_Reviews::already_reviewed( $b['yacht_id'], $order_id, $b['item_id'] ) ) {
			?>
			<p class="fy-acct-note" style="margin-top:8px">✓ <?php esc_html_e( 'You reviewed this charter — thank you!', 'fy-fleet' ); ?></p>
			<?php
			return;
		}
		if ( ! self::charter_has_passed( $b['date'], $b['time'] ) ) {
			return; // Not yet eligible — no clutter before the charter has even happened.
		}
		?>
		<form method="post" class="fy-review-form">
			<?php wp_nonce_field( 'fy_review_submit', 'fy_review_nonce' ); ?>
			<input type="hidden" name="fy_review_yacht_id" value="<?php echo esc_attr( $b['yacht_id'] ); ?>">
			<input type="hidden" name="fy_review_order_id" value="<?php echo esc_attr( $order_id ); ?>">
			<input type="hidden" name="fy_review_item_id" value="<?php echo esc_attr( $b['item_id'] ); ?>">
			<p class="fy-acct-note" style="margin:10px 0 4px;font-weight:900;color:#172033">⭐ <?php echo esc_html( sprintf( __( 'How was your charter on %s?', 'fy-fleet' ), $b['yacht'] ) ); ?></p>
			<div class="fy-star-picker">
				<?php for ( $s = 5; $s >= 1; $s-- ) : ?>
					<input type="radio" name="fy_review_rating" id="fy-star-<?php echo esc_attr( $order_id . '-' . $b['item_id'] . '-' . $s ); ?>" value="<?php echo esc_attr( $s ); ?>" <?php checked( 5, $s ); ?>>
					<label for="fy-star-<?php echo esc_attr( $order_id . '-' . $b['item_id'] . '-' . $s ); ?>" title="<?php echo esc_attr( $s ); ?>">★</label>
				<?php endfor; ?>
			</div>
			<textarea name="fy_review_text" required maxlength="1000" placeholder="<?php esc_attr_e( 'Tell other guests what stood out…', 'fy-fleet' ); ?>" style="width:100%;min-height:70px;border:1.5px solid #E6EAF3;border-radius:11px;padding:9px 12px;font:inherit;margin-top:8px"></textarea>
			<button type="submit" name="fy_review_submit" value="1" class="fy-sub-send" style="margin-top:8px"><?php esc_html_e( 'Post review', 'fy-fleet' ); ?></button>
		</form>
		<style>
		/* Classic CSS star-picker: radios in reverse DOM order + a general
		   sibling selector, so hovering star N visually fills stars 1..N
		   without any JS. */
		.fy-star-picker{display:flex;flex-direction:row-reverse;justify-content:flex-end;gap:2px;font-size:26px}
		.fy-star-picker input{position:absolute;opacity:0;width:1px;height:1px}
		.fy-star-picker label{color:#E0E4EC;cursor:pointer;transition:color .1s ease;line-height:1}
		.fy-star-picker input:checked ~ label,
		.fy-star-picker label:hover,
		.fy-star-picker label:hover ~ label{color:#F4C430}
		.fy-star-picker input:focus-visible + label{outline:2px solid #7C3AED;outline-offset:2px;border-radius:4px}
		@media(prefers-reduced-motion:reduce){.fy-star-picker label{transition:none}}
		</style>
		<?php
	}

	public static function handle_review_submit() {
		if ( empty( $_POST['fy_review_submit'] ) || ! is_user_logged_in() ) {
			return;
		}
		if ( ! isset( $_POST['fy_review_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fy_review_nonce'] ) ), 'fy_review_submit' ) ) {
			return;
		}
		$yacht_id = isset( $_POST['fy_review_yacht_id'] ) ? absint( $_POST['fy_review_yacht_id'] ) : 0;
		$order_id = isset( $_POST['fy_review_order_id'] ) ? absint( $_POST['fy_review_order_id'] ) : 0;
		$item_id  = isset( $_POST['fy_review_item_id'] ) ? absint( $_POST['fy_review_item_id'] ) : 0;
		$rating   = isset( $_POST['fy_review_rating'] ) ? absint( $_POST['fy_review_rating'] ) : 5;
		$text     = isset( $_POST['fy_review_text'] ) ? sanitize_textarea_field( wp_unslash( $_POST['fy_review_text'] ) ) : '';

		if ( ! $yacht_id || ! $order_id || '' === trim( $text ) || ! class_exists( 'FY_Fleet_Reviews' ) ) {
			wp_safe_redirect( wc_get_account_endpoint_url( self::EP_CHARTERS ) );
			exit;
		}

		// Re-derive eligibility server-side rather than trusting the hidden
		// fields alone — the booking must genuinely belong to this user
		// (found in THEIR OWN customer_bookings(), which is already scoped
		// to their orders) and its charter date must have passed.
		$owns_it = false;
		foreach ( self::customer_bookings() as $b ) {
			if ( (int) $b['yacht_id'] === $yacht_id && (int) $b['order']->get_id() === $order_id && (int) $b['item_id'] === $item_id ) {
				$owns_it = self::charter_has_passed( $b['date'], $b['time'] );
				break;
			}
		}

		if ( $owns_it ) {
			FY_Fleet_Reviews::submit_customer_review( $yacht_id, get_current_user_id(), $order_id, $item_id, $rating, $text );
		}

		wp_safe_redirect( wc_get_account_endpoint_url( self::EP_CHARTERS ) );
		exit;
	}

	public static function handle_cancel_request() {
		if ( ! is_user_logged_in() || empty( $_POST['fy_cancel_order'] ) ) {
			return;
		}
		if ( ! isset( $_POST['fy_cancel_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fy_cancel_nonce'] ) ), 'fy_cancel_request' ) ) {
			return;
		}

		$order_id = intval( $_POST['fy_cancel_order'] );
		$order    = wc_get_order( $order_id );
		$user     = wp_get_current_user();

		// The order must belong to this customer.
		if ( ! $order || ( (int) $order->get_customer_id() !== (int) $user->ID && strtolower( $order->get_billing_email() ) !== strtolower( $user->user_email ) ) ) {
			return;
		}

		$ticket_id = FY_Fleet_Tickets::create(
			array(
				'subject'    => sprintf( __( 'Cancellation request — order #%s', 'fy-fleet' ), $order->get_order_number() ),
				'message'    => sprintf( __( 'The customer requested cancellation of order #%s from their account. Policy: refunds exclude crew and processing fees; within 24 hours of departure, non-refundable.', 'fy-fleet' ), $order->get_order_number() ),
				'department' => 'cancellations',
				'user_id'    => $user->ID,
				'name'       => $user->display_name,
				'email'      => $user->user_email,
				'order_id'   => $order_id,
			)
		);

		if ( ! is_wp_error( $ticket_id ) ) {
			$order->add_order_note( __( '⚠️ Customer requested cancellation from their account portal.', 'fy-fleet' ) );
		}

		wp_safe_redirect( add_query_arg( 'fy_cancel_sent', '1', wc_get_account_endpoint_url( self::EP_CHARTERS ) ) );
		exit;
	}

	/* ------------------------------------------------------------------
	 * My Yacht Bookings (owner-facing — separate from My Charters above)
	 * ---------------------------------------------------------------- */

	public static function render_yacht_bookings() {
		echo self::styles(); // phpcs:ignore
		$user_id = get_current_user_id();
		$yachts  = self::owned_yacht_ids( $user_id );
		?>
		<div class="fy-acct fy-owner-bookings">
			<h2 class="fy-acct-title">🛥️ <?php esc_html_e( 'My Yacht Bookings', 'fy-fleet' ); ?></h2>

			<?php if ( empty( $yachts ) ) : ?>
				<p><?php esc_html_e( 'No live listings yet — once a yacht you submitted is approved, its bookings will appear here.', 'fy-fleet' ); ?></p>
				<a class="button" href="<?php echo esc_url( wc_get_account_endpoint_url( FY_Fleet_Submissions::EP ) ); ?>"><?php esc_html_e( '🛥️ List Your Yacht', 'fy-fleet' ); ?></a>
				<?php return; ?>
			<?php endif; ?>

			<?php
			$bookings = class_exists( 'FY_Fleet_Bookings_Admin' ) ? FY_Fleet_Bookings_Admin::get_bookings( '', '', $yachts ) : array();

			// Grouped by yacht so an owner with several listings can scan
			// visually instead of reading one long flat list — each section
			// headed by the yacht's own card photo, same thumb pattern
			// "My Charters" already uses.
			$by_yacht = array();
			foreach ( $bookings as $b ) {
				$by_yacht[ $b['yacht_id'] ][] = $b;
			}

			foreach ( $yachts as $yacht_id ) :
				$title = get_the_title( $yacht_id );
				$thumb = get_the_post_thumbnail_url( $yacht_id, 'woocommerce_thumbnail' );
				$rows  = isset( $by_yacht[ $yacht_id ] ) ? $by_yacht[ $yacht_id ] : array();
				?>
				<div class="fy-acct-card<?php echo $thumb ? ' has-thumb' : ''; ?>" style="align-items:flex-start">
					<?php if ( $thumb ) : ?>
						<img class="fy-acct-thumb" src="<?php echo esc_url( $thumb ); ?>" alt="<?php echo esc_attr( $title ); ?>" loading="lazy">
					<?php endif; ?>
					<div class="fy-acct-body" style="width:100%">
						<p class="fy-acct-yacht" style="margin-bottom:10px"><?php echo esc_html( $title ); ?></p>

						<?php if ( empty( $rows ) ) : ?>
							<p class="fy-acct-note"><?php esc_html_e( 'Bookings appear here once a guest books this yacht.', 'fy-fleet' ); ?></p>
						<?php else : ?>
							<?php foreach ( $rows as $b ) : ?>
								<div class="fy-acct-row" style="border-bottom:1px dashed #E6EAF3;padding-bottom:9px;margin-bottom:9px">
									<div>
										<p class="fy-acct-when">📅 <?php echo esc_html( FY_Fleet_Woo::format_date( $b['date'] ) ); ?><?php echo $b['time'] ? esc_html( ' · ' . $b['time'] ) : ''; ?><?php echo $b['guests'] ? esc_html( ' · ' . $b['guests'] . ' ' . __( 'guests', 'fy-fleet' ) ) : ''; ?></p>
										<?php if ( $b['marina'] ) : ?>
											<p class="fy-acct-when">📍 <?php echo esc_html( $b['marina'] ); ?></p>
										<?php endif; ?>
									</div>
									<span class="fy-acct-status s-<?php echo esc_attr( $b['status'] ); ?>"><?php echo esc_html( wc_get_order_status_name( $b['status'] ) ); ?></span>
								</div>
								<div class="fy-acct-money">
									<span class="fy-acct-chip paid">✅ <?php printf( esc_html__( 'Deposit paid: %s', 'fy-fleet' ), wp_strip_all_tags( wc_price( $b['deposit'] ) ) ); ?></span>
									<?php if ( $b['balance'] > 0 && 'completed' !== $b['status'] ) : ?>
										<span class="fy-acct-chip due">⚓ <?php printf( esc_html__( 'Due at the dock: %s', 'fy-fleet' ), wp_strip_all_tags( wc_price( $b['balance'] ) ) ); ?></span>
									<?php endif; ?>
								</div>
							<?php endforeach; ?>
						<?php endif; ?>

						<?php self::render_blocked_dates( $yacht_id ); ?>
					</div>
				</div>
			<?php endforeach; ?>

			<div class="fy-acct-card">
				<p class="fy-acct-note">🔒 <?php esc_html_e( 'For your guests\' privacy, names and contact details are not shown here — Feeling Yachty handles all guest communication directly. Questions about a booking? Reach us through Support.', 'fy-fleet' ); ?></p>
			</div>
		</div>
		<?php
	}

	/**
	 * Owner self-service availability — add/remove blocked dates on their
	 * OWN yacht, writing to the exact same _fy_blackout_dates meta staff
	 * already set in wp-admin (class-fy-metaboxes.php's Booking Options
	 * box) and FY_Fleet_Pricing::quote() already enforces at checkout — no
	 * new blocking mechanism, just a fast front-end way to use the one
	 * that's already there.
	 */
	private static function render_blocked_dates( $yacht_id ) {
		$dates = self::blocked_dates( $yacht_id );
		?>
		<div class="fy-blocked-dates">
			<strong style="font-size:12.5px;color:#5B21B6;text-transform:uppercase;letter-spacing:.05em">🚫 <?php esc_html_e( 'Blocked dates', 'fy-fleet' ); ?></strong>
			<p class="fy-acct-note" style="margin:4px 0 8px"><?php esc_html_e( 'Days you add here can\'t be booked online — use it for maintenance, personal use, or anything already arranged off-platform.', 'fy-fleet' ); ?></p>

			<?php if ( $dates ) : ?>
				<div class="fy-blocked-date-chips">
					<?php foreach ( $dates as $d ) : ?>
						<form method="post" class="fy-blocked-date-chip">
							<?php wp_nonce_field( 'fy_block_date_' . $yacht_id, 'fy_block_date_nonce' ); ?>
							<input type="hidden" name="fy_unblock_yacht_id" value="<?php echo esc_attr( $yacht_id ); ?>">
							<input type="hidden" name="fy_unblock_date" value="<?php echo esc_attr( $d ); ?>">
							<span><?php echo esc_html( FY_Fleet_Woo::format_date( $d ) ); ?></span>
							<button type="submit" name="fy_unblock_date_submit" value="1" aria-label="<?php echo esc_attr( sprintf( __( 'Unblock %s', 'fy-fleet' ), $d ) ); ?>">&times;</button>
						</form>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<form method="post" class="fy-block-date-form">
				<?php wp_nonce_field( 'fy_block_date_' . $yacht_id, 'fy_block_date_nonce' ); ?>
				<input type="hidden" name="fy_block_yacht_id" value="<?php echo esc_attr( $yacht_id ); ?>">
				<input type="date" name="fy_block_date" min="<?php echo esc_attr( gmdate( 'Y-m-d' ) ); ?>" required>
				<button type="submit" name="fy_block_date_submit" value="1" class="button"><?php esc_html_e( '+ Block this date', 'fy-fleet' ); ?></button>
			</form>
		</div>
		<style>
		.fy-blocked-dates{margin-top:14px;padding-top:12px;border-top:1px solid #F4D6E5}
		.fy-blocked-date-chips{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px}
		.fy-blocked-date-chip{display:inline-flex;margin:0}
		.fy-blocked-date-chip span{
			display:inline-flex;align-items:center;gap:6px;padding:6px 6px 6px 12px;border-radius:999px;
			background:#FFF1F7;color:#9D2463;font-size:12.5px;font-weight:800;
		}
		.fy-blocked-date-chip button{
			display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;margin-left:6px;
			border:0;border-radius:50%;background:rgba(157,36,99,.15);color:#9D2463;font-size:13px;cursor:pointer;line-height:1;
		}
		.fy-blocked-date-chip button:hover{background:#9D2463;color:#fff}
		.fy-block-date-form{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
		.fy-block-date-form input[type=date]{min-height:38px;border:1.5px solid #E6EAF3;border-radius:9px;padding:6px 10px;font:inherit}
		</style>
		<?php
	}

	/** @return string[] Y-m-d dates, from the same field FY_Fleet_Pricing::quote() reads. */
	public static function blocked_dates( $yacht_id ) {
		$raw = (string) get_post_meta( $yacht_id, '_fy_blackout_dates', true );
		$out = array();
		foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
			$line = trim( $line );
			if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $line ) ) {
				$out[] = $line;
			}
		}
		sort( $out );
		return array_values( array_unique( $out ) );
	}

	/** Both add and remove go through this — same ownership check, same storage format. */
	private static function save_blocked_dates( $yacht_id, array $dates ) {
		update_post_meta( $yacht_id, '_fy_blackout_dates', implode( "\n", array_unique( $dates ) ) );
		if ( class_exists( 'FY_Fleet_Render' ) ) {
			FY_Fleet_Render::flush_cache(); // Blackout dates don't change card display, but the yacht post was touched.
		}
	}

	/** Only the yacht's own owner may touch its blocked dates — checked on every add/remove, not just rendering. */
	private static function user_owns_yacht( $user_id, $yacht_id ) {
		return $yacht_id && FY_Fleet_CPT::POST_TYPE === get_post_type( $yacht_id ) && (int) get_post( $yacht_id )->post_author === (int) $user_id;
	}

	public static function handle_block_date() {
		if ( empty( $_POST['fy_block_date_submit'] ) || ! is_user_logged_in() ) {
			return;
		}
		$yacht_id = isset( $_POST['fy_block_yacht_id'] ) ? absint( $_POST['fy_block_yacht_id'] ) : 0;
		if ( ! isset( $_POST['fy_block_date_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fy_block_date_nonce'] ) ), 'fy_block_date_' . $yacht_id ) ) {
			return;
		}
		if ( ! self::user_owns_yacht( get_current_user_id(), $yacht_id ) ) {
			return;
		}
		$date = isset( $_POST['fy_block_date'] ) ? sanitize_text_field( wp_unslash( $_POST['fy_block_date'] ) ) : '';
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			$dates   = self::blocked_dates( $yacht_id );
			$dates[] = $date;
			self::save_blocked_dates( $yacht_id, $dates );
		}
		wp_safe_redirect( wc_get_account_endpoint_url( self::EP_YACHT_BOOKINGS ) );
		exit;
	}

	public static function handle_unblock_date() {
		if ( empty( $_POST['fy_unblock_date_submit'] ) || ! is_user_logged_in() ) {
			return;
		}
		$yacht_id = isset( $_POST['fy_unblock_yacht_id'] ) ? absint( $_POST['fy_unblock_yacht_id'] ) : 0;
		if ( ! isset( $_POST['fy_block_date_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fy_block_date_nonce'] ) ), 'fy_block_date_' . $yacht_id ) ) {
			return;
		}
		if ( ! self::user_owns_yacht( get_current_user_id(), $yacht_id ) ) {
			return;
		}
		$date  = isset( $_POST['fy_unblock_date'] ) ? sanitize_text_field( wp_unslash( $_POST['fy_unblock_date'] ) ) : '';
		$dates = array_diff( self::blocked_dates( $yacht_id ), array( $date ) );
		self::save_blocked_dates( $yacht_id, $dates );
		wp_safe_redirect( wc_get_account_endpoint_url( self::EP_YACHT_BOOKINGS ) );
		exit;
	}

	/* ------------------------------------------------------------------
	 * My Profile — photo, display name, claim a booking
	 * ---------------------------------------------------------------- */

	/** Attachment ID of the uploaded photo, or 0. */
	public static function avatar_id( $user_id ) {
		return (int) get_user_meta( $user_id, '_fy_avatar_id', true );
	}

	/**
	 * Serves the uploaded photo in place of Gravatar wherever get_avatar()/
	 * get_avatar_url() is called for this user — including inside
	 * FY_Fleet_Reviews::render(), with no changes needed there.
	 */
	public static function filter_avatar( $args, $id_or_email ) {
		$user = false;
		if ( is_numeric( $id_or_email ) ) {
			$user = get_user_by( 'id', (int) $id_or_email );
		} elseif ( $id_or_email instanceof WP_User ) {
			$user = $id_or_email;
		} elseif ( $id_or_email instanceof WP_Comment ) {
			$user = $id_or_email->user_id ? get_user_by( 'id', $id_or_email->user_id ) : false;
		} elseif ( is_string( $id_or_email ) ) {
			$user = get_user_by( 'email', $id_or_email );
		}
		if ( ! $user ) {
			return $args;
		}
		$attach_id = self::avatar_id( $user->ID );
		if ( ! $attach_id ) {
			return $args;
		}
		$size = isset( $args['size'] ) ? (int) $args['size'] : 96;
		$src  = wp_get_attachment_image_src( $attach_id, array( $size, $size ) );
		if ( ! $src ) {
			return $args;
		}
		$args['url']         = $src[0];
		$args['found_avatar'] = true;
		return $args;
	}

	public static function render_profile() {
		echo self::styles(); // phpcs:ignore
		$user      = wp_get_current_user();
		$attach_id = self::avatar_id( $user->ID );
		$avatar    = $attach_id ? wp_get_attachment_image_url( $attach_id, array( 140, 140 ) ) : get_avatar_url( $user->ID, array( 'size' => 140 ) );
		?>
		<div class="fy-acct fy-profile">
			<h2 class="fy-acct-title">👤 <?php esc_html_e( 'My Profile', 'fy-fleet' ); ?></h2>

			<?php if ( isset( $_GET['fy_profile_saved'] ) ) : ?>
				<div class="fy-acct-card" style="border-color:#00a32a">✅ <?php esc_html_e( 'Profile updated.', 'fy-fleet' ); ?></div>
			<?php endif; ?>

			<div class="fy-acct-card">
				<strong><?php esc_html_e( 'Photo & display name', 'fy-fleet' ); ?></strong>
				<p class="fy-acct-note"><?php esc_html_e( 'Your display name is what shows on any reviews you leave.', 'fy-fleet' ); ?></p>
				<form method="post" enctype="multipart/form-data" style="margin-top:10px">
					<?php wp_nonce_field( 'fy_profile_save', 'fy_profile_nonce' ); ?>
					<div class="fy-profile-photo-row">
						<label class="fy-profile-avatar-wrap" for="fy_profile_photo">
							<img id="fy-profile-avatar-preview" class="fy-profile-avatar" src="<?php echo esc_url( $avatar ); ?>" alt="<?php esc_attr_e( 'Your photo', 'fy-fleet' ); ?>">
							<span class="fy-profile-avatar-hint"><?php esc_html_e( 'Change photo', 'fy-fleet' ); ?></span>
						</label>
						<div style="flex:1;min-width:180px">
							<input type="file" id="fy_profile_photo" name="fy_profile_photo" accept="image/jpeg,image/png,image/webp" style="display:none">
							<label for="fy_profile_display_name" style="display:block;font-size:11.5px;font-weight:950;text-transform:uppercase;letter-spacing:.05em;color:#5B21B6;margin-bottom:4px"><?php esc_html_e( 'Display name', 'fy-fleet' ); ?></label>
							<input type="text" id="fy_profile_display_name" name="fy_profile_display_name" value="<?php echo esc_attr( $user->display_name ); ?>" maxlength="60" style="width:100%;min-height:44px;border:1.5px solid #E6EAF3;border-radius:11px;padding:9px 12px;font:inherit">
						</div>
					</div>
					<button type="submit" name="fy_profile_save" value="1" class="fy-sub-send" style="margin-top:14px"><?php esc_html_e( 'Save profile', 'fy-fleet' ); ?></button>
				</form>
			</div>

			<div class="fy-acct-card">
				<strong>🔗 <?php esc_html_e( 'Claim a past booking', 'fy-fleet' ); ?></strong>
				<p class="fy-acct-note"><?php esc_html_e( 'Booked before creating an account? Enter the order number and the email used at checkout to link it here — it\'ll then appear under My Charters.', 'fy-fleet' ); ?></p>
				<?php if ( isset( $_GET['fy_claim'] ) ) : ?>
					<?php
					$claim_msgs = array(
						'ok'          => array( true, __( '✅ Order claimed! It now appears under My Charters.', 'fy-fleet' ) ),
						'notfound'    => array( false, __( 'No order found with that number and email — double-check both and try again.', 'fy-fleet' ) ),
						'taken'       => array( false, __( 'That order is already linked to a different account.', 'fy-fleet' ) ),
					);
					$key = sanitize_key( wp_unslash( $_GET['fy_claim'] ) );
					if ( isset( $claim_msgs[ $key ] ) ) :
						list( $ok, $msg ) = $claim_msgs[ $key ];
						?>
						<div class="fy-acct-card" style="border-color:<?php echo $ok ? '#00a32a' : '#d63638'; ?>;margin-top:10px"><?php echo $ok ? '✅ ' : '⚠️ '; ?><?php echo esc_html( $msg ); ?></div>
					<?php endif; ?>
				<?php endif; ?>
				<form method="post" style="margin-top:10px">
					<?php wp_nonce_field( 'fy_claim_order', 'fy_claim_nonce' ); ?>
					<div class="fy-sub-grid" style="grid-template-columns:1fr 1fr">
						<div>
							<label for="fy_claim_order_id" style="display:block;font-size:11.5px;font-weight:950;text-transform:uppercase;letter-spacing:.05em;color:#5B21B6;margin-bottom:4px"><?php esc_html_e( 'Order number', 'fy-fleet' ); ?></label>
							<input type="text" id="fy_claim_order_id" name="fy_claim_order_id" required style="width:100%;min-height:44px;border:1.5px solid #E6EAF3;border-radius:11px;padding:9px 12px;font:inherit">
						</div>
						<div>
							<label for="fy_claim_email" style="display:block;font-size:11.5px;font-weight:950;text-transform:uppercase;letter-spacing:.05em;color:#5B21B6;margin-bottom:4px"><?php esc_html_e( 'Billing email used', 'fy-fleet' ); ?></label>
							<input type="email" id="fy_claim_email" name="fy_claim_email" required style="width:100%;min-height:44px;border:1.5px solid #E6EAF3;border-radius:11px;padding:9px 12px;font:inherit">
						</div>
					</div>
					<button type="submit" name="fy_claim_order" value="1" class="fy-sub-send" style="margin-top:14px"><?php esc_html_e( 'Claim this booking', 'fy-fleet' ); ?></button>
				</form>
			</div>
		</div>
		<style>
		.fy-profile-photo-row{display:flex;gap:16px;align-items:center;flex-wrap:wrap}
		.fy-profile-avatar-wrap{position:relative;display:block;width:88px;height:88px;border-radius:50%;cursor:pointer;flex:none}
		.fy-profile-avatar{width:88px;height:88px;border-radius:50%;object-fit:cover;border:3px solid #F4D6E5;display:block;transition:filter .18s ease}
		.fy-profile-avatar-hint{
			position:absolute;inset:0;border-radius:50%;display:flex;align-items:center;justify-content:center;text-align:center;
			background:rgba(23,32,51,.55);color:#fff;font-size:11px;font-weight:900;opacity:0;transition:opacity .18s ease;padding:6px;
		}
		.fy-profile-avatar-wrap:hover .fy-profile-avatar-hint,
		.fy-profile-avatar-wrap:focus-within .fy-profile-avatar-hint{opacity:1}
		.fy-profile-avatar-wrap:hover .fy-profile-avatar{filter:brightness(.85)}
		@media(prefers-reduced-motion:reduce){.fy-profile-avatar,.fy-profile-avatar-hint{transition:none}}
		</style>
		<script>
		(function(){
			var input = document.getElementById('fy_profile_photo');
			var preview = document.getElementById('fy-profile-avatar-preview');
			if(!input||!preview) return;
			input.addEventListener('change', function(){
				if(!input.files||!input.files[0]) return;
				// Instant local preview — no "did that work?" wait for the
				// upload to round-trip before seeing the new photo.
				preview.src = URL.createObjectURL(input.files[0]);
			});
		})();
		</script>
		<?php
	}

	public static function handle_profile_save() {
		if ( empty( $_POST['fy_profile_save'] ) || ! is_user_logged_in() ) {
			return;
		}
		if ( ! isset( $_POST['fy_profile_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fy_profile_nonce'] ) ), 'fy_profile_save' ) ) {
			return;
		}
		$user_id = get_current_user_id();

		$name = isset( $_POST['fy_profile_display_name'] ) ? sanitize_text_field( wp_unslash( $_POST['fy_profile_display_name'] ) ) : '';
		if ( '' !== $name ) {
			wp_update_user( array( 'ID' => $user_id, 'display_name' => $name ) );
		}

		if ( ! empty( $_FILES['fy_profile_photo']['name'] ) && UPLOAD_ERR_OK === $_FILES['fy_profile_photo']['error'] ) {
			require_once ABSPATH . 'wp-admin/includes/image.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';
			$attach_id = media_handle_upload( 'fy_profile_photo', 0 );
			if ( ! is_wp_error( $attach_id ) ) {
				update_user_meta( $user_id, '_fy_avatar_id', $attach_id );
			}
		}

		wp_safe_redirect( add_query_arg( 'fy_profile_saved', '1', wc_get_account_endpoint_url( self::EP_PROFILE ) ) );
		exit;
	}

	public static function handle_claim_order() {
		if ( empty( $_POST['fy_claim_order'] ) || ! is_user_logged_in() ) {
			return;
		}
		if ( ! isset( $_POST['fy_claim_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fy_claim_nonce'] ) ), 'fy_claim_order' ) ) {
			return;
		}

		$order_ref = isset( $_POST['fy_claim_order_id'] ) ? sanitize_text_field( wp_unslash( $_POST['fy_claim_order_id'] ) ) : '';
		$email     = isset( $_POST['fy_claim_email'] ) ? sanitize_email( wp_unslash( $_POST['fy_claim_email'] ) ) : '';
		// Accept either the raw ID or a copy-pasted "#1234".
		$order_id = absint( ltrim( $order_ref, '#' ) );
		$order    = $order_id ? wc_get_order( $order_id ) : false;

		$result = 'notfound';
		if ( $order && strtolower( $order->get_billing_email() ) === strtolower( $email ) ) {
			$existing_owner = (int) $order->get_customer_id();
			if ( 0 === $existing_owner ) {
				$order->set_customer_id( get_current_user_id() );
				$order->save();
				$result = 'ok';
				if ( class_exists( 'FY_Fleet_Log' ) ) {
					FY_Fleet_Log::add( 'order.claimed', sprintf( 'Order #%s claimed by %s', $order->get_order_number(), wp_get_current_user()->user_email ), array( 'order' => $order_id ) );
				}
			} elseif ( $existing_owner === get_current_user_id() ) {
				$result = 'ok'; // already theirs — not an error from their point of view.
			} else {
				$result = 'taken';
			}
		}

		wp_safe_redirect( add_query_arg( 'fy_claim', $result, wc_get_account_endpoint_url( self::EP_PROFILE ) ) );
		exit;
	}

	/* ------------------------------------------------------------------
	 * My Documents
	 * ---------------------------------------------------------------- */

	public static function get_documents( $user_id ) {
		$docs = get_user_meta( $user_id, '_fy_documents', true );
		return is_array( $docs ) ? $docs : array();
	}

	public static function render_documents() {
		echo self::styles(); // phpcs:ignore
		$docs = self::get_documents( get_current_user_id() );
		?>
		<div class="fy-acct">
			<h2 class="fy-acct-title">📄 <?php esc_html_e( 'My Documents', 'fy-fleet' ); ?></h2>
			<?php if ( empty( $docs ) ) : ?>
				<p><?php esc_html_e( 'No documents yet. Your signed charter forms appear here once our team uploads them.', 'fy-fleet' ); ?></p>
			<?php else : ?>
				<?php foreach ( $docs as $doc ) : ?>
					<a class="fy-acct-doc" href="<?php echo esc_url( $doc['url'] ); ?>" target="_blank" rel="noopener">
						<span>📎</span>
						<span class="fy-acct-doc-name"><?php echo esc_html( $doc['title'] ); ?></span>
						<span class="fy-acct-doc-date"><?php echo esc_html( $doc['date'] ); ?></span>
					</a>
				<?php endforeach; ?>
			<?php endif; ?>
			<p class="fy-acct-note"><?php esc_html_e( 'These are your signed charter documents (bareboat verification, agreements). Contact us via Support if anything is missing.', 'fy-fleet' ); ?></p>
		</div>
		<?php
	}

	public static function profile_documents( $user ) {
		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			return;
		}
		$docs = self::get_documents( $user->ID );
		wp_nonce_field( 'fy_user_docs', 'fy_user_docs_nonce' );
		?>
		<h2>⚓ <?php esc_html_e( 'Feeling Yachty — Customer Documents', 'fy-fleet' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Shown to this customer under My Account → My Documents. Paste the file URL (upload the PDF to the Media Library first, or link the GHL document).', 'fy-fleet' ); ?></p>
		<table class="form-table" id="fy-doc-rows">
			<?php
			$rows = array_merge( $docs, array( array( 'title' => '', 'url' => '', 'date' => '' ) ) ); // one blank row to add.
			foreach ( $rows as $i => $doc ) :
				?>
				<tr>
					<td><input type="text" name="fy_docs[<?php echo esc_attr( $i ); ?>][title]" value="<?php echo esc_attr( $doc['title'] ); ?>" placeholder="<?php esc_attr_e( 'e.g. Signed Bareboat Form', 'fy-fleet' ); ?>" class="regular-text"></td>
					<td><input type="url" name="fy_docs[<?php echo esc_attr( $i ); ?>][url]" value="<?php echo esc_attr( $doc['url'] ); ?>" placeholder="https://…/signed-form.pdf" class="regular-text" style="width:340px"></td>
					<td><input type="date" name="fy_docs[<?php echo esc_attr( $i ); ?>][date]" value="<?php echo esc_attr( $doc['date'] ); ?>"></td>
				</tr>
			<?php endforeach; ?>
		</table>
		<p class="description"><?php esc_html_e( 'Clear a row\'s title to remove it. Save the profile to apply (a fresh blank row appears each save).', 'fy-fleet' ); ?></p>
		<?php
	}

	public static function save_profile_documents( $user_id ) {
		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			return;
		}
		if ( ! isset( $_POST['fy_user_docs_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fy_user_docs_nonce'] ) ), 'fy_user_docs' ) ) {
			return;
		}
		$docs = array();
		if ( isset( $_POST['fy_docs'] ) && is_array( $_POST['fy_docs'] ) ) {
			foreach ( wp_unslash( $_POST['fy_docs'] ) as $doc ) {
				$title = isset( $doc['title'] ) ? sanitize_text_field( $doc['title'] ) : '';
				$url   = isset( $doc['url'] ) ? esc_url_raw( $doc['url'] ) : '';
				if ( '' === $title || '' === $url ) {
					continue;
				}
				$date   = isset( $doc['date'] ) ? sanitize_text_field( $doc['date'] ) : '';
				$docs[] = array(
					'title' => $title,
					'url'   => $url,
					'date'  => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ? $date : gmdate( 'Y-m-d' ),
				);
			}
		}
		update_user_meta( $user_id, '_fy_documents', $docs );
	}

	/* ------------------------------------------------------------------
	 * Support tab (front end of the ticket system)
	 * ---------------------------------------------------------------- */

	public static function render_support() {
		echo self::styles(); // phpcs:ignore
		$user      = wp_get_current_user();
		$ticket_id = isset( $_GET['ticket'] ) ? intval( $_GET['ticket'] ) : 0;

		echo '<div class="fy-acct">';
		echo '<h2 class="fy-acct-title">💬 ' . esc_html__( 'Support', 'fy-fleet' ) . '</h2>';

		if ( $ticket_id && FY_Fleet_Tickets::user_can_view( $ticket_id, $user ) ) {
			self::render_thread( $ticket_id );
		} else {
			self::render_ticket_home( $user );
		}
		echo '</div>';
	}

	private static function render_ticket_home( $user ) {
		?>
		<div class="fy-tkt-new">
			<strong><?php esc_html_e( 'Send us a message', 'fy-fleet' ); ?></strong>
			<form method="post">
				<?php wp_nonce_field( 'fy_ticket_new', 'fy_ticket_nonce' ); ?>
				<input type="hidden" name="fy_ticket_action" value="new">
				<label><?php esc_html_e( 'Department', 'fy-fleet' ); ?></label>
				<select name="fy_department">
					<?php foreach ( FY_Fleet_Tickets::departments() as $key => $label ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
				<label><?php esc_html_e( 'Subject', 'fy-fleet' ); ?></label>
				<input type="text" name="fy_subject" required>
				<label><?php esc_html_e( 'Message', 'fy-fleet' ); ?></label>
				<textarea name="fy_message" required></textarea>
				<button class="fy-tkt-send" type="submit">📨 <?php esc_html_e( 'Send Message', 'fy-fleet' ); ?></button>
			</form>
		</div>

		<?php
		$tickets = FY_Fleet_Tickets::for_user( $user );
		if ( $tickets ) {
			echo '<strong>' . esc_html__( 'Your conversations', 'fy-fleet' ) . '</strong>';
			foreach ( $tickets as $ticket ) {
				$status = get_post_meta( $ticket->ID, '_fy_status', true );
				$dept   = get_post_meta( $ticket->ID, '_fy_department', true );
				$depts  = FY_Fleet_Tickets::departments();
				printf(
					'<a class="fy-tkt-row" href="%s"><span class="fy-tkt-dept">%s</span><span class="fy-tkt-subject">%s</span><span class="fy-tkt-status st-%s">%s</span></a>',
					esc_url( add_query_arg( 'ticket', $ticket->ID, wc_get_account_endpoint_url( self::EP_SUPPORT ) ) ),
					esc_html( isset( $depts[ $dept ] ) ? $depts[ $dept ] : $dept ),
					esc_html( $ticket->post_title ),
					esc_attr( $status ),
					esc_html( isset( FY_Fleet_Tickets::statuses()[ $status ] ) ? FY_Fleet_Tickets::statuses()[ $status ] : $status )
				);
			}
		}
	}

	private static function render_thread( $ticket_id ) {
		echo '<p><a href="' . esc_url( wc_get_account_endpoint_url( self::EP_SUPPORT ) ) . '">&larr; ' . esc_html__( 'All conversations', 'fy-fleet' ) . '</a></p>';
		echo '<strong>' . esc_html( get_the_title( $ticket_id ) ) . '</strong>';

		foreach ( FY_Fleet_Tickets::get_replies( $ticket_id ) as $reply ) {
			$is_staff = '1' === get_comment_meta( $reply->comment_ID, '_fy_is_staff', true );
			printf(
				'<div class="fy-msgf %s"><div class="fy-msgf-who">%s</div><div class="fy-msgf-body">%s</div><div class="fy-msgf-when">%s</div></div>',
				$is_staff ? 'is-staff' : '',
				esc_html( $is_staff ? __( '⚓ Feeling Yachty Team', 'fy-fleet' ) : __( 'You', 'fy-fleet' ) ),
				wp_kses_post( wpautop( $reply->comment_content ) ),
				esc_html( mysql2date( 'M j, Y g:i a', $reply->comment_date ) )
			);
		}

		$status = get_post_meta( $ticket_id, '_fy_status', true );
		if ( 'closed' !== $status ) :
			?>
			<form method="post" style="margin-top:12px">
				<?php wp_nonce_field( 'fy_ticket_reply', 'fy_ticket_nonce' ); ?>
				<input type="hidden" name="fy_ticket_action" value="reply">
				<input type="hidden" name="fy_ticket_id" value="<?php echo esc_attr( $ticket_id ); ?>">
				<div class="fy-tkt-new" style="margin:0">
					<textarea name="fy_message" required placeholder="<?php esc_attr_e( 'Write a reply…', 'fy-fleet' ); ?>"></textarea>
					<button class="fy-tkt-send" type="submit"><?php esc_html_e( 'Reply', 'fy-fleet' ); ?></button>
				</div>
			</form>
			<?php
		else :
			echo '<p class="fy-acct-note">' . esc_html__( 'This conversation is closed — start a new one any time.', 'fy-fleet' ) . '</p>';
		endif;
	}
}
