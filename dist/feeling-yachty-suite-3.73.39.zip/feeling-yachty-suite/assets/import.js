/**
 * Fleet Spreadsheet Import — runs the import in small batches via AJAX
 * instead of one giant page submit, so large fleets (many rows, many
 * photos) never hit a server timeout. Progressive enhancement: if this
 * script fails to load, both forms still work as plain full-page POSTs
 * (see FY_Fleet_Import::handle_import() / handle_bundled_import()) — just
 * without batching, so very large imports may still time out that way.
 */
( function ( $ ) {
	'use strict';

	if ( typeof fyImport === 'undefined' ) {
		return;
	}

	function progressBox( $form ) {
		var $box = $form.next( '.fy-import-progress' );
		if ( ! $box.length ) {
			$box = $( '<div class="fy-import-progress" style="margin-top:14px;max-width:820px"></div>' );
			$form.after( $box );
		}
		return $box;
	}

	function renderProgress( $box, processed, total, created, updated, skipped, imgOffset ) {
		var pct = total > 0 ? Math.round( ( processed / total ) * 100 ) : 0;
		var photoNote = imgOffset
			? ' <span style="color:#5B21B6">(downloading photo ' + imgOffset + ' of this yacht…)</span>'
			: '';
		$box.html(
			'<div style="background:#fff;border:1px solid #E6EAF3;border-radius:10px;padding:14px 18px">' +
				'<div style="height:10px;border-radius:6px;background:#F0ECF9;overflow:hidden;margin-bottom:10px">' +
					'<div style="height:100%;width:' + pct + '%;background:linear-gradient(90deg,#E45C9C,#7C3AED);transition:width .2s"></div>' +
				'</div>' +
				'<p style="margin:0"><strong>Importing…</strong> ' + processed + ' / ' + total + ' yachts &mdash; ' +
				created + ' created, ' + updated + ' updated, ' + skipped + ' skipped.' + photoNote + '</p>' +
				'<p style="margin:6px 0 0;font-size:12px;color:#787c82">Keep this tab open until it finishes. ' +
				'If it stops, a Resume button appears — nothing already imported is lost.</p>' +
			'</div>'
		);
	}

	function renderDone( $box, created, updated, skipped ) {
		$box.html(
			'<div class="notice notice-success inline" style="margin:0"><p>' +
				'<strong>Import complete:</strong> ' + created + ' yacht(s) created, ' + updated + ' updated, ' + skipped + ' skipped. ' +
				'<a href="' + fyImport.visualizerUrl + '">Open the Fleet Visualizer</a>' +
			'</p></div>'
		);
	}

	/**
	 * @param {function} [onResume] When given, a Resume button is shown that
	 *                              continues from the current cursor instead
	 *                              of making the user reload and re-walk every
	 *                              already-imported row.
	 */
	function renderError( $box, message, onResume ) {
		$box.html( '<div class="notice notice-error inline" style="margin:0"><p>' + ( message || 'Something went wrong.' ) + '</p></div>' );
		if ( typeof onResume === 'function' ) {
			var $resume = $( '<p style="margin:10px 0 0"><button type="button" class="button button-primary fy-import-resume">▶ Resume from here</button></p>' );
			$box.find( '.notice' ).append( $resume );
			$resume.on( 'click', '.fy-import-resume', function () {
				onResume();
			} );
		}
	}

	/**
	 * Runs the offset-advancing AJAX loop for one form until the server
	 * reports done:true or a request fails.
	 */
	function runBatches( $form, source, extra ) {
		var $btn  = $form.find( 'button[type="submit"], input[type="submit"]' );
		var $box  = progressBox( $form );
		$btn.prop( 'disabled', true );

		var offset     = 0;
		var imgOffset  = 0;   // resume point inside the current yacht's photo list
		var rowYachtId = 0;   // yacht being filled while its photos stream in
		var cityTermId = 0;
		var retries    = 0;   // consecutive failures on the CURRENT cursor
		var MAX_RETRIES = 3;
		// The server reports counts for the batch it just processed, so the
		// browser keeps the running totals across the whole run.
		var totCreated = 0;
		var totUpdated = 0;
		var totSkipped = 0;

		function next() {
			var payload = $.extend(
				{
					action: 'fy_import_batch',
					nonce: fyImport.nonce,
					source: source,
					offset: offset,
					img_offset: imgOffset,
					row_yacht_id: rowYachtId,
					match_sku: $form.find( '[name="fy_match_sku"]' ).is( ':checked' ) ? 1 : 0,
					match_title: $form.find( '[name="fy_match_title"]' ).is( ':checked' ) ? 1 : 0,
					do_images: $form.find( '[name="fy_import_images"]' ).is( ':checked' ) ? 1 : 0
				},
				extra
			);

			if ( cityTermId ) {
				payload.city_term_id = cityTermId;
			} else {
				payload.city_choice = $form.find( '[name="fy_import_city"]' ).val();
				payload.city_name = $form.find( '[name="fy_import_city_name"]' ).val();
			}

			$.post( fyImport.ajaxUrl, payload )
				.done( function ( res ) {
					if ( ! res || ! res.success ) {
						renderError( $box, res && res.data ? res.data.message : '' );
						$btn.prop( 'disabled', false );
						return;
					}
					var d = res.data;
					cityTermId  = d.city_term_id || cityTermId;
					totCreated += ( d.created || 0 );
					totUpdated += ( d.updated || 0 );
					totSkipped += ( d.skipped || 0 );

					// Did the cursor move at all? It advances either by row
					// (offset) or by photo within a row (img_offset).
					var advanced = ( d.offset > offset ) || ( d.offset === offset && d.img_offset > imgOffset );

					offset     = ( typeof d.offset === 'number' ) ? d.offset : d.processed;
					imgOffset  = d.img_offset || 0;
					rowYachtId = d.row_yacht_id || 0;
					retries    = 0;

					if ( d.done ) {
						renderDone( $box, totCreated, totUpdated, totSkipped );
						$btn.prop( 'disabled', false );
						return;
					}

					// Stalled without advancing — stop rather than loop forever.
					if ( ! advanced ) {
						renderError( $box, 'The import stopped making progress and was halted to avoid looping. Reload and run it again — completed work is kept.' );
						$btn.prop( 'disabled', false );
						return;
					}

					renderProgress( $box, d.processed, d.total, totCreated, totUpdated, totSkipped, imgOffset );
					// A short pause between batches — the server just did real
					// work (downloading photos), and this keeps requests paced
					// out instead of firing back-to-back the instant one
					// finishes, which is friendlier to modest hosting and less
					// likely to trip a host's rate-limiting/security rules.
					setTimeout( next, 400 );
				} )
				.fail( function ( jqXHR ) {
					// Transient failures (a gateway hiccup, one slow photo
					// host) are common on long runs — retry the SAME cursor a
					// few times, backing off, before giving up. Nothing is
					// re-downloaded on retry: completed photos are remembered.
					if ( retries < MAX_RETRIES ) {
						retries++;
						$box.find( '.fy-import-retry' ).remove();
						$box.append(
							'<p class="fy-import-retry" style="margin:8px 0 0;color:#996800">' +
							'Hiccup on this batch (attempt ' + retries + ' of ' + MAX_RETRIES + ') — retrying…</p>'
						);
						setTimeout( next, 2000 * retries );
						return;
					}

					var status = jqXHR && jqXHR.status ? jqXHR.status : 0;
					var detail = '';
					if ( 502 === status || 504 === status || 0 === status ) {
						detail = 'The server timed out on this step (HTTP ' + status + '). ';
					} else if ( 500 === status ) {
						detail = 'The server hit a PHP error on this step (HTTP 500). ';
					} else if ( 403 === status ) {
						detail = 'The session expired (HTTP 403) — reload the page and sign in again. ';
					} else if ( status ) {
						detail = 'The server returned HTTP ' + status + '. ';
					}

					renderError(
						$box,
						detail + 'Stopped at yacht ' + ( offset + 1 ) + ( imgOffset ? ', photo ' + imgOffset : '' ) + '. ' +
						'Nothing already imported is lost — click Resume to carry on from exactly here.',
						function () {
							retries = 0;
							renderProgress( $box, offset, 0, totCreated, totUpdated, totSkipped, imgOffset );
							$btn.prop( 'disabled', true );
							next();
						}
					);
					$btn.prop( 'disabled', false );
				} );
		}

		renderProgress( $box, 0, 0, 0, 0, 0 );
		next();
	}

	$( function () {
		$( '#fy-import-bundled-form' ).on( 'submit', function ( e ) {
			e.preventDefault();
			runBatches( $( this ), 'bundled', {} );
		} );

		$( '#fy-import-upload-form' ).on( 'submit', function ( e ) {
			e.preventDefault();
			var $form = $( this );
			var input = $form.find( 'input[type="file"]' )[ 0 ];
			if ( ! input || ! input.files.length ) {
				return;
			}

			var $btn = $form.find( 'button[type="submit"], input[type="submit"]' );
			$btn.prop( 'disabled', true );
			var $box = progressBox( $form );
			$box.html( '<p>Uploading…</p>' );

			var fd = new FormData();
			fd.append( 'action', 'fy_import_prepare_upload' );
			fd.append( 'nonce', fyImport.nonce );
			fd.append( 'file', input.files[ 0 ] );

			$.ajax( {
				url: fyImport.ajaxUrl,
				type: 'POST',
				data: fd,
				processData: false,
				contentType: false
			} )
				.done( function ( res ) {
					if ( ! res || ! res.success ) {
						renderError( $box, res && res.data ? res.data.message : '' );
						$btn.prop( 'disabled', false );
						return;
					}
					runBatches( $form, 'uploaded', { token: res.data.token, ext: res.data.ext } );
				} )
				.fail( function () {
					renderError( $box, 'Upload failed — check the file and try again.' );
					$btn.prop( 'disabled', false );
				} );
		} );
	} );
} )( jQuery );
