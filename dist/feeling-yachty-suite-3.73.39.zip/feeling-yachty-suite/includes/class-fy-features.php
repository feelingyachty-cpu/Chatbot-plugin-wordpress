<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ⚙️ Control Panel — one screen to see the whole suite and switch optional
 * modules on/off without touching code, plus quick links to every setting.
 */
class FY_Fleet_Features {

	const OPTION = 'fy_fleet_features';

	public static function defaults() {
		return array(
			'seo'          => 0, // Built-in SEO module (off: Rank Math handles meta).
			'galleries'    => 0, // Reusable photo galleries.
			'payments_hub' => 0, // Stripe/PayPal install-and-status screen.
			'tags'         => 1, // Yacht Tags taxonomy — on by default: the spreadsheet importer tags every yacht by type, brand, model, year and location.
		);
	}

	public static function on( $key ) {
		$opts = wp_parse_args( get_option( self::OPTION, array() ), self::defaults() );
		return ! empty( $opts[ $key ] );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ), 6 );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_enable_tags_once' ), 5 );
	}

	/**
	 * One-time migration: switch Yacht Tags ON for installs that saved the
	 * Control Panel back when tags defaulted to OFF.
	 *
	 * The settings sanitizer writes an explicit 0 for every unchecked
	 * feature, so a stored "tags => 0" wins over the new default and would
	 * keep silently discarding the brand / model / year / location tags the
	 * spreadsheet importer writes. Runs once — the toggle can still be
	 * turned back off by hand afterwards and will stay off.
	 */
	public static function maybe_enable_tags_once() {
		if ( '1' === get_option( 'fy_fleet_tags_default_on' ) ) {
			return;
		}
		update_option( 'fy_fleet_tags_default_on', '1' );

		$opts = get_option( self::OPTION, array() );
		if ( ! is_array( $opts ) ) {
			$opts = array();
		}
		if ( empty( $opts['tags'] ) ) {
			$opts['tags'] = 1;
			update_option( self::OPTION, $opts );
			// The taxonomy registers on `init`, which already ran this
			// request — rebuild permalinks so its term URLs work.
			update_option( 'fy_fleet_flush_needed', '1' );
		}
	}

	public static function register() {
		register_setting(
			'fy_fleet_features_group',
			self::OPTION,
			array(
				'sanitize_callback' => function ( $input ) {
					$out = array();
					foreach ( array_keys( self::defaults() ) as $key ) {
						$out[ $key ] = ! empty( $input[ $key ] ) ? 1 : 0;
					}
					return $out;
				},
			)
		);
	}

	public static function add_menu() {
		add_submenu_page(
			'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE,
			__( 'Control Panel', 'fy-fleet' ),
			__( '⚙️ Control Panel', 'fy-fleet' ),
			'manage_options',
			'fy-fleet-control',
			array( __CLASS__, 'render' )
		);
	}

	/* ------------------------------------------------------------------ */

	private static function status_rows() {
		$rows = array();

		$woo = class_exists( 'WooCommerce' );
		$rows[] = array( $woo, __( 'WooCommerce active', 'fy-fleet' ), $woo ? '' : __( 'Nothing can be sold without it.', 'fy-fleet' ) );

		$gateways = 0;
		if ( $woo && WC()->payment_gateways() ) {
			$gateways = count( WC()->payment_gateways()->get_available_payment_gateways() );
		}
		$rows[] = array( $gateways > 0, sprintf( __( 'Payment methods enabled: %d', 'fy-fleet' ), $gateways ), $gateways ? '' : __( 'Customers cannot pay — WooCommerce → Settings → Payments.', 'fy-fleet' ) );

		$booking = FY_Fleet_Settings::get_booking();
		$rows[] = array( ! empty( $booking['ghl_form_url'] ), __( 'Bareboat agreement form connected', 'fy-fleet' ), '' );
		$rows[] = array( ! empty( $booking['webhook_url'] ), __( 'n8n webhook configured', 'fy-fleet' ), empty( $booking['webhook_url'] ) ? __( 'Bookings & messages are not being pushed anywhere.', 'fy-fleet' ) : '' );
		$rows[] = array( class_exists( 'FY_Fleet_Twilio' ) && FY_Fleet_Twilio::configured(), __( 'Twilio SMS/WhatsApp configured', 'fy-fleet' ), '' );
		$rows[] = array( class_exists( 'FY_Fleet_AI' ) && FY_Fleet_AI::configured(), __( 'AI assist configured', 'fy-fleet' ), '' );

		$yachts = wp_count_posts( FY_Fleet_CPT::POST_TYPE );
		$rows[] = array( (int) $yachts->publish > 0, sprintf( __( 'Published yachts: %d (drafts: %d)', 'fy-fleet' ), (int) $yachts->publish, (int) $yachts->draft ), '' );

		$cities = get_terms( array( 'taxonomy' => 'fy_yacht_cat', 'hide_empty' => false ) );
		$rows[] = array( ! is_wp_error( $cities ) && count( $cities ) > 0, sprintf( __( 'Cities: %d', 'fy-fleet' ), is_wp_error( $cities ) ? 0 : count( $cities ) ), '' );

		$backups = class_exists( 'FY_Fleet_REST' ) ? FY_Fleet_REST::list_backups() : array();
		$rows[] = array(
			! empty( $backups ),
			empty( $backups ) ? __( 'No backups yet', 'fy-fleet' ) : sprintf( __( 'Last backup: %s', 'fy-fleet' ), date_i18n( 'M j, g:i a', $backups[0]['time'] ) ),
			'',
		);

		return $rows;
	}

	private static function links() {
		$u = function ( $page ) {
			return admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=' . $page );
		};
		return array(
			array( '⭐', __( 'Start Here guide', 'fy-fleet' ), $u( 'fy-fleet-help' ) ),
			array( '📊', __( 'Dashboard', 'fy-fleet' ), $u( 'fy-fleet-dashboard' ) ),
			array( '📥', __( 'Inbox', 'fy-fleet' ), $u( 'fy-fleet-inbox' ) ),
			array( '🛥️', __( 'Fleet Visualizer', 'fy-fleet' ), $u( 'fy-fleet-visualizer' ) ),
			array( '🌎', __( 'Cities', 'fy-fleet' ), admin_url( 'edit-tags.php?taxonomy=fy_yacht_cat&post_type=' . FY_Fleet_CPT::POST_TYPE ) ),
			array( '📍', __( 'Marinas', 'fy-fleet' ), $u( 'fy-fleet-marinas' ) ),
			array( '💳', __( 'Checkout & Integrations (deposit, n8n, GHL form)', 'fy-fleet' ), $u( 'fy-fleet-booking' ) ),
			array( '🎨', __( 'Display Settings & colors', 'fy-fleet' ), $u( 'fy-fleet-settings' ) ),
			array( '🤖', __( 'API / n8n + Backups + Excel', 'fy-fleet' ), $u( 'fy-fleet-api' ) ),
			array( '📜', __( 'Activity Log', 'fy-fleet' ), $u( 'fy-fleet-log' ) ),
			array( '🏦', __( 'WooCommerce payment gateways', 'fy-fleet' ), admin_url( 'admin.php?page=wc-settings&tab=checkout' ) ),
		);
	}

	public static function render() {
		$opts    = wp_parse_args( get_option( self::OPTION, array() ), self::defaults() );
		$toggles = array(
			'seo'          => array( '🔎', __( 'Built-in SEO module', 'fy-fleet' ), __( 'Yacht SEO metabox, meta templates, Product/FAQ/review-star schema. Keep OFF while Rank Math handles meta, or tags will duplicate.', 'fy-fleet' ) ),
			'galleries'    => array( '📸', __( 'Photo Galleries', 'fy-fleet' ), __( 'Reusable galleries (grid or swipeable slider with lightbox) assignable to any yacht.', 'fy-fleet' ) ),
			'payments_hub' => array( '💳', __( 'Payments hub page', 'fy-fleet' ), __( 'Stripe/PayPal install-and-status screen inside the Command Center.', 'fy-fleet' ) ),
			'tags'         => array( '🏷️', __( 'Yacht Tags', 'fy-fleet' ), __( 'Free-form tags with their own URLs, separate from Cities.', 'fy-fleet' ) ),
		);
		?>
		<div class="wrap" style="max-width:1000px">
			<h1>⚙️ <?php esc_html_e( 'Command Center — Control Panel', 'fy-fleet' ); ?></h1>

			<style>
				.fy-cp-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:12px;margin:16px 0}
				.fy-cp-card{background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:14px 16px}
				.fy-cp-card label{display:flex;gap:10px;align-items:flex-start;font-weight:700;font-size:14px;cursor:pointer}
				.fy-cp-card input[type=checkbox]{width:20px;height:20px;margin-top:1px;accent-color:#C7347B}
				.fy-cp-card p{margin:8px 0 0 30px;color:#646970;font-size:12.5px;line-height:1.5}
				.fy-cp-status{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:8px;margin:14px 0}
				.fy-cp-row{display:flex;gap:10px;align-items:baseline;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:10px 14px;font-size:13px;font-weight:600}
				.fy-cp-row small{color:#b45309;font-weight:600}
				.fy-cp-links{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:8px;margin:14px 0 30px}
				.fy-cp-links a{display:flex;gap:9px;align-items:center;background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:12px 14px;text-decoration:none;font-weight:700;color:#1d2327}
				.fy-cp-links a:hover{border-color:#C7347B;color:#C7347B}
			</style>

			<h2><?php esc_html_e( 'System status', 'fy-fleet' ); ?></h2>
			<div class="fy-cp-status">
				<?php foreach ( self::status_rows() as $row ) : ?>
					<div class="fy-cp-row">
						<span><?php echo $row[0] ? '✅' : '⚠️'; ?></span>
						<span><?php echo esc_html( $row[1] ); ?><?php echo $row[2] ? ' <small>— ' . esc_html( $row[2] ) . '</small>' : ''; // phpcs:ignore ?></span>
					</div>
				<?php endforeach; ?>
			</div>

			<h2><?php esc_html_e( 'Optional features', 'fy-fleet' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Switch modules on or off — takes effect immediately after saving, data is never deleted by turning something off.', 'fy-fleet' ); ?></p>
			<form method="post" action="options.php">
				<?php settings_fields( 'fy_fleet_features_group' ); ?>
				<div class="fy-cp-grid">
					<?php foreach ( $toggles as $key => $meta ) : ?>
						<div class="fy-cp-card">
							<label>
								<input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( ! empty( $opts[ $key ] ) ); ?>>
								<span><?php echo esc_html( $meta[0] . ' ' . $meta[1] ); ?></span>
							</label>
							<p><?php echo esc_html( $meta[2] ); ?></p>
						</div>
					<?php endforeach; ?>
				</div>
				<?php submit_button( __( 'Save features', 'fy-fleet' ) ); ?>
			</form>

			<h2><?php esc_html_e( 'Everything, one click away', 'fy-fleet' ); ?></h2>
			<div class="fy-cp-links">
				<?php foreach ( self::links() as $link ) : ?>
					<a href="<?php echo esc_url( $link[2] ); ?>"><span><?php echo esc_html( $link[0] ); ?></span><span><?php echo esc_html( $link[1] ); ?></span></a>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}
}
