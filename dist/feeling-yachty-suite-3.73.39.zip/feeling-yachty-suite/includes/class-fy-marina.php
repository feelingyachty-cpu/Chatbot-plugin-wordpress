<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Marina & map per yacht.
 *
 * A yacht either points at a preset marina from the editable library
 * (Yacht Fleet → Checkout & Integrations → Marinas) or defines its own. The map is
 * built from GPS coordinates using Google's keyless embed, unless a custom
 * embed URL is supplied. A Google Maps directions link is generated from the
 * same coordinates, and a BoatTerminal schema node feeds local SEO.
 */
class FY_Fleet_Marina {

	const OPTION = 'fy_fleet_marinas';

	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_box' ) );
		add_action( 'save_post_' . FY_Fleet_CPT::POST_TYPE, array( __CLASS__, 'save' ), 10, 2 );
		add_shortcode( 'fy_yacht_marina', array( __CLASS__, 'shortcode' ) );
		add_action( 'wp_head', array( __CLASS__, 'print_schema' ) );
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_fix_coordinates' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
	}

	/** Marina title → lookup key: lowercased, everything but letters/digits stripped. */
	public static function normalize_title( $title ) {
		return preg_replace( '/[^a-z0-9]+/', '', strtolower( html_entity_decode( (string) $title, ENT_QUOTES ) ) );
	}

	/**
	 * One-time repair of marina coordinates the bulk import shipped wrong.
	 *
	 * Audited 2026-08-10 against the source spreadsheet and OpenStreetMap:
	 * the import copied the sheet faithfully, but the SHEET's coordinates were
	 * wrong for 100+ yachts — most pins sat clustered around downtown
	 * (longitude ≈ -80.185) while the written address was Miami Beach
	 * (-80.14) or the upper Miami River (-80.21 to -80.26). Every entry in
	 * includes/data/marina-corrections.php is a street address (or a named
	 * marina) whose true position was verified; vague titles ("MIAMI RIVER")
	 * are deliberately not corrected automatically.
	 *
	 * A yacht is only touched when its stored pin is far (> ~350 m) from the
	 * verified point — so anything already fixed by hand is left exactly
	 * where the owner put it. The embed map and Google link are derived from
	 * these coordinates at render time, so they heal on the next page view.
	 */
	public static function maybe_fix_coordinates() {
		if ( 1 === (int) get_option( 'fy_fleet_marina_coord_fix', 0 ) ) {
			return;
		}
		update_option( 'fy_fleet_marina_coord_fix', 1 );

		$file = FY_FLEET_DIR . 'includes/data/marina-corrections.php';
		if ( ! file_exists( $file ) ) {
			return;
		}
		$map = include $file;
		if ( ! is_array( $map ) || empty( $map ) ) {
			return;
		}

		$yacht_ids = get_posts(
			array(
				'post_type'      => FY_Fleet_CPT::POST_TYPE,
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);

		$fixed = 0;
		foreach ( $yacht_ids as $yacht_id ) {
			$key = self::normalize_title( get_post_meta( $yacht_id, '_fy_marina_title', true ) );
			if ( '' === $key || ! isset( $map[ $key ] ) ) {
				continue;
			}
			$good_lat = (float) $map[ $key ]['lat'];
			$good_lng = (float) $map[ $key ]['lng'];
			$cur_lat  = (float) get_post_meta( $yacht_id, '_fy_marina_lat', true );
			$cur_lng  = (float) get_post_meta( $yacht_id, '_fy_marina_lng', true );

			// ~0.0032° ≈ 350 m at Miami's latitude. Nearer than that = already
			// right (or hand-tuned) — leave it alone.
			if ( abs( $cur_lat - $good_lat ) < 0.0032 && abs( $cur_lng - $good_lng ) < 0.0036 ) {
				continue;
			}

			update_post_meta( $yacht_id, '_fy_marina_lat', $map[ $key ]['lat'] );
			update_post_meta( $yacht_id, '_fy_marina_lng', $map[ $key ]['lng'] );
			$fixed++;
		}

		if ( $fixed && class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'marina.coords_fixed', sprintf( 'Repositioned %d yachts\' marina map pins to their verified coordinates (import shipped wrong ones)', $fixed ) );
		}
	}

	/**
	 * The marina library, keyed by slug.
	 *
	 * Stored as a structured option and edited on the Marinas screen. The first
	 * time it is read it is seeded from the shipped Miami list.
	 */
	public static function library() {
		$stored = get_option( self::OPTION, null );

		if ( ! is_array( $stored ) ) {
			$stored = self::seed_from_defaults();
			update_option( self::OPTION, $stored );
		}

		$out = array();
		foreach ( $stored as $marina ) {
			$key = isset( $marina['key'] ) ? sanitize_key( $marina['key'] ) : '';
			$name = isset( $marina['name'] ) ? $marina['name'] : '';
			if ( '' === $key || '' === $name ) {
				continue;
			}
			// Keyed assignment means a duplicate slug can never appear twice.
			$out[ $key ] = array(
				'key'     => $key,
				'name'    => $name,
				'lat'     => isset( $marina['lat'] ) ? trim( (string) $marina['lat'] ) : '',
				'lng'     => isset( $marina['lng'] ) ? trim( (string) $marina['lng'] ) : '',
				'address' => isset( $marina['address'] ) ? $marina['address'] : '',
				'note'    => isset( $marina['note'] ) ? $marina['note'] : '',
				'embed'   => isset( $marina['embed'] ) ? $marina['embed'] : '',
			);
		}

		return $out;
	}

	/** Convert the shipped pipe-delimited list into structured rows. */
	public static function seed_from_defaults() {
		$rows = array();
		$seen = array();

		foreach ( preg_split( '/\r\n|\r|\n/', FY_Fleet_Settings::default_marinas() ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || false === strpos( $line, '|' ) ) {
				continue;
			}
			$parts = array_map( 'trim', explode( '|', $line ) );
			$key   = sanitize_key( isset( $parts[0] ) ? $parts[0] : '' );
			$name  = isset( $parts[1] ) ? $parts[1] : '';
			if ( '' === $key || '' === $name || isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;

			$rows[] = array(
				'key'     => $key,
				'name'    => $name,
				'lat'     => isset( $parts[2] ) ? $parts[2] : '',
				'lng'     => isset( $parts[3] ) ? $parts[3] : '',
				'address' => isset( $parts[4] ) ? $parts[4] : '',
				'note'    => isset( $parts[5] ) ? $parts[5] : '',
				'embed'   => '',
			);
		}

		return $rows;
	}

	/* ------------------------------------------------------------------
	 * Marinas admin screen
	 * ---------------------------------------------------------------- */

	public static function add_menu() {
		add_submenu_page(
			'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE,
			__( 'Marinas', 'fy-fleet' ),
			__( 'Marinas', 'fy-fleet' ),
			'manage_options',
			'fy-fleet-marinas',
			array( __CLASS__, 'render_admin_page' )
		);
	}

	public static function register_settings() {
		register_setting( 'fy_fleet_marinas_group', self::OPTION, array( __CLASS__, 'sanitize_library' ) );
	}

	public static function sanitize_library( $input ) {
		$rows = array();
		$seen = array();

		if ( ! is_array( $input ) ) {
			return $rows;
		}

		foreach ( $input as $marina ) {
			$name = isset( $marina['name'] ) ? sanitize_text_field( $marina['name'] ) : '';
			if ( '' === trim( $name ) ) {
				continue; // Blank name = removed row.
			}

			$key = isset( $marina['key'] ) ? sanitize_key( $marina['key'] ) : '';
			if ( '' === $key ) {
				$key = sanitize_key( sanitize_title( $name ) );
			}
			// Guarantee uniqueness even if two rows end up with the same slug.
			$base = $key;
			$i    = 2;
			while ( isset( $seen[ $key ] ) ) {
				$key = $base . '-' . $i;
				$i++;
			}
			$seen[ $key ] = true;

			$lat = isset( $marina['lat'] ) ? trim( sanitize_text_field( $marina['lat'] ) ) : '';
			$lng = isset( $marina['lng'] ) ? trim( sanitize_text_field( $marina['lng'] ) ) : '';

			$rows[] = array(
				'key'     => $key,
				'name'    => $name,
				'lat'     => is_numeric( $lat ) ? $lat : '',
				'lng'     => is_numeric( $lng ) ? $lng : '',
				'address' => isset( $marina['address'] ) ? sanitize_text_field( $marina['address'] ) : '',
				'note'    => isset( $marina['note'] ) ? sanitize_textarea_field( $marina['note'] ) : '',
				'embed'   => isset( $marina['embed'] ) ? esc_url_raw( $marina['embed'] ) : '',
			);
		}

		return $rows;
	}

	public static function enqueue( $hook ) {
		if ( false === strpos( (string) $hook, 'fy-fleet-marinas' ) ) {
			return;
		}
		wp_enqueue_style( 'fy-fleet-marinas', FY_FLEET_URL . 'assets/marinas.css', array(), FY_FLEET_VERSION );
		wp_enqueue_script( 'fy-fleet-marinas', FY_FLEET_URL . 'assets/marinas.js', array(), FY_FLEET_VERSION, true );
	}

	public static function render_admin_page() {
		$library = array_values( self::library() );
		?>
		<div class="wrap fy-marinas-admin">
			<h1><?php esc_html_e( 'Marinas', 'fy-fleet' ); ?></h1>
			<p class="description" style="max-width:900px">
				<?php esc_html_e( 'Add, edit or remove departure marinas. Each yacht picks one of these under "Marina & Map", or defines its own.', 'fy-fleet' ); ?><br>
				<strong><?php esc_html_e( 'Coordinates are optional.', 'fy-fleet' ); ?></strong>
				<?php esc_html_e( 'Leave them blank and the map plus the Google Maps link resolve by name and address. Fill them in to pin the exact dock — right-click the spot in Google Maps and click the coordinates to copy them.', 'fy-fleet' ); ?>
			</p>

			<form method="post" action="options.php">
				<?php settings_fields( 'fy_fleet_marinas_group' ); ?>

				<div id="fy-marina-rows">
					<?php foreach ( $library as $index => $marina ) : ?>
						<?php self::render_row( $index, $marina ); ?>
					<?php endforeach; ?>
				</div>

				<p>
					<button type="button" class="button button-secondary" id="fy-add-marina"><?php esc_html_e( '+ Add Marina', 'fy-fleet' ); ?></button>
					<span class="description" style="margin-left:8px"><?php esc_html_e( 'Clearing a marina\'s name removes it when you save.', 'fy-fleet' ); ?></span>
				</p>

				<script type="text/template" id="fy-marina-template"><?php self::render_row( '__INDEX__', array() ); ?></script>

				<?php submit_button( __( 'Save Marinas', 'fy-fleet' ) ); ?>
			</form>
		</div>
		<?php
	}

	private static function render_row( $index, $marina ) {
		$name    = isset( $marina['name'] ) ? $marina['name'] : '';
		$key     = isset( $marina['key'] ) ? $marina['key'] : '';
		$lat     = isset( $marina['lat'] ) ? $marina['lat'] : '';
		$lng     = isset( $marina['lng'] ) ? $marina['lng'] : '';
		$address = isset( $marina['address'] ) ? $marina['address'] : '';
		$note    = isset( $marina['note'] ) ? $marina['note'] : '';
		$embed   = isset( $marina['embed'] ) ? $marina['embed'] : '';
		$field   = self::OPTION . '[' . $index . ']';

		$has_coords = self::has_coords( $lat, $lng );
		$search     = trim( $name . ( $address ? ', ' . $address : '' ) );
		?>
		<div class="fy-marina-row">
			<div class="fy-marina-row-head">
				<strong class="fy-marina-row-name"><?php echo esc_html( $name ? $name : __( 'New marina', 'fy-fleet' ) ); ?></strong>
				<span class="fy-marina-flag <?php echo $has_coords ? 'is-ok' : 'is-warn'; ?>">
					<?php echo $has_coords ? esc_html__( 'GPS set', 'fy-fleet' ) : esc_html__( 'No GPS — searches by name', 'fy-fleet' ); ?>
				</span>
				<button type="button" class="button-link-delete fy-marina-remove"><?php esc_html_e( 'Remove', 'fy-fleet' ); ?></button>
			</div>

			<div class="fy-marina-grid">
				<label><?php esc_html_e( 'Name', 'fy-fleet' ); ?>
					<input type="text" class="fy-marina-name-input" name="<?php echo esc_attr( $field ); ?>[name]" value="<?php echo esc_attr( $name ); ?>">
				</label>
				<label><?php esc_html_e( 'Slug', 'fy-fleet' ); ?>
					<input type="text" name="<?php echo esc_attr( $field ); ?>[key]" value="<?php echo esc_attr( $key ); ?>" placeholder="<?php esc_attr_e( 'auto', 'fy-fleet' ); ?>">
				</label>
				<label><?php esc_html_e( 'Latitude', 'fy-fleet' ); ?>
					<input type="text" class="fy-marina-lat-input" name="<?php echo esc_attr( $field ); ?>[lat]" value="<?php echo esc_attr( $lat ); ?>" placeholder="25.7263">
				</label>
				<label><?php esc_html_e( 'Longitude', 'fy-fleet' ); ?>
					<input type="text" class="fy-marina-lng-input" name="<?php echo esc_attr( $field ); ?>[lng]" value="<?php echo esc_attr( $lng ); ?>" placeholder="-80.2330">
				</label>
				<label class="fy-marina-wide"><?php esc_html_e( 'Address', 'fy-fleet' ); ?>
					<input type="text" class="fy-marina-address-input" name="<?php echo esc_attr( $field ); ?>[address]" value="<?php echo esc_attr( $address ); ?>">
				</label>
				<label class="fy-marina-wide"><?php esc_html_e( 'Custom map embed URL (optional — overrides coordinates)', 'fy-fleet' ); ?>
					<input type="url" name="<?php echo esc_attr( $field ); ?>[embed]" value="<?php echo esc_attr( $embed ); ?>" placeholder="https://www.google.com/maps/embed?pb=…">
				</label>
				<label class="fy-marina-wide"><?php esc_html_e( 'Note', 'fy-fleet' ); ?>
					<input type="text" name="<?php echo esc_attr( $field ); ?>[note]" value="<?php echo esc_attr( $note ); ?>">
				</label>
			</div>

			<div class="fy-marina-row-actions">
				<button type="button" class="button button-small fy-marina-row-preview"><?php esc_html_e( 'Preview map', 'fy-fleet' ); ?></button>
				<?php if ( $search ) : ?>
					<a class="button button-small" target="_blank" rel="noopener" href="<?php echo esc_url( self::google_url( $lat, $lng, $search ) ); ?>"><?php esc_html_e( 'Google Maps', 'fy-fleet' ); ?></a>
				<?php endif; ?>
			</div>
			<div class="fy-marina-row-map"></div>
		</div>
		<?php
	}

	/**
	 * Resolved marina for a yacht, merging the preset with per-yacht overrides.
	 *
	 * @return array|null
	 */
	public static function for_yacht( $yacht_id ) {
		$source = get_post_meta( $yacht_id, '_fy_marina_source', true );
		if ( ! $source ) {
			return null;
		}

		$title   = get_post_meta( $yacht_id, '_fy_marina_title', true );
		$lat     = trim( (string) get_post_meta( $yacht_id, '_fy_marina_lat', true ) );
		$lng     = trim( (string) get_post_meta( $yacht_id, '_fy_marina_lng', true ) );
		$embed   = trim( (string) get_post_meta( $yacht_id, '_fy_marina_embed', true ) );
		$note    = get_post_meta( $yacht_id, '_fy_marina_note', true );
		$address = '';

		if ( 'custom' !== $source ) {
			$library = self::library();
			if ( isset( $library[ $source ] ) ) {
				$preset  = $library[ $source ];
				$title   = $title ? $title : $preset['name'];
				$lat     = $lat ? $lat : $preset['lat'];
				$lng     = $lng ? $lng : $preset['lng'];
				$embed   = $embed ? $embed : $preset['embed'];
				$address = $preset['address'];
				$note    = $note ? $note : $preset['note'];
			}
		}

		if ( ! $title && ! $lat && ! $embed ) {
			return null;
		}

		// Without coordinates, a name + city search still resolves correctly.
		$search = trim( $title . ( $address ? ', ' . $address : '' ) );

		return array(
			'title'   => $title,
			'address' => $address,
			'lat'     => $lat,
			'lng'     => $lng,
			'embed'   => self::embed_url( $lat, $lng, $embed, $search ),
			'google'  => self::google_url( $lat, $lng, $search ),
			'note'    => $note,
		);
	}

	public static function has_coords( $lat, $lng ) {
		return is_numeric( $lat ) && is_numeric( $lng );
	}

	/** Google's keyless map embed, or the custom URL when one is set. */
	public static function embed_url( $lat, $lng, $custom = '', $title = '' ) {
		if ( $custom ) {
			return $custom;
		}
		if ( self::has_coords( $lat, $lng ) ) {
			return 'https://www.google.com/maps?q=' . rawurlencode( $lat . ',' . $lng ) . '&z=15&output=embed';
		}
		if ( $title ) {
			return 'https://www.google.com/maps?q=' . rawurlencode( $title ) . '&z=14&output=embed';
		}
		return '';
	}

	public static function google_url( $lat, $lng, $title = '' ) {
		if ( self::has_coords( $lat, $lng ) ) {
			return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $lat . ',' . $lng );
		}
		return $title ? 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $title ) : '';
	}

	/**
	 * Local-SEO structured data: a BoatTerminal (schema.org Place) node for the
	 * departure marina, printed on yacht-backed product pages. Sits alongside
	 * Rank Math's Product schema without touching it.
	 */
	public static function print_schema() {
		if ( ! is_singular( 'product' ) ) {
			return;
		}
		$yacht_id = (int) get_post_meta( get_the_ID(), '_fy_yacht_id', true );
		if ( ! $yacht_id || FY_Fleet_CPT::POST_TYPE !== get_post_type( $yacht_id ) ) {
			return;
		}
		$marina = self::for_yacht( $yacht_id );
		if ( ! $marina || ! $marina['title'] ) {
			return;
		}

		$node = array(
			'@context'    => 'https://schema.org',
			'@type'       => 'BoatTerminal',
			'name'        => $marina['title'],
			'description' => sprintf( __( 'Departure marina for %s', 'fy-fleet' ), get_the_title( $yacht_id ) ),
		);
		if ( ! empty( $marina['address'] ) ) {
			$node['address'] = array(
				'@type'         => 'PostalAddress',
				'streetAddress' => $marina['address'],
			);
		}
		if ( self::has_coords( $marina['lat'], $marina['lng'] ) ) {
			$node['geo'] = array(
				'@type'     => 'GeoCoordinates',
				'latitude'  => (float) $marina['lat'],
				'longitude' => (float) $marina['lng'],
			);
		}
		if ( ! empty( $marina['google'] ) ) {
			$node['hasMap'] = $marina['google'];
		}

		echo '<script type="application/ld+json">' . wp_json_encode( $node ) . '</script>' . "\n";
	}

	/* ------------------------------------------------------------------
	 * Admin
	 * ---------------------------------------------------------------- */

	public static function add_meta_box() {
		add_meta_box( 'fy_marina', __( 'Marina & Map', 'fy-fleet' ), array( __CLASS__, 'render_meta_box' ), FY_Fleet_CPT::POST_TYPE, 'normal', 'default' );
	}

	public static function render_meta_box( $post ) {
		wp_nonce_field( 'fy_marina_save', 'fy_marina_nonce' );

		$source = get_post_meta( $post->ID, '_fy_marina_source', true );
		$title  = get_post_meta( $post->ID, '_fy_marina_title', true );
		$lat    = get_post_meta( $post->ID, '_fy_marina_lat', true );
		$lng    = get_post_meta( $post->ID, '_fy_marina_lng', true );
		$embed  = get_post_meta( $post->ID, '_fy_marina_embed', true );
		$note   = get_post_meta( $post->ID, '_fy_marina_note', true );

		$library = self::library();
		$preview = self::for_yacht( $post->ID );
		?>
		<table class="form-table fy-form-table">
			<tr>
				<th><label for="fy_marina_source"><?php esc_html_e( 'Marina', 'fy-fleet' ); ?></label></th>
				<td>
					<select id="fy_marina_source" name="fy_marina_source" class="fy-marina-source">
						<option value=""><?php esc_html_e( '— No map on this yacht —', 'fy-fleet' ); ?></option>
						<?php foreach ( $library as $marina ) : ?>
							<option value="<?php echo esc_attr( $marina['key'] ); ?>"
								data-lat="<?php echo esc_attr( $marina['lat'] ); ?>"
								data-lng="<?php echo esc_attr( $marina['lng'] ); ?>"
								data-name="<?php echo esc_attr( $marina['name'] ); ?>"
								<?php selected( $source, $marina['key'] ); ?>>
								<?php echo esc_html( $marina['name'] ); ?>
								<?php echo ( $marina['lat'] && $marina['lng'] ) ? '' : esc_html__( ' (no coordinates yet)', 'fy-fleet' ); ?>
							</option>
						<?php endforeach; ?>
						<option value="custom" <?php selected( $source, 'custom' ); ?>><?php esc_html_e( '➕ Custom marina / custom embed', 'fy-fleet' ); ?></option>
					</select>
					<p class="description">
						<?php
						printf(
							/* translators: %s: settings link */
							esc_html__( 'Presets are managed under %s. Anything you type below overrides the preset for this yacht only.', 'fy-fleet' ),
							'<a href="' . esc_url( admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-marinas' ) ) . '">' . esc_html__( 'Yacht Fleet → Marinas', 'fy-fleet' ) . '</a>'
						);
						?>
					</p>
				</td>
			</tr>
			<tr>
				<th><label for="fy_marina_title"><?php esc_html_e( 'Marina title', 'fy-fleet' ); ?></label></th>
				<td><input type="text" class="large-text fy-marina-title" id="fy_marina_title" name="fy_marina_title" value="<?php echo esc_attr( $title ); ?>" placeholder="<?php esc_attr_e( 'e.g. Rickenbacker Marina, Key Biscayne', 'fy-fleet' ); ?>"></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'GPS coordinates', 'fy-fleet' ); ?></th>
				<td>
					<label><?php esc_html_e( 'Latitude', 'fy-fleet' ); ?>
						<input type="text" class="regular-text fy-marina-lat" name="fy_marina_lat" value="<?php echo esc_attr( $lat ); ?>" placeholder="25.7455" style="width:140px">
					</label>
					&nbsp;
					<label><?php esc_html_e( 'Longitude', 'fy-fleet' ); ?>
						<input type="text" class="regular-text fy-marina-lng" name="fy_marina_lng" value="<?php echo esc_attr( $lng ); ?>" placeholder="-80.1687" style="width:140px">
					</label>
					<p class="description"><?php esc_html_e( 'Right-click the dock in Google Maps → click the coordinates to copy them, then paste here. These generate the embedded map, the Google Maps link and the local-SEO map data.', 'fy-fleet' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><label for="fy_marina_embed"><?php esc_html_e( 'Custom map embed URL', 'fy-fleet' ); ?></label></th>
				<td><input type="url" class="large-text fy-marina-embed" id="fy_marina_embed" name="fy_marina_embed" value="<?php echo esc_attr( $embed ); ?>" placeholder="https://www.google.com/maps/embed?pb=…">
				<p class="description"><?php esc_html_e( 'Optional. Overrides the coordinates for the embedded map only — paste the src from a Google Maps “Embed a map” iframe. Directions links still use the coordinates.', 'fy-fleet' ); ?></p></td>
			</tr>
			<tr>
				<th><label for="fy_marina_note"><?php esc_html_e( 'Arrival note', 'fy-fleet' ); ?></label></th>
				<td><textarea class="large-text" rows="2" id="fy_marina_note" name="fy_marina_note" placeholder="<?php esc_attr_e( 'e.g. Park in the north lot and meet the captain at dock C.', 'fy-fleet' ); ?>"><?php echo esc_textarea( $note ); ?></textarea></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Preview', 'fy-fleet' ); ?></th>
				<td>
					<button type="button" class="button fy-marina-preview-btn"><?php esc_html_e( 'Preview map', 'fy-fleet' ); ?></button>
					<div class="fy-marina-preview" style="margin-top:10px">
						<?php if ( $preview && $preview['embed'] ) : ?>
							<iframe src="<?php echo esc_url( $preview['embed'] ); ?>" style="width:100%;max-width:640px;height:320px;border:1px solid #dcdcde;border-radius:8px" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
							<p class="description">
								<a href="<?php echo esc_url( $preview['google'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open in Google Maps', 'fy-fleet' ); ?></a>
							</p>
						<?php else : ?>
							<p class="description fy-marina-preview-empty"><?php esc_html_e( 'Choose a marina or enter coordinates, then click Preview map.', 'fy-fleet' ); ?></p>
						<?php endif; ?>
					</div>
				</td>
			</tr>
		</table>
		<?php
	}

	public static function save( $post_id, $post ) {
		if ( ! isset( $_POST['fy_marina_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fy_marina_nonce'] ) ), 'fy_marina_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		update_post_meta( $post_id, '_fy_marina_source', isset( $_POST['fy_marina_source'] ) ? sanitize_text_field( wp_unslash( $_POST['fy_marina_source'] ) ) : '' );
		update_post_meta( $post_id, '_fy_marina_title', isset( $_POST['fy_marina_title'] ) ? sanitize_text_field( wp_unslash( $_POST['fy_marina_title'] ) ) : '' );
		update_post_meta( $post_id, '_fy_marina_lat', isset( $_POST['fy_marina_lat'] ) ? sanitize_text_field( wp_unslash( $_POST['fy_marina_lat'] ) ) : '' );
		update_post_meta( $post_id, '_fy_marina_lng', isset( $_POST['fy_marina_lng'] ) ? sanitize_text_field( wp_unslash( $_POST['fy_marina_lng'] ) ) : '' );
		update_post_meta( $post_id, '_fy_marina_embed', isset( $_POST['fy_marina_embed'] ) ? esc_url_raw( wp_unslash( $_POST['fy_marina_embed'] ) ) : '' );
		update_post_meta( $post_id, '_fy_marina_note', isset( $_POST['fy_marina_note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['fy_marina_note'] ) ) : '' );
	}

	/* ------------------------------------------------------------------
	 * Front end
	 * ---------------------------------------------------------------- */

	public static function shortcode( $atts ) {
		$atts     = shortcode_atts( array( 'yacht' => 0 ), $atts, 'fy_yacht_marina' );
		$yacht_id = intval( $atts['yacht'] );
		// On a yacht-backed product page the yacht is detected automatically.
		if ( ! $yacht_id && is_singular( 'product' ) ) {
			$yacht_id = (int) get_post_meta( get_the_ID(), '_fy_yacht_id', true );
		}
		if ( ! $yacht_id || FY_Fleet_CPT::POST_TYPE !== get_post_type( $yacht_id ) ) {
			return '';
		}
		return self::render( $yacht_id );
	}

	public static function render( $yacht_id ) {
		$marina = self::for_yacht( $yacht_id );
		if ( ! $marina ) {
			return '';
		}

		ob_start();
		?>
		<section class="fy-marina" aria-labelledby="fy-marina-title-<?php echo esc_attr( $yacht_id ); ?>">
			<style>
			.fy-marina{
				--fy-ink:#172033;--fy-muted:#526079;--fy-pink:#E45C9C;--fy-pink-deep:#C94386;
				--fy-purple:#7C3AED;--fy-purple-deep:#5B21B6;--fy-purple-soft:#F3E8FF;
				--fy-blue:#2563EB;--fy-blue-deep:#1E40AF;--fy-blue-soft:#EFF6FF;--fy-border:#E6EAF3;
				margin:22px 0;padding:18px;border:1px solid rgba(124,58,237,.16);border-radius:20px;
				background:linear-gradient(180deg,#fff,#fffafd);box-shadow:0 12px 30px rgba(23,32,51,.07);
				font-family:ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;color:var(--fy-ink);
			}
			.fy-marina *{box-sizing:border-box}
			.fy-marina-head{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px}
			.fy-marina-title{
				margin:0;font-size:clamp(17px,2.4vw,22px);font-weight:950;letter-spacing:-.02em;line-height:1.2;
				background:linear-gradient(90deg,var(--fy-pink-deep),var(--fy-purple),var(--fy-blue));
				-webkit-background-clip:text;background-clip:text;color:transparent;
			}
			.fy-marina-pill{
				display:inline-flex;align-items:center;min-height:26px;padding:4px 10px;border-radius:999px;
				background:var(--fy-blue-soft);border:1px solid rgba(37,99,235,.2);
				color:var(--fy-blue-deep);font-size:11px;font-weight:900;letter-spacing:.03em;
			}
			.fy-marina-map{
				position:relative;overflow:hidden;border-radius:15px;border:1px solid rgba(37,99,235,.14);
				background:#f8fafc;box-shadow:0 7px 18px rgba(23,32,51,.06);
			}
			.fy-marina-map iframe{display:block;width:100%;height:330px;border:0}
			.fy-marina-note{
				margin:12px 0 0;padding:10px 12px;border:1px solid rgba(124,58,237,.18);border-left:5px solid var(--fy-pink);
				border-radius:12px;background:var(--fy-purple-soft);color:var(--fy-purple-deep);
				font-size:12.5px;font-weight:800;line-height:1.5;
			}
			.fy-marina-actions{display:flex;flex-wrap:wrap;gap:9px;margin-top:12px}
			.fy-marina-btn{
				display:inline-flex;align-items:center;justify-content:center;gap:7px;flex:1 1 200px;min-height:50px;
				padding:10px 16px;border-radius:13px;font-size:13px;font-weight:900;text-decoration:none;
				box-shadow:0 8px 20px rgba(23,32,51,.1);transition:filter .15s ease;
			}
			.fy-marina-btn:hover{filter:brightness(1.06)}
			.fy-marina-google{background:linear-gradient(105deg,#1E40AF,#2563EB);color:#fff}
			.fy-marina-coords{
				margin:10px 0 0;color:var(--fy-muted);font-size:11.5px;font-weight:800;letter-spacing:.02em;
			}
			.fy-marina-address{
				margin:0 0 10px;color:var(--fy-muted);font-size:13px;font-weight:800;line-height:1.5;
			}
			@media(max-width:600px){
				.fy-marina{padding:13px;border-radius:16px}
				.fy-marina-map iframe{height:260px}
				.fy-marina-btn{flex:1 1 100%}
			}
			</style>

			<div class="fy-marina-head">
				<h3 class="fy-marina-title" id="fy-marina-title-<?php echo esc_attr( $yacht_id ); ?>">
					📍 <?php echo esc_html( $marina['title'] ); ?>
				</h3>
				<span class="fy-marina-pill"><?php esc_html_e( 'Departure marina', 'fy-fleet' ); ?></span>
			</div>

			<?php if ( $marina['embed'] ) : ?>
			<div class="fy-marina-map">
				<iframe
					src="<?php echo esc_url( $marina['embed'] ); ?>"
					title="<?php echo esc_attr( sprintf( __( 'Map of %s', 'fy-fleet' ), $marina['title'] ) ); ?>"
					loading="lazy"
					referrerpolicy="no-referrer-when-downgrade"
					allowfullscreen></iframe>
			</div>
			<?php endif; ?>

			<?php if ( ! empty( $marina['address'] ) ) : ?>
				<p class="fy-marina-address"><?php echo esc_html( $marina['address'] ); ?></p>
			<?php endif; ?>

			<?php if ( $marina['note'] ) : ?>
				<p class="fy-marina-note">🧭 <?php echo esc_html( $marina['note'] ); ?></p>
			<?php endif; ?>

			<div class="fy-marina-actions">
				<?php if ( $marina['google'] ) : ?>
					<a class="fy-marina-btn fy-marina-google" href="<?php echo esc_url( $marina['google'] ); ?>" target="_blank" rel="noopener">
						🗺️ <?php esc_html_e( 'Open in Google Maps', 'fy-fleet' ); ?>
					</a>
				<?php endif; ?>
			</div>

			<?php if ( self::has_coords( $marina['lat'], $marina['lng'] ) ) : ?>
				<p class="fy-marina-coords"><?php echo esc_html( $marina['lat'] . ', ' . $marina['lng'] ); ?></p>
			<?php endif; ?>
		</section>
		<?php
		return ob_get_clean();
	}
}
