<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AI assist for staff: drafts ticket replies in the Inbox using the business's
 * own API key (Anthropic Claude or OpenAI). Nothing is sent anywhere unless a
 * staff member clicks the button; the draft lands in the reply box for human
 * review before sending.
 *
 * The key can be kept out of the database with FY_AI_API_KEY in wp-config.php.
 */
class FY_Fleet_AI {

	public static function init() {
		add_action( 'wp_ajax_fy_ai_draft', array( __CLASS__, 'ajax_draft' ) );
	}

	public static function settings() {
		$opts = FY_Fleet_Settings::get_booking();
		return array(
			'provider' => ( isset( $opts['ai_provider'] ) && 'openai' === $opts['ai_provider'] ) ? 'openai' : 'anthropic',
			'key'      => defined( 'FY_AI_API_KEY' ) ? FY_AI_API_KEY : ( isset( $opts['ai_key'] ) ? $opts['ai_key'] : '' ),
			'model'    => isset( $opts['ai_model'] ) && $opts['ai_model'] ? $opts['ai_model'] : '',
		);
	}

	public static function configured() {
		$s = self::settings();
		return '' !== $s['key'];
	}

	public static function ajax_draft() {
		check_ajax_referer( 'fy_ai_draft', 'nonce' );
		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'fy-fleet' ) ), 403 );
		}
		if ( ! self::configured() ) {
			wp_send_json_error( array( 'message' => __( 'Add an AI API key under Checkout & Integrations first.', 'fy-fleet' ) ), 400 );
		}

		$ticket_id = isset( $_POST['ticket_id'] ) ? intval( $_POST['ticket_id'] ) : 0;
		if ( ! $ticket_id || FY_Fleet_Tickets::POST_TYPE !== get_post_type( $ticket_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Ticket not found.', 'fy-fleet' ) ), 404 );
		}

		// Build the conversation context.
		$thread = 'Subject: ' . get_the_title( $ticket_id ) . "\n";
		$thread .= 'Department: ' . get_post_meta( $ticket_id, '_fy_department', true ) . "\n\n";
		foreach ( FY_Fleet_Tickets::get_replies( $ticket_id ) as $reply ) {
			$who     = '1' === get_comment_meta( $reply->comment_ID, '_fy_is_staff', true ) ? 'STAFF' : 'CUSTOMER';
			$thread .= $who . ': ' . wp_strip_all_tags( $reply->comment_content ) . "\n\n";
		}

		$policy = implode( ' ', FY_Fleet_Settings::get_cancellation_lines() );
		$system = 'You draft replies for Feeling Yachty, a Miami luxury yacht charter company. '
			. 'Voice: warm, professional, concise, a touch of nautical fun. Always answer the customer\'s actual question first. '
			. 'Deposits reserve the date; the balance is paid at the dock. Cancellation policy: ' . $policy . ' '
			. 'Never invent prices or availability — if unknown, say the team will confirm. Reply with the message text only, no preamble.';

		$draft = self::complete_chat( $system, array( array( 'role' => 'user', 'content' => "Draft the next STAFF reply for this conversation:\n\n" . $thread ) ) );

		if ( is_wp_error( $draft ) ) {
			wp_send_json_error( array( 'message' => $draft->get_error_message() ), 500 );
		}
		wp_send_json_success( array( 'draft' => $draft ) );
	}

	/**
	 * Multi-turn completion — $messages is a list of {role: 'user'|'assistant', content: string},
	 * oldest first. Used for both the single-shot ticket-draft caller above (a
	 * one-message list) and the Support Bot's ongoing conversation (many turns).
	 *
	 * @param string      $system  System prompt.
	 * @param array       $messages List of {role, content} turns.
	 * @param string      $model_override Force a specific model regardless of the saved setting — e.g. the Support Bot always wants Sonnet 5, independent of whatever Checkout & Integrations has picked for ticket drafting.
	 * @return string|WP_Error
	 */
	public static function complete_chat( $system, array $messages, $model_override = '' ) {
		$s = self::settings();

		if ( 'openai' === $s['provider'] ) {
			$model      = $model_override ? $model_override : ( $s['model'] ? $s['model'] : 'gpt-4o-mini' );
			$oa_messages = array( array( 'role' => 'system', 'content' => $system ) );
			foreach ( $messages as $m ) {
				$oa_messages[] = array( 'role' => $m['role'], 'content' => $m['content'] );
			}
			$response = wp_remote_post(
				'https://api.openai.com/v1/chat/completions',
				array(
					'timeout' => 30,
					'headers' => array(
						'Authorization' => 'Bearer ' . $s['key'],
						'Content-Type'  => 'application/json',
					),
					'body'    => wp_json_encode(
						array(
							'model'      => $model,
							'messages'   => $oa_messages,
							'max_tokens' => 600,
						)
					),
				)
			);
			if ( is_wp_error( $response ) ) {
				return $response;
			}
			$data = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( isset( $data['choices'][0]['message']['content'] ) ) {
				return trim( $data['choices'][0]['message']['content'] );
			}
			return new WP_Error( 'fy_ai_bad', isset( $data['error']['message'] ) ? $data['error']['message'] : __( 'Unexpected AI response.', 'fy-fleet' ) );
		}

		// Anthropic (default).
		$model         = $model_override ? $model_override : ( $s['model'] ? $s['model'] : 'claude-sonnet-4-5' );
		$anthro_messages = array();
		foreach ( $messages as $m ) {
			$anthro_messages[] = array( 'role' => $m['role'], 'content' => $m['content'] );
		}
		$response = wp_remote_post(
			'https://api.anthropic.com/v1/messages',
			array(
				'timeout' => 30,
				'headers' => array(
					'x-api-key'         => $s['key'],
					'anthropic-version' => '2023-06-01',
					'Content-Type'      => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'model'      => $model,
						'max_tokens' => 600,
						'system'     => $system,
						'messages'   => $anthro_messages,
					)
				),
			)
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		// Claude sometimes returns an extended-thinking block ({"type":"thinking",...})
		// as content[0] BEFORE the actual reply — blindly indexing [0] silently
		// grabbed the thinking block's (missing) 'text' key and errored out on
		// a perfectly good response. Find the first block that's actually text.
		if ( isset( $data['content'] ) && is_array( $data['content'] ) ) {
			foreach ( $data['content'] as $block ) {
				if ( isset( $block['type'] ) && 'text' === $block['type'] && isset( $block['text'] ) ) {
					return trim( $block['text'] );
				}
			}
		}
		return new WP_Error( 'fy_ai_bad', isset( $data['error']['message'] ) ? $data['error']['message'] : __( 'Unexpected AI response.', 'fy-fleet' ) );
	}
}
