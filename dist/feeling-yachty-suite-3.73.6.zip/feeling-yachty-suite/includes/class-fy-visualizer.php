<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin "Fleet Visualizer": live preview of the real front-end design plus a
 * card grid for editing yachts one at a time without leaving the page.
 */
class FY_Fleet_Visualizer {

	const AJAX_SAVE         = 'fy_quick_save_yacht';
	const AJAX_BULK_DELETE  = 'fy_bulk_delete_yachts';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_action( 'wp_ajax_' . self::AJAX_SAVE, array( __CLASS__, 'ajax_save' ) );
		add_action( 'wp_ajax_' . self::AJAX_BULK_DELETE, array( __CLASS__, 'ajax_bulk_delete' ) );

		// Toolbar shortcut while browsing the site — sits beside "Edit with
		// Elementor", so spotting something wrong on a yacht page and fixing
		// it in the Visualizer is one click, not a dig through wp-admin.
		// Priority 81 lands it right after the Edit/Elementor group.
		add_action( 'admin_bar_menu', array( __CLASS__, 'admin_bar_link' ), 81 );
	}

	/** "⚓ Fleet Visualizer" button in the admin toolbar (front end and admin). */
	public static function admin_bar_link( $bar ) {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return;
		}
		$bar->add_node(
			array(
				'id'    => 'fy-fleet-visualizer',
				'title' => '⚓ ' . __( 'Fleet Visualizer', 'fy-fleet' ),
				'href'  => admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-visualizer' ),
				'meta'  => array( 'title' => __( 'Open the Yacht Fleet Visualizer', 'fy-fleet' ) ),
			)
		);
	}

	public static function add_menu() {
		add_submenu_page(
			'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE,
			__( 'Fleet Visualizer', 'fy-fleet' ),
			__( 'Fleet Visualizer', 'fy-fleet' ),
			'edit_posts',
			'fy-fleet-visualizer',
			array( __CLASS__, 'render_page' )
		);
	}

	public static function enqueue( $hook ) {
		if ( false === strpos( (string) $hook, 'fy-fleet-visualizer' ) ) {
			return;
		}
		wp_enqueue_style( 'fy-fleet-visualizer', FY_FLEET_URL . 'assets/visualizer.css', array(), FY_FLEET_VERSION );
		wp_enqueue_script( 'fy-fleet-visualizer', FY_FLEET_URL . 'assets/visualizer.js', array(), FY_FLEET_VERSION, true );
		wp_localize_script(
			'fy-fleet-visualizer',
			'fyVisualizer',
			array(
				'ajaxUrl'         => admin_url( 'admin-ajax.php' ),
				'nonce'           => wp_create_nonce( self::AJAX_SAVE ),
				'action'          => self::AJAX_SAVE,
				'bulkDeleteNonce' => wp_create_nonce( self::AJAX_BULK_DELETE ),
				'bulkDeleteAction'=> self::AJAX_BULK_DELETE,
				'i18n'    => array(
					'saving' => __( 'Saving…', 'fy-fleet' ),
					'saved'  => __( 'Saved', 'fy-fleet' ),
					'failed' => __( 'Save failed', 'fy-fleet' ),
					'confirmBulkDelete' => __( 'Remove %d yacht(s) from the fleet? Each card goes to the trash and its WooCommerce product is set to private — both recoverable, and past orders are unaffected.', 'fy-fleet' ),
					'deleting'          => __( 'Removing…', 'fy-fleet' ),
				),
			)
		);
	}

	private static function get_yachts( $city = '' ) {
		$query = array(
			'post_type'      => FY_Fleet_CPT::POST_TYPE,
			'post_status'    => array( 'publish', 'draft', 'pending' ),
			'posts_per_page' => -1,
			'orderby'        => 'title',
			'order'          => 'ASC',
		);
		if ( '' !== $city ) {
			$query['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery
				array(
					'taxonomy' => 'fy_yacht_cat',
					'field'    => 'slug',
					'terms'    => $city,
				),
			);
		}
		$yachts = get_posts( $query );
		usort(
			$yachts,
			function ( $a, $b ) {
				$sa = (float) get_post_meta( $a->ID, '_fy_size_ft', true );
				$sb = (float) get_post_meta( $b->ID, '_fy_size_ft', true );
				if ( $sa === $sb ) {
					return strcasecmp( get_the_title( $a ), get_the_title( $b ) );
				}
				return ( $sa < $sb ) ? -1 : 1;
			}
		);
		return $yachts;
	}

	public static function render_page() {
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'edit';
		$base = admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-visualizer' );

		// One visualizer per city: ?fy_city=panama-yacht-rentals shows ONLY that
		// city's yachts — the exact yacht set its Elementor widget displays.
		$city   = isset( $_GET['fy_city'] ) ? sanitize_title( wp_unslash( $_GET['fy_city'] ) ) : '';
		$cities = get_terms( array( 'taxonomy' => 'fy_yacht_cat', 'hide_empty' => false ) );
		$cities = is_wp_error( $cities ) ? array() : $cities;
		$city_q = $city ? '&fy_city=' . $city : '';

		$city_term = null;
		foreach ( $cities as $term ) {
			if ( $term->slug === $city ) {
				$city_term = $term;
			}
		}
		if ( $city && ! $city_term ) { // Unknown slug — fall back to all.
			$city   = '';
			$city_q = '';
		}

		$yachts = self::get_yachts( $city );

		$imported = isset( $_GET['fy_imported'] ) ? intval( $_GET['fy_imported'] ) : -1;
		$updated  = isset( $_GET['fy_updated'] ) ? intval( $_GET['fy_updated'] ) : 0;
		?>
		<div class="wrap fy-visualizer">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Fleet Visualizer', 'fy-fleet' ); ?></h1>
			<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=product' ) ); ?>" class="page-title-action">🛒 <?php esc_html_e( 'Add New Yacht (WooCommerce product)', 'fy-fleet' ); ?></a>

			<?php if ( $imported >= 0 ) : ?>
				<div class="notice notice-success is-dismissible"><p>
					<?php
					printf(
						/* translators: 1: created count, 2: updated count */
						esc_html__( 'Fleet import complete — %1$d yachts added, %2$d updated.', 'fy-fleet' ),
						$imported,
						$updated
					);
					?>
				</p></div>
			<?php endif; ?>

			<h2 class="nav-tab-wrapper fy-tabs">
				<a href="<?php echo esc_url( $base . '&tab=edit' . $city_q ); ?>" class="nav-tab <?php echo 'edit' === $tab ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Edit Yachts', 'fy-fleet' ); ?></a>
				<a href="<?php echo esc_url( $base . '&tab=preview' . $city_q ); ?>" class="nav-tab <?php echo 'preview' === $tab ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Live Preview', 'fy-fleet' ); ?></a>
				<?php if ( class_exists( 'FY_Fleet_Woo' ) && FY_Fleet_Woo::active() ) : ?>
					<a href="<?php echo esc_url( $base . '&tab=link' . $city_q ); ?>" class="nav-tab <?php echo 'link' === $tab ? 'nav-tab-active' : ''; ?>">🔗 <?php esc_html_e( 'Match Products', 'fy-fleet' ); ?></a>
				<?php endif; ?>
			</h2>

			<?php // One button per city — every city is its own visualizer + widget. ?>
			<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin:12px 0 4px">
				<span style="font-weight:700"><?php esc_html_e( 'City widget:', 'fy-fleet' ); ?></span>
				<a class="button <?php echo '' === $city ? 'button-primary' : ''; ?>" href="<?php echo esc_url( $base . '&tab=' . $tab ); ?>">🌎 <?php esc_html_e( 'All yachts', 'fy-fleet' ); ?></a>
				<?php foreach ( $cities as $term ) : ?>
					<a class="button <?php echo $term->slug === $city ? 'button-primary' : ''; ?>" href="<?php echo esc_url( $base . '&tab=' . $tab . '&fy_city=' . $term->slug ); ?>">
						<?php echo esc_html( $term->name ); ?> (<?php echo (int) $term->count; ?>)
					</a>
				<?php endforeach; ?>
				<a class="button" href="<?php echo esc_url( admin_url( 'edit-tags.php?taxonomy=fy_yacht_cat&post_type=' . FY_Fleet_CPT::POST_TYPE ) ); ?>">＋ <?php esc_html_e( 'New city', 'fy-fleet' ); ?></a>
			</div>

			<?php
			// The widget "ID card": the slug is the widget's unique id — same
			// value the Elementor City dropdown and the shortcode use.
			$widget_id        = $city ? $city : 'all';
			$widget_shortcode = $city ? '[fy_yacht_fleet fleet="' . $city . '"]' : '[fy_yacht_fleet]';
			?>
			<div style="margin:4px 0 14px;padding:10px 14px;background:#fff;border:1px solid #dcdcde;border-left:4px solid #C7347B;border-radius:8px;font-size:13px">
				🧩 <strong><?php echo $city_term ? esc_html( $city_term->name ) : esc_html__( 'All yachts', 'fy-fleet' ); ?></strong>
				— <?php esc_html_e( 'Widget ID:', 'fy-fleet' ); ?> <code><?php echo esc_html( $widget_id ); ?></code>
				· <?php esc_html_e( 'Shortcode:', 'fy-fleet' ); ?> <code><?php echo esc_html( $widget_shortcode ); ?></code><br>
				<span class="description"><?php esc_html_e( 'In Elementor: drop the “Yacht Fleet Finder” widget on any page and pick this city in its City dropdown — that page then shows ONLY these yachts. New yachts join the right widget automatically through their city.', 'fy-fleet' ); ?></span>
			</div>

			<?php if ( empty( $yachts ) && $city ) : ?>
				<div class="notice notice-warning"><p>
					<?php printf( esc_html__( 'No yachts in %s yet. Add one under Products → Add New, then tick this city in the Cities box (right sidebar) — it appears in this widget automatically.', 'fy-fleet' ), esc_html( $city_term ? $city_term->name : $city ) ); ?>
				</p></div>
			<?php elseif ( empty( $yachts ) ) : ?>
				<div class="notice notice-warning"><p>
					<?php esc_html_e( 'No yachts yet. Import the starter Miami fleet (48 yachts) to get going:', 'fy-fleet' ); ?>
				</p>
				<?php self::import_form(); ?>
				</div>
			<?php elseif ( 'link' === $tab ) : ?>
				<?php self::render_link_tab( $yachts ); ?>
			<?php elseif ( 'preview' === $tab ) : ?>
				<?php
				$mode     = ( isset( $_GET['fy_pv'] ) && 'product' === $_GET['fy_pv'] ) ? 'product' : 'grid';
				$pv_yacht = isset( $_GET['fy_pv_yacht'] ) ? intval( $_GET['fy_pv_yacht'] ) : ( $yachts ? $yachts[0]->ID : 0 );
				$pv_base  = $base . '&tab=preview' . $city_q;
				?>
				<div class="fy-device-bar" role="group" aria-label="<?php esc_attr_e( 'Preview type', 'fy-fleet' ); ?>" style="margin-bottom:8px">
					<a class="button <?php echo 'grid' === $mode ? 'button-primary' : ''; ?>" href="<?php echo esc_url( $pv_base ); ?>">🛥️ <?php esc_html_e( 'Fleet widget', 'fy-fleet' ); ?></a>
					<a class="button <?php echo 'product' === $mode ? 'button-primary' : ''; ?>" href="<?php echo esc_url( $pv_base . '&fy_pv=product' ); ?>">🛒 <?php esc_html_e( 'Product page (the shortcodes)', 'fy-fleet' ); ?></a>
					<?php if ( 'product' === $mode ) : ?>
						<select onchange="location='<?php echo esc_url( $pv_base . '&fy_pv=product' ); ?>&fy_pv_yacht='+this.value">
							<?php foreach ( $yachts as $y ) : ?>
								<option value="<?php echo esc_attr( $y->ID ); ?>" <?php selected( $pv_yacht, $y->ID ); ?>><?php echo esc_html( $y->post_title ); ?></option>
							<?php endforeach; ?>
						</select>
					<?php endif; ?>
				</div>

				<p class="description fy-preview-note">
					<?php if ( 'product' === $mode ) : ?>
						<?php esc_html_e( 'Exactly what the WooCommerce product description shows: this yacht\'s [fy_yacht_…] shortcodes, rendered in the order they sit in the product editor. On the live page, WooCommerce adds the title, photo and Add to Cart around it.', 'fy-fleet' ); ?>
					<?php else : ?>
						<?php esc_html_e( 'This is the real front-end output, exactly as visitors will see it. Filters, search and sorting all work here.', 'fy-fleet' ); ?>
					<?php endif; ?>
				</p>

				<div class="fy-device-bar" role="group" aria-label="<?php esc_attr_e( 'Preview device size', 'fy-fleet' ); ?>">
					<button type="button" class="button fy-device-btn is-active" data-device="desktop">🖥️ <?php esc_html_e( 'Desktop', 'fy-fleet' ); ?></button>
					<button type="button" class="button fy-device-btn" data-device="tablet">📱 <?php esc_html_e( 'Tablet — 768px', 'fy-fleet' ); ?></button>
					<button type="button" class="button fy-device-btn" data-device="mobile">📲 <?php esc_html_e( 'Mobile — 390px', 'fy-fleet' ); ?></button>
					<span class="fy-device-hint"><?php esc_html_e( 'See exactly what clients see on each screen size.', 'fy-fleet' ); ?></span>
				</div>

				<?php
				// An iframe gives the preview its own real viewport, so the
				// grid's responsive breakpoints behave exactly as on a phone.
				// The grid's CSS/JS live in enqueued files now, so the iframe
				// must load them itself or the preview renders unstyled.
				if ( 'product' === $mode ) {
					$body = '<div style="max-width:760px;margin:0 auto;padding:24px 18px;font-family:ui-sans-serif,system-ui,-apple-system,\'Segoe UI\',Roboto,Arial,sans-serif">'
						. self::product_preview_html( $pv_yacht )
						. '<div style="margin:26px 0 0;padding:16px;border:2px dashed #C7347B;border-radius:14px;text-align:center;color:#C7347B;font-weight:800">🛒 '
						. esc_html__( 'On the live product page, the WooCommerce “Add to cart” (deposit price) sits with the title and photo above this description.', 'fy-fleet' )
						. '</div></div>';
				} else {
					// Render THIS city's widget — identical to the Elementor
					// output with the same city picked in its dropdown.
					$body = FY_Fleet_Render::render( array( 'fleet' => $city ) )
						. '<script src="' . esc_url( FY_FLEET_URL . 'assets/fleet.js?v=' . FY_FLEET_VERSION ) . '"></script>';
				}
				$preview_html = '<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">'
					. '<link rel="stylesheet" href="' . esc_url( FY_FLEET_URL . 'assets/fleet.css?v=' . FY_FLEET_VERSION ) . '">'
					. '<style>' . FY_Fleet_Settings::color_override_css() . '</style>'
					. '</head><body style="margin:0">'
					. $body
					. '</body></html>';
				?>
				<div class="fy-preview-frame" id="fy-preview-frame" data-device="desktop">
					<iframe id="fy-preview-iframe" srcdoc="<?php echo esc_attr( $preview_html ); ?>" title="<?php esc_attr_e( 'Fleet preview', 'fy-fleet' ); ?>" style="width:100%;height:1500px;border:0;display:block"></iframe>
				</div>
				<?php if ( 'grid' === $mode ) : ?>
					<p class="description"><?php esc_html_e( 'Note: the Book button is inactive inside this preview — it works on the live page.', 'fy-fleet' ); ?></p>
				<?php endif; ?>
			<?php else : ?>
				<p class="description fy-edit-note">
					<?php
					printf(
						/* translators: %d: yacht count */
						esc_html__( '%d yachts, ordered smallest to largest exactly as they appear on the site. Edit the common fields inline and click Save — for badges and hours/pricing rows, open the full editor.', 'fy-fleet' ),
						count( $yachts )
					);
					?>
				</p>
				<?php if ( isset( $_GET['fy_synced'] ) ) : ?>
					<div class="notice notice-success is-dismissible"><p><?php printf( esc_html__( '%d yacht products re-synced (descriptions, deposit prices, button URLs, images).', 'fy-fleet' ), intval( $_GET['fy_synced'] ) ); ?></p></div>
				<?php endif; ?>
				<?php if ( isset( $_GET['fy_matched'] ) ) : ?>
					<div class="notice notice-success is-dismissible"><p><?php printf( esc_html__( '🔗 %d yacht/product matches saved.', 'fy-fleet' ), intval( $_GET['fy_matched'] ) ); ?></p></div>
				<?php endif; ?>
				<?php if ( isset( $_GET['fy_city_urls_fixed'] ) ) : ?>
					<div class="notice notice-success is-dismissible"><p><?php printf( esc_html__( '🔧 %d “Book Experience” links repointed to their yacht’s current city URL.', 'fy-fleet' ), intval( $_GET['fy_city_urls_fixed'] ) ); ?></p></div>
				<?php endif; ?>
				<?php if ( isset( $_GET['fy_demo_seeded'] ) && current_user_can( 'manage_options' ) ) : ?>
					<?php
					$demo_creds = get_transient( 'fy_demo_seed_result_' . get_current_user_id() );
					delete_transient( 'fy_demo_seed_result_' . get_current_user_id() ); // shown once, then gone.
					?>
					<?php if ( $demo_creds ) : ?>
						<div class="notice notice-success" style="padding:16px">
							<p><strong>🧪 <?php esc_html_e( 'Demo accounts are ready — log in as either to see the whole portal exactly as a real user would.', 'fy-fleet' ); ?></strong></p>
							<table class="widefat" style="max-width:760px;margin-top:8px">
								<thead><tr><th><?php esc_html_e( 'Region', 'fy-fleet' ); ?></th><th><?php esc_html_e( 'Username', 'fy-fleet' ); ?></th><th><?php esc_html_e( 'Password', 'fy-fleet' ); ?></th><th><?php esc_html_e( 'Their yacht (owner view)', 'fy-fleet' ); ?></th></tr></thead>
								<tbody>
								<?php foreach ( $demo_creds as $region => $c ) : ?>
									<tr>
										<td><?php echo esc_html( ucfirst( $region ) ); ?></td>
										<?php if ( ! empty( $c['error'] ) ) : ?>
											<td colspan="3"><?php echo esc_html( $c['error'] ); ?></td>
										<?php else : ?>
											<td><code><?php echo esc_html( $c['login'] ); ?></code></td>
											<td><code><?php echo esc_html( $c['password'] ); ?></code></td>
											<td><?php echo esc_html( $c['owned_yacht'] ); ?></td>
										<?php endif; ?>
									</tr>
								<?php endforeach; ?>
								</tbody>
							</table>
							<p class="description" style="margin-top:8px"><?php esc_html_e( 'Log out of wp-admin (or use a private window) and sign in on the front end as one of these — real orders, a real owned yacht with a blocked date, and a real submitted review are already in place. Running this again resets and reseeds both accounts.', 'fy-fleet' ); ?></p>
						</div>
					<?php else : ?>
						<div class="notice notice-warning"><p><?php esc_html_e( 'Demo data was seeded, but the credentials already expired from view — click Seed demo account again to see them.', 'fy-fleet' ); ?></p></div>
					<?php endif; ?>
				<?php endif; ?>
				<?php if ( isset( $_GET['fy_removed'] ) ) : ?>
					<div class="notice notice-success is-dismissible"><p>
						<?php printf( esc_html__( '🗑️ “%s” removed from the fleet. The card is in the trash and its product is now private, so customers cannot reach it — restore the card from Trash to undo.', 'fy-fleet' ), esc_html( sanitize_text_field( wp_unslash( $_GET['fy_removed'] ) ) ) ); ?>
					</p></div>
				<?php endif; ?>
				<?php if ( isset( $_GET['fy_linked'] ) ) : ?>
					<div class="notice notice-success is-dismissible"><p>
						<?php printf( esc_html__( '🔗 %1$d yachts linked to products you already had. %2$d could not be matched by name — open those products and pick the yacht from the “Already have a yacht card?” dropdown.', 'fy-fleet' ), intval( $_GET['fy_linked'] ), isset( $_GET['fy_unmatched'] ) ? intval( $_GET['fy_unmatched'] ) : 0 ); ?>
					</p></div>
				<?php endif; ?>

				<?php
				// Yachts with no product yet. Re-syncing while these exist would
				// CREATE products for them — duplicating any the owner already
				// built by hand — so warn and offer linking first.
				$fy_unlinked = 0;
				foreach ( $yachts as $fy_y ) {
					$fy_pid = (int) get_post_meta( $fy_y->ID, '_fy_product_id', true );
					if ( ! $fy_pid || 'product' !== get_post_type( $fy_pid ) ) {
						$fy_unlinked++;
					}
				}
				?>
				<?php if ( $fy_unlinked && class_exists( 'FY_Fleet_Woo' ) && FY_Fleet_Woo::active() ) : ?>
					<div class="notice notice-warning"><p>
						<strong><?php printf( esc_html__( '%d yachts have no WooCommerce product linked.', 'fy-fleet' ), $fy_unlinked ); ?></strong><br>
						<?php esc_html_e( 'Their [fy_yacht_…] blocks render empty on the product page, because the product does not know which yacht it belongs to.', 'fy-fleet' ); ?><br>
						<?php esc_html_e( 'If you already built those products by hand, click “Link products to yachts” FIRST — re-syncing before linking would create a second copy of every product.', 'fy-fleet' ); ?>
					</p>
					<p>
						<a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=fy_link_products' ), 'fy_link_products' ) ); ?>">
							🔗 <?php esc_html_e( 'Link products to yachts (match by name)', 'fy-fleet' ); ?>
						</a>
					</p></div>
				<?php endif; ?>

				<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:0 0 12px">
					<?php self::import_form( true ); ?>
					<?php if ( class_exists( 'FY_Fleet_Woo' ) && FY_Fleet_Woo::active() ) : ?>
						<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=fy_sync_products' ), 'fy_sync_products' ) ); ?>">
							🔄 <?php esc_html_e( 'Re-sync all yacht products', 'fy-fleet' ); ?>
						</a>
						<span class="description"><?php esc_html_e( 'Updates every WooCommerce product from its yacht: descriptions, deposit prices, missing button URLs and images. Image imports pause at ~20s — click again to continue.', 'fy-fleet' ); ?></span>
						<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=fy_fix_city_urls' ), 'fy_fix_city_urls' ) ); ?>">
							🔧 <?php esc_html_e( 'Fix mismatched city links', 'fy-fleet' ); ?>
						</a>
						<span class="description"><?php esc_html_e( 'Repoints any “Book Experience” button still using an old city slug (e.g. /miami-yacht-rentals/ instead of /miami-yacht-rental/) to that yacht’s real product page. Links you pointed somewhere else on purpose are left alone.', 'fy-fleet' ); ?></span>
					<?php endif; ?>
					<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=fy_flush_grid_cache' ), 'fy_flush_grid_cache' ) ); ?>">
						♻️ <?php esc_html_e( 'Refresh fleet page', 'fy-fleet' ); ?>
					</a>
					<span class="description"><?php esc_html_e( 'Your fleet page is saved as a ready-made copy so it loads fast for visitors. It refreshes itself whenever you edit a yacht or re-sync products — use this only if the page still looks out of date.', 'fy-fleet' ); ?></span>
					<?php if ( class_exists( 'FY_Fleet_Demo_Seed' ) ) : ?>
						<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=fy_seed_demo_account' ), 'fy_seed_demo_account' ) ); ?>">
							🧪 <?php esc_html_e( 'Seed demo account', 'fy-fleet' ); ?>
						</a>
						<span class="description"><?php esc_html_e( 'Creates (or resets) a real test account — an owner with a live yacht and a client with real past and upcoming bookings — so you can log in and see the whole account portal exactly as a real user would.', 'fy-fleet' ); ?></span>
					<?php endif; ?>
				</div>

				<div class="fy-vis-toolbar">
					<input type="search" id="fy-vis-search" placeholder="🔎 <?php esc_attr_e( 'Find a yacht by name…', 'fy-fleet' ); ?>">
					<select id="fy-vis-sort">
						<option value="size-asc"><?php esc_html_e( 'Size: Small → Large', 'fy-fleet' ); ?></option>
						<option value="size-desc"><?php esc_html_e( 'Size: Large → Small', 'fy-fleet' ); ?></option>
						<option value="price-asc"><?php esc_html_e( 'Price: Low → High', 'fy-fleet' ); ?></option>
						<option value="price-desc"><?php esc_html_e( 'Price: High → Low', 'fy-fleet' ); ?></option>
						<option value="name"><?php esc_html_e( 'Name: A → Z', 'fy-fleet' ); ?></option>
					</select>
					<span class="fy-vis-count" id="fy-vis-count"></span>
				</div>

				<div class="fy-vis-bulkbar" id="fy-vis-bulkbar">
					<label class="fy-vis-bulk-selectall"><input type="checkbox" id="fy-vis-select-all"> <?php esc_html_e( 'Select all', 'fy-fleet' ); ?></label>
					<span id="fy-vis-bulk-count" class="fy-vis-bulk-count"><?php esc_html_e( '0 selected', 'fy-fleet' ); ?></span>
					<button type="button" class="button fy-vis-bulk-delete" id="fy-vis-bulk-delete" disabled>🗑️ <?php esc_html_e( 'Remove Selected', 'fy-fleet' ); ?></button>
				</div>

				<div class="fy-vis-grid">
					<?php foreach ( $yachts as $yacht ) : ?>
						<?php self::render_card( $yacht ); ?>
					<?php endforeach; ?>
				</div>
				<script type="text/template" id="fy-vis-prow-price"><?php self::render_pricing_row( array( 'type' => 'price' ) ); ?></script>
				<script type="text/template" id="fy-vis-prow-heading"><?php self::render_pricing_row( array( 'type' => 'heading' ) ); ?></script>
				<script type="text/template" id="fy-vis-prow-note"><?php self::render_pricing_row( array( 'type' => 'note' ) ); ?></script>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * The yacht's WooCommerce product description, rendered the way the live
	 * product page renders it: the REAL stored [fy_yacht_*] shortcode stack in
	 * the owner's order, with the yacht pinned explicitly (admin has no "current
	 * product" for auto-detection). Falls back to the default full build.
	 */
	private static function product_preview_html( $yacht_id ) {
		if ( ! $yacht_id || ! class_exists( 'FY_Fleet_Woo' ) || FY_Fleet_CPT::POST_TYPE !== get_post_type( $yacht_id ) ) {
			return '<p>' . esc_html__( 'Pick a yacht from the dropdown above.', 'fy-fleet' ) . '</p>';
		}
		$product_id = (int) get_post_meta( $yacht_id, '_fy_product_id', true );
		$desc       = ( $product_id && 'product' === get_post_type( $product_id ) ) ? (string) get_post_field( 'post_content', $product_id ) : '';
		if ( '' !== $desc && false !== strpos( $desc, '[fy_yacht_' ) ) {
			$desc = preg_replace( '/\[(fy_yacht_[a-z_]+)/', '[$1 yacht="' . (int) $yacht_id . '"', $desc );
			return do_shortcode( $desc );
		}
		return FY_Fleet_Woo::build_product_description( $yacht_id );
	}

	/**
	 * "Match Products" tab — one row per yacht showing whether it is joined to
	 * a WooCommerce product, with a dropdown to set or change it by hand.
	 * Everything the shortcodes need hangs off this link, so this screen is the
	 * one place to see and fix the whole fleet at a glance.
	 */
	private static function render_link_tab( $yachts ) {
		$products = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);

		// Which yacht (if any) currently owns each product.
		$owner_of = array();
		foreach ( $products as $product ) {
			$owner = (int) get_post_meta( $product->ID, '_fy_yacht_id', true );
			if ( $owner && FY_Fleet_CPT::POST_TYPE === get_post_type( $owner ) ) {
				$owner_of[ $product->ID ] = $owner;
			}
		}

		$matched = 0;
		foreach ( $yachts as $yacht ) {
			if ( FY_Fleet_Woo::get_product_id( $yacht->ID ) ) {
				$matched++;
			}
		}
		$missing = count( $yachts ) - $matched;
		?>
		<p class="description" style="max-width:900px">
			<?php esc_html_e( 'Every [fy_yacht_…] block asks the product “which yacht am I?”. That answer is this link — without it the blocks render empty, no matter what the yacht contains. Set any that are missing below.', 'fy-fleet' ); ?>
		</p>

		<p style="font-size:14px;font-weight:700;margin:12px 0">
			<span style="color:#00a32a">✅ <?php printf( esc_html__( '%d matched', 'fy-fleet' ), $matched ); ?></span>
			&nbsp;·&nbsp;
			<span style="color:<?php echo $missing ? '#b32d2e' : '#646970'; ?>">⚠️ <?php printf( esc_html__( '%d not matched', 'fy-fleet' ), $missing ); ?></span>
		</p>

		<?php if ( $missing ) : ?>
			<p>
				<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=fy_link_products' ), 'fy_link_products' ) ); ?>">
					🪄 <?php esc_html_e( 'Auto-match the rest by name', 'fy-fleet' ); ?>
				</a>
				<span class="description" style="margin-left:8px"><?php esc_html_e( 'Fills in every yacht whose product has the same title, then you handle the leftovers here.', 'fy-fleet' ); ?></span>
			</p>
		<?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="fy_save_links">
			<?php wp_nonce_field( 'fy_save_links' ); ?>

			<p>
				<label style="font-weight:700">
					<input type="checkbox" name="fy_sync_after" value="1" checked>
					<?php esc_html_e( 'After linking, update each product from its yacht', 'fy-fleet' ); ?>
				</label><br>
				<span class="description"><?php esc_html_e( 'Recommended — this is what fills the description with the shortcodes and sets the price to the deposit. Untick to link only and leave the product’s current price and text untouched.', 'fy-fleet' ); ?></span>
			</p>

			<table class="widefat striped">
				<thead>
					<tr>
						<th style="width:32%"><?php esc_html_e( 'Yacht', 'fy-fleet' ); ?></th>
						<th style="width:14%"><?php esc_html_e( 'Status', 'fy-fleet' ); ?></th>
						<th><?php esc_html_e( 'WooCommerce product', 'fy-fleet' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $yachts as $yacht ) : ?>
					<?php
					$current = FY_Fleet_Woo::get_product_id( $yacht->ID );
					$size    = get_post_meta( $yacht->ID, '_fy_size_ft', true );
					?>
					<tr>
						<td>
							<strong><?php echo esc_html( $yacht->post_title ); ?></strong>
							<div class="description">
								<?php echo $size ? esc_html( $size . 'ft' ) : ''; ?>
								<?php echo 'publish' !== $yacht->post_status ? ' · ' . esc_html( ucfirst( $yacht->post_status ) ) : ''; ?>
							</div>
						</td>
						<td>
							<?php if ( $current ) : ?>
								<span style="color:#00a32a;font-weight:700">✅ <?php esc_html_e( 'Matched', 'fy-fleet' ); ?></span><br>
								<a href="<?php echo esc_url( get_permalink( $current ) ); ?>" target="_blank" class="description"><?php esc_html_e( 'view page', 'fy-fleet' ); ?></a>
							<?php else : ?>
								<span style="color:#b32d2e;font-weight:700">⚠️ <?php esc_html_e( 'No product', 'fy-fleet' ); ?></span><br>
								<span class="description"><?php esc_html_e( 'blocks empty', 'fy-fleet' ); ?></span>
							<?php endif; ?>
						</td>
						<td>
							<select name="fy_link[<?php echo esc_attr( $yacht->ID ); ?>]" style="max-width:100%;width:420px">
								<option value="0"><?php esc_html_e( '— none —', 'fy-fleet' ); ?></option>
								<?php foreach ( $products as $product ) : ?>
									<?php
									$taken = isset( $owner_of[ $product->ID ] ) && (int) $owner_of[ $product->ID ] !== (int) $yacht->ID;
									$label = $product->post_title;
									if ( 'publish' !== $product->post_status ) {
										$label .= ' (' . $product->post_status . ')';
									}
									if ( $taken ) {
										/* translators: %s: the other yacht's name */
										$label .= ' — ' . sprintf( __( 'already on %s', 'fy-fleet' ), get_the_title( $owner_of[ $product->ID ] ) );
									}
									?>
									<option value="<?php echo esc_attr( $product->ID ); ?>" <?php selected( $current, $product->ID ); ?>>
										<?php echo esc_html( $label ); ?>
									</option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<?php submit_button( __( 'Save matches', 'fy-fleet' ) ); ?>
			<p class="description">
				<?php esc_html_e( 'Choosing a product that already belongs to another yacht moves it — the previous yacht is left with no product, so nothing is ever shared by two.', 'fy-fleet' ); ?>
			</p>
		</form>
		<?php
	}

	private static function import_form( $compact = false ) {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="fy-import-form">
			<input type="hidden" name="action" value="fy_import_fleet">
			<?php wp_nonce_field( 'fy_import_fleet' ); ?>
			<button type="submit" class="button<?php echo $compact ? '' : ' button-primary'; ?>"
				onclick="return confirm('<?php echo esc_js( __( 'Import the starter Miami fleet? Yachts matched by name will be updated; anything else is left alone.', 'fy-fleet' ) ); ?>');">
				<?php esc_html_e( 'Import / Restore Starter Fleet (48 yachts)', 'fy-fleet' ); ?>
			</button>
		</form>
		<?php
	}

	private static function render_card( $yacht ) {
		$id        = $yacht->ID;
		$size      = get_post_meta( $id, '_fy_size_ft', true );
		$capacity  = get_post_meta( $id, '_fy_capacity_max', true );
		$price     = get_post_meta( $id, '_fy_price', true );
		$duration  = get_post_meta( $id, '_fy_duration_label', true );
		$note      = get_post_meta( $id, '_fy_price_note', true );
		$image_url = get_post_meta( $id, '_fy_image_url', true );
		$button    = get_post_meta( $id, '_fy_button_url', true );
		$is_pink   = get_post_meta( $id, '_fy_is_pink', true );
		$is_free   = get_post_meta( $id, '_fy_is_free_hour', true );
		$rows      = get_post_meta( $id, '_fy_pricing', true );
		$rows      = is_array( $rows ) ? $rows : array();
		$badges    = get_post_meta( $id, '_fy_badges', true );
		$badges    = is_array( $badges ) ? $badges : array();
		$owner     = get_post_meta( $id, '_fy_source_owner', true );

		$thumb = get_the_post_thumbnail_url( $id, 'medium' );
		$shown = $thumb ? $thumb : $image_url;

		$hour_count = 0;
		foreach ( $rows as $row ) {
			if ( ! isset( $row['type'] ) || 'price' === $row['type'] ) {
				$hour_count++;
			}
		}
		?>
		<div class="fy-vis-card" data-yacht-id="<?php echo esc_attr( $id ); ?>"
			data-title="<?php echo esc_attr( strtolower( $yacht->post_title ) ); ?>"
			data-size="<?php echo esc_attr( (float) $size ); ?>"
			data-price="<?php echo esc_attr( (float) $price ); ?>">
			<div class="fy-vis-media">
				<label class="fy-vis-select" title="<?php esc_attr_e( 'Select for bulk remove', 'fy-fleet' ); ?>">
					<input type="checkbox" class="fy-vis-select-check" value="<?php echo esc_attr( $id ); ?>">
				</label>
				<?php // All ~230 yachts render at once here (staff scan/Ctrl+F the whole fleet), so without this the browser fetches every thumbnail on open. ?>
				<img class="fy-vis-thumb" src="<?php echo esc_url( $shown ); ?>" alt="" loading="lazy" decoding="async" <?php echo $shown ? '' : 'style="display:none"'; ?>>
				<div class="fy-vis-thumb-empty" <?php echo $shown ? 'style="display:none"' : ''; ?>><?php esc_html_e( 'No photo', 'fy-fleet' ); ?></div>
				<?php if ( 'publish' !== $yacht->post_status ) : ?>
					<span class="fy-vis-status"><?php echo esc_html( ucfirst( $yacht->post_status ) ); ?></span>
				<?php endif; ?>
				<?php
				// Product link state — the one thing that decides whether the
				// [fy_yacht_*] blocks render anything on the product page.
				$card_woo_on  = class_exists( 'FY_Fleet_Woo' ) && FY_Fleet_Woo::active();
				$card_product = $card_woo_on ? FY_Fleet_Woo::get_product_id( $id ) : 0;
				?>
				<?php if ( $card_woo_on && ! $card_product ) : ?>
					<a class="fy-vis-link-flag is-missing" href="<?php echo esc_url( admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-visualizer&tab=link' ) ); ?>" title="<?php esc_attr_e( 'No WooCommerce product linked — the shortcode blocks render empty. Click to match it.', 'fy-fleet' ); ?>">⚠️ <?php esc_html_e( 'No product', 'fy-fleet' ); ?></a>
				<?php elseif ( $card_woo_on ) : ?>
					<span class="fy-vis-link-flag is-ok" title="<?php esc_attr_e( 'Linked to its WooCommerce product — the shortcode blocks will render.', 'fy-fleet' ); ?>">🔗 <?php esc_html_e( 'Matched', 'fy-fleet' ); ?></span>
				<?php endif; ?>
			</div>

			<div class="fy-vis-body">
				<label class="fy-vis-label"><?php esc_html_e( 'Name', 'fy-fleet' ); ?>
					<input type="text" class="fy-f" data-field="title" value="<?php echo esc_attr( $yacht->post_title ); ?>">
				</label>

				<?php if ( '' !== trim( (string) $owner ) ) : ?>
					<p class="fy-vis-meta" title="<?php esc_attr_e( 'Internal reference only — never shown on the site, WooCommerce product, or gallery.', 'fy-fleet' ); ?>">🗂️ <?php printf( esc_html__( 'Source owner: %s', 'fy-fleet' ), esc_html( $owner ) ); ?></p>
				<?php endif; ?>

				<div class="fy-vis-row3">
					<label class="fy-vis-label"><?php esc_html_e( 'Size (ft)', 'fy-fleet' ); ?>
						<input type="number" class="fy-f" data-field="size" value="<?php echo esc_attr( $size ); ?>">
					</label>
					<?php
					// Say which it is, per yacht — the imported fleet stores an
					// hourly rate here, the older listings a whole-charter price.
					$price_hourly = class_exists( 'FY_Fleet_Pricing' ) && FY_Fleet_Pricing::starting_price_is_hourly( $id );
					?>
					<label class="fy-vis-label"><?php echo $price_hourly ? esc_html__( 'Price ($ per hour)', 'fy-fleet' ) : esc_html__( 'Price ($ total)', 'fy-fleet' ); ?>
						<input type="number" step="0.01" class="fy-f" data-field="price" value="<?php echo esc_attr( $price ); ?>">
					</label>
					<label class="fy-vis-label"><?php esc_html_e( 'Max guests', 'fy-fleet' ); ?>
						<input type="number" class="fy-f" data-field="capacity" value="<?php echo esc_attr( $capacity ); ?>" placeholder="<?php echo esc_attr( FY_Fleet_CPT::DEFAULT_CAPACITY ); ?>">
					</label>
				</div>

				<label class="fy-vis-label"><?php esc_html_e( 'Starting duration', 'fy-fleet' ); ?>
					<input type="text" class="fy-f" data-field="duration" value="<?php echo esc_attr( $duration ); ?>">
				</label>

				<label class="fy-vis-label"><?php esc_html_e( 'Price note', 'fy-fleet' ); ?>
					<input type="text" class="fy-f" data-field="note" value="<?php echo esc_attr( $note ); ?>">
				</label>

				<label class="fy-vis-label"><?php esc_html_e( 'Image URL', 'fy-fleet' ); ?>
					<input type="url" class="fy-f fy-vis-image-input" data-field="image_url" value="<?php echo esc_attr( $image_url ); ?>">
				</label>

				<label class="fy-vis-label"><?php esc_html_e( 'Button URL (WooCommerce, booking, etc.)', 'fy-fleet' ); ?>
					<input type="url" class="fy-f" data-field="button_url" value="<?php echo esc_attr( $button ); ?>">
				</label>

				<div class="fy-vis-checks">
					<label><input type="checkbox" class="fy-f" data-field="pink" <?php checked( $is_pink, '1' ); ?>> <?php esc_html_e( 'Pink', 'fy-fleet' ); ?></label>
					<label><input type="checkbox" class="fy-f" data-field="free" <?php checked( $is_free, '1' ); ?>> <?php esc_html_e( 'Free hour', 'fy-fleet' ); ?></label>
				</div>

				<details class="fy-vis-pricing">
					<summary>
						⏱️ <?php printf( esc_html__( 'Hours & Pricing — %d rows (click to edit)', 'fy-fleet' ), count( $rows ) ); ?>
					</summary>
					<div class="fy-vis-rows">
						<?php foreach ( $rows as $row ) : ?>
							<?php self::render_pricing_row( $row ); ?>
						<?php endforeach; ?>
					</div>
					<div class="fy-vis-row-buttons">
						<button type="button" class="button button-small fy-vis-add-row" data-row-type="price">+ <?php esc_html_e( 'Price', 'fy-fleet' ); ?></button>
						<button type="button" class="button button-small fy-vis-add-row" data-row-type="heading">+ <?php esc_html_e( 'Day heading', 'fy-fleet' ); ?></button>
						<button type="button" class="button button-small fy-vis-add-row" data-row-type="note">+ <?php esc_html_e( 'Note', 'fy-fleet' ); ?></button>
					</div>
				</details>
				<p class="fy-vis-meta"><?php printf( esc_html__( '%d badges — edit in the full editor', 'fy-fleet' ), count( $badges ) ); ?></p>

				<div class="fy-vis-actions">
					<button type="button" class="button button-primary fy-vis-save"><?php esc_html_e( 'Save', 'fy-fleet' ); ?></button>
					<a class="button" href="<?php echo esc_url( get_edit_post_link( $id ) ); ?>"><?php esc_html_e( 'Full editor →', 'fy-fleet' ); ?></a>
					<a class="button" href="<?php echo esc_url( FY_Fleet_CPT::duplicate_url( $id ) ); ?>" title="<?php esc_attr_e( 'Copy this yacht as a new draft — its own product, URL and photo included', 'fy-fleet' ); ?>">⧉ <?php esc_html_e( 'Duplicate', 'fy-fleet' ); ?></a>
					<?php $vis_product_id = (int) get_post_meta( $id, '_fy_product_id', true ); ?>
					<?php if ( $vis_product_id && 'product' === get_post_type( $vis_product_id ) ) : ?>
						<a class="button" href="<?php echo esc_url( get_edit_post_link( $vis_product_id ) ); ?>" title="<?php esc_attr_e( 'Open the WooCommerce product — the page customers buy on', 'fy-fleet' ); ?>">🛒 <?php esc_html_e( 'Product', 'fy-fleet' ); ?></a>
					<?php endif; ?>
					<?php if ( current_user_can( 'delete_post', $id ) ) : ?>
						<a class="button fy-vis-remove" href="<?php echo esc_url( FY_Fleet_CPT::delete_url( $id ) ); ?>"
							title="<?php esc_attr_e( 'Take this yacht off the site. The card goes to the trash and its product is set to private — both recoverable, and past orders keep working.', 'fy-fleet' ); ?>"
							onclick="return confirm('<?php echo esc_js( sprintf( __( "Remove %s from the fleet?\n\nThe yacht card moves to the trash and its WooCommerce product is set to private, so customers can no longer reach it. Nothing is permanently deleted, and past orders are unaffected.", 'fy-fleet' ), $yacht->post_title ) ); ?>');">🗑️ <?php esc_html_e( 'Remove', 'fy-fleet' ); ?></a>
					<?php endif; ?>
					<span class="fy-vis-msg" aria-live="polite"></span>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * One pricing row in the inline editor. Also used (with empty $row) as the
	 * template that JS clones for the add buttons.
	 */
	public static function render_pricing_row( $row ) {
		$type     = isset( $row['type'] ) ? $row['type'] : 'price';
		$duration = isset( $row['duration'] ) ? $row['duration'] : '';
		$price    = isset( $row['price'] ) ? $row['price'] : '';
		$free     = ! empty( $row['free'] );
		$text     = isset( $row['text'] ) ? $row['text'] : '';
		?>
		<div class="fy-vis-prow fy-vis-prow-<?php echo esc_attr( $type ); ?>" data-row-type="<?php echo esc_attr( $type ); ?>">
			<?php if ( 'heading' === $type ) : ?>
				<span class="fy-vis-prow-tag">📅</span>
				<input type="text" class="fy-vis-prow-text" value="<?php echo esc_attr( $text ); ?>" placeholder="<?php esc_attr_e( 'Monday–Thursday', 'fy-fleet' ); ?>">
			<?php elseif ( 'note' === $type ) : ?>
				<span class="fy-vis-prow-tag">📝</span>
				<input type="text" class="fy-vis-prow-text" value="<?php echo esc_attr( $text ); ?>" placeholder="<?php esc_attr_e( 'Weekend surcharge — $150', 'fy-fleet' ); ?>">
			<?php else : ?>
				<input type="text" class="fy-vis-prow-duration" value="<?php echo esc_attr( $duration ); ?>" placeholder="<?php esc_attr_e( '3 Hours', 'fy-fleet' ); ?>">
				<?php
				// step="1" whole-number stepping was the actual bug behind
				// "floating values not saved": on a phone it makes the numeric
				// keypad omit the decimal key entirely, and the spinner arrows/
				// arrow keys round to the nearest whole number either way — so
				// a price like 712.50 (from a $237.50/hr yacht) loses its
				// cents the moment the field is touched again, even though
				// the server side already stores it as a proper float.
				?>
				<input type="number" min="0" step="0.01" class="fy-vis-prow-price" value="<?php echo esc_attr( $price ); ?>" placeholder="$">
				<label class="fy-vis-prow-free" title="<?php esc_attr_e( 'Free-hour row style', 'fy-fleet' ); ?>">
					<input type="checkbox" class="fy-vis-prow-freecheck" <?php checked( $free ); ?>> <?php esc_html_e( 'Free hr', 'fy-fleet' ); ?>
				</label>
			<?php endif; ?>
			<button type="button" class="button-link-delete fy-vis-prow-remove" aria-label="<?php esc_attr_e( 'Remove row', 'fy-fleet' ); ?>">×</button>
		</div>
		<?php
	}

	public static function ajax_save() {
		check_ajax_referer( self::AJAX_SAVE, 'nonce' );

		$post_id = isset( $_POST['post_id'] ) ? intval( $_POST['post_id'] ) : 0;
		if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'fy-fleet' ) ), 403 );
		}
		if ( FY_Fleet_CPT::POST_TYPE !== get_post_type( $post_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Not a yacht.', 'fy-fleet' ) ), 400 );
		}

		$fields = isset( $_POST['fields'] ) && is_array( $_POST['fields'] ) ? wp_unslash( $_POST['fields'] ) : array();

		if ( isset( $fields['title'] ) && '' !== trim( $fields['title'] ) ) {
			wp_update_post(
				array(
					'ID'         => $post_id,
					'post_title' => sanitize_text_field( $fields['title'] ),
				)
			);
		}

		$map = array(
			'size'      => '_fy_size_ft',
			'price'     => '_fy_price',
			'duration'  => '_fy_duration_label',
			'note'      => '_fy_price_note',
		);
		foreach ( $map as $key => $meta_key ) {
			if ( ! isset( $fields[ $key ] ) ) {
				continue;
			}
			$value = $fields[ $key ];
			if ( 'size' === $key ) {
				$value = intval( $value );
			} elseif ( 'price' === $key ) {
				$value = floatval( $value );
			} else {
				$value = sanitize_text_field( $value );
			}
			update_post_meta( $post_id, $meta_key, $value );
		}

		if ( isset( $fields['capacity'] ) ) {
			$cap = trim( $fields['capacity'] );
			update_post_meta( $post_id, '_fy_capacity_max', '' === $cap ? '' : intval( $cap ) );
		}
		$save_warning = '';
		if ( isset( $fields['image_url'] ) ) {
			$new_url = esc_url_raw( $fields['image_url'] );
			$old_url = trim( (string) get_post_meta( $post_id, '_fy_image_url', true ) );
			update_post_meta( $post_id, '_fy_image_url', $new_url );

			// A real Featured Image always wins over this field on the card,
			// the product and everywhere else (class-fy-render.php) — so
			// typing a new URL here and saving had no visible effect once a
			// yacht already had a photo, which every imported yacht does.
			// Download the new photo and make IT the featured image, same
			// as the importer does, so this field does what it looks like
			// it should do.
			if ( '' !== $new_url && $new_url !== $old_url ) {
				require_once ABSPATH . 'wp-admin/includes/media.php';
				require_once ABSPATH . 'wp-admin/includes/file.php';
				require_once ABSPATH . 'wp-admin/includes/image.php';

				// Downloading someone else's server can fail in ways that
				// aren't a WP_Error (memory exhaustion resizing a huge photo,
				// a broken image library). Uncaught, that turns this whole
				// AJAX reply into an error page and the browser reports a bare
				// "Save failed" — even though every other field saved fine.
				try {
					$attachment_id = media_sideload_image( $new_url, $post_id, get_the_title( $post_id ), 'id' );
					if ( is_wp_error( $attachment_id ) ) {
						$save_warning = sprintf(
							/* translators: %s: error message */
							__( 'Saved, but the new photo could not be downloaded: %s', 'fy-fleet' ),
							$attachment_id->get_error_message()
						);
					} else {
						set_post_thumbnail( $post_id, $attachment_id );
						update_post_meta( $post_id, '_fy_image_sideloaded', md5( $new_url ) );
					}
				} catch ( \Throwable $e ) {
					$save_warning = sprintf(
						/* translators: %s: error message */
						__( 'Saved, but the new photo could not be downloaded: %s', 'fy-fleet' ),
						$e->getMessage()
					);
				}
			}
		}
		if ( isset( $fields['button_url'] ) ) {
			update_post_meta( $post_id, '_fy_button_url', esc_url_raw( $fields['button_url'] ) );
		}
		update_post_meta( $post_id, '_fy_is_pink', ! empty( $fields['pink'] ) && 'false' !== $fields['pink'] ? '1' : '' );
		update_post_meta( $post_id, '_fy_is_free_hour', ! empty( $fields['free'] ) && 'false' !== $fields['free'] ? '1' : '' );

		// Inline hours & pricing rows, sent as a JSON array.
		if ( isset( $_POST['pricing'] ) ) {
			$decoded = json_decode( wp_unslash( $_POST['pricing'] ), true );
			if ( is_array( $decoded ) ) {
				$rows = array();
				foreach ( $decoded as $row ) {
					$type = isset( $row['type'] ) ? sanitize_key( $row['type'] ) : 'price';
					if ( 'heading' === $type || 'note' === $type ) {
						$text = isset( $row['text'] ) ? sanitize_text_field( $row['text'] ) : '';
						if ( '' !== $text ) {
							$rows[] = array( 'type' => $type, 'text' => $text );
						}
					} else {
						$duration = isset( $row['duration'] ) ? sanitize_text_field( $row['duration'] ) : '';
						if ( '' !== $duration ) {
							$rows[] = array(
								'type'     => 'price',
								'duration' => $duration,
								'price'    => isset( $row['price'] ) ? floatval( $row['price'] ) : 0,
								'free'     => ! empty( $row['free'] ) ? '1' : '',
							);
						}
					}
				}
				update_post_meta( $post_id, '_fy_pricing', $rows );

				// Keep the WooCommerce product's deposit price in step. A
				// fatal error in here (a bad taxonomy term, an attribute
				// mismatch) would otherwise corrupt this whole AJAX response
				// into an HTML error page — the browser then can't parse it
				// as JSON and reports a bare "Save failed" with no hint that
				// the fields above it actually did save. Catching it means
				// the visible fields still save even when the product sync
				// itself can't complete.
				if ( class_exists( 'FY_Fleet_Woo' ) && FY_Fleet_Woo::active() ) {
					try {
						FY_Fleet_Woo::sync_product( $post_id );
					} catch ( \Throwable $e ) {
						if ( class_exists( 'FY_Fleet_Log' ) ) {
							FY_Fleet_Log::add( 'visualizer.sync_failed', sprintf( 'Product sync failed for "%s" (#%d): %s', get_the_title( $post_id ), $post_id, $e->getMessage() ) );
						}
						$save_warning = __( 'Saved, but the WooCommerce product could not be re-synced — check the Activity Log.', 'fy-fleet' );
					}
				}
			}
		}

		if ( '' !== $save_warning ) {
			wp_send_json_success( array( 'message' => $save_warning ) );
		}
		wp_send_json_success( array( 'message' => __( 'Saved', 'fy-fleet' ) ) );
	}

	/**
	 * Remove several yachts at once — same effect as the single "Remove"
	 * link (card → trash, product → private, both recoverable), just
	 * looped over a checkbox selection instead of one at a time.
	 */
	public static function ajax_bulk_delete() {
		check_ajax_referer( self::AJAX_BULK_DELETE, 'nonce' );

		$ids = isset( $_POST['ids'] ) && is_array( $_POST['ids'] ) ? array_map( 'intval', wp_unslash( $_POST['ids'] ) ) : array();
		if ( empty( $ids ) ) {
			wp_send_json_error( array( 'message' => __( 'No yachts selected.', 'fy-fleet' ) ), 400 );
		}

		$removed = array();
		$skipped = 0;
		foreach ( $ids as $yacht_id ) {
			if ( ! $yacht_id || FY_Fleet_CPT::POST_TYPE !== get_post_type( $yacht_id ) || ! current_user_can( 'delete_post', $yacht_id ) ) {
				$skipped++;
				continue;
			}
			$title = get_the_title( $yacht_id );
			// Trashing fires FY_Fleet_Woo::on_yacht_trashed (via the
			// trashed_post hook), which sets the linked product to private —
			// same as the single-yacht Remove link, nothing duplicated here.
			if ( wp_trash_post( $yacht_id ) ) {
				$removed[] = $yacht_id;
				if ( class_exists( 'FY_Fleet_Log' ) ) {
					FY_Fleet_Log::add( 'yacht.removed', sprintf( 'Yacht "%s" removed from the fleet (bulk)', $title ) );
				}
			} else {
				$skipped++;
			}
		}

		wp_send_json_success(
			array(
				'removed' => $removed,
				'count'   => count( $removed ),
				'skipped' => $skipped,
			)
		);
	}
}
