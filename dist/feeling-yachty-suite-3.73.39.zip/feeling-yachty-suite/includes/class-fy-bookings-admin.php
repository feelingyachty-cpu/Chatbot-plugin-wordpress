<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bookings dashboard: every WooCommerce order line that carries charter data,
 * shown as a list and as a month calendar.
 */
class FY_Fleet_Bookings_Admin {

	public static function init() {
		// Owner's call: no Bookings screen — WooCommerce → Orders is the one
		// place to look. This class stays as the DATA layer only: get_bookings()
		// still powers the Dashboard, the /fy/v1/bookings API and the n8n
		// booking.paid webhook.

		// Bump the cache version on any order status change so get_bookings()
		// serves fresh data right after a booking is placed/paid/cancelled,
		// instead of waiting out the cache lifetime.
		add_action( 'woocommerce_order_status_changed', array( __CLASS__, 'bump_cache_version' ) );
	}

	public static function bump_cache_version() {
		update_option( 'fy_fleet_bookings_cache_version', self::cache_version() + 1, false );
	}

	private static function cache_version() {
		return (int) get_option( 'fy_fleet_bookings_cache_version', 1 );
	}

	public static function add_menu() {
		add_submenu_page(
			'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE,
			__( 'Bookings', 'fy-fleet' ),
			__( 'Bookings', 'fy-fleet' ),
			'edit_shop_orders',
			'fy-fleet-bookings',
			array( __CLASS__, 'render_page' )
		);
	}

	public static function enqueue( $hook ) {
		if ( false === strpos( (string) $hook, 'fy-fleet-bookings' ) ) {
			return;
		}
		wp_enqueue_style( 'fy-fleet-bookings', FY_FLEET_URL . 'assets/bookings.css', array(), FY_FLEET_VERSION );
	}

	/**
	 * Collect bookings from WooCommerce orders.
	 *
	 * @param string $from Y-m-d inclusive.
	 * @param string $to   Y-m-d inclusive.
	 */
	/**
	 * @param string $from      Optional Y-m-d lower bound.
	 * @param string $to        Optional Y-m-d upper bound.
	 * @param int[]  $yacht_ids Optional — when given, only bookings for
	 *                          these yacht IDs are returned (used by the
	 *                          owner-facing "My Yacht Bookings" tab; empty
	 *                          means "all yachts", the original behaviour).
	 */
	public static function get_bookings( $from = '', $to = '', $yacht_ids = array() ) {
		if ( ! FY_Fleet_Woo::active() || ! function_exists( 'wc_get_orders' ) ) {
			return array();
		}
		$yacht_ids = array_map( 'intval', (array) $yacht_ids );

		// Cache keyed to the requested range + a version bumped on every order
		// status change, so repeat calls in the same window (dashboard,
		// customer DB, webhook payload) reuse one scan instead of re-querying
		// every order from scratch each time.
		$cache_key = 'fy_fleet_bookings_' . self::cache_version() . '_' . md5( $from . '|' . $to . '|' . implode( ',', $yacht_ids ) );
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		// Page through ALL matching orders rather than stopping at a fixed
		// cap — a hard limit here silently drops the oldest bookings (from
		// the calendar, the customer DB, everywhere) once order count grows
		// past it, with no warning.
		$bookings = array();
		$page     = 1;
		$per_page = 200;
		do {
			$orders = wc_get_orders(
				array(
					'limit'   => $per_page,
					'page'    => $page,
					'status'  => array( 'pending', 'processing', 'on-hold', 'completed' ),
					'return'  => 'objects',
					'orderby' => 'date',
					'order'   => 'DESC',
				)
			);

			foreach ( $orders as $order ) {
				foreach ( $order->get_items() as $item_id => $item ) {
					$date          = $item->get_meta( '_fy_date' );
					$item_yacht_id = (int) $item->get_meta( '_fy_yacht_id' );
					if ( ! $date && ! $item_yacht_id ) {
						continue;
					}
					if ( $yacht_ids && ! in_array( $item_yacht_id, $yacht_ids, true ) ) {
						continue;
					}
					// Date-ranged calls (calendar, dashboard, conflicts) only make
					// sense for dated rows; unranged calls (customer DB, API) also
					// include native pure-Woo charters awaiting a date.
					if ( ! $date && ( $from || $to ) ) {
						continue;
					}
					if ( $date && $from && $date < $from ) {
						continue;
					}
					if ( $date && $to && $date > $to ) {
						continue;
					}

					$addons = json_decode( (string) $item->get_meta( '_fy_addons_raw' ), true );

					// Machine meta first; visible-label fallbacks cover orders
					// placed before those metas existed.
					$duration = $item->get_meta( '_fy_duration' );
					$occasion = $item->get_meta( '_fy_occasion' );
					$notes    = $item->get_meta( '_fy_notes' );
					$marina   = $item->get_meta( '_fy_marina' );

					$yacht_id = (int) $item->get_meta( '_fy_yacht_id' );

					$bookings[] = array(
						'order_id'      => $order->get_id(),
						'order_no'      => $order->get_order_number(),
						'order_created' => $order->get_date_created() ? $order->get_date_created()->date( 'Y-m-d H:i:s' ) : '',
						'status'        => $order->get_status(),
						'customer'      => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
						'email'         => $order->get_billing_email(),
						'phone'         => $order->get_billing_phone(),
						'yacht'         => $item->get_name(),
						'yacht_id'      => $yacht_id,
						'yacht_capacity'=> $yacht_id ? FY_Fleet_CPT::capacity( $yacht_id ) : null,
						'date'          => $date,
						'time'          => $item->get_meta( '_fy_time' ),
						'duration'      => $duration ? $duration : $item->get_meta( __( 'Charter length', 'fy-fleet' ) ),
						'hours'         => $item->get_meta( '_fy_hours' ),
						'guests'        => $item->get_meta( '_fy_guests' ),
						'occasion'      => $occasion ? $occasion : $item->get_meta( __( 'Occasion', 'fy-fleet' ) ),
						'notes'         => $notes ? $notes : $item->get_meta( __( 'Special requests', 'fy-fleet' ) ),
						'marina'        => $marina ? $marina : $item->get_meta( __( 'Departure marina', 'fy-fleet' ) ),
						'total'         => (float) $item->get_meta( '_fy_charter_total' ),
						'deposit'       => (float) $item->get_meta( '_fy_deposit' ),
						'balance'       => (float) $item->get_meta( '_fy_balance' ),
						'addons'        => is_array( $addons ) ? $addons : array(),
						'confirmed'     => class_exists( 'FY_Fleet_Checkout' ) && FY_Fleet_Checkout::order_confirmed( $order ),
						'edit_url'      => $order->get_edit_order_url(),
					);
				}
			}

			$page++;
		} while ( count( $orders ) === $per_page );

		usort(
			$bookings,
			function ( $a, $b ) {
				if ( $a['date'] === $b['date'] ) {
					return strcmp( (string) $a['time'], (string) $b['time'] );
				}
				return strcmp( $a['date'], $b['date'] );
			}
		);

		set_transient( $cache_key, $bookings, 5 * MINUTE_IN_SECONDS );

		return $bookings;
	}

	/** Paid/active bookings for one yacht on one date. */
	public static function find_conflicts( $yacht_id, $date, $time = '' ) {
		$hits = array();
		foreach ( self::get_bookings( $date, $date ) as $booking ) {
			if ( (int) $booking['yacht_id'] !== (int) $yacht_id ) {
				continue;
			}
			if ( '' !== $time && (string) $booking['time'] !== (string) $time ) {
				continue;
			}
			$hits[] = $booking;
		}
		return $hits;
	}

	public static function render_page() {
		$view  = isset( $_GET['view'] ) ? sanitize_key( $_GET['view'] ) : 'calendar';
		$month = isset( $_GET['m'] ) ? sanitize_text_field( wp_unslash( $_GET['m'] ) ) : gmdate( 'Y-m' );
		if ( ! preg_match( '/^\d{4}-\d{2}$/', $month ) ) {
			$month = gmdate( 'Y-m' );
		}
		$base = admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-bookings' );
		?>
		<div class="wrap fy-bookings">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Bookings', 'fy-fleet' ); ?></h1>

			<?php if ( ! FY_Fleet_Woo::active() ) : ?>
				<div class="notice notice-error"><p><?php esc_html_e( 'WooCommerce is not active, so there are no orders to read bookings from.', 'fy-fleet' ); ?></p></div>
				</div>
				<?php
				return;
			endif;
			?>

			<h2 class="nav-tab-wrapper">
				<a href="<?php echo esc_url( $base . '&view=calendar&m=' . $month ); ?>" class="nav-tab <?php echo 'calendar' === $view ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Calendar', 'fy-fleet' ); ?></a>
				<a href="<?php echo esc_url( $base . '&view=list' ); ?>" class="nav-tab <?php echo 'list' === $view ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'All Bookings', 'fy-fleet' ); ?></a>
			</h2>

			<?php
			if ( 'list' === $view ) {
				self::render_list();
			} else {
				self::render_calendar( $month, $base );
			}
			?>
		</div>
		<?php
	}

	private static function render_list() {
		$bookings = self::get_bookings();
		?>
		<p class="description"><?php printf( esc_html__( '%d bookings found across your WooCommerce orders.', 'fy-fleet' ), count( $bookings ) ); ?></p>
		<table class="widefat striped fy-bookings-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Date', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'Time', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'Yacht', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'Customer', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'Guests', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'Add-ons', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'Total', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'Deposit paid', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'Balance at dock', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'Form', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'Order', 'fy-fleet' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php if ( empty( $bookings ) ) : ?>
				<tr><td colspan="11"><?php esc_html_e( 'No bookings yet.', 'fy-fleet' ); ?></td></tr>
			<?php else : ?>
				<?php foreach ( $bookings as $b ) : ?>
					<tr>
						<td><strong><?php echo esc_html( FY_Fleet_Woo::format_date( $b['date'] ) ); ?></strong></td>
						<td><?php echo esc_html( $b['time'] ); ?></td>
						<td><?php echo esc_html( $b['yacht'] ); ?></td>
						<td>
							<?php echo esc_html( $b['customer'] ); ?><br>
							<small><?php echo esc_html( $b['phone'] ); ?></small>
						</td>
						<td><?php echo esc_html( $b['guests'] ); ?></td>
						<td>
							<?php
							if ( empty( $b['addons'] ) ) {
								echo '&mdash;';
							} else {
								$labels = array();
								foreach ( $b['addons'] as $addon ) {
									$labels[] = $addon['label'] . ( isset( $addon['qty'] ) && $addon['qty'] > 1 ? ' x' . $addon['qty'] : '' );
								}
								echo esc_html( implode( ', ', $labels ) );
							}
							?>
						</td>
						<td><?php echo wp_kses_post( wc_price( $b['total'] ) ); ?></td>
						<td><?php echo wp_kses_post( wc_price( $b['deposit'] ) ); ?></td>
						<td><strong><?php echo wp_kses_post( wc_price( $b['balance'] ) ); ?></strong></td>
						<td><?php echo $b['confirmed'] ? '✅' : '⚠️'; ?></td>
						<td><a href="<?php echo esc_url( $b['edit_url'] ); ?>">#<?php echo esc_html( $b['order_no'] ); ?></a><br>
							<small><?php echo esc_html( wc_get_order_status_name( $b['status'] ) ); ?></small></td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
		</table>
		<?php
	}

	private static function render_calendar( $month, $base ) {
		$start = $month . '-01';
		$time  = strtotime( $start );
		$days  = (int) gmdate( 't', $time );
		$end   = $month . '-' . str_pad( $days, 2, '0', STR_PAD_LEFT );

		$bookings = self::get_bookings( $start, $end );

		$by_day = array();
		foreach ( $bookings as $b ) {
			$by_day[ $b['date'] ][] = $b;
		}

		$prev = gmdate( 'Y-m', strtotime( '-1 month', $time ) );
		$next = gmdate( 'Y-m', strtotime( '+1 month', $time ) );

		// Monday-first grid.
		$first_weekday = (int) gmdate( 'N', $time );
		$blanks        = $first_weekday - 1;
		?>
		<div class="fy-cal-header">
			<a class="button" href="<?php echo esc_url( $base . '&view=calendar&m=' . $prev ); ?>">&larr; <?php esc_html_e( 'Previous', 'fy-fleet' ); ?></a>
			<h2 class="fy-cal-month"><?php echo esc_html( date_i18n( 'F Y', $time ) ); ?></h2>
			<a class="button" href="<?php echo esc_url( $base . '&view=calendar&m=' . $next ); ?>"><?php esc_html_e( 'Next', 'fy-fleet' ); ?> &rarr;</a>
			<a class="button button-secondary" href="<?php echo esc_url( $base . '&view=calendar&m=' . gmdate( 'Y-m' ) ); ?>"><?php esc_html_e( 'This month', 'fy-fleet' ); ?></a>
			<span class="fy-cal-count"><?php printf( esc_html__( '%d charters this month', 'fy-fleet' ), count( $bookings ) ); ?></span>
		</div>

		<div class="fy-cal">
			<?php
			$labels = array(
				__( 'Mon', 'fy-fleet' ), __( 'Tue', 'fy-fleet' ), __( 'Wed', 'fy-fleet' ),
				__( 'Thu', 'fy-fleet' ), __( 'Fri', 'fy-fleet' ), __( 'Sat', 'fy-fleet' ), __( 'Sun', 'fy-fleet' ),
			);
			foreach ( $labels as $label ) {
				echo '<div class="fy-cal-dow">' . esc_html( $label ) . '</div>';
			}

			for ( $i = 0; $i < $blanks; $i++ ) {
				echo '<div class="fy-cal-cell is-empty"></div>';
			}

			$today = gmdate( 'Y-m-d' );
			for ( $day = 1; $day <= $days; $day++ ) {
				$date  = $month . '-' . str_pad( $day, 2, '0', STR_PAD_LEFT );
				$items = isset( $by_day[ $date ] ) ? $by_day[ $date ] : array();
				$class = 'fy-cal-cell';
				if ( $date === $today ) {
					$class .= ' is-today';
				}
				if ( $items ) {
					$class .= ' has-bookings';
				}

				// The same yacht twice in one day is a conflict worth shouting about.
				$per_yacht = array();
				foreach ( $items as $b ) {
					$per_yacht[ $b['yacht_id'] ] = isset( $per_yacht[ $b['yacht_id'] ] ) ? $per_yacht[ $b['yacht_id'] ] + 1 : 1;
				}
				$conflict_yachts = array_keys( array_filter( $per_yacht, function ( $n ) { return $n > 1; } ) );
				if ( ! empty( $conflict_yachts ) ) {
					$class .= ' has-conflict';
				}
				?>
				<div class="<?php echo esc_attr( $class ); ?>">
					<div class="fy-cal-daynum"><?php echo esc_html( $day ); ?></div>
					<?php if ( ! empty( $conflict_yachts ) ) : ?>
						<span class="fy-cal-conflict-flag">⚠️ <?php esc_html_e( 'Same yacht booked twice!', 'fy-fleet' ); ?></span>
					<?php endif; ?>
					<?php foreach ( $items as $b ) : ?>
						<a class="fy-cal-event status-<?php echo esc_attr( $b['status'] ); ?><?php echo in_array( $b['yacht_id'], $conflict_yachts, true ) ? ' is-conflict' : ''; ?>" href="<?php echo esc_url( $b['edit_url'] ); ?>"
							title="<?php echo esc_attr( $b['yacht'] . ' — ' . $b['customer'] . ' — ' . $b['guests'] . ' guests' ); ?>">
							<span class="fy-cal-time"><?php echo esc_html( $b['time'] ? $b['time'] : __( 'TBD', 'fy-fleet' ) ); ?></span>
							<span class="fy-cal-yacht"><?php echo esc_html( $b['yacht'] ); ?></span>
							<span class="fy-cal-who"><?php echo esc_html( $b['customer'] ); ?></span>
						</a>
					<?php endforeach; ?>
				</div>
				<?php
			}
			?>
		</div>

		<p class="fy-cal-legend">
			<span class="fy-cal-key status-processing"></span> <?php esc_html_e( 'Processing', 'fy-fleet' ); ?>
			<span class="fy-cal-key status-completed"></span> <?php esc_html_e( 'Completed', 'fy-fleet' ); ?>
			<span class="fy-cal-key status-pending"></span> <?php esc_html_e( 'Pending payment', 'fy-fleet' ); ?>
			<span class="fy-cal-key status-on-hold"></span> <?php esc_html_e( 'On hold', 'fy-fleet' ); ?>
		</p>
		<?php
	}
}
