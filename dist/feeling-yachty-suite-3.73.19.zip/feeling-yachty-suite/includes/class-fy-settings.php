<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class FY_Fleet_Settings {

	const OPTION = 'fy_fleet_settings';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_migrate_fuel_rate' ), 5 );
		add_action( 'wp_loaded', array( __CLASS__, 'maybe_rewrite_deposit_copy' ), 5 );
		add_action( 'wp_loaded', array( __CLASS__, 'maybe_rewrite_listed_copy' ), 6 );
		add_action( 'update_option_' . self::BOOKING_OPTION, array( __CLASS__, 'flag_rate_change' ), 10, 2 );
		add_action( 'admin_notices', array( __CLASS__, 'rate_change_notice' ) );
	}

	/**
	 * One-time: move the fleet fuel charge from the $75/hr Suite bump back
	 * to $50/hr on installs that still have the migrated default.
	 *
	 * A saved option always beats a changed default (wp_parse_args only
	 * fills in MISSING keys), so without this the new rate would silently
	 * never apply. Only touches the value when it is still exactly the old
	 * default — a rate deliberately set to something else is left alone.
	 */
	public static function maybe_migrate_fuel_rate() {
		if ( fy_fleet_is_plugin_admin_screen() ) {
			return;
		}
		// Versioned guard: bumping the number re-runs the whole block, which
		// is safe because every step below checks the CURRENT value before
		// touching it and leaves hand-edited settings alone.
		if ( 11 === (int) get_option( 'fy_fleet_pricing_migration', 0 ) ) {
			return;
		}
		update_option( 'fy_fleet_pricing_migration', 11 );

		// Shipped defaults used to be a leftover number. Only rewrite when
		// the saved value is still exactly that leftover — a hand-typed
		// number is left alone.
		$display = get_option( self::OPTION, array() );
		if ( is_array( $display ) && ! empty( $display ) ) {
			$dchanged = false;
			$wa       = isset( $display['whatsapp_number'] ) ? preg_replace( '/\D+/', '', (string) $display['whatsapp_number'] ) : '';
			if ( '17543253827' === $wa ) {
				$display['whatsapp_number'] = '19542463636';
				$dchanged                   = true;
			}
			$ph = isset( $display['phone_number'] ) ? preg_replace( '/\D+/', '', (string) $display['phone_number'] ) : '';
			if ( in_array( $ph, array( '17543253827', '7543253827', '19542463636' ), true ) ) {
				$display['phone_number'] = '9542463636';
				$dchanged                = true;
			}
			if ( $dchanged ) {
				update_option( self::OPTION, $display );
			}
		}

		$seo = get_option( 'fy_fleet_seo', array() );
		if ( is_array( $seo ) && ! empty( $seo ) ) {
			$seo_digits = isset( $seo['org_phone'] ) ? preg_replace( '/\D+/', '', (string) $seo['org_phone'] ) : '';
			if ( in_array( $seo_digits, array( '17543253827', '7543253827' ), true ) ) {
				$seo['org_phone'] = '+1 954-246-3636';
				update_option( 'fy_fleet_seo', $seo );
			}
		}

		// Yacht-level _fy_fuel_rate / _fy_crew_rate win over the $800 / $1,400
		// bands. Old imports and the metabox placeholders used to fill the
		// then-current fleet defaults ($50/$75 fuel, $75/$100 crew), which
		// silently locked those yachts out of $25 fuel and $75 crew. Clear
		// only those leftover defaults — a 2-person crew (150, 200, …) stays.
		self::clear_leftover_yacht_rate_overrides();

		$saved   = get_option( self::BOOKING_OPTION, array() );
		$changed = false;
		if ( ! is_array( $saved ) || empty( $saved ) ) {
			update_option( 'fy_fleet_rates_need_resync', '1' );
			return;
		}

		if ( isset( $saved['fuel_rate'] ) && 75 === (int) $saved['fuel_rate'] ) {
			$saved['fuel_rate'] = 50;
			$changed            = true;
		}

		$miami_digits = isset( $saved['phone_miami'] ) ? preg_replace( '/\D+/', '', (string) $saved['phone_miami'] ) : '';
		if ( in_array( $miami_digits, array( '17543253827', '7543253827' ), true ) ) {
			$saved['phone_miami'] = '9542463636';
			$changed              = true;
		}

		// The charge model moved to "crew + fuel online, boat at the dock",
		// but a site that saved Checkout & Integrations under the old
		// percentage-deposit model keeps charging (and, worse, ADVERTISING)
		// that stale deposit — e.g. "$68 deposit" on a $225/hr yacht.
		if ( isset( $saved['deposit_type'] ) && in_array( $saved['deposit_type'], array( 'percent', 'flat' ), true ) ) {
			$saved['deposit_type'] = 'crew_fuel';
			$changed               = true;
		}

		// The add-on catalog has been revised several times (new items, new
		// prices, the jet-ski hour rules, the catering menu). Matching one
		// exact historical string proved too brittle — a site migrated to an
		// INTERMEDIATE shipped catalog no longer matched and got stranded
		// there, never receiving later additions. So instead: if every key in
		// the saved catalog is one this plugin itself shipped at some point
		// (and none of the catering lines are present yet), the whole catalog
		// is refreshed to the current defaults. A catalog holding ANY
		// owner-invented key is treated as hand-built and never touched.
		if ( isset( $saved['addons'] ) && '' !== trim( (string) $saved['addons'] ) ) {
			$shipped_keys = array(
				// v1 catalog
				'jet-ski', 'jet-car', 'bartender', 'photography', 'photography-drone',
				// later shipped catalogs
				'decorations', 'photo-video', 'photo-video-drone', 'private-chef',
				'transportation', 'open-bar-6', 'open-bar-13',
			);

			$only_shipped = true;
			$has_catering = false;
			foreach ( preg_split( '/\r\n|\r|\n/', (string) $saved['addons'] ) as $line ) {
				$line = trim( $line );
				if ( '' === $line || false === strpos( $line, '|' ) ) {
					continue;
				}
				$key = sanitize_key( substr( $line, 0, strpos( $line, '|' ) ) );
				if ( 0 === strpos( $key, 'cat-' ) ) {
					$has_catering = true;
					continue;
				}
				if ( ! in_array( $key, $shipped_keys, true ) ) {
					$only_shipped = false;
				}
			}

			if ( $only_shipped && ! $has_catering ) {
				$defaults        = self::booking_defaults();
				$saved['addons'] = $defaults['addons'];
				$changed         = true;
			}
		}

		// Open Bar and Videography became CHOICE SETS — one checkbox plus a
		// dropdown, instead of two competing checkboxes. That lives in the
		// group column, so the saved catalog has to be patched or the site
		// keeps showing the old pairs. The wholesale refresh above can't do
		// it: any site that already took the catering menu is excluded there
		// by design. So patch just these four lines, in place, and only when
		// the owner hasn't already given them a group of their own.
		if ( isset( $saved['addons'] ) && '' !== trim( (string) $saved['addons'] ) ) {
			$defaults = self::booking_defaults();
			$shipped  = array();
			foreach ( preg_split( '/\r\n|\r|\n/', (string) $defaults['addons'] ) as $line ) {
				$line = trim( $line );
				if ( '' === $line || false === strpos( $line, '|' ) ) {
					continue;
				}
				$shipped[ sanitize_key( substr( $line, 0, strpos( $line, '|' ) ) ) ] = $line;
			}

			$targets = array( 'photo-video', 'photo-video-drone', 'open-bar-6', 'open-bar-13' );
			$lines   = preg_split( '/\r\n|\r|\n/', (string) $saved['addons'] );
			$patched = false;

			foreach ( $lines as $i => $line ) {
				$line = trim( $line );
				if ( '' === $line || false === strpos( $line, '|' ) ) {
					continue;
				}
				$key = sanitize_key( substr( $line, 0, strpos( $line, '|' ) ) );
				if ( ! in_array( $key, $targets, true ) || ! isset( $shipped[ $key ] ) ) {
					continue;
				}
				// Already grouped — the owner (or a previous run) set it.
				$parts = explode( '|', $line );
				if ( isset( $parts[8] ) && '' !== trim( $parts[8] ) ) {
					continue;
				}
				$lines[ $i ] = $shipped[ $key ];
				$patched     = true;
			}

			if ( $patched ) {
				$saved['addons'] = implode( "\n", array_filter( array_map( 'trim', $lines ), 'strlen' ) );
				$changed         = true;
			}
		}

		// v5: the reservation-deposit rule (20% of the boat cost charged
		// online when it tops $1,400) changes what most variations charge —
		// flag every product as stale so the admin notice points the owner
		// at the Visualizer's one-click "Re-sync all yacht products", which
		// reprices the whole 180-yacht fleet in one pass.
		update_option( 'fy_fleet_rates_need_resync', '1' );

		if ( $changed ) {
			update_option( self::BOOKING_OPTION, $saved );
		}
	}

	/**
	 * Blank yacht crew/fuel fields that still hold a retired fleet default
	 * so the $800 / $1,400 bands apply. Leaves any other number alone.
	 */
	private static function clear_leftover_yacht_rate_overrides() {
		if ( ! function_exists( 'get_posts' ) ) {
			return;
		}
		$type = class_exists( 'FY_Fleet_CPT' ) ? FY_Fleet_CPT::POST_TYPE : 'fy_yacht';
		$ids  = get_posts(
			array(
				'post_type'      => $type,
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_query'     => array(
					'relation' => 'OR',
					array(
						'key'     => '_fy_fuel_rate',
						'compare' => 'EXISTS',
					),
					array(
						'key'     => '_fy_crew_rate',
						'compare' => 'EXISTS',
					),
				),
			)
		);
		foreach ( (array) $ids as $yacht_id ) {
			$fuel = get_post_meta( $yacht_id, '_fy_fuel_rate', true );
			if ( '' !== $fuel && null !== $fuel && in_array( (int) $fuel, array( 50, 75 ), true ) && abs( (float) $fuel - (int) $fuel ) < 0.009 ) {
				update_post_meta( $yacht_id, '_fy_fuel_rate', '' );
			}
			$crew = get_post_meta( $yacht_id, '_fy_crew_rate', true );
			if ( '' !== $crew && null !== $crew && in_array( (int) $crew, array( 75, 100 ), true ) && abs( (float) $crew - (int) $crew ) < 0.009 ) {
				update_post_meta( $yacht_id, '_fy_crew_rate', '' );
			}
		}
	}

	/**
	 * Variation prices are calculated when a product is synced, so changing
	 * a per-hour rate leaves every existing product priced at the OLD rate
	 * until it is re-synced. Flag it so the notice below can say so rather
	 * than letting stale prices be charged silently.
	 */
	public static function flag_rate_change( $old_value, $new_value ) {
		foreach ( array( 'crew_rate', 'crew_rate_under', 'fuel_rate', 'fuel_rate_under', 'fuel_threshold', 'service_fee', 'charter_deposit_threshold', 'charter_deposit_pct' ) as $key ) {
			$before = isset( $old_value[ $key ] ) ? (float) $old_value[ $key ] : null;
			$after  = isset( $new_value[ $key ] ) ? (float) $new_value[ $key ] : null;
			if ( $before !== $after ) {
				update_option( 'fy_fleet_rates_need_resync', '1' );
				return;
			}
		}
	}

	/** Prompt to re-sync products after a per-hour rate change. */
	public static function rate_change_notice() {
		if ( ! current_user_can( 'manage_options' ) || '1' !== get_option( 'fy_fleet_rates_need_resync' ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || false === strpos( (string) $screen->id, 'fy-fleet' ) ) {
			return; // Only inside the Command Center, not all over wp-admin.
		}

		if ( ! empty( $_GET['fy_dismiss_rate_notice'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- dismissing a notice, no data changed
			delete_option( 'fy_fleet_rates_need_resync' );
			return;
		}

		$import_url  = admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-import' );
		$dismiss_url = add_query_arg( 'fy_dismiss_rate_notice', '1' );
		?>
		<div class="notice notice-warning">
			<p>
				<strong>⚠️ <?php esc_html_e( 'Per-hour rates changed — product prices are still the old ones.', 'fy-fleet' ); ?></strong><br>
				<?php esc_html_e( 'Each yacht\'s bookable durations are priced when its product is synced, so existing products still charge the previous crew/deposit rate. Re-run the import with "Download every photo" UNCHECKED to push the new rates onto every yacht (fast — no photos are touched).', 'fy-fleet' ); ?>
			</p>
			<p>
				<a class="button button-primary" href="<?php echo esc_url( $import_url ); ?>"><?php esc_html_e( 'Open Import Spreadsheet', 'fy-fleet' ); ?></a>
				<a class="button" href="<?php echo esc_url( $dismiss_url ); ?>"><?php esc_html_e( 'Dismiss', 'fy-fleet' ); ?></a>
			</p>
		</div>
		<?php
	}

	public static function defaults() {
		return array(
			'heading'         => 'Compare Miami Yacht Rentals by Size, Price and Group Size',
			'subheading'      => 'Browse private Miami boats and yachts from 25ft to 90ft. Compare starting packages, yacht style and special offers before opening a yacht for photos, amenities and booking.',
			'pricing_title'   => '💳 How Miami Yacht Pricing Works',
			'pricing_body'    => 'Each card shows the lowest total — boat + crew + deposit for the shortest charter. Open Hours & Pricing for every duration. Only crew + deposit are charged online to reserve the boat and crew. Remaining balance is cash or Zelle at the dock.',
			'pricing_highlight' => 'Only crew + deposit are charged online now to confirm your booking. This reserves both the boat and your crew. Remaining balance is due at the dock by cash or Zelle only.',
			'free_hour_note'  => 'Free-hour offers show the total time received—for example, pay for 4 hours and receive 5 hours total.',
			'legend'          => 'From prices are boat + crew + deposit.',
			'bottom_text'     => 'Not sure which Miami yacht fits your event? Text your date, guest count, budget and preferred yacht style, and the team will help narrow the fleet to the strongest options.',
			'whatsapp_number' => '19542463636',
			'whatsapp_message'=> 'Hi Feeling Yachty! Please send me Miami yacht rental options. My date is [date], guest count is [guests], and budget is [budget].',
			'phone_number'    => '9542463636',
			'url_base'        => '%fleet%',
		);
	}

	const BOOKING_OPTION = 'fy_fleet_booking_settings';

	public static function get() {
		$saved = get_option( self::OPTION, array() );
		return wp_parse_args( $saved, self::defaults() );
	}

	/* ------------------------------------------------------------------
	 * Booking / WooCommerce settings
	 * ---------------------------------------------------------------- */

	public static function booking_defaults() {
		return array(
			'deposit_type'    => 'crew_fuel',
			'deposit_value'   => 30,
			'crew_rate'       => 100,
			// Boat cost at or under the $1,400 threshold uses this crew
			// rate. Fuel follows the $800 line ($25 / $50), not this one.
			'crew_rate_under' => 75,
			'fuel_rate'       => 50,
			// Boat cost at or under $800 uses this fuel rate. Crew stays $75.
			'fuel_rate_under' => 25,
			'fuel_threshold'  => 800,
			// Boats whose cost for the chosen hours tops the threshold pay
			// this % of the boat cost online too — non-refundable, credited
			// in full against the balance due at the dock. 0 disables.
			'charter_deposit_threshold' => 1400,
			'charter_deposit_pct'       => 20,
			'service_fee'     => 0,
			// Share of the add-ons total taken online; the rest is paid at
			// the dock alongside the charter cost.
			'addon_deposit_pct' => 50,
			'time_slots'      => "9:00 AM\n12:00 PM\n3:00 PM\n6:00 PM",
			'weekend_days'    => '5,6,7',
			'occasions'       => "Birthday\nBachelorette\nBachelor Party\nAnniversary\nCorporate Event\nFamily Day\nPhoto / Content Shoot\nJust for fun\nOther",
			'ghl_form_url'    => 'https://api.leadconnectorhq.com/widget/form/jtAf3RGg818QiqMy504y',
			'ghl_form_height' => 900,
			'require_form'    => 1,
			'show_book_button'=> 1,
			'book_button_text'=> '⚓ Book This Yacht',
			'cancellation_text' => self::default_cancellation_text(),
			'color_pink'      => '#E45C9C',
			'color_pink_deep' => '#C94386',
			'color_purple'    => '#7C3AED',
			'color_blue'      => '#2563EB',
			'color_ink'       => '#172033',
			'min_notice_days' => 1,
			'webhook_url'     => '',
			'webhook_secret'  => '',
			'email_logo'      => 'https://feelingyachty.com/wp-content/uploads/2024/05/feeling-yatchy-logo-1-3.png',
			'phone_miami'     => '9542463636',
			'phone_panama'    => '+507 202-1729',
			// key|Label|price|flat,hour,hours,quote|note|max qty|min charter hrs|hrs reserved for departure+return|group
			'addons'          => "jet-ski|Jet Ski|150|hours|Needs a 3-hour charter minimum — departure and return take about 2 hours. A 3-hour charter includes 1 hour of jet ski, and every extra charter hour adds one more: 4 hrs = 2, 5 hrs = 3, up to 6. Price is per jet ski, per hour.|6|3|2\n"
				. "decorations|Decorations & Balloons Package|350|flat|We'll contact you to discuss colors and occasion|1|0|0\n"
				. "photo-video|Photo + Video|500|flat||1|0|0|choice:Videography\n"
				. "photo-video-drone|Photo + Video + Drone|600|flat||1|0|0|choice:Videography\n"
				. "private-chef|Private Chef|0|quote|Custom menu, quoted to your party|1|0|0\n"
				. "transportation|Transportation|0|quote|Door-to-dock pickup — tell us your party size and we'll quote it|1|0|0\n"
				. "bartender|Bartender|75|hour||1|0|0\n"
				. "open-bar-6|Up to 6 guests|650|flat|Bartender not included|1|0|0|choice:Open Bar\n"
				. "open-bar-13|Up to 13 guests|1200|flat|Bartender not included|1|0|0|choice:Open Bar\n"
				// ---- Catering menu (collapsed into one expandable section) ----
				. "cat-charc-med|Medium Charcuterie Platter (6–8 guests)|300|flat||2|0|0|Premium Charcuterie\n"
				. "cat-charc-lg|Large Charcuterie Platter (10–13 guests)|425|flat||2|0|0|Premium Charcuterie\n"
				. "cat-fruit-med|Medium Fruit Platter (6–8 guests)|140|flat||2|0|0|Fresh Fruit Experience\n"
				. "cat-fruit-lg|Large Fruit Platter (10–13 guests)|195|flat||2|0|0|Fresh Fruit Experience\n"
				. "cat-beef-carp|Beef Carpaccio|185|flat||2|0|0|Gourmet Selection\n"
				. "cat-eggpl-carp|Eggplant Carpaccio|135|flat||2|0|0|Gourmet Selection\n"
				. "cat-zucc-carp|Zucchini Carpaccio|135|flat||2|0|0|Gourmet Selection\n"
				. "cat-ceviche|Ceviche Cups (13 cups)|165|flat||2|0|0|Sea Selection\n"
				. "cat-shrimp-cocktail|Shrimp Cocktail (13 units)|175|flat||2|0|0|Sea Selection\n"
				. "cat-sushi|Sushi Assortment (80 pieces)|325|flat||2|0|0|Sea Selection\n"
				. "cat-beef-chick-skew|Beef & Chicken Skewers (13 units)|145|flat||2|0|0|Gourmet Bites\n"
				. "cat-caprese|Caprese Skewers (13 units)|125|flat||2|0|0|Gourmet Bites\n"
				. "cat-salmon-canape|Salmon Canapés (13 units)|165|flat||2|0|0|Gourmet Bites\n"
				. "cat-shrimp-skew|Shrimp Skewers (13 units)|165|flat||2|0|0|Gourmet Bites\n"
				. "cat-tequenos|Tequeños (25 units)|115|flat||2|0|0|Hot Appetizers\n"
				. "cat-croquettes|Ham & Cheese Croquettes (25 units)|115|flat||2|0|0|Hot Appetizers\n"
				. "cat-arepas|Stuffed Arepas (13 units)|140|flat||2|0|0|Hot Appetizers\n"
				. "cat-empanadas|Empanadas (13 units)|125|flat||2|0|0|Hot Appetizers\n"
				. "cat-corn-cakes|Mini Corn Cakes with Cheese (13 units)|125|flat||2|0|0|Hot Appetizers\n"
				. "cat-meatballs|Mini Meatballs (24 units)|145|flat||2|0|0|Hot Appetizers\n"
				. "cat-sliders|Mini Sliders (13 units)|165|flat||2|0|0|Gourmet Sliders & Wraps\n"
				. "cat-hotdogs|Gourmet Hot Dogs (13 units)|155|flat||2|0|0|Gourmet Sliders & Wraps\n"
				. "cat-subs|Stuffed Gourmet Subs (13 units)|175|flat||2|0|0|Gourmet Sliders & Wraps\n"
				. "cat-wraps|Mini Wraps (13 units)|155|flat||2|0|0|Gourmet Sliders & Wraps\n"
				. "cat-tacos|Mexican Tacos (13 units)|165|flat||2|0|0|Gourmet Sliders & Wraps\n"
				. "cat-paella-sea|Seafood Paella (13 guests)|495|flat||2|0|0|Signature Dishes\n"
				. "cat-paella-trad|Traditional Paella (13 guests)|425|flat||2|0|0|Signature Dishes\n"
				. "cat-omelet|Ham, Cheese & Bacon Omelet with Pancakes|225|flat||2|0|0|Breakfast Options\n"
				. "cat-croissants|Ham & Cheese Mini Croissants|145|flat||2|0|0|Breakfast Options\n"
				. "cat-hummus|Artisan Hummus Trio|125|flat||2|0|0|Premium Extras\n"
				. "cat-tres-leches|Tres Leches|115|flat||2|0|0|Mini Dessert Collection\n"
				. "cat-passion-mousse|Passion Fruit Mousse|125|flat||2|0|0|Mini Dessert Collection\n"
				. "cat-straw-mousse|Strawberry Mousse|125|flat||2|0|0|Mini Dessert Collection\n"
				. "cat-lemon-pie|Lemon Pie|125|flat||2|0|0|Mini Dessert Collection\n"
				. "cat-straw-cream|Strawberries & Cream|135|flat||2|0|0|Mini Dessert Collection\n"
				. "cat-choc-nutella|Chocolate Cake with Nutella|135|flat||2|0|0|Mini Dessert Collection\n"
				. "cat-churros|Arequipe Churros|125|flat||2|0|0|Mini Dessert Collection\n"
				. "cat-mini-pancakes|Nutella & Strawberry Mini Pancakes|145|flat||2|0|0|Mini Dessert Collection\n"
				. "cat-tiramisu|Tiramisu|135|flat||2|0|0|Mini Dessert Collection",
		);
	}

	/**
	 * Starter marina library.
	 * Line format: key|Name|latitude|longitude|Address|Note
	 */
	public static function default_marinas() {
		$lines = array(
			'dinner-key|Dinner Key Marina|25.7263|-80.2330|3400 Pan American Dr, Miami, FL 33133|Largest wet-slip marina in Florida; adjacent to City Hall & Monty’s.',
			'miamarina|Miamarina at Bayside|25.7786|-80.1822|401 Biscayne Blvd, Miami, FL 33132|125 wet slips inside Bayside Marketplace.',
			'marine-stadium|Marine Stadium Marina & Mooring Field|25.7430|-80.1699|3501 Rickenbacker Cswy, Miami, FL 33149|Dry-rack facility next to the historic stadium basin.',
			'bill-bird|Bill Bird Marina (Haulover Park)|25.9067|-80.1247|10800 Collins Ave, Miami Beach, FL 33154|Full-service marina at Haulover Inlet.',
			'crandon|Crandon Park Marina|25.7246|-80.1556|4000 Crandon Blvd, Key Biscayne, FL 33149|Northern Key Biscayne; ocean access.',
			'matheson|Matheson Hammock Marina|25.6750|-80.2583|9610 Old Cutler Rd, Coral Gables, FL 33156|Park marina near the atoll pool.',
			'black-point|Black Point Park & Marina|25.5383|-80.3290|24775 SW 87th Ave, Cutler Bay, FL 33190|Closest county ramp to Biscayne National Park.',
			'pelican-harbor|Pelican Harbor Marina|25.8503|-80.1589|1275 NE 79th St, Miami, FL 33138|Intracoastal access by 79th St Causeway.',
			'miami-beach|Miami Beach Marina|25.77248|-80.13962|300 Alton Rd, Miami Beach, FL 33139|South Beach flagship marina near South Pointe Park & Government Cut.',
			'sea-isle|Venetian Marina & Yacht Club (Sea Isle)|25.790911|-80.184382|1635 N Bayshore Dr, Miami, FL 33132|Bayfront slips by the Venetian Causeway.',
			'island-gardens|Island Gardens Deep Harbour|25.7849|-80.1819|888 MacArthur Cswy, Miami, FL 33132|Superyacht basin with skyline views.',
			'yacht-haven-grande|Yacht Haven Grande Miami at Island Gardens|25.7834787|-80.1822715|838 MacArthur Cswy, Miami, FL 33132|IGY superyacht marina on Watson Island.',
			'one-island-park|One Island Park Marina|25.7709167|-80.1468833|120 MacArthur Cswy, Miami Beach, FL 33139|Exclusive berths in the South Beach bayfront enclave.',
			'fifth-street|5th Street Marina|25.777433|-80.205967|341 NW South River Dr, Miami, FL 33128|Service/shipyard slips on the Miami River; check bridge clearances.',
			'vice-city|Vice City Marina|25.765183|-80.188217|801 Brickell Bay Dr, Miami, FL 33131|Boutique river/bay marina and charter dock.',
			'keystone-point|Keystone Point Marina|25.89806|-80.15944|1950 NE 135th St, North Miami, FL 33181|North Biscayne Bay access close to Haulover.',
			'sunset-harbour|Sunset Harbour Yacht Club|25.794383|-80.145833|1928 Sunset Harbour Dr, Miami Beach, FL 33139|Private slips in Sunset Harbour; dining & baywalk at the doorstep.',

			// Coordinates not verified yet — maps and directions fall back to a
			// name search, which works everywhere. Paste exact GPS to pin the dock.
			'miami-yacht-engine|Miami Yacht & Engine Works|||Miami, FL|',
			'austral-international|Austral International Marina|||Miami, FL|',
			'coral-reef-yc|Coral Reef Yacht Club|||Miami, FL|',
			'best-western-bay|Best Western On the Bay and Marina|||Miami, FL|',
			'grove-harbour|Grove Harbour Marina|||Coconut Grove, Miami, FL|',
			'grove-key|Grove Key Marina|||Coconut Grove, Miami, FL|',
			'hurricane-cove|Hurricane Cove Marina|||Miami, FL|',
			'la-coloma|La Coloma Marina|||Miami, FL|',
			'marbella|Marbella Marina|||Miami, FL|',
			'miami-outboard|Miami Outboard Club|||Miami, FL|',
			'miami-yacht-club|Miami Yacht Club|||Miami, FL|',
			'norseman|Norseman Shipbuilding Marine|||Miami, FL|',
			'north-beach|North Beach Marina|||Miami, FL|',
			'palm-bay-club|Palm Bay Club Marina|||Miami, FL|',
			'bayshore-landing|Bayshore Landing Marina|||Coconut Grove, Miami, FL|',
			'untwine|Untwine Marina|||Miami, FL|',
			'popeye|Popeye Marina|||Miami, FL|',
			'oceanika|Oceanika Yachts Marina & Brokerage|||Miami, FL|',
			'river-run-yc|River Run Yacht Club|||Miami, FL|',
			'jockey-club|Jockey Club Marina|||Miami, FL|',
			'epic-marina|EPIC Marina|||Miami, FL|',
			'shake-a-leg|Shake-a-Leg Miami|||Coconut Grove, Miami, FL|',
			'middle-point|Middle Point Marina|||Miami, FL|',
			'city-of-miami-marinas|City of Miami Marinas|||Miami, FL|',
			'rmk-merrill-stevens|RMK Merrill-Stevens|||Miami, FL|',
			'chamonix|Chamonix Marina|||Miami, FL|',
			'river-point|River Point Marina|||Miami, FL|',
			'brickell-place|Brickell Place Marina|||Miami, FL|',
			'miami-boat-locker|Miami Boat Locker|||Miami, FL|',
			'miami-river-hurricane-safe|Miami River Hurricane Safe Boatyard|||Miami, FL|',
			'loggerhead-south-miami|Loggerhead Marina at South Miami|||Miami, FL|',
			'river-cove|River Cove Marina|||Miami, FL|',
			'museum-park|Museum Park Marina|||Miami, FL|',
			'city-centre-yachts|City Centre Yachts|||Miami, FL|',
			'cay-marine|Cay Marine Services|||Miami, FL|',
			'anchor-marine|Anchor Marine|||Miami, FL|',
			'jones-boat-yard|Jones Boat Yard|||Miami, FL|',
			'cg-sailing-club|Coconut Grove Sailing Club|||Coconut Grove, Miami, FL|',
			'deering-bay-yc|Deering Bay Yacht Club|||Miami, FL|',
			'river-landing|River Landing|||Miami, FL|',
			'riverside|Riverside Marina|||Miami, FL|',
		);
		return implode( "\n", $lines );
	}

	public static function get_booking() {
		$saved = get_option( self::BOOKING_OPTION, array() );
		$opts  = wp_parse_args( $saved, self::booking_defaults() );

		// Fall back to the shipped bilingual form the first time round.
		if ( ! isset( $saved['ghl_form_code'] ) ) {
			$opts['ghl_form_code'] = self::default_ghl_code();
		}
		return $opts;
	}

	/** Starting value for the editable "GHL Form Code" field. */
	public static function default_ghl_code() {
		$file = FY_FLEET_DIR . 'includes/data/ghl-form-default.php';
		if ( ! file_exists( $file ) ) {
			return '';
		}
		$code = include $file;
		return is_string( $code ) ? $code : '';
	}

	/**
	 * The GHL form markup to print at checkout, with the embed placeholder
	 * replaced by the configured GoHighLevel iframe.
	 */
	public static function get_ghl_output() {
		$opts = self::get_booking();
		$code = isset( $opts['ghl_form_code'] ) ? $opts['ghl_form_code'] : '';

		$embed = '';
		if ( ! empty( $opts['ghl_form_url'] ) ) {
			// GoHighLevel's own embed pattern: the data attributes plus their
			// form_embed.js script give auto-height and in-form navigation.
			// Swap the form any time by changing the URL setting — everything
			// here rebuilds from it.
			$form_url = $opts['ghl_form_url'];
			$form_id  = sanitize_key( basename( wp_parse_url( $form_url, PHP_URL_PATH ) ) );
			$embed    = sprintf(
				'<iframe src="%1$s" style="width:100%%;height:%2$dpx;border:none;border-radius:12px" id="inline-%3$s" ' .
				'data-layout="{\'id\':\'INLINE\'}" data-trigger-type="alwaysShow" data-trigger-value="" ' .
				'data-activation-type="alwaysActivated" data-activation-value="" ' .
				'data-deactivation-type="neverDeactivate" data-deactivation-value="" ' .
				'data-form-name="%4$s" data-layout-iframe-id="inline-%3$s" data-form-id="%3$s" title="%4$s"></iframe>' .
				'<script src="https://link.msgsndr.com/js/form_embed.js"></script>',
				esc_url( $form_url ),
				(int) $opts['ghl_form_height'],
				esc_attr( $form_id ),
				esc_attr__( 'Bareboat Charter Agreement Form', 'fy-fleet' )
			);
		}

		if ( false !== strpos( $code, '{{GHL_FORM_EMBED}}' ) ) {
			$code = str_replace( '{{GHL_FORM_EMBED}}', $embed, $code );
		} elseif ( $embed ) {
			$code .= $embed;
		}

		return $code;
	}

	/** Rewrite leftover 754 numbers. $kind is call or whatsapp. */
	public static function rewrite_leftover_phone( $raw, $kind = 'call' ) {
		$digits = preg_replace( '/\D+/', '', (string) $raw );
		if ( in_array( $digits, array( '17543253827', '7543253827' ), true ) ) {
			return 'whatsapp' === $kind ? '19542463636' : '9542463636';
		}
		if ( 'call' === $kind && '19542463636' === $digits ) {
			return '9542463636';
		}
		return $raw;
	}

	public static function get_deposit_type() {
		$opts = self::get_booking();
		return in_array( $opts['deposit_type'], array( 'flat', 'full', 'crew_fuel' ), true ) ? $opts['deposit_type'] : 'crew_fuel';
	}

	public static function get_deposit_value() {
		$opts  = self::get_booking();
		$value = (float) $opts['deposit_value'];
		if ( 'percent' === self::get_deposit_type() ) {
			$value = max( 1, min( 100, $value ) );
		}
		return max( 0, $value );
	}

	/** Per-hour crew charge when the boat cost is over the $1,400 line. */
	public static function get_crew_rate() {
		$opts = self::get_booking();
		return max( 0, (float) ( isset( $opts['crew_rate'] ) && '' !== $opts['crew_rate'] ? $opts['crew_rate'] : 100 ) );
	}

	/** Per-hour crew charge when the boat cost is at or under the $1,400 line. */
	public static function get_crew_rate_under() {
		$opts = self::get_booking();
		return max( 0, (float) ( isset( $opts['crew_rate_under'] ) && '' !== $opts['crew_rate_under'] ? $opts['crew_rate_under'] : 75 ) );
	}

	/**
	 * Guest-facing pay-today rules. Boat cost is the Hours & Pricing total.
	 * Only crew + boat deposit are charged online. Deposit is credited to the boat.
	 */
	public static function threshold_rule_text() {
		$low    = number_format( self::get_fuel_threshold() );
		$low_up = number_format( self::get_fuel_threshold() + 1 );
		$thr    = number_format( self::get_charter_deposit_threshold() );
		$pct    = (int) self::get_charter_deposit_pct();
		$crew   = number_format( self::get_crew_rate_under() );
		$over   = number_format( self::get_crew_rate() );
		$dep    = number_format( self::get_fuel_rate() );
		$cheap  = number_format( self::get_fuel_rate_under() );
		$extras = (int) round( self::get_addon_deposit_ratio() * 100 );
		return sprintf(
			/* translators: 1: $800, 2: $801, 3: $1,400, 4: crew under, 5: $25 deposit, 6: $50 deposit, 7: crew over, 8: 20, 9: extras % */
			__( 'Only crew + deposit are charged online now to confirm your booking. This reserves both the boat and your crew exclusively for your selected date and hours. Boat $%1$s or less: Crew $%4$s/hr + Deposit $%5$s/hr. Boat $%2$s–$%3$s: Crew $%4$s/hr + Deposit $%6$s/hr. Boat over $%3$s: Crew $%7$s/hr + Deposit $%6$s/hr + %8$d%% boat deposit. Premium yachts may require a 50%% boat deposit. Extras: %9$d%% due now. Because the boat and crew are taken off the schedule and reserved specifically for you, crew reservation fees and deposits are non-refundable if you cancel. Any boat deposit is credited toward your boat price. Remaining balance is due at the dock by cash or Zelle only.', 'fy-fleet' ),
			$low,
			$low_up,
			$thr,
			$crew,
			$cheap,
			$dep,
			$over,
			$pct,
			$extras
		);
	}

	/** Per-hour boat deposit when the boat cost is over the $800 line. (Setting key stays fuel_rate.) */
	public static function get_fuel_rate() {
		$opts = self::get_booking();
		return max( 0, (float) ( isset( $opts['fuel_rate'] ) && '' !== $opts['fuel_rate'] ? $opts['fuel_rate'] : 50 ) );
	}

	/** Per-hour boat deposit when the boat cost is at or under $800. */
	public static function get_fuel_rate_under() {
		$opts = self::get_booking();
		return max( 0, (float) ( isset( $opts['fuel_rate_under'] ) && '' !== $opts['fuel_rate_under'] ? $opts['fuel_rate_under'] : 25 ) );
	}

	/** Boat cost at or under which the $25/hr boat deposit applies. */
	public static function get_fuel_threshold() {
		$opts = self::get_booking();
		return max( 0, (float) ( isset( $opts['fuel_threshold'] ) ? $opts['fuel_threshold'] : 800 ) );
	}

	/** Boat cost above which a reservation deposit is charged online (0 = never). */
	public static function get_charter_deposit_threshold() {
		$opts = self::get_booking();
		return max( 0, (float) ( isset( $opts['charter_deposit_threshold'] ) ? $opts['charter_deposit_threshold'] : 1400 ) );
	}

	/** Percent of the boat cost taken as that reservation deposit. */
	public static function get_charter_deposit_pct() {
		$opts = self::get_booking();
		return max( 0, min( 100, (float) ( isset( $opts['charter_deposit_pct'] ) ? $opts['charter_deposit_pct'] : 20 ) ) );
	}

	/** Flat service fee added once per booking (0 = none, shown as $0.00). */
	public static function get_service_fee() {
		$opts = self::get_booking();
		return max( 0, (float) ( isset( $opts['service_fee'] ) ? $opts['service_fee'] : 0 ) );
	}

	/** Fraction (0–1) of the add-ons total charged online; the rest is due at the dock. */
	public static function get_addon_deposit_ratio() {
		$opts = self::get_booking();
		$pct  = isset( $opts['addon_deposit_pct'] ) ? (float) $opts['addon_deposit_pct'] : 50;
		return max( 0, min( 100, $pct ) ) / 100;
	}

	public static function get_time_slots() {
		$opts  = self::get_booking();
		$slots = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $opts['time_slots'] ) as $line ) {
			$line = trim( $line );
			if ( '' !== $line ) {
				$slots[] = $line;
			}
		}
		return $slots;
	}

	public static function get_occasions() {
		$opts = self::get_booking();
		$out  = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $opts['occasions'] ) as $line ) {
			$line = trim( $line );
			if ( '' !== $line ) {
				$out[] = $line;
			}
		}
		return $out;
	}

	/** Weekday numbers (1=Mon … 7=Sun) treated as weekend for surcharges. */
	public static function get_weekend_days() {
		$opts = self::get_booking();
		$days = array();
		foreach ( explode( ',', (string) $opts['weekend_days'] ) as $part ) {
			$n = intval( trim( $part ) );
			if ( $n >= 1 && $n <= 7 ) {
				$days[] = $n;
			}
		}
		return $days ? array_values( array_unique( $days ) ) : array( 5, 6, 7 );
	}

	/** Guest-facing cancellation copy — crew + deposits are non-refundable. */
	public static function default_cancellation_text() {
		return "Because the boat and crew are taken off the schedule and reserved specifically for you, crew reservation fees and deposits are non-refundable if you cancel.\nAny boat deposit is credited toward your boat price.\nRemaining balance is due at the dock by cash or Zelle only.";
	}

	/**
	 * Swap leftover fuel-fee / refundable-deposit copy so guests never see
	 * the old rules after this Suite upload. Runs once.
	 */
	public static function maybe_rewrite_deposit_copy() {
		if ( fy_fleet_is_plugin_admin_screen() ) {
			return;
		}
		if ( 2 === (int) get_option( 'fy_deposit_copy_rewrite', 0 ) ) {
			return;
		}

		$opts = get_option( self::BOOKING_OPTION, array() );
		if ( ! is_array( $opts ) ) {
			$opts = array();
		}
		$text = isset( $opts['cancellation_text'] ) ? (string) $opts['cancellation_text'] : '';
		if ( '' === $text
			|| false !== stripos( $text, 'your deposit is refunded, minus crew' )
			|| false !== stripos( $text, 'Crew and processing fees are non-refundable' )
			|| false !== stripos( $text, 'crew and fuel' )
		) {
			$opts['cancellation_text'] = self::default_cancellation_text();
			update_option( self::BOOKING_OPTION, $opts );
		}

		$display = get_option( self::OPTION, array() );
		if ( is_array( $display ) ) {
			$body = isset( $display['pricing_body'] ) ? (string) $display['pricing_body'] : '';
			if ( '' === $body
				|| false !== stripos( $body, 'Crew and fuel' )
				|| false !== stripos( $body, 'fuel are additional' )
				|| false !== stripos( $body, 'lowest yacht price' )
			) {
				$display['pricing_body'] = self::defaults()['pricing_body'];
				if ( isset( $display['pricing_highlight'] ) && false !== stripos( (string) $display['pricing_highlight'], 'A deposit reserves the charter' ) ) {
					$display['pricing_highlight'] = self::defaults()['pricing_highlight'];
				}
				if ( isset( $display['legend'] ) && ( false !== stripos( (string) $display['legend'], 'Starting packages' ) || false !== stripos( (string) $display['legend'], 'fuel' ) ) ) {
					$display['legend'] = self::defaults()['legend'];
				}
				update_option( self::OPTION, $display );
			}
		}

		if ( ! class_exists( 'FY_Fleet_CPT' ) ) {
			return;
		}
		$yachts = get_posts(
			array(
				'post_type'      => FY_Fleet_CPT::POST_TYPE,
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);
		$needles = array( 'crew and fuel fees', 'fuel fees for your chosen', 'not crew or fuel', 'fuel is $25', 'fuel is $50' );
		foreach ( $yachts as $yacht_id ) {
			$faq = (string) get_post_meta( $yacht_id, '_fy_faq', true );
			if ( '' === $faq ) {
				continue;
			}
			$hit = false;
			foreach ( $needles as $needle ) {
				if ( false !== stripos( $faq, $needle ) ) {
					$hit = true;
					break;
				}
			}
			if ( ! $hit ) {
				continue;
			}
			$lines = preg_split( '/\r\n|\r|\n/', $faq );
			$out   = array();
			$replaced = false;
			foreach ( $lines as $line ) {
				$keep = true;
				foreach ( $needles as $needle ) {
					if ( false !== stripos( $line, $needle ) ) {
						$keep = false;
						break;
					}
				}
				if ( $keep && '' !== trim( $line ) ) {
					$out[] = $line;
				} else {
					$replaced = true;
				}
			}
			if ( $replaced ) {
				array_unshift( $out, 'What do I pay when I book online?|' . self::threshold_rule_text() );
				update_post_meta( $yacht_id, '_fy_faq', implode( "\n", $out ) );
			}
		}

		update_option( 'fy_deposit_copy_rewrite', 2 );
	}

	/**
	 * Listed From / Hours now include crew + deposit. Rewrite the saved
	 * fleet blurb that still says deposits are not added on top.
	 * Does not bump fy_deposit_copy_rewrite or fy_fleet_pricing_migration.
	 */
	public static function maybe_rewrite_listed_copy() {
		if ( fy_fleet_is_plugin_admin_screen() ) {
			return;
		}
		if ( 1 === (int) get_option( 'fy_listed_fees_copy', 0 ) ) {
			return;
		}
		$display = get_option( self::OPTION, array() );
		if ( is_array( $display ) ) {
			$changed = false;
			$body    = isset( $display['pricing_body'] ) ? (string) $display['pricing_body'] : '';
			if ( '' !== $body && (
				false !== stripos( $body, 'boat + crew for the shortest' )
				|| false !== stripos( $body, 'not added on top' )
			) ) {
				$display['pricing_body'] = self::defaults()['pricing_body'];
				$changed                 = true;
			}
			$legend = isset( $display['legend'] ) ? (string) $display['legend'] : '';
			if ( '' !== $legend && (
				false !== stripos( $legend, 'From prices are boat + crew' )
				|| false !== stripos( $legend, 'not added on top' )
			) ) {
				$display['legend'] = self::defaults()['legend'];
				$changed           = true;
			}
			if ( $changed ) {
				update_option( self::OPTION, $display );
			}
		}
		update_option( 'fy_listed_fees_copy', 1 );
	}

	/** Cancellation policy as trimmed lines, ready to print. */
	public static function get_cancellation_lines() {
		$opts = self::get_booking();
		$out  = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $opts['cancellation_text'] ) as $line ) {
			$line = trim( $line );
			if ( '' !== $line ) {
				$out[] = $line;
			}
		}
		return $out;
	}

	/** Brand colours with guaranteed-valid values. */
	public static function get_colors() {
		$opts     = self::get_booking();
		$defaults = self::booking_defaults();
		$colors   = array();
		foreach ( array( 'color_pink', 'color_pink_deep', 'color_purple', 'color_blue', 'color_ink' ) as $key ) {
			$colors[ $key ] = ! empty( $opts[ $key ] ) ? $opts[ $key ] : $defaults[ $key ];
		}
		return $colors;
	}

	/**
	 * CSS-variable override so admin colour choices restyle the grid and the
	 * booking form without touching the shipped stylesheets.
	 */
	public static function color_override_css() {
		$c = self::get_colors();
		return sprintf(
			'#fy-miami-yacht-rentals-neon,.fy-bk{--fy-pink:%1$s;--fy-pink-deep:%2$s;--fy-pink-dark:%2$s;--fy-purple:%3$s;--fy-blue:%4$s;--fy-ink:%5$s;}',
			$c['color_pink'],
			$c['color_pink_deep'],
			$c['color_purple'],
			$c['color_blue'],
			$c['color_ink']
		);
	}

	/**
	 * Global add-on catalog.
	 * Line format: key|Label|price|hour or flat|note|max qty
	 */
	public static function get_addons() {
		$opts = self::get_booking();
		$out  = array();

		foreach ( preg_split( '/\r\n|\r|\n/', (string) $opts['addons'] ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || false === strpos( $line, '|' ) ) {
				continue;
			}
			$parts = array_map( 'trim', explode( '|', $line ) );
			$key   = sanitize_key( isset( $parts[0] ) ? $parts[0] : '' );
			$label = isset( $parts[1] ) ? $parts[1] : '';
			if ( '' === $key || '' === $label ) {
				continue;
			}
			$unit = isset( $parts[3] ) ? strtolower( $parts[3] ) : 'flat';
			if ( ! in_array( $unit, array( 'flat', 'hour', 'hours', 'quote' ), true ) ) {
				$unit = 'flat';
			}

			$out[] = array(
				'key'   => $key,
				'label' => $label,
				'price' => isset( $parts[2] ) ? (float) $parts[2] : 0,
				// flat  = one price per charter
				// hour  = price × the charter's length
				// hours = price × a number of hours the CUSTOMER picks (capped)
				// quote = no price; "contact us for a custom quote"
				'unit'  => $unit,
				'note'  => isset( $parts[4] ) ? $parts[4] : '',
				'max'   => ( isset( $parts[5] ) && intval( $parts[5] ) > 0 ) ? intval( $parts[5] ) : 1,
				// Shortest charter this add-on can be booked on (0 = any).
				'min_hours' => ( isset( $parts[6] ) && intval( $parts[6] ) > 0 ) ? intval( $parts[6] ) : 0,
				// For "hours" add-ons: hours held back for departure and
				// return, which can't be spent on the water toy. The most
				// bookable is therefore (charter − this). With 2 reserved: a
				// 3-hour charter allows 1, 4 allows 2, 5 allows 3, and every
				// extra charter hour adds one more. 0 = uncapped.
				'reserve_hours' => ( isset( $parts[7] ) && intval( $parts[7] ) > 0 ) ? intval( $parts[7] ) : 0,
				// Optional heading. Items sharing a group are collapsed into
				// one expandable section (the catering menu) instead of
				// listing 39 checkboxes down the page.
				'group'     => isset( $parts[8] ) ? trim( $parts[8] ) : '',
			);
		}

		return $out;
	}

	/**
	 * Most hours of an "hours" add-on bookable on a charter of $hours.
	 *
	 * charter − reserve_hours, where the reserve is the time needed to get
	 * out and back. With 2 reserved: 3h→1, 4h→2, 5h→3 — every extra charter
	 * hour buys exactly one more hour on the water toy.
	 */
	public static function addon_max_hours( $addon, $charter_hours ) {
		$charter_hours = (float) $charter_hours;
		if ( $charter_hours <= 0 ) {
			return 0;
		}
		if ( ! empty( $addon['min_hours'] ) && $charter_hours < (float) $addon['min_hours'] ) {
			return 0; // Charter too short for this add-on at all.
		}
		$reserve = ! empty( $addon['reserve_hours'] ) ? (int) $addon['reserve_hours'] : 0;
		if ( $reserve < 1 ) {
			return (int) floor( $charter_hours );
		}
		return (int) max( 1, floor( $charter_hours ) - $reserve );
	}

	public static function add_menu() {
		add_submenu_page(
			'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE,
			__( 'Fleet Display Settings', 'fy-fleet' ),
			__( 'Display Settings', 'fy-fleet' ),
			'manage_options',
			'fy-fleet-settings',
			array( __CLASS__, 'render_page' )
		);

		add_submenu_page(
			'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE,
			__( 'Checkout & Integrations', 'fy-fleet' ),
			__( 'Checkout & Integrations', 'fy-fleet' ),
			'manage_options',
			'fy-fleet-booking',
			array( __CLASS__, 'render_booking_page' )
		);
	}

	public static function register_settings() {
		register_setting( 'fy_fleet_settings_group', self::OPTION, array( __CLASS__, 'sanitize' ) );
		register_setting( 'fy_fleet_booking_group', self::BOOKING_OPTION, array( __CLASS__, 'sanitize_booking' ) );
	}

	public static function sanitize_booking( $input ) {
		$out = array();

		$out['deposit_type']  = ( isset( $input['deposit_type'] ) && in_array( $input['deposit_type'], array( 'flat', 'full', 'crew_fuel', 'percent' ), true ) ) ? $input['deposit_type'] : 'crew_fuel';
		if ( in_array( $out['deposit_type'], array( 'percent', 'flat' ), true ) ) {
			$out['deposit_type'] = 'crew_fuel';
		}
		$out['deposit_value'] = isset( $input['deposit_value'] ) ? floatval( $input['deposit_value'] ) : 30;
		// Fall back to the documented defaults (not 0) if the field is ever
		// missing from the submission — a silent $0 crew/fuel rate would
		// quietly stop charging for either on every yacht.
		$out['addon_deposit_pct'] = isset( $input['addon_deposit_pct'] ) ? max( 0, min( 100, floatval( $input['addon_deposit_pct'] ) ) ) : 50;
		$out['crew_rate']     = isset( $input['crew_rate'] ) ? max( 0, floatval( $input['crew_rate'] ) ) : 100;
		$out['crew_rate_under'] = isset( $input['crew_rate_under'] ) ? max( 0, floatval( $input['crew_rate_under'] ) ) : 75;
		$out['fuel_rate']     = isset( $input['fuel_rate'] ) ? max( 0, floatval( $input['fuel_rate'] ) ) : 50;
		$out['fuel_rate_under'] = isset( $input['fuel_rate_under'] ) ? max( 0, floatval( $input['fuel_rate_under'] ) ) : 25;
		$out['fuel_threshold']  = isset( $input['fuel_threshold'] ) ? max( 0, floatval( $input['fuel_threshold'] ) ) : 800;
		$out['service_fee']   = isset( $input['service_fee'] ) ? max( 0, floatval( $input['service_fee'] ) ) : 0;
		$out['charter_deposit_threshold'] = isset( $input['charter_deposit_threshold'] ) ? max( 0, floatval( $input['charter_deposit_threshold'] ) ) : 1400;
		$out['charter_deposit_pct']       = isset( $input['charter_deposit_pct'] ) ? max( 0, min( 100, floatval( $input['charter_deposit_pct'] ) ) ) : 20;
		$out['ghl_form_url']  = isset( $input['ghl_form_url'] ) ? esc_url_raw( $input['ghl_form_url'] ) : '';
		$out['ghl_form_height'] = isset( $input['ghl_form_height'] ) ? max( 300, intval( $input['ghl_form_height'] ) ) : 900;
		$out['require_form']  = ! empty( $input['require_form'] ) ? 1 : 0;
		$out['show_book_button'] = ! empty( $input['show_book_button'] ) ? 1 : 0;
		$out['book_button_text'] = isset( $input['book_button_text'] ) ? sanitize_text_field( $input['book_button_text'] ) : '';
		$out['weekend_days']  = isset( $input['weekend_days'] ) ? sanitize_text_field( $input['weekend_days'] ) : '5,6,7';
		$out['min_notice_days'] = isset( $input['min_notice_days'] ) ? max( 0, min( 60, intval( $input['min_notice_days'] ) ) ) : 1;
		$out['webhook_url']     = isset( $input['webhook_url'] ) ? esc_url_raw( $input['webhook_url'] ) : '';
		$out['webhook_secret']  = isset( $input['webhook_secret'] ) ? sanitize_text_field( $input['webhook_secret'] ) : '';
		$out['email_logo']      = isset( $input['email_logo'] ) ? esc_url_raw( $input['email_logo'] ) : '';
		$out['phone_miami']     = isset( $input['phone_miami'] ) ? self::rewrite_leftover_phone( sanitize_text_field( $input['phone_miami'] ), 'call' ) : '';
		$out['phone_panama']    = isset( $input['phone_panama'] ) ? sanitize_text_field( $input['phone_panama'] ) : '';

		// Twilio.
		foreach ( array( 'twilio_sid', 'twilio_token', 'twilio_from_sms', 'twilio_from_wa', 'twilio_staff_to' ) as $field ) {
			$out[ $field ] = isset( $input[ $field ] ) ? sanitize_text_field( $input[ $field ] ) : '';
		}
		$out['twilio_notify_staff']    = ! empty( $input['twilio_notify_staff'] ) ? 1 : 0;
		$out['twilio_notify_customer'] = ! empty( $input['twilio_notify_customer'] ) ? 1 : 0;
		$out['twilio_customer_tpl']    = isset( $input['twilio_customer_tpl'] ) ? sanitize_textarea_field( $input['twilio_customer_tpl'] ) : '';

		// AI assist.
		$out['ai_provider'] = ( isset( $input['ai_provider'] ) && 'openai' === $input['ai_provider'] ) ? 'openai' : 'anthropic';
		$out['ai_key']      = isset( $input['ai_key'] ) ? sanitize_text_field( $input['ai_key'] ) : '';
		$out['ai_model']    = isset( $input['ai_model'] ) ? sanitize_text_field( $input['ai_model'] ) : '';

		foreach ( array( 'time_slots', 'occasions', 'addons', 'cancellation_text' ) as $field ) {
			$out[ $field ] = isset( $input[ $field ] ) ? sanitize_textarea_field( $input[ $field ] ) : '';
		}

		// Brand colours used by the fleet grid and booking form.
		foreach ( array( 'color_pink', 'color_pink_deep', 'color_purple', 'color_blue', 'color_ink' ) as $field ) {
			$hex = isset( $input[ $field ] ) ? trim( (string) $input[ $field ] ) : '';
			$out[ $field ] = preg_match( '/^#[0-9a-fA-F]{3}(?:[0-9a-fA-F]{3})?$/', $hex ) ? $hex : '';
		}

		// The GHL block is raw HTML/CSS/JS. Only users who are trusted with
		// unfiltered HTML may store it verbatim; everyone else gets it filtered.
		$code = isset( $input['ghl_form_code'] ) ? (string) $input['ghl_form_code'] : '';
		$out['ghl_form_code'] = current_user_can( 'unfiltered_html' ) ? $code : wp_kses_post( $code );

		return $out;
	}

	public static function render_booking_page() {
		$opts = self::get_booking();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Checkout & Integrations', 'fy-fleet' ); ?></h1>

			<?php if ( ! class_exists( 'WooCommerce' ) ) : ?>
				<div class="notice notice-error"><p>
					<strong><?php esc_html_e( 'WooCommerce is not active.', 'fy-fleet' ); ?></strong>
					<?php esc_html_e( 'Install and activate WooCommerce to enable booking, cart and checkout.', 'fy-fleet' ); ?>
				</p></div>
			<?php endif; ?>

			<form method="post" action="options.php">
				<?php settings_fields( 'fy_fleet_booking_group' ); ?>
				<?php $name = esc_attr( self::BOOKING_OPTION ); ?>

				<h2><?php esc_html_e( 'Payment at Booking', 'fy-fleet' ); ?></h2>
				<table class="form-table">
					<tr><th><?php esc_html_e( 'Charge type', 'fy-fleet' ); ?></th>
						<td>
							<label><input type="radio" name="<?php echo $name; ?>[deposit_type]" value="crew_fuel" <?php checked( $opts['deposit_type'], 'crew_fuel' ); ?>> <?php esc_html_e( 'Crew + boat deposit (recommended) — crew and deposits are charged online to reserve the boat and crew. Crew is a reservation fee and is not credited. Boat deposits are credited toward the boat. Remaining balance is due at the dock plus unpaid extras.', 'fy-fleet' ); ?></label><br>
							<label><input type="radio" name="<?php echo $name; ?>[deposit_type]" value="full" <?php checked( $opts['deposit_type'], 'full' ); ?>> <?php esc_html_e( 'Full amount — Booking + Crew + boat deposit + Service fee, charged in full when the customer books. Nothing due at the dock.', 'fy-fleet' ); ?></label><br>
							<label><input type="radio" name="<?php echo $name; ?>[deposit_type]" value="percent" <?php checked( $opts['deposit_type'], 'percent' ); ?>> <?php esc_html_e( 'Percentage of charter total (old model) — a deposit now, balance paid at the dock.', 'fy-fleet' ); ?></label><br>
							<label><input type="radio" name="<?php echo $name; ?>[deposit_type]" value="flat" <?php checked( $opts['deposit_type'], 'flat' ); ?>> <?php esc_html_e( 'Flat amount (old model) — a fixed deposit now, balance paid at the dock.', 'fy-fleet' ); ?></label>
						</td></tr>
					<tr><th><label for="deposit_value"><?php esc_html_e( 'Deposit value', 'fy-fleet' ); ?></label></th>
						<td><input type="number" step="0.01" min="0" id="deposit_value" name="<?php echo $name; ?>[deposit_value]" value="<?php echo esc_attr( $opts['deposit_value'] ); ?>" class="small-text">
						<p class="description"><?php esc_html_e( 'Only used by the "Percentage" and "Flat amount" options above. Ignored by "Crew + boat deposit" and "Full amount".', 'fy-fleet' ); ?></p></td></tr>
				</table>

				<h2><?php esc_html_e( 'Per-Hour Charter Charges', 'fy-fleet' ); ?></h2>
				<p class="description" style="max-width:820px"><?php esc_html_e( 'Every booking is priced as the yacht\'s own Hours & Pricing boat total, PLUS crew and hourly boat deposit for those hours. Crew follows the $1,400 line. The hourly deposit follows the $800 line. Shown to the customer as Booking, Crew, and Boat deposit. Only the deposit is credited toward the boat at the dock.', 'fy-fleet' ); ?></p>
				<table class="form-table">
					<tr><th><label for="crew_rate_under"><?php esc_html_e( 'Crew ($ / hour) — boat at or under $1,400', 'fy-fleet' ); ?></label></th>
						<td><input type="number" step="0.01" min="0" id="crew_rate_under" name="<?php echo $name; ?>[crew_rate_under]" value="<?php echo esc_attr( isset( $opts['crew_rate_under'] ) ? $opts['crew_rate_under'] : 75 ); ?>" class="small-text">
						<p class="description"><?php esc_html_e( 'Collected online on every yacht when the boat total for the chosen hours is $1,400 or less — including boats at or under $800. Default $75/hr.', 'fy-fleet' ); ?></p></td></tr>
					<tr><th><label for="crew_rate"><?php esc_html_e( 'Crew ($ / hour) — boat over $1,400', 'fy-fleet' ); ?></label></th>
						<td><input type="number" step="0.01" min="0" id="crew_rate" name="<?php echo $name; ?>[crew_rate]" value="<?php echo esc_attr( isset( $opts['crew_rate'] ) ? $opts['crew_rate'] : 0 ); ?>" class="small-text">
						<p class="description"><?php esc_html_e( 'Collected online when the boat total for the chosen hours is over $1,400. Default $100/hr. Example: Coco 5 hours = $1,425 boat → $100 × 5 = $500 crew.', 'fy-fleet' ); ?></p></td></tr>
					<tr><th><label for="fuel_rate_under"><?php esc_html_e( 'Hourly boat deposit ($ / hour) — boat at or under $800', 'fy-fleet' ); ?></label></th>
						<td><input type="number" step="0.01" min="0" id="fuel_rate_under" name="<?php echo $name; ?>[fuel_rate_under]" value="<?php echo esc_attr( isset( $opts['fuel_rate_under'] ) ? $opts['fuel_rate_under'] : 25 ); ?>" class="small-text">
						<p class="description"><?php esc_html_e( 'Charged online and credited toward the boat at the dock when the boat total is $800 or less. Default $25/hr. Crew on these boats stays $75/hr.', 'fy-fleet' ); ?></p></td></tr>
					<tr><th><label for="fuel_rate"><?php esc_html_e( 'Hourly boat deposit ($ / hour) — boat over $800', 'fy-fleet' ); ?></label></th>
						<td><input type="number" step="0.01" min="0" id="fuel_rate" name="<?php echo $name; ?>[fuel_rate]" value="<?php echo esc_attr( isset( $opts['fuel_rate'] ) ? $opts['fuel_rate'] : 0 ); ?>" class="small-text">
						<p class="description"><?php esc_html_e( 'Charged online and credited toward the boat when the boat total is over $800 (both the $801–$1,400 band and over $1,400). Default $50/hr.', 'fy-fleet' ); ?></p></td></tr>
					<tr><th><label for="service_fee"><?php esc_html_e( 'Service fee ($, flat)', 'fy-fleet' ); ?></label></th>
						<td><input type="number" step="0.01" min="0" id="service_fee" name="<?php echo $name; ?>[service_fee]" value="<?php echo esc_attr( isset( $opts['service_fee'] ) ? $opts['service_fee'] : 0 ); ?>" class="small-text">
						<p class="description"><?php esc_html_e( 'Charged once per booking regardless of hours. Leave at 0 to show "$0.00" as it does today.', 'fy-fleet' ); ?></p></td></tr>
					<tr><th><label for="addon_deposit_pct"><?php esc_html_e( 'Add-ons charged online (%)', 'fy-fleet' ); ?></label></th>
						<td><input type="number" step="1" min="0" max="100" id="addon_deposit_pct" name="<?php echo $name; ?>[addon_deposit_pct]" value="<?php echo esc_attr( isset( $opts['addon_deposit_pct'] ) ? $opts['addon_deposit_pct'] : 50 ); ?>" class="small-text">
						<p class="description"><?php esc_html_e( 'Share of the extras total (jet ski, open bar, photo packages…) taken with the online booking. The remainder is paid at the dock with the charter. 50 = half now, half at the dock.', 'fy-fleet' ); ?></p></td></tr>
				</table>

				<h2><?php esc_html_e( 'The $800 and $1,400 boat-cost lines', 'fy-fleet' ); ?></h2>
				<p class="description" style="max-width:820px"><?php echo esc_html( self::threshold_rule_text() ); ?></p>
				<table class="form-table">
					<tr><th><label for="fuel_threshold"><?php esc_html_e( 'Lower boat-cost line ($800 deposit split)', 'fy-fleet' ); ?></label></th>
						<td><input type="number" step="1" min="0" id="fuel_threshold" name="<?php echo $name; ?>[fuel_threshold]" value="<?php echo esc_attr( isset( $opts['fuel_threshold'] ) ? $opts['fuel_threshold'] : 800 ); ?>" class="small-text">
						<p class="description"><?php esc_html_e( 'At or under this boat total: $75/hr crew and $25/hr boat deposit. Over this line (and at or under $1,400): $75/hr crew and $50/hr boat deposit. 800 = $800.', 'fy-fleet' ); ?></p></td></tr>
					<tr><th><label for="charter_deposit_threshold"><?php esc_html_e( 'Upper boat-cost line ($1,400 crew + % boat deposit)', 'fy-fleet' ); ?></label></th>
						<td><input type="number" step="1" min="0" id="charter_deposit_threshold" name="<?php echo $name; ?>[charter_deposit_threshold]" value="<?php echo esc_attr( isset( $opts['charter_deposit_threshold'] ) ? $opts['charter_deposit_threshold'] : 1400 ); ?>" class="small-text">
						<p class="description"><?php esc_html_e( 'Over this boat total: $100/hr crew, $50/hr boat deposit, plus the percent boat deposit below. At or under: $75/hr crew and the hourly deposit from the $800 line. 1400 = $1,400.', 'fy-fleet' ); ?></p></td></tr>
					<tr><th><label for="charter_deposit_pct"><?php esc_html_e( 'Percent boat deposit — only over $1,400', 'fy-fleet' ); ?></label></th>
						<td><input type="number" step="1" min="0" max="100" id="charter_deposit_pct" name="<?php echo $name; ?>[charter_deposit_pct]" value="<?php echo esc_attr( isset( $opts['charter_deposit_pct'] ) ? $opts['charter_deposit_pct'] : 20 ); ?>" class="small-text">
						<p class="description"><?php esc_html_e( 'Percent of the boat cost taken online when the boat is over the $1,400 line. Credited toward the boat at the dock. 0 turns the percent deposit off — the $800 / $1,400 crew and hourly-deposit splits still apply.', 'fy-fleet' ); ?></p></td></tr>
				</table>

				<h2><?php esc_html_e( 'Booking Webhook (n8n / automations)', 'fy-fleet' ); ?></h2>
				<table class="form-table">
					<tr><th><label for="webhook_url"><?php esc_html_e( 'Webhook URL', 'fy-fleet' ); ?></label></th>
						<td><input type="url" id="webhook_url" name="<?php echo $name; ?>[webhook_url]" value="<?php echo esc_attr( isset( $opts['webhook_url'] ) ? $opts['webhook_url'] : '' ); ?>" class="large-text" placeholder="https://your-n8n.app/webhook/new-booking">
						<p class="description"><?php esc_html_e( 'The moment a deposit is paid, the full booking (customer, yacht, date, add-ons, deposit, balance) is POSTed here as JSON. Perfect for n8n: WhatsApp alerts to staff, adding the client to GoHighLevel, calendar sync. Deliveries appear in the Activity Log.', 'fy-fleet' ); ?></p></td></tr>
					<tr><th><label for="webhook_secret"><?php esc_html_e( 'Signing secret (optional)', 'fy-fleet' ); ?></label></th>
						<td>
							<input type="text" id="webhook_secret" name="<?php echo $name; ?>[webhook_secret]" value="<?php echo esc_attr( isset( $opts['webhook_secret'] ) ? $opts['webhook_secret'] : '' ); ?>" class="regular-text" style="font-family:monospace">
							<button type="button" class="button" onclick="var a=new Uint8Array(24);crypto.getRandomValues(a);document.getElementById('webhook_secret').value='fy_'+Array.from(a,function(b){return b.toString(16).padStart(2,'0')}).join('');"><?php esc_html_e( '🎲 Generate', 'fy-fleet' ); ?></button>
							<p class="description"><?php esc_html_e( 'Click Generate, Save Changes, then give this exact string to whoever runs your n8n workflow. Every outgoing request carries an X-FY-Signature header = HMAC-SHA256 of the raw JSON body using this secret, so n8n can verify the sender is really your site. Events sent: booking.paid, ticket.created, ticket.reply.', 'fy-fleet' ); ?></p>
						</td></tr>
				</table>

				<h2>📧 <?php esc_html_e( 'Email Branding', 'fy-fleet' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Every WooCommerce email (order confirmations, receipts, account emails) carries your logo, brand colors, the full charter details with the reservation number, and this contact footer.', 'fy-fleet' ); ?></p>
				<table class="form-table">
					<tr><th><label for="email_logo"><?php esc_html_e( 'Logo URL', 'fy-fleet' ); ?></label></th>
						<td><input type="url" id="email_logo" name="<?php echo $name; ?>[email_logo]" value="<?php echo esc_attr( isset( $opts['email_logo'] ) ? $opts['email_logo'] : '' ); ?>" class="large-text">
						<?php if ( ! empty( $opts['email_logo'] ) ) : ?><p><img src="<?php echo esc_url( $opts['email_logo'] ); ?>" alt="" style="max-width:200px;background:#fff;padding:8px;border:1px solid #dcdcde;border-radius:8px"></p><?php endif; ?></td></tr>
					<tr><th><label for="phone_miami"><?php esc_html_e( 'Miami phone (call · SMS · WhatsApp)', 'fy-fleet' ); ?></label></th>
						<td><input type="text" id="phone_miami" name="<?php echo $name; ?>[phone_miami]" value="<?php echo esc_attr( isset( $opts['phone_miami'] ) ? $opts['phone_miami'] : '' ); ?>" class="regular-text"></td></tr>
					<tr><th><label for="phone_panama"><?php esc_html_e( 'Panama phone (call · SMS · WhatsApp)', 'fy-fleet' ); ?></label></th>
						<td><input type="text" id="phone_panama" name="<?php echo $name; ?>[phone_panama]" value="<?php echo esc_attr( isset( $opts['phone_panama'] ) ? $opts['phone_panama'] : '' ); ?>" class="regular-text"></td></tr>
				</table>

				<h2><?php esc_html_e( 'Twilio — SMS & WhatsApp', 'fy-fleet' ); ?></h2>
				<?php if ( isset( $_GET['fy_twilio_test'] ) ) : ?>
					<div class="notice <?php echo 'ok' === $_GET['fy_twilio_test'] ? 'notice-success' : 'notice-error'; ?> inline"><p>
						<?php echo 'ok' === $_GET['fy_twilio_test'] ? esc_html__( 'Test message accepted by Twilio ✅', 'fy-fleet' ) : esc_html( sanitize_text_field( wp_unslash( $_GET['fy_twilio_test'] ) ) ); ?>
					</p></div>
				<?php endif; ?>
				<p class="description" style="max-width:860px"><?php esc_html_e( 'Automatic texts when a deposit is paid: an alert to your staff and a confirmation to the customer. Note: iMessage cannot be sent by any third party (Apple does not allow it) — SMS reaches iPhones as a normal text. WhatsApp requires an approved Twilio WhatsApp sender.', 'fy-fleet' ); ?></p>
				<table class="form-table">
					<tr><th><label for="twilio_sid"><?php esc_html_e( 'Account SID', 'fy-fleet' ); ?></label></th>
						<td><input type="text" id="twilio_sid" name="<?php echo $name; ?>[twilio_sid]" value="<?php echo esc_attr( isset( $opts['twilio_sid'] ) ? $opts['twilio_sid'] : '' ); ?>" class="regular-text" autocomplete="off"></td></tr>
					<tr><th><label for="twilio_token"><?php esc_html_e( 'Auth token', 'fy-fleet' ); ?></label></th>
						<td><input type="password" id="twilio_token" name="<?php echo $name; ?>[twilio_token]" value="<?php echo esc_attr( isset( $opts['twilio_token'] ) ? $opts['twilio_token'] : '' ); ?>" class="regular-text" autocomplete="new-password">
						<p class="description"><?php esc_html_e( 'More secure option: define FY_TWILIO_TOKEN in wp-config.php and leave this blank.', 'fy-fleet' ); ?></p></td></tr>
					<tr><th><label for="twilio_from_sms"><?php esc_html_e( 'SMS from number', 'fy-fleet' ); ?></label></th>
						<td><input type="text" id="twilio_from_sms" name="<?php echo $name; ?>[twilio_from_sms]" value="<?php echo esc_attr( isset( $opts['twilio_from_sms'] ) ? $opts['twilio_from_sms'] : '' ); ?>" placeholder="+17545550100" class="regular-text"></td></tr>
					<tr><th><label for="twilio_from_wa"><?php esc_html_e( 'WhatsApp sender', 'fy-fleet' ); ?></label></th>
						<td><input type="text" id="twilio_from_wa" name="<?php echo $name; ?>[twilio_from_wa]" value="<?php echo esc_attr( isset( $opts['twilio_from_wa'] ) ? $opts['twilio_from_wa'] : '' ); ?>" placeholder="+14155238886" class="regular-text"></td></tr>
					<tr><th><label for="twilio_staff_to"><?php esc_html_e( 'Staff alert number', 'fy-fleet' ); ?></label></th>
						<td><input type="text" id="twilio_staff_to" name="<?php echo $name; ?>[twilio_staff_to]" value="<?php echo esc_attr( isset( $opts['twilio_staff_to'] ) ? $opts['twilio_staff_to'] : '' ); ?>" placeholder="9542463636" class="regular-text"></td></tr>
					<tr><th><?php esc_html_e( 'Send automatically', 'fy-fleet' ); ?></th>
						<td>
							<label><input type="checkbox" name="<?php echo $name; ?>[twilio_notify_staff]" value="1" <?php checked( ! empty( $opts['twilio_notify_staff'] ) ); ?>> <?php esc_html_e( 'Text staff when a deposit is paid', 'fy-fleet' ); ?></label><br>
							<label><input type="checkbox" name="<?php echo $name; ?>[twilio_notify_customer]" value="1" <?php checked( ! empty( $opts['twilio_notify_customer'] ) ); ?>> <?php esc_html_e( 'Text the customer a booking confirmation', 'fy-fleet' ); ?></label>
						</td></tr>
					<tr><th><label for="twilio_customer_tpl"><?php esc_html_e( 'Customer message template', 'fy-fleet' ); ?></label></th>
						<td><textarea id="twilio_customer_tpl" name="<?php echo $name; ?>[twilio_customer_tpl]" rows="3" class="large-text" placeholder="⚓ Feeling Yachty: you're booked! {yacht} on {date} at {time}. Balance due at the dock: {balance}."><?php echo esc_textarea( isset( $opts['twilio_customer_tpl'] ) ? $opts['twilio_customer_tpl'] : '' ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Tokens: {name} {yacht} {date} {time} {guests} {marina} {balance} {order}', 'fy-fleet' ); ?></p></td></tr>
				</table>
				<h2><?php esc_html_e( 'AI Assist (Inbox reply drafting + Support Bot)', 'fy-fleet' ); ?></h2>
				<table class="form-table">
					<tr><th><label for="ai_provider"><?php esc_html_e( 'Provider', 'fy-fleet' ); ?></label></th>
						<td><select id="ai_provider" name="<?php echo $name; ?>[ai_provider]">
							<option value="anthropic" <?php selected( isset( $opts['ai_provider'] ) ? $opts['ai_provider'] : 'anthropic', 'anthropic' ); ?>>Anthropic (Claude)</option>
							<option value="openai" <?php selected( isset( $opts['ai_provider'] ) ? $opts['ai_provider'] : '', 'openai' ); ?>>OpenAI (ChatGPT)</option>
						</select></td></tr>
					<tr><th><label for="ai_key"><?php esc_html_e( 'API key', 'fy-fleet' ); ?></label></th>
						<td><input type="password" id="ai_key" name="<?php echo $name; ?>[ai_key]" value="<?php echo esc_attr( isset( $opts['ai_key'] ) ? $opts['ai_key'] : '' ); ?>" class="regular-text" autocomplete="new-password">
						<p class="description"><?php esc_html_e( 'Paste your API key here and save — that\'s the whole setup. Powers two things: the "✨ Draft reply with AI" button in the Inbox (drafts always land in the reply box for human review, nothing sends automatically), and the Support Bot\'s live chat replies (🤖 Support Bot, under Yacht Fleet) once a webhook or this key is configured there. More secure alternative: define FY_AI_API_KEY in wp-config.php instead of pasting it here — either way works, wp-config.php takes priority if both are set.', 'fy-fleet' ); ?></p></td></tr>
					<tr><th><label for="ai_model"><?php esc_html_e( 'Model (optional)', 'fy-fleet' ); ?></label></th>
						<td><input type="text" id="ai_model" name="<?php echo $name; ?>[ai_model]" value="<?php echo esc_attr( isset( $opts['ai_model'] ) ? $opts['ai_model'] : '' ); ?>" class="regular-text" placeholder="claude-sonnet-4-5 / gpt-4o-mini">
						<p class="description"><?php esc_html_e( 'Leave blank to use each feature\'s own default. The Support Bot always uses Claude Sonnet 5 regardless of what\'s entered here.', 'fy-fleet' ); ?></p></td></tr>
				</table>

				<h2><?php esc_html_e( 'Cancellation Policy', 'fy-fleet' ); ?></h2>
				<table class="form-table">
					<tr><th><label for="cancellation_text"><?php esc_html_e( 'Policy text', 'fy-fleet' ); ?></label></th>
						<td><textarea id="cancellation_text" name="<?php echo $name; ?>[cancellation_text]" rows="4" class="large-text"><?php echo esc_textarea( $opts['cancellation_text'] ); ?></textarea>
						<p class="description"><?php esc_html_e( 'One sentence per line. Shown on the booking form, the cart, checkout and the order-received page. Explain that crew reservation fees and deposits are non-refundable, and that boat deposits are credited toward the boat.', 'fy-fleet' ); ?></p></td></tr>
				</table>

				<h2><?php esc_html_e( 'Brand Colors', 'fy-fleet' ); ?></h2>
				<p class="description"><?php esc_html_e( 'These recolor the fleet grid and booking form everywhere. Defaults are your current neon palette.', 'fy-fleet' ); ?></p>
				<table class="form-table">
					<tr><th><?php esc_html_e( 'Colors', 'fy-fleet' ); ?></th>
						<td style="display:flex;gap:18px;flex-wrap:wrap;align-items:center">
							<label><input type="color" name="<?php echo $name; ?>[color_pink]" value="<?php echo esc_attr( $opts['color_pink'] ); ?>"> <?php esc_html_e( 'Pink', 'fy-fleet' ); ?></label>
							<label><input type="color" name="<?php echo $name; ?>[color_pink_deep]" value="<?php echo esc_attr( $opts['color_pink_deep'] ); ?>"> <?php esc_html_e( 'Deep pink (prices/buttons)', 'fy-fleet' ); ?></label>
							<label><input type="color" name="<?php echo $name; ?>[color_purple]" value="<?php echo esc_attr( $opts['color_purple'] ); ?>"> <?php esc_html_e( 'Purple', 'fy-fleet' ); ?></label>
							<label><input type="color" name="<?php echo $name; ?>[color_blue]" value="<?php echo esc_attr( $opts['color_blue'] ); ?>"> <?php esc_html_e( 'Blue', 'fy-fleet' ); ?></label>
							<label><input type="color" name="<?php echo $name; ?>[color_ink]" value="<?php echo esc_attr( $opts['color_ink'] ); ?>"> <?php esc_html_e( 'Text', 'fy-fleet' ); ?></label>
						</td></tr>
				</table>

				<h2><?php esc_html_e( 'Add-Ons', 'fy-fleet' ); ?></h2>
				<table class="form-table">
					<tr><th><label for="addons"><?php esc_html_e( 'Add-on catalog', 'fy-fleet' ); ?></label></th>
						<td><textarea id="addons" name="<?php echo $name; ?>[addons]" rows="8" class="large-text code"><?php echo esc_textarea( $opts['addons'] ); ?></textarea>
						<p class="description">
							<?php esc_html_e( 'One per line: key|Label|price|flat, hour, hours or quote|note|max qty|min charter hours|hours reserved|group', 'fy-fleet' ); ?><br>
						<?php esc_html_e( 'Group: leave blank for its own checkbox. A shared name (e.g. "Hot Appetizers") collapses those items into the menu expander. Prefix it with "choice:" — such as "choice:Open Bar" — to turn the lines into one checkbox with a dropdown, for options the customer picks between rather than combines.', 'fy-fleet' ); ?><br>
							<code>jet-ski|Jet Ski|150|hours|Set schedule — see below|1|3|2</code><br>
							<?php esc_html_e( 'Unit: "flat" charges once · "hour" multiplies by the charter length · "hours" lets the customer pick how many hours (capped) · "quote" shows "custom quote" with no price. The last two numbers are the shortest charter it can be booked on, and one hour per N charter hours (2 = a 5-hour charter allows 3).', 'fy-fleet' ); ?><br>
							<?php esc_html_e( '"hour" multiplies the price by the charter length. "flat" charges once. Per-yacht extras (like a water slide) are set on the individual yacht.', 'fy-fleet' ); ?>
						</p></td></tr>
				</table>

				<h2><?php esc_html_e( 'Bareboat Verification Form (required at checkout)', 'fy-fleet' ); ?></h2>
				<table class="form-table">
					<tr><th><?php esc_html_e( 'Require the form', 'fy-fleet' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo $name; ?>[require_form]" value="1" <?php checked( $opts['require_form'], 1 ); ?>> <?php esc_html_e( 'Customers must confirm they completed the verification form before they can place the order', 'fy-fleet' ); ?></label></td></tr>
					<tr><th><label for="ghl_form_url"><?php esc_html_e( 'GoHighLevel form URL', 'fy-fleet' ); ?></label></th>
						<td><input type="url" id="ghl_form_url" name="<?php echo $name; ?>[ghl_form_url]" value="<?php echo esc_attr( $opts['ghl_form_url'] ); ?>" class="large-text" placeholder="https://api.leadconnectorhq.com/widget/form/XXXXXXXX">
						<p class="description"><?php esc_html_e( 'Paste the embed/share URL of your GoHighLevel bareboat form. In GHL: open the form → Share/Embed → copy the URL from the iframe src. It is embedded directly on the checkout page.', 'fy-fleet' ); ?></p></td></tr>
					<tr><th><label for="ghl_form_height"><?php esc_html_e( 'Embed height (px)', 'fy-fleet' ); ?></label></th>
						<td><input type="number" min="300" step="10" id="ghl_form_height" name="<?php echo $name; ?>[ghl_form_height]" value="<?php echo esc_attr( $opts['ghl_form_height'] ); ?>" class="small-text"></td></tr>
				</table>

				<h2 id="fy-ghl-form-code"><?php esc_html_e( 'GHL Form Code', 'fy-fleet' ); ?></h2>
				<p class="description" style="max-width:820px">
					<?php esc_html_e( 'This is the exact HTML printed on the checkout page above the payment section — your bilingual bareboat intro plus the embedded GoHighLevel form. Edit it freely; HTML, CSS and JavaScript are all allowed.', 'fy-fleet' ); ?>
					<br>
					<?php
					printf(
						/* translators: %s: placeholder token */
						esc_html__( 'Leave the %s placeholder where you want the GoHighLevel form to appear — it is replaced automatically with the form URL above. You can also delete the placeholder and paste your own GHL iframe directly.', 'fy-fleet' ),
						'<code>{{GHL_FORM_EMBED}}</code>'
					);
					?>
				</p>
				<textarea id="ghl_form_code" name="<?php echo $name; ?>[ghl_form_code]" rows="22" class="large-text code" spellcheck="false" style="font-family:Consolas,Monaco,monospace;font-size:12px;"><?php echo esc_textarea( isset( $opts['ghl_form_code'] ) ? $opts['ghl_form_code'] : '' ); ?></textarea>
				<p class="description">
					<?php if ( ! current_user_can( 'unfiltered_html' ) ) : ?>
						<strong><?php esc_html_e( 'Note: your user role cannot save raw scripts or styles, so this code will be filtered on save. Ask an administrator to edit it instead.', 'fy-fleet' ); ?></strong>
					<?php else : ?>
						<?php esc_html_e( 'Tip: clear the box and save to reset it — the shipped Feeling Yachty bilingual form is restored automatically when the field has never been saved.', 'fy-fleet' ); ?>
					<?php endif; ?>
				</p>

				<?php submit_button(); ?>
			</form>

			<?php if ( class_exists( 'FY_Fleet_Twilio' ) && FY_Fleet_Twilio::configured() ) : ?>
				<hr>
				<h2><?php esc_html_e( 'Twilio test message', 'fy-fleet' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
					<input type="hidden" name="action" value="fy_twilio_test">
					<?php wp_nonce_field( 'fy_twilio_test' ); ?>
					<input type="text" name="fy_test_to" placeholder="+17545551234" required>
					<select name="fy_test_channel">
						<option value="sms">SMS</option>
						<option value="whatsapp">WhatsApp</option>
					</select>
					<button class="button"><?php esc_html_e( 'Send test', 'fy-fleet' ); ?></button>
				</form>
			<?php endif; ?>
		</div>
		<?php
	}

	public static function sanitize( $input ) {
		$out = array();
		$text_fields = array( 'heading', 'pricing_title', 'whatsapp_number', 'phone_number' );
		foreach ( $text_fields as $f ) {
			$out[ $f ] = isset( $input[ $f ] ) ? sanitize_text_field( $input[ $f ] ) : '';
		}
		$out['whatsapp_number'] = self::rewrite_leftover_phone( $out['whatsapp_number'], 'whatsapp' );
		$out['phone_number']    = self::rewrite_leftover_phone( $out['phone_number'], 'call' );

		/*
		 * %fleet% has to survive sanitisation. sanitize_title() strips the
		 * percent signs and turns it into the literal word "fleet", so simply
		 * opening Display Settings and pressing Save was enough to rewrite
		 * every yacht URL to /fleet/... and break the whole site. Sanitise the
		 * placeholder and the literal case separately.
		 */
		$raw  = isset( $input['url_base'] ) ? trim( (string) $input['url_base'], '/ ' ) : '';
		$base = ( '%fleet%' === $raw ) ? '%fleet%' : sanitize_title( $raw );
		$out['url_base'] = $base ? $base : '%fleet%';
		// Permalinks must be rebuilt whenever the base changes.
		$existing = get_option( self::OPTION, array() );
		if ( ! isset( $existing['url_base'] ) || $existing['url_base'] !== $out['url_base'] ) {
			update_option( 'fy_fleet_flush_needed', '1' );
		}
		$textarea_fields = array( 'subheading', 'pricing_body', 'pricing_highlight', 'free_hour_note', 'legend', 'bottom_text', 'whatsapp_message' );
		foreach ( $textarea_fields as $f ) {
			$out[ $f ] = isset( $input[ $f ] ) ? sanitize_textarea_field( $input[ $f ] ) : '';
		}
		return $out;
	}

	public static function render_page() {
		$opts = self::get();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Fleet Display Settings', 'fy-fleet' ); ?></h1>
			<p><?php esc_html_e( 'Controls the text around your yacht grid (heading, pricing info box, nav links, WhatsApp/phone). The yachts themselves are managed in the Fleet Visualizer.', 'fy-fleet' ); ?></p>
			<form method="post" action="options.php">
				<?php settings_fields( 'fy_fleet_settings_group' ); ?>
				<table class="form-table">
					<tr><th><label for="url_base"><?php esc_html_e( 'Yacht page URL base', 'fy-fleet' ); ?></label></th>
						<td>
							<code><?php echo esc_html( trailingslashit( home_url() ) ); ?></code>
							<input type="text" id="url_base" name="<?php echo esc_attr( self::OPTION ); ?>[url_base]" value="<?php echo esc_attr( $opts['url_base'] ); ?>" class="regular-text" style="width:220px">
							<code>/<?php esc_html_e( 'yacht-name', 'fy-fleet' ); ?>/</code>
							<p class="description">
								<?php esc_html_e( 'Every yacht gets its own page at this base, using its name as the slug. Leave this as %fleet% and each city builds its own base from its fleet category — Miami yachts under the Miami slug, Panama under Panama, and any city you add later with no change here. Replace it with a fixed word only if you want every yacht, in every city, under that one base. Edit an individual yacht\'s slug with the Permalink field under its title.', 'fy-fleet' ); ?><br>
								<strong><?php esc_html_e( 'After changing this, open Settings → Permalinks once to rebuild the links.', 'fy-fleet' ); ?></strong>
							</p>
						</td></tr>
					<tr><th><label for="heading"><?php esc_html_e( 'Main Heading', 'fy-fleet' ); ?></label></th>
						<td><input type="text" class="large-text" id="heading" name="<?php echo esc_attr( self::OPTION ); ?>[heading]" value="<?php echo esc_attr( $opts['heading'] ); ?>"></td></tr>
					<tr><th><label for="subheading"><?php esc_html_e( 'Subheading', 'fy-fleet' ); ?></label></th>
						<td><textarea class="large-text" rows="2" id="subheading" name="<?php echo esc_attr( self::OPTION ); ?>[subheading]"><?php echo esc_textarea( $opts['subheading'] ); ?></textarea></td></tr>
					<tr><th><label for="pricing_title"><?php esc_html_e( 'Pricing Info Title', 'fy-fleet' ); ?></label></th>
						<td><input type="text" class="large-text" id="pricing_title" name="<?php echo esc_attr( self::OPTION ); ?>[pricing_title]" value="<?php echo esc_attr( $opts['pricing_title'] ); ?>"></td></tr>
					<tr><th><label for="pricing_body"><?php esc_html_e( 'Pricing Info Body', 'fy-fleet' ); ?></label></th>
						<td><textarea class="large-text" rows="2" id="pricing_body" name="<?php echo esc_attr( self::OPTION ); ?>[pricing_body]"><?php echo esc_textarea( $opts['pricing_body'] ); ?></textarea></td></tr>
					<tr><th><label for="pricing_highlight"><?php esc_html_e( 'Deposit / Payment Highlight', 'fy-fleet' ); ?></label></th>
						<td><textarea class="large-text" rows="2" id="pricing_highlight" name="<?php echo esc_attr( self::OPTION ); ?>[pricing_highlight]"><?php echo esc_textarea( $opts['pricing_highlight'] ); ?></textarea></td></tr>
					<tr><th><label for="free_hour_note"><?php esc_html_e( 'Free-Hour Note', 'fy-fleet' ); ?></label></th>
						<td><textarea class="large-text" rows="2" id="free_hour_note" name="<?php echo esc_attr( self::OPTION ); ?>[free_hour_note]"><?php echo esc_textarea( $opts['free_hour_note'] ); ?></textarea></td></tr>
					<tr><th><label for="legend"><?php esc_html_e( 'Legend text (above grid)', 'fy-fleet' ); ?></label></th>
						<td><textarea class="large-text" rows="2" id="legend" name="<?php echo esc_attr( self::OPTION ); ?>[legend]"><?php echo esc_textarea( $opts['legend'] ); ?></textarea></td></tr>
					<tr><th><label for="bottom_text"><?php esc_html_e( 'Bottom help text', 'fy-fleet' ); ?></label></th>
						<td><textarea class="large-text" rows="2" id="bottom_text" name="<?php echo esc_attr( self::OPTION ); ?>[bottom_text]"><?php echo esc_textarea( $opts['bottom_text'] ); ?></textarea></td></tr>
					<tr><th><label for="whatsapp_number"><?php esc_html_e( 'WhatsApp Number (digits only, with country code)', 'fy-fleet' ); ?></label></th>
						<td><input type="text" id="whatsapp_number" name="<?php echo esc_attr( self::OPTION ); ?>[whatsapp_number]" value="<?php echo esc_attr( $opts['whatsapp_number'] ); ?>" placeholder="19542463636"></td></tr>
					<tr><th><label for="whatsapp_message"><?php esc_html_e( 'WhatsApp Prefilled Message', 'fy-fleet' ); ?></label></th>
						<td><textarea class="large-text" rows="2" id="whatsapp_message" name="<?php echo esc_attr( self::OPTION ); ?>[whatsapp_message]"><?php echo esc_textarea( $opts['whatsapp_message'] ); ?></textarea></td></tr>
					<tr><th><label for="phone_number"><?php esc_html_e( 'Call Phone Number', 'fy-fleet' ); ?></label></th>
						<td><input type="text" id="phone_number" name="<?php echo esc_attr( self::OPTION ); ?>[phone_number]" value="<?php echo esc_attr( $opts['phone_number'] ); ?>" placeholder="9542463636"></td></tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}

	public static function parse_links( $raw ) {
		$out = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $raw ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || false === strpos( $line, '|' ) ) {
				continue;
			}
			list( $label, $url ) = array_map( 'trim', explode( '|', $line, 2 ) );
			if ( '' === $label || '' === $url ) {
				continue;
			}
			$out[] = array( 'label' => $label, 'url' => $url );
		}
		return $out;
	}
}
