(function () {
	'use strict';

	function nextIndex( container ) {
		var rows = container.querySelectorAll( '.fy-repeater-row' );
		return rows.length;
	}

	function addRow( containerId, templateId ) {
		var container = document.getElementById( containerId );
		var template  = document.getElementById( templateId );
		if ( ! container || ! template ) {
			return;
		}
		var index = Date.now() + '_' + nextIndex( container );
		var html  = template.innerHTML.split( '__INDEX__' ).join( index );
		var wrap  = document.createElement( 'div' );
		wrap.innerHTML = html.trim();
		var row = wrap.firstElementChild;
		if ( row ) {
			container.appendChild( row );
		}
	}

	// Live thumbnail preview for the Image URL field in the yacht editor.
	document.addEventListener( 'input', function ( e ) {
		if ( ! e.target || ! e.target.classList.contains( 'fy-image-url-input' ) ) {
			return;
		}
		var preview = document.querySelector( '.fy-image-preview' );
		var empty   = document.querySelector( '.fy-image-empty' );
		var url     = e.target.value.trim();
		if ( ! preview ) {
			return;
		}
		if ( ! url ) {
			preview.style.display = 'none';
			if ( empty ) { empty.style.display = ''; }
			return;
		}
		preview.src = url;
		preview.style.display = '';
		if ( empty ) { empty.style.display = 'none'; }
	} );

	document.addEventListener( 'click', function ( e ) {
		if ( e.target && e.target.classList.contains( 'fy-remove-row' ) ) {
			e.preventDefault();
			var row = e.target.closest( '.fy-repeater-row' );
			if ( row ) {
				row.parentNode.removeChild( row );
			}
			return;
		}
		if ( e.target && e.target.id === 'fy-add-badge' ) {
			e.preventDefault();
			addRow( 'fy-badges-rows', 'fy-badge-template' );
		}
		if ( e.target && e.target.id === 'fy-add-price-row' ) {
			e.preventDefault();
			addRow( 'fy-pricing-rows', 'fy-price-row-template' );
		}
		if ( e.target && e.target.id === 'fy-add-heading-row' ) {
			e.preventDefault();
			addRow( 'fy-pricing-rows', 'fy-heading-row-template' );
		}
		if ( e.target && e.target.classList.contains( 'fy-quick-heading' ) ) {
			e.preventDefault();
			addRow( 'fy-pricing-rows', 'fy-heading-row-template' );
			var headingRows = document.querySelectorAll( '#fy-pricing-rows .fy-price-row-heading' );
			var lastHeading = headingRows[ headingRows.length - 1 ];
			if ( lastHeading ) {
				var field = lastHeading.querySelector( 'input[type="text"]' );
				if ( field ) {
					field.value = e.target.getAttribute( 'data-heading' ) || '';
				}
			}
		}
		if ( e.target && e.target.id === 'fy-add-note-row' ) {
			e.preventDefault();
			addRow( 'fy-pricing-rows', 'fy-note-row-template' );
		}
		if ( e.target && e.target.id === 'fy-add-custom-addon' ) {
			e.preventDefault();
			addRow( 'fy-custom-addon-rows', 'fy-custom-addon-template' );
		}
		if ( e.target && e.target.id === 'fy-add-review' ) {
			e.preventDefault();
			addRow( 'fy-review-rows', 'fy-review-template' );
		}
		if ( e.target && e.target.classList.contains( 'fy-marina-preview-btn' ) ) {
			e.preventDefault();
			marinaPreview( e.target );
		}
	} );

	// "Preview map" in the Marina & Map box: build the same keyless Google
	// embed the front end uses, from whatever is currently in the fields —
	// no save required. Custom embed URL wins, then GPS, then a name search.
	function marinaPreview( btn ) {
		var value = function ( id ) {
			var el = document.getElementById( id );
			return el ? el.value.trim() : '';
		};
		var url   = '';
		var embed = value( 'fy_marina_embed' );
		var lat   = value( 'fy_marina_lat' );
		var lng   = value( 'fy_marina_lng' );
		var title = value( 'fy_marina_title' );
		if ( ! title ) {
			var source = document.getElementById( 'fy_marina_source' );
			if ( source && source.value ) {
				title = source.options[ source.selectedIndex ].text.trim();
			}
		}
		if ( embed ) {
			url = embed;
		} else if ( lat && lng && ! isNaN( parseFloat( lat ) ) && ! isNaN( parseFloat( lng ) ) ) {
			url = 'https://www.google.com/maps?q=' + encodeURIComponent( lat + ',' + lng ) + '&z=15&output=embed';
		} else if ( title ) {
			url = 'https://www.google.com/maps?q=' + encodeURIComponent( title ) + '&z=14&output=embed';
		}

		var box = btn.parentNode.querySelector( '.fy-marina-preview' );
		if ( ! box ) {
			return;
		}
		if ( ! url ) {
			box.innerHTML = '<p class="description fy-marina-preview-empty">' + ( box.dataset.emptyText || 'Choose a marina or enter coordinates, then click Preview map.' ) + '</p>';
			return;
		}
		var iframe = box.querySelector( 'iframe' );
		if ( ! iframe ) {
			box.innerHTML = '';
			iframe = document.createElement( 'iframe' );
			iframe.style.cssText = 'width:100%;max-width:640px;height:320px;border:1px solid #dcdcde;border-radius:8px';
			iframe.loading = 'lazy';
			iframe.referrerPolicy = 'no-referrer-when-downgrade';
			box.appendChild( iframe );
		}
		iframe.src = url;
	}

	/**
	 * Yacht/product Gallery box: WordPress media picker + drag-to-reorder.
	 * Each photo is one <div class="fy-yacht-gallery-item"> holding a single
	 * hidden fy_gallery_image_ids[] input — order on submit follows DOM
	 * order, so dragging a card is enough to reorder, no index bookkeeping.
	 */
	function addGalleryItem( attachment ) {
		var container = document.getElementById( 'fy-yacht-gallery-items' );
		var template  = document.getElementById( 'fy-yacht-gallery-item-template' );
		if ( ! container || ! template ) {
			return;
		}
		var wrap = document.createElement( 'div' );
		wrap.innerHTML = template.innerHTML.trim();
		var item = wrap.firstElementChild;
		if ( ! item ) {
			return;
		}
		var idField = item.querySelector( '.fy-yacht-gallery-id' );
		var img     = item.querySelector( '.fy-yacht-gallery-thumb img' );
		if ( idField ) {
			idField.value = attachment.id;
		}
		if ( img ) {
			var url = ( attachment.sizes && attachment.sizes.thumbnail ) ? attachment.sizes.thumbnail.url : attachment.url;
			img.src = url;
			img.style.display = '';
		}
		container.appendChild( item );
	}

	document.addEventListener( 'click', function ( e ) {
		if ( e.target && e.target.id === 'fy-yacht-gallery-add' ) {
			e.preventDefault();
			if ( ! window.wp || ! window.wp.media ) {
				return;
			}
			var frame = window.wp.media( {
				title: 'Select or upload photos',
				multiple: 'add',
				library: { type: 'image' }
			} );
			frame.on( 'select', function () {
				frame.state().get( 'selection' ).each( function ( attachment ) {
					addGalleryItem( attachment.toJSON() );
				} );
			} );
			frame.open();
			return;
		}
		if ( e.target && e.target.classList.contains( 'fy-yacht-gallery-remove' ) ) {
			e.preventDefault();
			var row = e.target.closest( '.fy-yacht-gallery-item' );
			if ( row ) {
				row.parentNode.removeChild( row );
			}
		}
	} );

	if ( window.jQuery ) {
		jQuery( function ( $ ) {
			if ( $.fn.sortable ) {
				$( '#fy-yacht-gallery-items' ).sortable( { items: '.fy-yacht-gallery-item', cursor: 'move' } );
			}
		} );
	}
})();
