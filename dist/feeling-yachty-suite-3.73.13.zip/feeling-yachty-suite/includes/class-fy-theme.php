<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin/login/storefront branding — folded in from the former standalone
 * "Feeling Yachty Admin Theme" plugin so the whole suite ships as one
 * install. Purely cosmetic: dark pink/purple admin dashboard, branded login
 * screen, WooCommerce storefront CSS, order-email branding, and the
 * product-page express-checkout reveal script. Touches no yacht data.
 */
class FY_Fleet_Theme {

	public static function init() {
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin' ) );
		add_action( 'login_enqueue_scripts', array( __CLASS__, 'enqueue_login' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_front' ), 20 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'trim_icon_fonts' ), 100 );
		add_action( 'init', array( __CLASS__, 'disable_emoji_images' ) );
		add_action( 'wp_head', array( __CLASS__, 'font_preconnect' ), 1 );

		add_filter( 'woocommerce_account_menu_items', array( __CLASS__, 'account_menu' ), 30 );
		add_action( 'woocommerce_account_dashboard', array( __CLASS__, 'account_welcome' ), 5 );
		add_filter( 'woocommerce_return_to_shop_redirect', array( __CLASS__, 'shop_redirect' ) );
		add_filter( 'gettext', array( __CLASS__, 'reword' ), 20, 3 );

		add_action( 'plugins_loaded', array( __CLASS__, 'register_email_branding' ), 20 );

		add_filter( 'login_headerurl', array( __CLASS__, 'login_url' ) );
		add_filter( 'login_headertext', array( __CLASS__, 'login_title' ) );
	}

	/** URL of the brand logo (assets/theme/logo.png), or '' if missing. */
	public static function logo_url() {
		foreach ( array( 'logo.png', 'logo.svg', 'logo.jpg', 'logo.webp' ) as $file ) {
			if ( file_exists( FY_FLEET_DIR . 'assets/theme/' . $file ) ) {
				return FY_FLEET_URL . 'assets/theme/' . $file;
			}
		}
		return '';
	}

	public static function enabled() {
		return apply_filters( 'fy_admin_theme_enabled', true );
	}

	/* ------------------------------------------------------------------
	 * Admin dashboard
	 * ---------------------------------------------------------------- */

	public static function enqueue_admin() {
		if ( ! self::enabled() ) {
			return;
		}
		wp_enqueue_style( 'fy-admin-theme', FY_FLEET_URL . 'assets/theme/admin-theme.css', array(), FY_FLEET_VERSION );

		if ( class_exists( 'WooCommerce' ) ) {
			wp_enqueue_style( 'fy-admin-theme-woo', FY_FLEET_URL . 'assets/theme/woocommerce.css', array( 'fy-admin-theme' ), FY_FLEET_VERSION );
		}

		$logo = self::logo_url();
		if ( $logo ) {
			$css = '
				#adminmenu::before {
					content: "";
					display: block;
					height: 84px;
					margin: 10px 12px 6px;
					background: url(' . esc_url( $logo ) . ') center / contain no-repeat;
				}
				.folded #adminmenu::before { display: none; }
				@media screen and (max-width: 960px) { #adminmenu::before { display: none; } }
			';
			wp_add_inline_style( 'fy-admin-theme', $css );
		}
	}

	/* ------------------------------------------------------------------
	 * Login screen
	 * ---------------------------------------------------------------- */

	public static function enqueue_login() {
		if ( ! self::enabled() ) {
			return;
		}
		wp_enqueue_style( 'fy-admin-theme-login', FY_FLEET_URL . 'assets/theme/login.css', array(), FY_FLEET_VERSION );

		$logo = self::logo_url();
		if ( $logo ) {
			$css = '
				.login h1 a {
					background-image: url(' . esc_url( $logo ) . ');
					width: 220px;
					height: 160px;
					background-size: contain;
					background-position: center;
				}
			';
			wp_add_inline_style( 'fy-admin-theme-login', $css );
		}
	}

	public static function login_url() {
		return home_url( '/' );
	}

	public static function login_title() {
		return get_bloginfo( 'name' );
	}

	/* ------------------------------------------------------------------
	 * Storefront (WooCommerce pages only)
	 * ---------------------------------------------------------------- */

	/**
	 * { "<duration slug>": { hours, price } } for one yacht — the exact same
	 * rows and the exact same slug (sanitize_title of the duration label)
	 * that FY_Fleet_Woo::sync_variations() used to build the Charter
	 * Duration variations, so the live summary can look a duration's real
	 * price up instead of re-deriving it.
	 */
	private static function pricing_rows_for_js( $yacht_id ) {
		return class_exists( 'FY_Fleet_Pricing' ) ? FY_Fleet_Pricing::rows_by_duration_slug( $yacht_id ) : array();
	}

	public static function enqueue_front() {
		if ( ! self::enabled() || ! class_exists( 'WooCommerce' ) ) {
			return;
		}
		if ( ! ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) ) {
			return;
		}
		wp_enqueue_style( 'fy-admin-theme-woo-front', FY_FLEET_URL . 'assets/theme/woocommerce-front.css', array(), FY_FLEET_VERSION );

		// Product pages: reveal express checkout only once date/time/duration
		// are all chosen (pairs with the .fy-express-ready CSS rules).
		if ( is_product() ) {
			wp_enqueue_script( 'fy-admin-theme-product-express', FY_FLEET_URL . 'assets/theme/product-express.js', array( 'jquery' ), FY_FLEET_VERSION, true );

			// This yacht's own crew/fuel/service-fee rates if it has an
			// override set, otherwise the fleet-wide default — same
			// resolution FY_Fleet_Pricing::quote() uses server-side, so the
			// live summary box always matches what's actually charged.
			$yacht_id = 0;
			if ( class_exists( 'FY_Fleet_CPT' ) ) {
				$yacht_id = (int) get_post_meta( get_the_ID(), '_fy_yacht_id', true );
			}
			if ( class_exists( 'FY_Fleet_Pricing' ) && $yacht_id ) {
				$charges = array(
					'hourlyRate' => (float) get_post_meta( $yacht_id, '_fy_price', true ),
					'crewRate'   => FY_Fleet_Pricing::yacht_rate_or_default( $yacht_id, '_fy_crew_rate', FY_Fleet_Settings::get_crew_rate() ),
					'crewRateUnder' => FY_Fleet_Pricing::crew_rate_for_boat( $yacht_id, 0 ),
					'fuelRate'   => FY_Fleet_Pricing::yacht_rate_or_default( $yacht_id, '_fy_fuel_rate', FY_Fleet_Settings::get_fuel_rate() ),
					'fuelRateUnder' => FY_Fleet_Pricing::fuel_rate_for_boat( $yacht_id, 0 ),
					'fuelThreshold' => FY_Fleet_Settings::get_fuel_threshold(),
					'serviceFee' => FY_Fleet_Pricing::yacht_rate_or_default( $yacht_id, '_fy_service_fee', FY_Fleet_Settings::get_service_fee() ),
					'depositThreshold' => FY_Fleet_Settings::get_charter_deposit_threshold(),
					'depositPct'       => FY_Fleet_Settings::get_charter_deposit_pct(),
					// The real per-duration boat cost, keyed by the same slug
					// WooCommerce uses for the Charter Duration variation
					// (FY_Fleet_Woo::sync_variations() builds both from the
					// same row). "hourlyRate * hours" is only a stand-in for
					// this on yachts where _fy_price genuinely is an hourly
					// rate — on yachts where it's a flat/package price
					// instead, that stand-in overstates the boat cost (and
					// therefore the reservation deposit) by using it as a
					// per-hour rate. Reading the row directly keeps the
					// on-page total equal to what the variation actually
					// charges, no matter which kind of rate the yacht has.
					'pricingRows' => self::pricing_rows_for_js( $yacht_id ),
				);
			} else {
				$charges = array(
					'hourlyRate' => 0,
					'crewRate'   => class_exists( 'FY_Fleet_Settings' ) ? FY_Fleet_Settings::get_crew_rate() : 0,
					'crewRateUnder' => class_exists( 'FY_Fleet_Settings' ) ? FY_Fleet_Settings::get_crew_rate_under() : 75,
					'fuelRate'   => class_exists( 'FY_Fleet_Settings' ) ? FY_Fleet_Settings::get_fuel_rate() : 0,
					'fuelRateUnder' => class_exists( 'FY_Fleet_Settings' ) ? FY_Fleet_Settings::get_fuel_rate_under() : 25,
					'fuelThreshold' => class_exists( 'FY_Fleet_Settings' ) ? FY_Fleet_Settings::get_fuel_threshold() : 800,
					'serviceFee' => class_exists( 'FY_Fleet_Settings' ) ? FY_Fleet_Settings::get_service_fee() : 0,
					'depositThreshold' => class_exists( 'FY_Fleet_Settings' ) ? FY_Fleet_Settings::get_charter_deposit_threshold() : 0,
					'depositPct'       => class_exists( 'FY_Fleet_Settings' ) ? FY_Fleet_Settings::get_charter_deposit_pct() : 0,
					'pricingRows'      => array(),
				);
			}
			wp_localize_script( 'fy-admin-theme-product-express', 'fyCharges', $charges );

			wp_enqueue_script( 'fy-admin-theme-related-carousel', FY_FLEET_URL . 'assets/theme/related-carousel.js', array( 'jquery' ), FY_FLEET_VERSION, true );
			wp_localize_script( 'fy-admin-theme-related-carousel', 'fyRelated', array( 'ajaxUrl' => admin_url( 'admin-ajax.php' ) ) );

			// App-style pickers for date / start time / charter length /
			// guests, plus toggle-switch add-on cards. Loads AFTER
			// product-express.js because it re-homes the arrival note that
			// file inserts; it drives the same native fields rather than
			// replacing any pricing logic (see assets/theme/booking-ui.js).
			wp_enqueue_style( 'fy-admin-theme-booking-ui', FY_FLEET_URL . 'assets/theme/booking-ui.css', array( 'fy-admin-theme-woo-front' ), FY_FLEET_VERSION );
			wp_enqueue_script( 'fy-admin-theme-booking-ui', FY_FLEET_URL . 'assets/theme/booking-ui.js', array( 'jquery', 'fy-admin-theme-product-express' ), FY_FLEET_VERSION, true );

			// Gallery thumbnails as one swipeable strip instead of a grid that
			// dumps every photo on the page. Native scroll-snap plus lazy
			// loading — see the header of gallery-slider.js for why there is
			// no carousel library involved.
			wp_enqueue_style( 'fy-admin-theme-gallery-slider', FY_FLEET_URL . 'assets/theme/gallery-slider.css', array( 'fy-admin-theme-woo-front' ), FY_FLEET_VERSION );
			wp_enqueue_script( 'fy-admin-theme-gallery-slider', FY_FLEET_URL . 'assets/theme/gallery-slider.js', array( 'jquery' ), FY_FLEET_VERSION, true );
		}

		// Branded empty-cart scene. The cart is a WooCommerce Cart BLOCK, so
		// there is no PHP template to filter — see assets/theme/cart-empty.js.
		if ( is_cart() ) {
			wp_enqueue_style( 'fy-admin-theme-cart-empty', FY_FLEET_URL . 'assets/theme/cart-empty.css', array( 'fy-admin-theme-woo-front' ), FY_FLEET_VERSION );
			wp_enqueue_script( 'fy-admin-theme-cart-empty', FY_FLEET_URL . 'assets/theme/cart-empty.js', array(), FY_FLEET_VERSION, true );
			wp_localize_script(
				'fy-admin-theme-cart-empty',
				'fyCartEmpty',
				array(
					'contactUrl' => home_url( '/contact/' ),
				)
			);
		}

		// Sticky booking bar + thank-you contact buttons + "added to cart" popup.
		wp_enqueue_script( 'fy-admin-theme-front-extras', FY_FLEET_URL . 'assets/theme/front-extras.js', array( 'jquery' ), FY_FLEET_VERSION, true );

		// The "added to cart" popup's back-to-fleet link and its subtle
		// add-on-services line. Region-aware the same way "Book a Yacht"
		// already is elsewhere, so a Panama guest lands on the Panama fleet
		// rather than Miami's. The service links are a fixed marketing list
		// (not post data), so they live here rather than a database lookup —
		// one place to edit if the URLs ever change.
		wp_localize_script(
			'fy-admin-theme-front-extras',
			'fyCartAddedData',
			array(
				'fleetUrl' => class_exists( 'FY_Fleet_Account' ) ? FY_Fleet_Account::region_fleet_url( get_current_user_id() ) : home_url( '/miami-yacht-rental/' ),
				'servicesUrl' => 'https://feelingyachty.com/miami-yacht-services',
				'services'  => array(
					array( 'label' => 'Catering', 'url' => 'https://feelingyachty.com/miami-yacht-services/catering/' ),
					array( 'label' => 'Photo, Video & Drone', 'url' => 'https://feelingyachty.com/miami-yacht-services/photography/' ),
					array( 'label' => 'Private Chef', 'url' => 'https://feelingyachty.com/miami-yacht-services/private-chef/' ),
					array( 'label' => 'Decor & Balloons', 'url' => 'https://feelingyachty.com/miami-yacht-services/decorations/' ),
					array( 'label' => 'Bartender & Open Bar', 'url' => 'https://feelingyachty.com/miami-yacht-services/bartender/' ),
					array( 'label' => 'Party Planning', 'url' => 'https://feelingyachty.com/miami-yacht-party/' ),
					array( 'label' => 'Black Car Transportation', 'url' => 'https://feelingyachty.com/miami-yacht-services/black-car' ),
					array( 'label' => 'Live DJ', 'url' => 'https://feelingyachty.com/miami-yacht-services/dj' ),
				),
			)
		);

		// The sticky bar's price used to be scraped from WooCommerce's own
		// price element via jQuery .text() — which pulls in the visually-
		// hidden "Price range: $X through $Y" accessibility text WooCommerce
		// adds for screen readers, so the bar showed both the visible range
		// AND that hidden string mashed together with no space between them.
		// Passing the number the plugin already computed (the same "From $X"
		// figure now shown on the card and the product header) sidesteps
		// scraping the DOM altogether.
		if ( is_product() ) {
			$sticky_yacht = 0;
			if ( class_exists( 'FY_Fleet_CPT' ) ) {
				$sticky_yacht = (int) get_post_meta( get_the_ID(), '_fy_yacht_id', true );
			}
			$sticky_from = ( $sticky_yacht && class_exists( 'FY_Fleet_Pricing' ) ) ? FY_Fleet_Pricing::display_from_price( $sticky_yacht ) : null;
			wp_localize_script(
				'fy-admin-theme-front-extras',
				'fyStickyBar',
				array(
					'fromPrice' => $sticky_from ? '$' . number_format( $sticky_from['amount'] ) : '',
					'fromUnit'  => ( $sticky_from && class_exists( 'FY_Fleet_Pricing' ) ) ? FY_Fleet_Pricing::display_from_unit( $sticky_yacht, $sticky_from ) : '',
				)
			);
		}
	}

	/**
	 * Stop WordPress replacing emoji with images.
	 *
	 * Measured on a live yacht page: 105 of that page's 143 <img> tags were
	 * emoji — one external request each, to s.w.org, purely to draw the ✨ and
	 * 💙 in yacht names. That's more image requests than the yacht's entire
	 * photo gallery (17), plus an extra script.
	 *
	 * Every browser this site supports renders emoji natively from the system
	 * font, so removing the converter costs nothing visually — the emoji still
	 * appear. It also removes a whole class of layout bug, since emoji stop
	 * being images that CSS can accidentally size (an <img> emoji in a product
	 * title was rendering 255px tall inside the related-products carousel).
	 *
	 * Front end only: the admin keeps its emoji picker behaviour untouched.
	 */
	public static function disable_emoji_images() {
		if ( is_admin() ) {
			return;
		}
		remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
		remove_action( 'wp_print_styles', 'print_emoji_styles' );
		remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
		remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
		remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );

		// The emoji script is also injected as a DNS-prefetch hint; drop that
		// too so the browser stops connecting to a host it no longer needs.
		add_filter(
			'wp_resource_hints',
			function ( $urls, $relation ) {
				if ( 'dns-prefetch' !== $relation ) {
					return $urls;
				}
				return array_filter(
					$urls,
					function ( $url ) {
						return false === strpos( (string) ( is_array( $url ) ? ( isset( $url['href'] ) ? $url['href'] : '' ) : $url ), 's.w.org' );
					}
				);
			},
			10,
			2
		);
	}

	/**
	 * The theme's framework loads several icon-font stylesheets on every
	 * page; the site uses (at most) Font Awesome. Dequeue the rest —
	 * sitewide, frontend only.
	 */
	public static function trim_icon_fonts() {
		if ( is_admin() ) {
			return;
		}
		$keep = apply_filters( 'fy_admin_theme_keep_icon_packs', array( 'font-awesome' ) );

		global $wp_styles;
		if ( ! $wp_styles instanceof WP_Styles ) {
			return;
		}
		foreach ( $wp_styles->registered as $handle => $style ) {
			if ( empty( $style->src ) || false === strpos( (string) $style->src, 'gesso-core/inc/icons/' ) ) {
				continue;
			}
			$kept = false;
			foreach ( $keep as $pack ) {
				if ( false !== strpos( (string) $style->src, '/' . $pack . '/' ) ) {
					$kept = true;
					break;
				}
			}
			if ( ! $kept ) {
				wp_dequeue_style( $handle );
			}
		}
	}

	/** Warm up the Google Fonts connection so text renders without a flash. */
	public static function font_preconnect() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}
		if ( ! ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) ) {
			return;
		}
		echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
		echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
	}

	/* ------------------------------------------------------------------
	 * My Account polish
	 * ---------------------------------------------------------------- */

	/** Charters have no downloadable files — drop the tab. */
	public static function account_menu( $items ) {
		unset( $items['downloads'] );
		return $items;
	}

	/** Friendly welcome card at the top of the account dashboard. */
	public static function account_welcome() {
		$user  = wp_get_current_user();
		$first = $user->first_name ? $user->first_name : $user->display_name;
		echo '<div class="fy-welcome-card">';
		echo '<p class="fy-welcome-hi">' . sprintf( esc_html__( 'Hi %s 👋', 'fy-fleet' ), esc_html( $first ) ) . '</p>';
		echo '<p class="fy-welcome-sub">' . esc_html__( 'Welcome to your charter hub — check your bookings, pay balances, message the crew, or book your next day on the water.', 'fy-fleet' ) . '</p>';
		echo '<div class="fy-welcome-actions">';
		echo '<a class="fy-welcome-btn fy-welcome-btn--main" href="https://feelingyachty.com/miami-yacht-rentals/">🛥️ ' . esc_html__( 'Book a Yacht Experience', 'fy-fleet' ) . '</a>';
		if ( class_exists( 'FY_Fleet_Account' ) ) {
			echo '<a class="fy-welcome-btn" href="' . esc_url( wc_get_account_endpoint_url( 'fy-charters' ) ) . '">⚓ ' . esc_html__( 'My charters', 'fy-fleet' ) . '</a>';
			echo '<a class="fy-welcome-btn" href="' . esc_url( wc_get_account_endpoint_url( 'fy-support' ) ) . '">💬 ' . esc_html__( 'Support', 'fy-fleet' ) . '</a>';
		}
		echo '</div></div>';
	}

	/** "Return to shop" style buttons lead to the Miami rentals page. */
	public static function shop_redirect() {
		return 'https://feelingyachty.com/miami-yacht-rentals/';
	}

	/** Charter-friendly wording for WooCommerce's generic storefront texts. */
	public static function reword( $translated, $text, $domain ) {
		if ( is_admin() || 'woocommerce' !== $domain ) {
			return $translated;
		}
		switch ( $text ) {
			case 'Orders':
				return __( 'My Bookings', 'fy-fleet' );
			case 'Browse products':
				return __( 'Book a Yacht Experience 🛥️', 'fy-fleet' );
			case 'No order has been made yet.':
				return __( 'No charters booked yet — your next day on the water starts here.', 'fy-fleet' );
			case 'Account details':
				return __( 'My Details', 'fy-fleet' );
		}
		return $translated;
	}

	/* ------------------------------------------------------------------
	 * WooCommerce email branding.
	 *
	 * Registered ONLY when FY_Fleet_Emails (the fleet plugin's own email
	 * module) is absent/disabled — both do the same job, and running both
	 * would duplicate the charter card and contact footer in every email.
	 * ---------------------------------------------------------------- */

	public static function register_email_branding() {
		// The suite's own FY_Fleet_Emails module is always active in this
		// build, so this theme-side branding never actually registers —
		// kept only so removing/disabling FY_Fleet_Emails in the future
		// doesn't leave WooCommerce emails unbranded.
		if ( class_exists( 'FY_Fleet_Emails' ) ) {
			return;
		}
		add_filter( 'pre_option_woocommerce_email_header_image', array( __CLASS__, 'email_logo' ) );
		add_filter( 'woocommerce_email_styles', array( __CLASS__, 'email_styles' ) );
		add_action( 'woocommerce_email_order_details', array( __CLASS__, 'email_charter_details' ), 5, 4 );
		add_filter( 'woocommerce_email_footer_text', array( __CLASS__, 'email_footer' ) );
	}

	public static function email_logo( $value ) {
		$logo = self::logo_url();
		return $logo ? $logo : $value;
	}

	public static function email_styles( $css ) {
		return $css . '
			#wrapper { background-color: #F6F2FB; }
			#template_container { border: 1px solid #E6EAF3 !important; border-radius: 18px !important; overflow: hidden; box-shadow: 0 10px 26px rgba(23,32,51,.08) !important; }
			#template_header { background-color: #1B1033 !important; border-bottom: 4px solid #E45C9C; }
			#template_header h1 { color: #ffffff !important; text-shadow: none !important; }
			#template_header_image { background-color: #1B1033; }
			#template_header_image img { max-width: 170px; margin: 18px auto 0; }
			#template_header_image p { margin: 0; padding: 18px 0 0; background-color: #1B1033; text-align: center; }
			#body_content { background-color: #ffffff; }
			#body_content_inner { color: #3A4459 !important; font-size: 15px; line-height: 1.65; }
			h2 { color: #5B21B6 !important; font-weight: 700; }
			a { color: #C94386 !important; }
			.td { border-color: #E6EAF3 !important; font-size: 14.5px; }
			#template_footer #credit { color: #526079 !important; font-size: 13px; line-height: 1.7; }
		';
	}

	/** "Your Charter Details" block at the top of every order email. */
	public static function email_charter_details( $order, $sent_to_admin, $plain_text = false, $email = null ) {
		if ( ! is_a( $order, 'WC_Order' ) ) {
			return;
		}

		$bookings = array();
		foreach ( $order->get_items() as $item ) {
			$date = $item->get_meta( '_fy_date' );
			if ( ! $date ) {
				continue;
			}
			$bookings[] = array(
				'yacht'   => $item->get_name(),
				'date'    => $date,
				'time'    => $item->get_meta( '_fy_time' ),
				'hours'   => $item->get_meta( '_fy_hours' ),
				'guests'  => $item->get_meta( '_fy_guests' ),
				'marina'  => $item->get_meta( '_fy_marina' ),
				'total'   => (float) $item->get_meta( '_fy_charter_total' ),
				'deposit' => (float) $item->get_meta( '_fy_deposit' ),
				'balance' => (float) $item->get_meta( '_fy_balance' ),
			);
		}
		if ( empty( $bookings ) ) {
			return;
		}

		if ( $plain_text ) {
			echo "==== YOUR CHARTER DETAILS ====\n";
			echo 'Booking #' . wp_strip_all_tags( $order->get_order_number() ) . "\n";
			foreach ( $bookings as $b ) {
				echo "\n" . wp_strip_all_tags( $b['yacht'] ) . "\n";
				echo 'Date: ' . wp_strip_all_tags( $b['date'] ) . ' | Start: ' . wp_strip_all_tags( $b['time'] ) . ' | Duration: ' . wp_strip_all_tags( $b['hours'] ) . " hours\n";
				echo 'Passengers: ' . wp_strip_all_tags( $b['guests'] ) . ( $b['marina'] ? ' | Marina: ' . wp_strip_all_tags( $b['marina'] ) : '' ) . "\n";
				if ( $b['total'] ) {
					echo 'Charter total: ' . wp_strip_all_tags( wc_price( $b['total'] ) ) . ' | Deposit paid: ' . wp_strip_all_tags( wc_price( $b['deposit'] ) ) . ' | Balance at dock: ' . wp_strip_all_tags( wc_price( $b['balance'] ) ) . "\n";
				}
			}
			echo "==============================\n\n";
			return;
		}

		$cell  = 'padding:7px 12px;font-size:14px;color:#3A4459;border-bottom:1px solid #F0ECF9;';
		$label = $cell . 'font-weight:700;color:#172033;width:42%;';

		echo '<div style="margin:0 0 26px;border:1px solid #E6D9F8;border-radius:14px;overflow:hidden;">';
		echo '<div style="background:linear-gradient(90deg,#E45C9C,#7C3AED);background-color:#7C3AED;color:#ffffff;padding:12px 16px;font-size:16px;font-weight:800;">';
		echo '&#9875; Your Charter Details &mdash; Booking #' . esc_html( $order->get_order_number() );
		echo '</div>';

		foreach ( $bookings as $b ) {
			echo '<div style="padding:14px 16px 4px;font-size:15.5px;font-weight:800;color:#5B21B6;">' . esc_html( $b['yacht'] ) . '</div>';
			echo '<table cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse;">';
			echo '<tr><td style="' . esc_attr( $label ) . '">&#128197; Booking date</td><td style="' . esc_attr( $cell ) . '">' . esc_html( $b['date'] ) . '</td></tr>';
			echo '<tr><td style="' . esc_attr( $label ) . '">&#128336; Start time</td><td style="' . esc_attr( $cell ) . '">' . esc_html( $b['time'] ) . '</td></tr>';
			echo '<tr><td style="' . esc_attr( $label ) . '">&#8987; Duration</td><td style="' . esc_attr( $cell ) . '">' . esc_html( $b['hours'] ) . ' hours</td></tr>';
			echo '<tr><td style="' . esc_attr( $label ) . '">&#128101; Passengers</td><td style="' . esc_attr( $cell ) . '">' . esc_html( $b['guests'] ) . '</td></tr>';
			if ( $b['marina'] ) {
				echo '<tr><td style="' . esc_attr( $label ) . '">&#9973; Marina</td><td style="' . esc_attr( $cell ) . '">' . esc_html( $b['marina'] ) . '</td></tr>';
			}
			if ( $b['total'] ) {
				echo '<tr><td style="' . esc_attr( $label ) . '">&#128176; Charter total</td><td style="' . esc_attr( $cell ) . '">' . wp_kses_post( wc_price( $b['total'] ) ) . '</td></tr>';
				echo '<tr><td style="' . esc_attr( $label ) . '">&#9989; Deposit paid</td><td style="' . esc_attr( $cell ) . '">' . wp_kses_post( wc_price( $b['deposit'] ) ) . '</td></tr>';
				echo '<tr><td style="' . esc_attr( $label ) . 'color:#C94386;">&#128205; Balance due at dock</td><td style="' . esc_attr( $cell ) . 'font-weight:800;color:#C94386;">' . wp_kses_post( wc_price( $b['balance'] ) ) . '</td></tr>';
			}
			echo '</table>';
		}

		echo '<div style="padding:10px 16px;background:#FBF7FF;font-size:12.5px;color:#526079;">Questions? WhatsApp, SMS or call &mdash; Miami (954) 246-3636 &middot; Panam&aacute; +507 202-1729</div>';
		echo '</div>';
	}

	public static function email_footer( $text ) {
		$contacts = '<br/><br/><strong>Feeling Yachty</strong> — WhatsApp, SMS or call:<br/>'
			. 'Miami: <a href="tel:+19542463636">(954) 246-3636</a> · '
			. 'Panam&aacute;: <a href="tel:+5072021729">+507 202-1729</a><br/>'
			. '<a href="https://wa.me/19542463636">WhatsApp Miami</a> · '
			. '<a href="https://wa.me/5072021729">WhatsApp Panam&aacute;</a> · '
			. '<a href="https://feelingyachty.com">feelingyachty.com</a>';
		return $text . $contacts;
	}
}
