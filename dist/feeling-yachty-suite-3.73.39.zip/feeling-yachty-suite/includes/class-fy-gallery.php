<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reusable photo galleries.
 *
 * Galleries are their own post type so one set of photos can be built once and
 * assigned to any number of yachts. Images come from the media library or from
 * plain URLs, so photos already hosted elsewhere work without re-uploading.
 */
class FY_Fleet_Gallery {

	const POST_TYPE = 'fy_gallery';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_post_type' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_boxes' ) );
		add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'save_gallery' ), 10, 2 );
		add_action( 'save_post_' . FY_Fleet_CPT::POST_TYPE, array( __CLASS__, 'save_assignment' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_shortcode( 'fy_yacht_gallery', array( __CLASS__, 'shortcode' ) );
	}

	public static function register_post_type() {
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'          => array(
					'name'          => __( 'Galleries', 'fy-fleet' ),
					'singular_name' => __( 'Gallery', 'fy-fleet' ),
					'add_new'       => __( 'Add New Gallery', 'fy-fleet' ),
					'add_new_item'  => __( 'Add New Gallery', 'fy-fleet' ),
					'edit_item'     => __( 'Edit Gallery', 'fy-fleet' ),
					'menu_name'     => __( 'Galleries', 'fy-fleet' ),
					'all_items'     => __( 'Galleries', 'fy-fleet' ),
					'not_found'     => __( 'No galleries yet. Create one and assign it to any yacht.', 'fy-fleet' ),
				),
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE,
				'supports'        => array( 'title' ),
				'capability_type' => 'post',
				'show_in_rest'    => true,
			)
		);

		register_post_meta(
			self::POST_TYPE,
			'_fy_gallery_images',
			array(
				'show_in_rest'  => false,
				'single'        => true,
				'type'          => 'array',
				'auth_callback' => function () {
					return current_user_can( 'edit_posts' );
				},
			)
		);
	}

	public static function enqueue( $hook ) {
		global $post_type;
		if ( ! in_array( $post_type, array( self::POST_TYPE, FY_Fleet_CPT::POST_TYPE ), true ) ) {
			return;
		}
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'fy-fleet-gallery', FY_FLEET_URL . 'assets/gallery.css', array(), FY_FLEET_VERSION );
		wp_enqueue_script( 'fy-fleet-gallery', FY_FLEET_URL . 'assets/gallery.js', array( 'jquery' ), FY_FLEET_VERSION, true );
	}

	public static function add_meta_boxes() {
		add_meta_box( 'fy_gallery_images', __( 'Gallery Photos', 'fy-fleet' ), array( __CLASS__, 'render_gallery_box' ), self::POST_TYPE, 'normal', 'high' );
		add_meta_box( 'fy_gallery_assign', __( 'Photo Gallery', 'fy-fleet' ), array( __CLASS__, 'render_assign_box' ), FY_Fleet_CPT::POST_TYPE, 'side', 'default' );
	}

	/** Images stored on a gallery: list of ['id' => int, 'url' => string, 'alt' => string]. */
	public static function get_images( $gallery_id ) {
		$images = get_post_meta( $gallery_id, '_fy_gallery_images', true );
		if ( ! is_array( $images ) ) {
			return array();
		}

		$out = array();
		foreach ( $images as $image ) {
			$id  = isset( $image['id'] ) ? intval( $image['id'] ) : 0;
			$url = isset( $image['url'] ) ? $image['url'] : '';
			if ( $id && ! $url ) {
				$url = wp_get_attachment_image_url( $id, 'large' );
			}
			if ( ! $url ) {
				continue;
			}
			$out[] = array(
				'id'  => $id,
				'url' => $url,
				'alt' => isset( $image['alt'] ) ? $image['alt'] : '',
			);
		}
		return $out;
	}

	public static function render_gallery_box( $post ) {
		wp_nonce_field( 'fy_gallery_save', 'fy_gallery_nonce' );
		$images = self::get_images( $post->ID );
		$layout = get_post_meta( $post->ID, '_fy_gallery_layout', true );
		$layout = in_array( $layout, array( 'grid', 'slider' ), true ) ? $layout : 'grid';
		?>
		<p>
			<strong><?php esc_html_e( 'Layout:', 'fy-fleet' ); ?></strong>
			<label style="margin-left:8px"><input type="radio" name="fy_gallery_layout" value="grid" <?php checked( $layout, 'grid' ); ?>> <?php esc_html_e( 'Grid', 'fy-fleet' ); ?></label>
			<label style="margin-left:12px"><input type="radio" name="fy_gallery_layout" value="slider" <?php checked( $layout, 'slider' ); ?>> <?php esc_html_e( 'Slider (swipeable)', 'fy-fleet' ); ?></label>
		</p>
		<p class="description">
			<?php esc_html_e( 'Add photos from the media library, or paste image URLs for photos already hosted on your site. Drag to reorder.', 'fy-fleet' ); ?>
		</p>

		<div id="fy-gallery-items" class="fy-gallery-items">
			<?php foreach ( $images as $index => $image ) : ?>
				<?php self::render_item( $index, $image ); ?>
			<?php endforeach; ?>
		</div>

		<p>
			<button type="button" class="button button-primary" id="fy-gallery-add"><?php esc_html_e( 'Add from Media Library', 'fy-fleet' ); ?></button>
			<button type="button" class="button" id="fy-gallery-add-url"><?php esc_html_e( '+ Add by URL', 'fy-fleet' ); ?></button>
		</p>

		<script type="text/template" id="fy-gallery-item-template"><?php self::render_item( '__INDEX__', array() ); ?></script>
		<?php
	}

	private static function render_item( $index, $image ) {
		$id  = isset( $image['id'] ) ? $image['id'] : '';
		$url = isset( $image['url'] ) ? $image['url'] : '';
		$alt = isset( $image['alt'] ) ? $image['alt'] : '';
		?>
		<div class="fy-gallery-item">
			<div class="fy-gallery-thumb">
				<img src="<?php echo esc_url( $url ); ?>" alt="" <?php echo $url ? '' : 'style="display:none"'; ?>>
			</div>
			<div class="fy-gallery-fields">
				<input type="hidden" name="fy_gallery[<?php echo esc_attr( $index ); ?>][id]" value="<?php echo esc_attr( $id ); ?>" class="fy-gallery-id">
				<label><?php esc_html_e( 'Image URL', 'fy-fleet' ); ?>
					<input type="url" name="fy_gallery[<?php echo esc_attr( $index ); ?>][url]" value="<?php echo esc_attr( $url ); ?>" class="fy-gallery-url widefat">
				</label>
				<label><?php esc_html_e( 'Alt text', 'fy-fleet' ); ?>
					<input type="text" name="fy_gallery[<?php echo esc_attr( $index ); ?>][alt]" value="<?php echo esc_attr( $alt ); ?>" class="widefat">
				</label>
			</div>
			<button type="button" class="button-link-delete fy-gallery-remove"><?php esc_html_e( 'Remove', 'fy-fleet' ); ?></button>
		</div>
		<?php
	}

	public static function save_gallery( $post_id, $post ) {
		if ( ! isset( $_POST['fy_gallery_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fy_gallery_nonce'] ) ), 'fy_gallery_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$images = array();
		if ( isset( $_POST['fy_gallery'] ) && is_array( $_POST['fy_gallery'] ) ) {
			foreach ( wp_unslash( $_POST['fy_gallery'] ) as $image ) {
				$url = isset( $image['url'] ) ? esc_url_raw( $image['url'] ) : '';
				$id  = isset( $image['id'] ) ? intval( $image['id'] ) : 0;
				if ( ! $url && ! $id ) {
					continue;
				}
				$images[] = array(
					'id'  => $id,
					'url' => $url,
					'alt' => isset( $image['alt'] ) ? sanitize_text_field( $image['alt'] ) : '',
				);
			}
		}
		update_post_meta( $post_id, '_fy_gallery_images', $images );

		$layout = isset( $_POST['fy_gallery_layout'] ) ? sanitize_key( wp_unslash( $_POST['fy_gallery_layout'] ) ) : 'grid';
		update_post_meta( $post_id, '_fy_gallery_layout', in_array( $layout, array( 'grid', 'slider' ), true ) ? $layout : 'grid' );
	}

	/** Gallery picker shown on the yacht editor. */
	public static function render_assign_box( $post ) {
		wp_nonce_field( 'fy_gallery_assign', 'fy_gallery_assign_nonce' );
		$assigned  = (int) get_post_meta( $post->ID, '_fy_gallery_id', true );
		$galleries = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => array( 'publish', 'draft' ),
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);
		?>
		<select name="fy_gallery_id" class="widefat">
			<option value="0"><?php esc_html_e( '— No gallery —', 'fy-fleet' ); ?></option>
			<?php foreach ( $galleries as $gallery ) : ?>
				<option value="<?php echo esc_attr( $gallery->ID ); ?>" <?php selected( $assigned, $gallery->ID ); ?>>
					<?php echo esc_html( $gallery->post_title ); ?>
					(<?php echo count( self::get_images( $gallery->ID ) ); ?>)
				</option>
			<?php endforeach; ?>
		</select>
		<p class="description">
			<?php esc_html_e( 'Shown on this yacht\'s page. Galleries are reusable across yachts.', 'fy-fleet' ); ?>
		</p>
		<p>
			<a class="button" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=' . self::POST_TYPE ) ); ?>"><?php esc_html_e( 'Create a gallery', 'fy-fleet' ); ?></a>
			<?php if ( $assigned ) : ?>
				<a class="button" href="<?php echo esc_url( get_edit_post_link( $assigned ) ); ?>"><?php esc_html_e( 'Edit this one', 'fy-fleet' ); ?></a>
			<?php endif; ?>
		</p>
		<?php
	}

	public static function save_assignment( $post_id, $post ) {
		if ( ! isset( $_POST['fy_gallery_assign_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fy_gallery_assign_nonce'] ) ), 'fy_gallery_assign' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		update_post_meta( $post_id, '_fy_gallery_id', isset( $_POST['fy_gallery_id'] ) ? intval( $_POST['fy_gallery_id'] ) : 0 );
	}

	/* ------------------------------------------------------------------
	 * Front end
	 * ---------------------------------------------------------------- */

	public static function shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'yacht'   => 0,
				'gallery' => 0,
				'layout'  => '',
			),
			$atts,
			'fy_yacht_gallery'
		);

		if ( $atts['gallery'] ) {
			return self::render_gallery( intval( $atts['gallery'] ), $atts['layout'] );
		}
		return self::render( intval( $atts['yacht'] ), $atts['layout'] );
	}

	/**
	 * A shared, reusable gallery assigned via _fy_gallery_id takes priority
	 * (lets several yachts share one hand-curated photo set). Otherwise this
	 * falls back to the yacht's OWN photos — everything downloaded into its
	 * Media Library from the fleet spreadsheet's Images column.
	 */
	public static function render( $yacht_id, $layout = '' ) {
		$gallery_id = (int) get_post_meta( $yacht_id, '_fy_gallery_id', true );
		if ( $gallery_id ) {
			return self::render_gallery( $gallery_id, $layout );
		}
		return self::render_yacht_images( $yacht_id, $layout );
	}

	/** Images owned directly by the yacht (imported/uploaded, not a shared gallery). */
	public static function render_yacht_images( $yacht_id, $layout = '' ) {
		$ids = get_post_meta( $yacht_id, '_fy_gallery_image_ids', true );
		$ids = is_array( $ids ) ? array_map( 'intval', $ids ) : array();
		if ( empty( $ids ) ) {
			return '';
		}
		$images = array();
		foreach ( $ids as $id ) {
			$url = wp_get_attachment_image_url( $id, 'large' );
			if ( ! $url ) {
				continue;
			}
			$images[] = array(
				'id'  => $id,
				'url' => $url,
				'alt' => get_post_meta( $id, '_wp_attachment_image_alt', true ),
			);
		}
		return self::render_images( $images, $layout );
	}

	/**
	 * @param int    $gallery_id Gallery post ID.
	 * @param string $layout     'grid', 'slider', or '' to use the gallery's own setting.
	 */
	public static function render_gallery( $gallery_id, $layout = '' ) {
		$images = self::get_images( $gallery_id );
		if ( ! $layout ) {
			$layout = get_post_meta( $gallery_id, '_fy_gallery_layout', true );
		}
		return self::render_images( $images, $layout );
	}

	/** Shared renderer: a flat list of {id,url,alt} → the grid/slider markup. */
	private static function render_images( $images, $layout = '' ) {
		if ( empty( $images ) ) {
			return '';
		}

		$layout = in_array( $layout, array( 'grid', 'slider' ), true ) ? $layout : 'grid';

		ob_start();
		?>
		<section class="fy-gal fy-gal-<?php echo esc_attr( $layout ); ?>" aria-label="<?php esc_attr_e( 'Yacht photos', 'fy-fleet' ); ?>">
			<style>
			.fy-gal{
				--fy-pink-deep:#C94386;--fy-purple:#7C3AED;--fy-blue:#2563EB;
				margin:22px 0;font-family:ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;
			}
			.fy-gal-title{
				margin:0 0 12px;font-size:clamp(17px,2.4vw,22px);font-weight:950;letter-spacing:-.02em;
				background:linear-gradient(90deg,var(--fy-pink-deep),var(--fy-purple),var(--fy-blue));
				-webkit-background-clip:text;background-clip:text;color:transparent;
			}
			.fy-gal-grid .fy-gal-strip{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:10px}
			/* Slider: horizontal scroll-snap, no JavaScript needed. */
			.fy-gal-slider .fy-gal-strip{
				display:grid;grid-auto-flow:column;grid-auto-columns:minmax(260px,42%);
				gap:12px;overflow-x:auto;scroll-snap-type:x mandatory;
				padding-bottom:10px;-webkit-overflow-scrolling:touch;overscroll-behavior-x:contain;
			}
			.fy-gal-slider .fy-gal-item{scroll-snap-align:center}
			.fy-gal-slider .fy-gal-strip::-webkit-scrollbar{height:8px}
			.fy-gal-slider .fy-gal-strip::-webkit-scrollbar-thumb{background:rgba(124,58,237,.35);border-radius:999px}
			.fy-gal-slider .fy-gal-strip::-webkit-scrollbar-track{background:rgba(23,32,51,.06);border-radius:999px}
			.fy-gal-hint{margin:6px 0 0;color:#526079;font-size:11.5px;font-weight:800}
			@media(min-width:900px){.fy-gal-slider .fy-gal-strip{grid-auto-columns:minmax(280px,31%)}}
			.fy-gal-item{
				display:block;aspect-ratio:4/3;overflow:hidden;border-radius:15px;
				border:1px solid rgba(37,99,235,.12);background:#f8fafc;
				box-shadow:0 7px 18px rgba(23,32,51,.07);
			}
			.fy-gal-item img{
				display:block;width:100%;height:100%;object-fit:cover;
				transition:transform .25s ease;
			}
			.fy-gal-item:hover img{transform:scale(1.05)}
			@media(prefers-reduced-motion:reduce){.fy-gal-item img{transition:none}.fy-gal-item:hover img{transform:none}}
			</style>
			<h3 class="fy-gal-title">📸 <?php esc_html_e( 'Photos', 'fy-fleet' ); ?></h3>
			<div class="fy-gal-strip">
				<?php foreach ( $images as $index => $image ) : ?>
					<a class="fy-gal-item" href="<?php echo esc_url( $image['url'] ); ?>" data-fy-lightbox="<?php echo esc_attr( $index ); ?>">
						<img src="<?php echo esc_url( $image['url'] ); ?>" alt="<?php echo esc_attr( $image['alt'] ); ?>" loading="lazy" decoding="async" width="800" height="600">
					</a>
				<?php endforeach; ?>
			</div>
			<?php if ( 'slider' === $layout ) : ?>
				<p class="fy-gal-hint"><?php esc_html_e( '← Swipe or scroll for more photos →', 'fy-fleet' ); ?></p>
			<?php endif; ?>
		</section>
		<?php echo self::lightbox_once(); // phpcs:ignore -- static trusted template ?>
		<?php
		return ob_get_clean();
	}

	/**
	 * Full-screen lightbox with prev/next, swipe and keyboard support.
	 * Keeps mobile visitors in the funnel instead of losing them to a new tab.
	 * Printed once per page regardless of how many galleries render.
	 */
	private static function lightbox_once() {
		static $printed = false;
		if ( $printed ) {
			return '';
		}
		$printed = true;

		ob_start();
		?>
		<div class="fy-lb" id="fy-lightbox" hidden>
			<style>
			.fy-lb{position:fixed;inset:0;z-index:999999;display:flex;align-items:center;justify-content:center;background:rgba(15,20,33,.94)}
			.fy-lb[hidden]{display:none}
			.fy-lb-img{max-width:92vw;max-height:86vh;border-radius:12px;box-shadow:0 24px 70px rgba(0,0,0,.55);user-select:none}
			.fy-lb-btn{
				position:absolute;display:grid;place-items:center;width:48px;height:48px;border:0;border-radius:50%;
				background:rgba(255,255,255,.14);color:#fff;font-size:24px;line-height:1;cursor:pointer;backdrop-filter:blur(4px);
			}
			.fy-lb-btn:hover{background:rgba(255,255,255,.28)}
			.fy-lb-close{top:16px;right:16px}
			.fy-lb-prev{left:12px;top:50%;transform:translateY(-50%)}
			.fy-lb-next{right:12px;top:50%;transform:translateY(-50%)}
			.fy-lb-count{position:absolute;bottom:18px;left:50%;transform:translateX(-50%);color:rgba(255,255,255,.85);font:800 12.5px/1 ui-sans-serif,system-ui,sans-serif;letter-spacing:.05em}
			@media(pointer:coarse){.fy-lb-btn{width:52px;height:52px}}
			</style>
			<button type="button" class="fy-lb-btn fy-lb-close" aria-label="<?php esc_attr_e( 'Close', 'fy-fleet' ); ?>">×</button>
			<button type="button" class="fy-lb-btn fy-lb-prev" aria-label="<?php esc_attr_e( 'Previous photo', 'fy-fleet' ); ?>">‹</button>
			<img class="fy-lb-img" src="" alt="">
			<button type="button" class="fy-lb-btn fy-lb-next" aria-label="<?php esc_attr_e( 'Next photo', 'fy-fleet' ); ?>">›</button>
			<span class="fy-lb-count"></span>
		</div>
		<script>
		(function(){
			var lb=document.getElementById('fy-lightbox');
			if(!lb||lb.getAttribute('data-ready'))return;
			lb.setAttribute('data-ready','1');
			var img=lb.querySelector('.fy-lb-img'),count=lb.querySelector('.fy-lb-count');
			var items=[],current=0,touchX=null;

			function collect(anchor){
				var strip=anchor.closest('.fy-gal-strip');
				return strip?Array.prototype.slice.call(strip.querySelectorAll('[data-fy-lightbox]')):[anchor];
			}
			function show(i){
				if(!items.length)return;
				current=(i+items.length)%items.length;
				img.src=items[current].href;
				img.alt=(items[current].querySelector('img')||{}).alt||'';
				count.textContent=(current+1)+' / '+items.length;
			}
			function open(anchor){
				items=collect(anchor);
				show(items.indexOf(anchor));
				lb.hidden=false;
				document.body.style.overflow='hidden';
			}
			function close(){lb.hidden=true;document.body.style.overflow='';}

			document.addEventListener('click',function(e){
				var a=e.target.closest?e.target.closest('[data-fy-lightbox]'):null;
				if(a){e.preventDefault();open(a);return;}
				if(e.target.closest('.fy-lb-close')){close();return;}
				if(e.target.closest('.fy-lb-prev')){show(current-1);return;}
				if(e.target.closest('.fy-lb-next')){show(current+1);return;}
				if(e.target===lb){close();}
			});
			document.addEventListener('keydown',function(e){
				if(lb.hidden)return;
				if(e.key==='Escape')close();
				if(e.key==='ArrowLeft')show(current-1);
				if(e.key==='ArrowRight')show(current+1);
			});
			lb.addEventListener('touchstart',function(e){touchX=e.touches[0].clientX;},{passive:true});
			lb.addEventListener('touchend',function(e){
				if(touchX===null)return;
				var dx=e.changedTouches[0].clientX-touchX;
				if(Math.abs(dx)>40)show(current+(dx<0?1:-1));
				touchX=null;
			},{passive:true});
		})();
		</script>
		<?php
		return ob_get_clean();
	}
}
