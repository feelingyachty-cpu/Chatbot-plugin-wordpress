<?php
/**
 * Default "GHL Form Code" shown at checkout.
 *
 * This is only the starting value — it is copied into the editable
 * "GHL Form Code" field under Yacht Fleet → Checkout & Integrations, where it can be
 * changed at any time (paste your GoHighLevel iframe embed inside it).
 *
 * CSS rules are identical to the original; only whitespace is condensed.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return <<<'FYGHL'
<!-- =========================================
Feeling Yachty — Bilingual Verification Form Intro
English displays by default.
========================================= -->
<section id="fy-bareboat-form-intro">
<style>
#fy-bareboat-form-intro{--fy-pink:#E45C9C;--fy-pink-dark:#C7347B;--fy-pink-deep:#A91F63;--fy-light-pink:#FFF7FB;--fy-soft-pink:#FDF2F8;--fy-border:#F4D6E5;--fy-blue:#2563EB;--fy-blue-light:#EEF7FF;--fy-gold:#A86500;--fy-gold-light:#FFFAF0;--fy-text:#334155;--fy-muted:#64748B;width:100%;box-sizing:border-box;font-family:Arial,Helvetica,sans-serif;color:var(--fy-text)}
#fy-bareboat-form-intro *,#fy-bareboat-form-intro *::before,#fy-bareboat-form-intro *::after{box-sizing:border-box}
#fy-bareboat-form-intro .fy-wrapper{width:100%;padding:24px;border:1px solid var(--fy-border);border-radius:18px;background:var(--fy-light-pink);box-shadow:0 8px 24px rgba(228,92,156,.11);line-height:1.7}
#fy-bareboat-form-intro .fy-language-area{display:flex;justify-content:center;margin-bottom:24px}
#fy-bareboat-form-intro .fy-language-inner{width:100%;max-width:430px;text-align:center}
#fy-bareboat-form-intro .fy-language-switch{position:relative;display:inline-flex;align-items:center;justify-content:center;gap:10px;width:100%;min-height:60px;padding:14px 22px;overflow:hidden;border:2px solid #FFFFFF;border-radius:999px;background:linear-gradient(110deg,#E45C9C,#B83280,#7C3AED,#2563EB,#E45C9C);background-size:300% 300%;color:#FFFFFF;font-size:17px;font-weight:800;line-height:1.25;text-align:center;cursor:pointer;box-shadow:0 0 0 4px rgba(228,92,156,.14),0 10px 28px rgba(199,52,123,.32);animation:fyFormGradient 4s ease infinite,fyFormPulse 2.2s ease-in-out infinite;transition:transform .2s ease,box-shadow .2s ease}
#fy-bareboat-form-intro .fy-language-switch::before{content:"";position:absolute;top:-80%;left:-35%;width:28%;height:260%;background:rgba(255,255,255,.55);transform:rotate(24deg);animation:fyFormShine 2.8s ease-in-out infinite;pointer-events:none}
#fy-bareboat-form-intro .fy-language-switch:hover{transform:translateY(-2px) scale(1.02);box-shadow:0 0 0 5px rgba(228,92,156,.18),0 14px 32px rgba(199,52,123,.38)}
#fy-bareboat-form-intro .fy-language-switch:active{transform:scale(.98)}
#fy-bareboat-form-intro .fy-language-switch:focus-visible{outline:4px solid rgba(37,99,235,.28);outline-offset:4px}
#fy-bareboat-form-intro .fy-language-icon{font-size:24px;line-height:1}
#fy-bareboat-form-intro .fy-language-helper{margin:12px 0 0;color:var(--fy-muted);font-size:14px;font-weight:600;text-align:center}
#fy-bareboat-form-intro .fy-content{animation:fyFormFade .35s ease}
#fy-bareboat-form-intro .fy-content[hidden]{display:none!important}
#fy-bareboat-form-intro .fy-title{margin:0 0 16px;color:var(--fy-pink);font-size:28px;line-height:1.3}
#fy-bareboat-form-intro .fy-lead{margin-top:0;font-size:17px}
#fy-bareboat-form-intro .fy-info-box{margin:20px 0;padding:18px;border-left:5px solid var(--fy-pink);border-radius:12px;background:#FFFFFF}
#fy-bareboat-form-intro .fy-info-title{display:block;margin-bottom:10px;color:var(--fy-pink-dark);font-size:18px;line-height:1.4}
#fy-bareboat-form-intro .fy-important-box{margin-top:20px;padding:18px;border-left:5px solid #F4B400;border-radius:12px;background:var(--fy-gold-light)}
#fy-bareboat-form-intro .fy-important-title{display:block;margin-bottom:10px;color:var(--fy-gold);font-size:18px;line-height:1.4}
#fy-bareboat-form-intro .fy-contact-box{margin:20px 0;padding:18px;border-left:5px solid var(--fy-blue);border-radius:12px;background:var(--fy-blue-light)}
#fy-bareboat-form-intro .fy-contact-title{display:block;margin-bottom:10px;color:var(--fy-blue);font-size:18px;line-height:1.4}
#fy-bareboat-form-intro .fy-thank-you{margin:20px 0 0}
#fy-bareboat-form-intro .fy-instagram{margin-top:22px;padding:18px;border:1px solid var(--fy-border);border-radius:12px;background:#FFFFFF;text-align:center}
#fy-bareboat-form-intro .fy-instagram-title{margin:0;color:var(--fy-pink-dark);font-size:17px}
#fy-bareboat-form-intro .fy-instagram-link{display:inline-block;margin-top:8px;color:var(--fy-pink);font-size:20px;font-weight:800;text-decoration:none}
#fy-bareboat-form-intro .fy-instagram-link:hover{color:var(--fy-pink-deep);text-decoration:underline}
#fy-bareboat-form-intro .fy-ghl-embed{margin-top:22px;padding:0;border:1px solid var(--fy-border);border-radius:12px;background:#FFFFFF;overflow:hidden}
#fy-bareboat-form-intro .fy-ghl-embed iframe{display:block;width:100%;border:0}
@keyframes fyFormGradient{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}
@keyframes fyFormPulse{0%,100%{box-shadow:0 0 0 4px rgba(228,92,156,.14),0 10px 28px rgba(199,52,123,.30)}50%{box-shadow:0 0 0 8px rgba(228,92,156,.08),0 14px 34px rgba(124,58,237,.37)}}
@keyframes fyFormShine{0%{left:-40%}55%,100%{left:125%}}
@keyframes fyFormFade{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:translateY(0)}}
@media (max-width:600px){
#fy-bareboat-form-intro .fy-wrapper{padding:17px;border-radius:14px}
#fy-bareboat-form-intro .fy-language-switch{min-height:62px;padding:14px 16px;font-size:16px}
#fy-bareboat-form-intro .fy-title{font-size:23px}
#fy-bareboat-form-intro .fy-info-box,#fy-bareboat-form-intro .fy-contact-box,#fy-bareboat-form-intro .fy-important-box{padding:16px}
}
@media (prefers-reduced-motion:reduce){
#fy-bareboat-form-intro .fy-language-switch,#fy-bareboat-form-intro .fy-language-switch::before,#fy-bareboat-form-intro .fy-content{animation:none}
}
</style>
<div class="fy-wrapper">
  <div class="fy-language-area">
    <div class="fy-language-inner">
      <button type="button" class="fy-language-switch" id="fy-form-language-toggle" aria-controls="fy-form-english fy-form-spanish" aria-pressed="false" aria-label="Switch this information to Spanish">
        <span class="fy-language-icon" aria-hidden="true">🇪🇸</span>
        <span id="fy-form-language-button-text">Ver este formulario en español</span>
      </button>
      <p class="fy-language-helper" id="fy-form-language-helper">This form information is currently displayed in English.</p>
    </div>
  </div>

  <div class="fy-content" id="fy-form-english" lang="en">
    <h2 class="fy-title">🛥️ Bareboat Charter Reservation Verification Form</h2>
    <p class="fy-lead"><strong>This Reservation Verification Form is mandatory for every charter.</strong></p>
    <div class="fy-info-box">
      <strong class="fy-info-title">⚓ Why This Form Is Required</strong>
      <p>To comply with applicable <strong>U.S. Coast Guard Bareboat Charter requirements</strong>, Feeling Yachty must collect and verify the required reservation information, government-issued identification, signatures, and acknowledgements before your charter may depart.</p>
      <p><strong>Your charter will not be permitted to depart until this form has been fully completed, signed, reviewed, and approved.</strong></p>
    </div>
    <div class="fy-contact-box">
      <strong class="fy-contact-title">📱 Please Provide Accurate Contact Information</strong>
      <p>The information provided in this form will be used to send your reservation confirmation, required documents, payment information, reminders, SMS updates, check-in instructions, marina location, boarding details, weather updates, schedule changes, and other important communications regarding your charter.</p>
      <p><strong>Incorrect or incomplete information may result in missed updates, boarding delays, or difficulty receiving important information before your trip.</strong></p>
    </div>
    <div class="fy-important-box">
      <strong class="fy-important-title">⚠️ Complete This Form as Soon as Possible</strong>
      <p>Your reservation will remain pending until all required information, identification, signatures, and documentation have been received, verified, and approved.</p>
      <p><strong>Without the required documentation, Feeling Yachty cannot complete the reservation verification process or authorize the charter to depart.</strong></p>
    </div>
    <p class="fy-thank-you">✅ Thank you for helping us keep your charter safe, organized, and compliant. We look forward to welcoming you aboard! 🌊🛥️</p>
    <div class="fy-instagram">
      <p class="fy-instagram-title">📸 <strong>Follow Feeling Yachty</strong></p>
      <p style="margin:8px 0 0;">Charter highlights, destination ideas, guest experiences, and special offers.</p>
      <a class="fy-instagram-link" href="https://www.instagram.com/feeling.yachty" target="_blank" rel="noopener noreferrer">@feeling.yachty</a>
    </div>
  </div>

  <div class="fy-content" id="fy-form-spanish" lang="es" hidden>
    <h2 class="fy-title">🛥️ Formulario de Verificación de Reserva de Chárter Bareboat</h2>
    <p class="fy-lead"><strong>Este Formulario de Verificación de Reserva es obligatorio para cada chárter.</strong></p>
    <div class="fy-info-box">
      <strong class="fy-info-title">⚓ Por Qué Se Requiere Este Formulario</strong>
      <p>Para cumplir con los requisitos aplicables de la <strong>Guardia Costera de los Estados Unidos para chárteres Bareboat</strong>, Feeling Yachty debe recopilar y verificar la información de la reserva, la identificación oficial, las firmas y las aceptaciones requeridas antes de que su chárter pueda salir.</p>
      <p><strong>Su chárter no podrá salir hasta que este formulario haya sido completado, firmado, revisado y aprobado.</strong></p>
    </div>
    <div class="fy-contact-box">
      <strong class="fy-contact-title">📱 Proporcione Información de Contacto Correcta</strong>
      <p>La información proporcionada en este formulario se utilizará para enviarle la confirmación de su reserva, documentos requeridos, información de pago, recordatorios, mensajes SMS, instrucciones de registro, ubicación de la marina, detalles de embarque, actualizaciones del clima, cambios de horario y otras comunicaciones importantes relacionadas con su chárter.</p>
      <p><strong>La información incorrecta o incompleta puede causar que no reciba actualizaciones, retrasos durante el embarque o dificultades para recibir información importante antes de su viaje.</strong></p>
    </div>
    <div class="fy-important-box">
      <strong class="fy-important-title">⚠️ Complete Este Formulario lo Antes Posible</strong>
      <p>Su reserva permanecerá pendiente hasta que toda la información, identificación, documentación y firmas requeridas hayan sido recibidas, verificadas y aprobadas.</p>
      <p><strong>Sin la documentación requerida, Feeling Yachty no podrá completar el proceso de verificación ni autorizar la salida del chárter.</strong></p>
    </div>
    <p class="fy-thank-you">✅ Gracias por ayudarnos a mantener su chárter seguro, organizado y en cumplimiento con los requisitos aplicables. ¡Esperamos darle la bienvenida a bordo! 🌊🛥️</p>
    <div class="fy-instagram">
      <p class="fy-instagram-title">📸 <strong>Siga a Feeling Yachty</strong></p>
      <p style="margin:8px 0 0;">Vea nuestros chárteres, destinos, experiencias de clientes y ofertas especiales.</p>
      <a class="fy-instagram-link" href="https://www.instagram.com/feeling.yachty" target="_blank" rel="noopener noreferrer">@feeling.yachty</a>
    </div>
  </div>

  <!-- ==========================================================
  PASTE YOUR GOHIGHLEVEL FORM EMBED BELOW.
  In GHL: open the form → Share / Embed → copy the <iframe> code
  and replace this whole comment block with it.
  ========================================================== -->
  <div class="fy-ghl-embed">
    {{GHL_FORM_EMBED}}
  </div>
</div>

<script>
(function(){
  var section=document.getElementById("fy-bareboat-form-intro");
  if(!section)return;
  var toggleButton=section.querySelector("#fy-form-language-toggle");
  var buttonText=section.querySelector("#fy-form-language-button-text");
  var helperText=section.querySelector("#fy-form-language-helper");
  var languageIcon=section.querySelector(".fy-language-icon");
  var englishContent=section.querySelector("#fy-form-english");
  var spanishContent=section.querySelector("#fy-form-spanish");
  if(!toggleButton||!buttonText||!helperText||!languageIcon||!englishContent||!spanishContent)return;
  var currentLanguage="en";
  function replayAnimation(el){el.style.animation="none";void el.offsetWidth;el.style.animation="fyFormFade 0.35s ease";}
  function switchLanguage(){
    var showSpanish=currentLanguage==="en";
    englishContent.hidden=showSpanish;
    spanishContent.hidden=!showSpanish;
    if(showSpanish){
      currentLanguage="es";
      buttonText.textContent="View this form in English";
      helperText.textContent="La información del formulario se muestra actualmente en español.";
      languageIcon.textContent="🇺🇸";
      toggleButton.setAttribute("aria-pressed","true");
      toggleButton.setAttribute("aria-label","Cambiar la información del formulario al inglés");
      replayAnimation(spanishContent);
    }else{
      currentLanguage="en";
      buttonText.textContent="Ver este formulario en español";
      helperText.textContent="This form information is currently displayed in English.";
      languageIcon.textContent="🇪🇸";
      toggleButton.setAttribute("aria-pressed","false");
      toggleButton.setAttribute("aria-label","Switch this form information to Spanish");
      replayAnimation(englishContent);
    }
  }
  toggleButton.addEventListener("click",switchLanguage);
})();
</script>
</section>
FYGHL;
