<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Booking pricing engine.
 *
 * Turns a yacht's stored rate rows (which may be split by day headings such as
 * "Monday–Thursday" / "Friday–Sunday") into a concrete quote for a chosen date,
 * duration and set of add-ons. Used by both the front-end form and the
 * authoritative server-side recalculation at add-to-cart.
 */
class FY_Fleet_Pricing {

	/**
	 * Total hours on the water implied by a duration label.
	 * "Pay for 4 Hours Get 5 Hours Total" => 5. "3 Hours" => 3.
	 */
	public static function hours_from_label( $label ) {
		$label = (string) $label;
		if ( preg_match( '/get\s+(\d+(?:\.\d+)?)\s*hour/i', $label, $m ) ) {
			return (float) $m[1];
		}
		if ( preg_match( '/(\d+(?:\.\d+)?)\s*hour/i', $label, $m ) ) {
			return (float) $m[1];
		}
		return 0.0;
	}

	/**
	 * { "<duration slug>": { hours, price } } for one yacht — the real boat
	 * cost for each duration, keyed the same way
	 * FY_Fleet_Woo::sync_variations() keys the WooCommerce Charter Duration
	 * variation it builds from that same row (sanitize_title of the label).
	 *
	 * A yacht with day-of-week price groups (Mon–Thu vs Fri–Sun) can reuse
	 * one label at two different prices — sync_variations() then creates
	 * two variations sharing that one attribute value, and WooCommerce's
	 * own variation matching always resolves to the FIRST one it created
	 * (confirmed by testing: `find_matching_product_variation()` returns
	 * the lowest-ID match). This keeps the FIRST row per slug too, so a
	 * balance or on-page total computed from this map always agrees with
	 * what the yacht's product actually charges — never a different,
	 * plausible-looking price from the other group.
	 */
	public static function rows_by_duration_slug( $yacht_id ) {
		$rows = get_post_meta( $yacht_id, '_fy_pricing', true );
		$out  = array();
		if ( ! is_array( $rows ) ) {
			return $out;
		}
		foreach ( $rows as $row ) {
			if ( isset( $row['type'] ) && 'price' !== $row['type'] ) {
				continue;
			}
			$hours = self::hours_from_label( isset( $row['duration'] ) ? $row['duration'] : '' );
			$price = isset( $row['price'] ) ? (float) $row['price'] : 0;
			if ( $hours <= 0 || $price <= 0 ) {
				continue;
			}
			$slug = sanitize_title( $row['duration'] );
			if ( isset( $out[ $slug ] ) ) {
				continue; // First occurrence wins — see method docblock.
			}
			$out[ $slug ] = array(
				'hours'    => $hours,
				'price'    => $price,
				'duration' => isset( $row['duration'] ) ? (string) $row['duration'] : '',
			);
		}
		return $out;
	}

	/** One duration's real boat cost by its variation slug, or null. */
	public static function row_for_duration_slug( $yacht_id, $slug ) {
		$rows = self::rows_by_duration_slug( $yacht_id );
		return isset( $rows[ $slug ] ) ? $rows[ $slug ] : null;
	}

	/** First Hours & Pricing row whose label parses to these hours, or null. */
	public static function row_for_hours( $yacht_id, $hours ) {
		$hours = (float) $hours;
		if ( $hours <= 0 ) {
			return null;
		}
		$rows = get_post_meta( $yacht_id, '_fy_pricing', true );
		if ( ! is_array( $rows ) ) {
			return null;
		}
		foreach ( $rows as $row ) {
			if ( isset( $row['type'] ) && 'price' !== $row['type'] ) {
				continue;
			}
			$label = isset( $row['duration'] ) ? $row['duration'] : '';
			$h     = self::hours_from_label( $label );
			$p     = isset( $row['price'] ) ? (float) $row['price'] : 0;
			if ( $h > 0 && $p > 0 && abs( $h - $hours ) < 0.01 ) {
				return array(
					'hours'    => $h,
					'price'    => $p,
					'duration' => (string) $label,
				);
			}
		}
		return null;
	}

	/**
	 * Boat cost for a chosen duration. Uses the pricing row. Never multiplies
	 * _fy_price × hours unless that field is a true hourly rate.
	 */
	public static function boat_for_choice( $yacht_id, $hours, $row = null ) {
		if ( is_array( $row ) && isset( $row['price'] ) && (float) $row['price'] > 0 ) {
			return (float) $row['price'];
		}
		$by_hours = self::row_for_hours( $yacht_id, $hours );
		if ( $by_hours ) {
			return (float) $by_hours['price'];
		}
		$hourly = (float) get_post_meta( $yacht_id, '_fy_price', true );
		if ( $hours > 0 && $hourly > 0 && self::starting_price_is_hourly( $yacht_id ) ) {
			return round( $hourly * $hours, 2 );
		}
		return 0.0;
	}

	private static function day_map() {
		return array(
			'monday' => 1, 'mon' => 1,
			'tuesday' => 2, 'tue' => 2, 'tues' => 2,
			'wednesday' => 3, 'wed' => 3,
			'thursday' => 4, 'thu' => 4, 'thur' => 4, 'thurs' => 4,
			'friday' => 5, 'fri' => 5,
			'saturday' => 6, 'sat' => 6,
			'sunday' => 7, 'sun' => 7,
		);
	}

	/**
	 * Day numbers (1=Mon … 7=Sun) covered by a heading like "Monday–Thursday".
	 * Returns an empty array when the heading names no days.
	 */
	public static function days_from_heading( $text ) {
		$text = strtolower( (string) $text );
		$map  = self::day_map();

		preg_match_all( '/[a-z]+/', $text, $matches );
		$found = array();
		foreach ( $matches[0] as $word ) {
			if ( isset( $map[ $word ] ) ) {
				$found[] = $map[ $word ];
			}
		}
		if ( empty( $found ) ) {
			return array();
		}
		if ( 1 === count( $found ) ) {
			return array( $found[0] );
		}

		$start = $found[0];
		$end   = $found[ count( $found ) - 1 ];
		$days  = array();
		$day   = $start;
		for ( $i = 0; $i < 7; $i++ ) {
			$days[] = $day;
			if ( $day === $end ) {
				break;
			}
			$day = ( $day % 7 ) + 1;
		}
		return $days;
	}

	/**
	 * Split stored rate rows into day-scoped groups.
	 *
	 * @return array List of array{heading:string,days:int[],rows:array,notes:string[]}
	 */
	public static function groups( $rows ) {
		if ( ! is_array( $rows ) ) {
			return array();
		}

		$groups  = array();
		$current = array( 'heading' => '', 'days' => array(), 'rows' => array(), 'notes' => array() );

		foreach ( $rows as $row ) {
			$type = isset( $row['type'] ) ? $row['type'] : 'price';

			if ( 'heading' === $type ) {
				if ( ! empty( $current['rows'] ) ) {
					$groups[] = $current;
				}
				$text    = isset( $row['text'] ) ? $row['text'] : '';
				$current = array(
					'heading' => $text,
					'days'    => self::days_from_heading( $text ),
					'rows'    => array(),
					'notes'   => array(),
				);
			} elseif ( 'note' === $type ) {
				$current['notes'][] = isset( $row['text'] ) ? $row['text'] : '';
			} else {
				$current['rows'][] = array(
					'duration' => isset( $row['duration'] ) ? $row['duration'] : '',
					'price'    => isset( $row['price'] ) ? (float) $row['price'] : 0,
					'free'     => ! empty( $row['free'] ),
					'hours'    => self::hours_from_label( isset( $row['duration'] ) ? $row['duration'] : '' ),
				);
			}
		}

		if ( ! empty( $current['rows'] ) ) {
			$groups[] = $current;
		}

		return $groups;
	}

	/**
	 * Index of the rate group that applies on a given Y-m-d date.
	 * Falls back to an undated group, then to the first group.
	 */
	public static function group_index_for_date( $groups, $date ) {
		if ( empty( $groups ) ) {
			return -1;
		}
		$timestamp = strtotime( $date );
		if ( ! $timestamp ) {
			return 0;
		}
		$weekday = (int) gmdate( 'N', $timestamp );

		foreach ( $groups as $index => $group ) {
			if ( ! empty( $group['days'] ) && in_array( $weekday, $group['days'], true ) ) {
				return $index;
			}
		}
		foreach ( $groups as $index => $group ) {
			if ( empty( $group['days'] ) ) {
				return $index;
			}
		}
		return 0;
	}

	/** Global add-on catalog, merged with any yacht-specific extras. */
	public static function addons_for_yacht( $yacht_id ) {
		$catalog = FY_Fleet_Settings::get_addons();
		$out     = array();

		$disabled = get_post_meta( $yacht_id, '_fy_disabled_addons', true );
		$disabled = is_array( $disabled ) ? $disabled : array();

		foreach ( $catalog as $addon ) {
			if ( in_array( $addon['key'], $disabled, true ) ) {
				continue;
			}
			$out[ $addon['key'] ] = $addon;
		}

		$extra = get_post_meta( $yacht_id, '_fy_custom_addons', true );
		if ( is_array( $extra ) ) {
			foreach ( $extra as $i => $addon ) {
				if ( empty( $addon['label'] ) ) {
					continue;
				}
				$key         = 'yacht-' . $yacht_id . '-' . $i;
				$out[ $key ] = array(
					'key'   => $key,
					'label' => $addon['label'],
					'price' => isset( $addon['price'] ) ? (float) $addon['price'] : 0,
					'unit'  => ( isset( $addon['unit'] ) && 'hour' === $addon['unit'] ) ? 'hour' : 'flat',
					'note'  => isset( $addon['note'] ) ? $addon['note'] : '',
					'max'   => isset( $addon['max'] ) ? intval( $addon['max'] ) : 1,
				);
			}
		}

		return $out;
	}

	/** Weekend surcharge for this yacht on this date, or 0. */
	public static function surcharge_for_date( $yacht_id, $date ) {
		$amount = (float) get_post_meta( $yacht_id, '_fy_weekend_surcharge', true );
		if ( $amount <= 0 ) {
			return 0.0;
		}
		$timestamp = strtotime( $date );
		if ( ! $timestamp ) {
			return 0.0;
		}
		$weekday = (int) gmdate( 'N', $timestamp );
		$days    = FY_Fleet_Settings::get_weekend_days();
		return in_array( $weekday, $days, true ) ? $amount : 0.0;
	}

	/**
	 * Build an authoritative quote. Never trust client-side totals — this is
	 * recalculated server-side at add-to-cart.
	 *
	 * @param int   $yacht_id Yacht post ID.
	 * @param array $args     date, time, group_index, row_index, guests, addons[key=>qty], occasion, notes.
	 * @return array|WP_Error
	 */
	public static function quote( $yacht_id, $args ) {
		$yacht = get_post( $yacht_id );
		if ( ! $yacht || FY_Fleet_CPT::POST_TYPE !== $yacht->post_type ) {
			return new WP_Error( 'fy_bad_yacht', __( 'That yacht could not be found.', 'fy-fleet' ) );
		}

		$date = isset( $args['date'] ) ? sanitize_text_field( $args['date'] ) : '';
		if ( ! $date || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			return new WP_Error( 'fy_bad_date', __( 'Please choose a charter date.', 'fy-fleet' ) );
		}
		$notice_days = self::min_notice_days();
		$earliest    = gmdate( 'Y-m-d', time() + $notice_days * DAY_IN_SECONDS );
		if ( strtotime( $date ) < strtotime( $earliest ) ) {
			return new WP_Error(
				'fy_too_soon',
				$notice_days > 0
					? sprintf(
						/* translators: %d: days of notice */
						_n( 'Bookings need at least %d day of notice — please choose a later date or message us on WhatsApp for same-day charters.', 'Bookings need at least %d days of notice — please choose a later date or message us on WhatsApp.', $notice_days, 'fy-fleet' ),
						$notice_days
					)
					: __( 'Please choose a date in the future.', 'fy-fleet' )
			);
		}

		// Dates the owner has blocked for this yacht.
		$blackouts = preg_split( '/\r\n|\r|\n/', (string) get_post_meta( $yacht_id, '_fy_blackout_dates', true ) );
		if ( in_array( $date, array_map( 'trim', $blackouts ), true ) ) {
			return new WP_Error( 'fy_blocked_date', __( 'This yacht is not available on that date — please pick another day or message us on WhatsApp.', 'fy-fleet' ) );
		}

		$time  = isset( $args['time'] ) ? sanitize_text_field( $args['time'] ) : '';
		$slots = FY_Fleet_Settings::get_time_slots();
		// Settings slots are "9:00 AM"; the product page posts "9:00 am"
		// (and half-hour times the shortcode list never includes). Accept
		// any clock time, or a listed slot after normalizing case/spacing.
		if ( ( ! empty( $slots ) || '' !== $time ) && ! self::is_clock_time( $time ) && ! self::time_in_slots( $time, $slots ) ) {
			return new WP_Error( 'fy_bad_time', __( 'Please choose a start time.', 'fy-fleet' ) );
		}

		$rows   = get_post_meta( $yacht_id, '_fy_pricing', true );
		$groups = self::groups( $rows );
		if ( empty( $groups ) ) {
			return new WP_Error( 'fy_no_rates', __( 'This yacht has no bookable durations yet.', 'fy-fleet' ) );
		}

		// The rate group is decided by the date, not by the client.
		$group_index = self::group_index_for_date( $groups, $date );
		if ( ! isset( $groups[ $group_index ] ) ) {
			return new WP_Error( 'fy_no_rates', __( 'No rates apply to that date.', 'fy-fleet' ) );
		}
		$group = $groups[ $group_index ];

		$row_index = isset( $args['row_index'] ) ? intval( $args['row_index'] ) : -1;
		if ( ! isset( $group['rows'][ $row_index ] ) ) {
			return new WP_Error( 'fy_bad_duration', __( 'Please choose a charter length.', 'fy-fleet' ) );
		}
		$row = $group['rows'][ $row_index ];

		$hours   = $row['hours'] > 0 ? $row['hours'] : 0;
		$charter = (float) $row['price'];

		$guests = isset( $args['guests'] ) ? intval( $args['guests'] ) : 1;
		if ( $guests < 1 ) {
			$guests = 1;
		}
		$capacity = FY_Fleet_CPT::capacity( $yacht_id );
		if ( $capacity > 0 && $guests > $capacity ) {
			return new WP_Error(
				'fy_too_many_guests',
				sprintf(
					/* translators: %d: max guests this yacht holds */
					__( 'This yacht holds up to %d guests — please lower your guest count or choose a larger yacht.', 'fy-fleet' ),
					$capacity
				)
			);
		}

		$surcharge = self::surcharge_for_date( $yacht_id, $date );

		$available   = self::addons_for_yacht( $yacht_id );
		$chosen      = isset( $args['addons'] ) && is_array( $args['addons'] ) ? $args['addons'] : array();
		$addon_lines = array();
		$addons_total = 0.0;

		foreach ( $chosen as $key => $qty ) {
			$key = sanitize_text_field( $key );
			$qty = intval( $qty );
			if ( $qty < 1 || ! isset( $available[ $key ] ) ) {
				continue;
			}
			$addon = $available[ $key ];
			$max   = isset( $addon['max'] ) && $addon['max'] > 0 ? (int) $addon['max'] : 1;
			if ( $qty > $max ) {
				$qty = $max;
			}

			$unit = isset( $addon['unit'] ) ? $addon['unit'] : 'flat';
			if ( 'quote' === $unit ) {
				$units = 0;
				$line  = 0.0;
			} elseif ( ( 'hour' === $unit || 'hours' === $unit ) && $hours > 0 ) {
				$units = $hours;
				$line  = (float) $addon['price'] * $units * $qty;
			} else {
				$units = 1;
				$line  = (float) $addon['price'] * $qty;
			}

			$addon_lines[] = array(
				'key'   => $key,
				'label' => $addon['label'],
				'unit'  => $unit,
				'price' => (float) $addon['price'],
				'qty'   => $qty,
				'hours' => ( 'hour' === $unit || 'hours' === $unit ) ? $hours : 0,
				'total' => $line,
			);
			$addons_total += $line;
		}

		// Crew + hourly boat deposit are charged per hour. Crew follows the
		// $1,400 line. The hourly deposit follows the $800 line (was labeled
		// fuel). Only the deposit is credited against the boat — crew is a
		// non-refundable reservation fee. Coco 4h: today $500, dock $940.
		$crew_rate   = self::crew_rate_for_boat( $yacht_id, $charter );
		$fuel_rate   = self::fuel_rate_for_boat( $yacht_id, $charter );
		$service_fee = self::yacht_rate_or_default( $yacht_id, '_fy_service_fee', FY_Fleet_Settings::get_service_fee() );
		$crew_total  = round( $crew_rate * $hours, 2 );
		$fuel_total  = round( $fuel_rate * $hours, 2 );

		$total = $charter + $crew_total + $fuel_total + $service_fee + $surcharge + $addons_total;

		$reservation = 0.0;
		$addons_now  = round( $addons_total * FY_Fleet_Settings::get_addon_deposit_ratio(), 2 );
		if ( 'crew_fuel' === FY_Fleet_Settings::get_deposit_type() ) {
			$reservation = self::charter_deposit_for_boat( $charter );
			$deposit     = round( $crew_total + $fuel_total + $reservation + $addons_now, 2 );
			$total       = $charter + $service_fee + $surcharge + $addons_total;
			$balance     = self::dock_balance( $charter, $fuel_total, $reservation, $addons_total, $addons_now, $service_fee + $surcharge );
		} else {
			$deposit = self::deposit_for( $total );
			$balance = max( 0, $total - $deposit );
		}

		$marina       = class_exists( 'FY_Fleet_Marina' ) ? FY_Fleet_Marina::for_yacht( $yacht_id ) : null;
		$marina_title = $marina ? $marina['title'] : '';
		$marina_link  = $marina ? $marina['google'] : '';

		return array(
			'marina'        => $marina_title,
			'marina_link'   => $marina_link,
			'yacht_id'      => $yacht_id,
			'yacht'         => get_the_title( $yacht ),
			'date'          => $date,
			'time'          => $time,
			'day_label'     => $group['heading'],
			'duration'      => $row['duration'],
			'hours'         => $hours,
			'guests'        => $guests,
			'charter'       => $charter,
			'crew_rate'     => $crew_rate,
			'crew_total'    => $crew_total,
			'fuel_rate'     => $fuel_rate,
			'fuel_total'    => $fuel_total,
			'service_fee'   => $service_fee,
			'surcharge'     => $surcharge,
			'addons'        => $addon_lines,
			'addons_total'  => $addons_total,
			'total'         => $total,
			'deposit'       => $deposit,
			'reservation_deposit' => $reservation,
			'balance'       => $balance,
			'occasion'      => isset( $args['occasion'] ) ? sanitize_text_field( $args['occasion'] ) : '',
			'notes'         => isset( $args['notes'] ) ? sanitize_textarea_field( $args['notes'] ) : '',
		);
	}

	/** "9:00 AM", "9:00 am", "09:00 am" → "9:00 am". Empty / unparseable → ''. */
	public static function normalize_time_label( $time ) {
		$time = trim( (string) $time );
		if ( '' === $time ) {
			return '';
		}
		$ts = strtotime( $time );
		if ( false === $ts ) {
			return strtolower( preg_replace( '/\s+/', ' ', $time ) );
		}
		return strtolower( date( 'g:i a', $ts ) );
	}

	/** True for a 12-hour clock string such as "6:00 am" or "12:30 PM". */
	public static function is_clock_time( $time ) {
		return (bool) preg_match( '/^\d{1,2}:\d{2}\s*([ap]\.?m\.?)$/i', trim( (string) $time ) );
	}

	/** Case-insensitive match against the settings time-slot list. */
	public static function time_in_slots( $time, $slots ) {
		$want = self::normalize_time_label( $time );
		if ( '' === $want ) {
			return false;
		}
		foreach ( (array) $slots as $slot ) {
			if ( self::normalize_time_label( $slot ) === $want ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Crew $/hr for this boat total.
	 * At or under the $1,400 line: fleet $75/hr (all yachts).
	 * Over the line: yacht override, or fleet $100/hr.
	 * A filled _fy_crew_rate on the yacht wins on both sides (2-person crew).
	 */
	public static function crew_rate_for_boat( $yacht_id, $boat_total ) {
		$override = get_post_meta( $yacht_id, '_fy_crew_rate', true );
		if ( '' !== $override && null !== $override ) {
			return max( 0, (float) $override );
		}
		$threshold = FY_Fleet_Settings::get_charter_deposit_threshold();
		if ( $threshold > 0 && (float) $boat_total <= $threshold ) {
			return FY_Fleet_Settings::get_crew_rate_under();
		}
		return FY_Fleet_Settings::get_crew_rate();
	}

	/**
	 * Hourly boat deposit $/hr for this boat total. Setting key stays _fy_fuel_rate.
	 * At or under $800: fleet $25/hr.
	 * Over $800: fleet $50/hr.
	 * A filled _fy_fuel_rate on the yacht wins on both sides.
	 */
	public static function fuel_rate_for_boat( $yacht_id, $boat_total ) {
		$override = get_post_meta( $yacht_id, '_fy_fuel_rate', true );
		if ( '' !== $override && null !== $override ) {
			return max( 0, (float) $override );
		}
		$low = FY_Fleet_Settings::get_fuel_threshold();
		if ( $low > 0 && (float) $boat_total <= $low ) {
			return FY_Fleet_Settings::get_fuel_rate_under();
		}
		return FY_Fleet_Settings::get_fuel_rate();
	}

	/** This yacht's own override for a $/hr or flat rate, or the fleet-wide default when blank. */
	public static function yacht_rate_or_default( $yacht_id, $meta_key, $default ) {
		$value = get_post_meta( $yacht_id, $meta_key, true );
		return ( '' === $value || null === $value ) ? (float) $default : max( 0, (float) $value );
	}

	/** Minimum days of notice required for online bookings. */
	public static function min_notice_days() {
		$opts = FY_Fleet_Settings::get_booking();
		$days = isset( $opts['min_notice_days'] ) ? intval( $opts['min_notice_days'] ) : 1;
		return max( 0, min( 60, $days ) );
	}

	/** Deposit due today for a given charter total. */
	/**
	 * Is this yacht's "From $X" a PER-HOUR rate, or a whole-charter price?
	 *
	 * The two fleets disagree, and the meta field can't tell them apart on
	 * its own: the imported Miami fleet stores an hourly rate (× hours = the
	 * duration's total), while the older hand-built listings store the first
	 * duration's total outright. Printing "per hour" on the latter would
	 * treble the advertised price of 50 boats, so the label is derived from
	 * the yacht's own Hours & Pricing rows rather than assumed.
	 *
	 * Decided by the first usable duration row: if rate × its hours lands on
	 * its total (2% tolerance for rounding), the price is hourly.
	 */
	public static function starting_price_is_hourly( $yacht_id ) {
		$price = (float) get_post_meta( $yacht_id, '_fy_price', true );
		if ( $price <= 0 ) {
			return false;
		}
		$rows = get_post_meta( $yacht_id, '_fy_pricing', true );
		if ( ! is_array( $rows ) ) {
			return false;
		}
		foreach ( $rows as $row ) {
			if ( isset( $row['type'] ) && 'price' !== $row['type'] ) {
				continue;
			}
			$hours = self::hours_from_label( isset( $row['duration'] ) ? $row['duration'] : '' );
			$total = isset( $row['price'] ) ? (float) $row['price'] : 0;
			if ( $hours <= 0 || $total <= 0 ) {
				continue;
			}
			return abs( ( $price * $hours ) - $total ) <= max( 1.0, $total * 0.02 );
		}
		return false;
	}

	/** " per hour" when the starting price is a rate, '' when it's a package price. */
	public static function starting_price_unit( $yacht_id ) {
		return self::starting_price_is_hourly( $yacht_id ) ? __( 'per hour', 'fy-fleet' ) : '';
	}

	/**
	 * Guest-facing listed total: boat + crew for those hours.
	 * Hourly / percent boat deposits are credited toward the boat, so they
	 * are not added on top. Coco 3h: $855 + $225 crew = $1,080.
	 */
	public static function listed_total( $yacht_id, $boat, $hours ) {
		$boat  = (float) $boat;
		$hours = (float) $hours;
		if ( $boat <= 0 ) {
			return 0.0;
		}
		$crew = ( $hours > 0 ) ? self::crew_rate_for_boat( $yacht_id, $boat ) * $hours : 0.0;
		return round( $boat + $crew, 2 );
	}

	/**
	 * The headline "From $…" figure: what a real shortest charter costs
	 * (boat + crew). Deposits are not added on top.
	 *
	 * @return array{amount:float,hours:float}|null
	 */
	public static function display_from_price( $yacht_id ) {
		$rows = get_post_meta( $yacht_id, '_fy_pricing', true );
		$best = null;
		if ( is_array( $rows ) ) {
			foreach ( $rows as $row ) {
				if ( isset( $row['type'] ) && 'price' !== $row['type'] ) {
					continue;
				}
				$hours = self::hours_from_label( isset( $row['duration'] ) ? $row['duration'] : '' );
				$total = isset( $row['price'] ) ? (float) $row['price'] : 0;
				if ( $hours <= 0 || $total <= 0 ) {
					continue;
				}
				// This yacht's OWN shortest duration wins — not a fixed "3
				// hours". Most of the fleet starts at 3, so that used to be
				// hardcoded, but a handful of yachts (some 2-hour, some
				// starting at 4) were quoted at the wrong duration's price
				// the moment their rows didn't include a 3-hour option, or
				// silently showed 3 hours' price even when 2 was cheaper and
				// bookable. Whatever an editor sets as the shortest row is
				// what the card advertises, automatically.
				if ( null === $best || $hours < $best['hours'] ) {
					$best = array( 'amount' => $total, 'hours' => $hours );
				}
			}
		}
		if ( null !== $best ) {
			$best['amount'] = self::listed_total( $yacht_id, $best['amount'], $best['hours'] );
			return $best;
		}
		$rate = (float) get_post_meta( $yacht_id, '_fy_price', true );
		return $rate > 0 ? array( 'amount' => $rate, 'hours' => 0 ) : null;
	}

	/** "for 3 hours" — the unit line under a headline From price. */
	public static function display_from_unit( $yacht_id, $from = null ) {
		$from = ( null === $from ) ? self::display_from_price( $yacht_id ) : $from;
		if ( ! $from ) {
			return '';
		}
		if ( $from['hours'] > 0 ) {
			/* translators: %s: number of hours, e.g. "3" */
			return sprintf( __( 'for %s hours', 'fy-fleet' ), rtrim( rtrim( number_format( $from['hours'], 1 ), '0' ), '.' ) );
		}
		return self::starting_price_unit( $yacht_id );
	}

	/**
	 * Reservation deposit on the BOAT cost for the chosen hours.
	 *
	 * Business rule (owner, 2026-08-10): charters whose boat cost tops
	 * $1,400 pay 20% of that cost online, on top of crew + hourly boat
	 * deposit. It is non-refundable and credited toward the boat. Crew is
	 * not credited. Premium-tier yachts needing 50% are arranged by hand
	 * after booking — deliberately NOT automated here.
	 */
	/**
	 * Dock balance: boat − hourly deposit − % boat deposit + unpaid extras.
	 * Crew is charged today but is not credited against the boat.
	 */
	public static function dock_balance( $boat, $hourly_deposit, $pct_deposit, $addons_total = 0, $addons_now = 0, $fees = 0 ) {
		return round(
			max( 0, (float) $boat - (float) $hourly_deposit - (float) $pct_deposit )
			+ max( 0, (float) $addons_total - (float) $addons_now )
			+ max( 0, (float) $fees ),
			2
		);
	}

	public static function charter_deposit_for_boat( $boat_total ) {
		$threshold = FY_Fleet_Settings::get_charter_deposit_threshold();
		$pct       = FY_Fleet_Settings::get_charter_deposit_pct();
		if ( $threshold <= 0 || $pct <= 0 || (float) $boat_total <= $threshold ) {
			return 0.0;
		}
		return round( (float) $boat_total * $pct / 100, 2 );
	}

	public static function deposit_for( $total ) {
		$type = FY_Fleet_Settings::get_deposit_type();

		// New default: the full per-hour total (boat + crew + fuel + service
		// fee) is charged at booking — no partial deposit, nothing left due
		// at the dock. "percent"/"flat" remain available in Settings for
		// anyone who wants the old partial-deposit model back.
		if ( 'full' === $type ) {
			return round( max( 0, (float) $total ), 2 );
		}

		$value = FY_Fleet_Settings::get_deposit_value();
		if ( 'flat' === $type ) {
			$deposit = min( (float) $value, (float) $total );
		} else {
			$deposit = (float) $total * ( (float) $value / 100 );
		}
		$deposit = round( $deposit, 2 );
		return max( 0, $deposit );
	}

	/**
	 * Everything the booking form needs, as a JSON-ready array.
	 */
	public static function form_data( $yacht_id ) {
		$rows   = get_post_meta( $yacht_id, '_fy_pricing', true );
		$groups = self::groups( $rows );

		$out_groups = array();
		foreach ( $groups as $group ) {
			$out_rows = array();
			foreach ( $group['rows'] as $row ) {
				$out_rows[] = array(
					'duration' => $row['duration'],
					'price'    => $row['price'],
					'free'     => (bool) $row['free'],
					'hours'    => $row['hours'],
				);
			}
			$out_groups[] = array(
				'heading' => $group['heading'],
				'days'    => array_values( $group['days'] ),
				'rows'    => $out_rows,
				'notes'   => array_values( $group['notes'] ),
			);
		}

		$addons = array();
		foreach ( self::addons_for_yacht( $yacht_id ) as $addon ) {
			$addons[] = array(
				'key'   => $addon['key'],
				'label' => $addon['label'],
				'price' => (float) $addon['price'],
				'unit'  => $addon['unit'],
				'note'  => isset( $addon['note'] ) ? $addon['note'] : '',
				'max'   => isset( $addon['max'] ) && $addon['max'] > 0 ? (int) $addon['max'] : 1,
			);
		}

		return array(
			'yachtId'      => $yacht_id,
			'name'         => get_the_title( $yacht_id ),
			'groups'       => $out_groups,
			'addons'       => $addons,
			'surcharge'    => (float) get_post_meta( $yacht_id, '_fy_weekend_surcharge', true ),
			'crewRate'     => self::yacht_rate_or_default( $yacht_id, '_fy_crew_rate', FY_Fleet_Settings::get_crew_rate() ),
			'crewRateUnder'=> self::crew_rate_for_boat( $yacht_id, 0 ),
			'fuelRate'     => self::yacht_rate_or_default( $yacht_id, '_fy_fuel_rate', FY_Fleet_Settings::get_fuel_rate() ),
			'fuelRateUnder'=> self::fuel_rate_for_boat( $yacht_id, 0 ),
			'fuelThreshold'=> FY_Fleet_Settings::get_fuel_threshold(),
			'serviceFee'   => self::yacht_rate_or_default( $yacht_id, '_fy_service_fee', FY_Fleet_Settings::get_service_fee() ),
			'weekendDays'  => array_values( FY_Fleet_Settings::get_weekend_days() ),
			'timeSlots'    => array_values( FY_Fleet_Settings::get_time_slots() ),
			'depositType'  => FY_Fleet_Settings::get_deposit_type(),
			'depositValue' => FY_Fleet_Settings::get_deposit_value(),
			'occasions'    => array_values( FY_Fleet_Settings::get_occasions() ),
			'image'        => self::yacht_image( $yacht_id ),
		);
	}

	public static function yacht_image( $yacht_id ) {
		$url = get_the_post_thumbnail_url( $yacht_id, 'large' );
		if ( ! $url ) {
			$url = get_post_meta( $yacht_id, '_fy_image_url', true );
		}
		return $url ? $url : '';
	}
}
