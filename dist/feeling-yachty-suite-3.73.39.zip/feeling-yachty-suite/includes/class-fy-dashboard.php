<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sales dashboard: bookings and revenue over 7/15/30 days or a custom range.
 *
 * Money figures are visible only to users holding the `view_fy_revenue`
 * capability (administrators by default) — staff without it see activity
 * counts but no dollars.
 */
class FY_Fleet_Dashboard {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'ensure_cap' ) );
	}

	public static function ensure_cap() {
		$admin = get_role( 'administrator' );
		if ( $admin && ! $admin->has_cap( 'view_fy_revenue' ) ) {
			$admin->add_cap( 'view_fy_revenue' );
		}
	}

	public static function add_menu() {
		add_submenu_page(
			'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE,
			__( 'Dashboard', 'fy-fleet' ),
			__( '📊 Dashboard', 'fy-fleet' ),
			'edit_shop_orders',
			'fy-fleet-dashboard',
			array( __CLASS__, 'render' )
		);
	}

	public static function render() {
		$range = isset( $_GET['range'] ) ? sanitize_key( $_GET['range'] ) : '30';
		$from  = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '';
		$to    = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '';

		if ( 'custom' === $range && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to ) ) {
			$start = $from;
			$end   = $to;
		} else {
			$days  = in_array( $range, array( '7', '15', '30' ), true ) ? (int) $range : 30;
			$range = (string) $days;
			$start = gmdate( 'Y-m-d', time() - ( $days - 1 ) * DAY_IN_SECONDS );
			$end   = gmdate( 'Y-m-d', time() + 365 * DAY_IN_SECONDS ); // include upcoming charters booked in period
			$end   = gmdate( 'Y-m-d', strtotime( '+120 days' ) );
		}

		$bookings = FY_Fleet_Woo::active() ? FY_Fleet_Bookings_Admin::get_bookings( $start, $end ) : array();
		$show_money = current_user_can( 'view_fy_revenue' );

		$count = count( $bookings );
		$revenue = 0.0; $deposits = 0.0; $balance = 0.0; $guests = 0;
		$per_day = array(); $per_yacht = array();
		foreach ( $bookings as $b ) {
			$revenue  += $b['total'];
			$deposits += $b['deposit'];
			$balance  += $b['balance'];
			$guests   += (int) $b['guests'];
			$per_day[ $b['date'] ]     = isset( $per_day[ $b['date'] ] ) ? $per_day[ $b['date'] ] + 1 : 1;
			$per_yacht[ $b['yacht'] ]  = isset( $per_yacht[ $b['yacht'] ] ) ? $per_yacht[ $b['yacht'] ] + 1 : 1;
		}
		arsort( $per_yacht );
		$max_day = $per_day ? max( $per_day ) : 1;

		$base = admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-dashboard' );
		$money = function ( $amount ) use ( $show_money ) {
			return $show_money ? wp_kses_post( wc_price( $amount ) ) : '<span title="' . esc_attr__( 'Requires the view_fy_revenue privilege', 'fy-fleet' ) . '">🔒</span>';
		};
		?>
		<div class="wrap fy-dash">
			<style>
			.fy-dash-ranges{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:12px 0 18px}
			.fy-dash-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:14px;margin-bottom:20px}
			.fy-dash-card{background:#fff;border:1px solid #dcdcde;border-top:4px solid #C7347B;border-radius:10px;padding:16px 18px}
			.fy-dash-card h3{margin:0 0 6px;font-size:12px;text-transform:uppercase;letter-spacing:.05em;color:#646970}
			.fy-dash-num{font-size:26px;font-weight:800;color:#1d2327;line-height:1.1}
			.fy-dash-chart{display:flex;align-items:flex-end;gap:3px;height:120px;background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:14px;margin-bottom:20px;overflow-x:auto}
			.fy-dash-bar{flex:1;min-width:8px;background:linear-gradient(180deg,#7C3AED,#C7347B);border-radius:4px 4px 0 0}
			.fy-dash-2col{display:grid;grid-template-columns:1fr 1fr;gap:16px}
			@media(max-width:960px){.fy-dash-2col{grid-template-columns:1fr}}
			.fy-dash-panel{background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:14px 18px}
			.fy-dash-panel h2{margin-top:2px}
			.fy-dash-panel li{display:flex;justify-content:space-between;gap:10px;padding:6px 0;border-bottom:1px solid #f0f0f1}
			</style>

			<h1>📊 <?php esc_html_e( 'Sales Dashboard', 'fy-fleet' ); ?></h1>

			<form class="fy-dash-ranges" method="get">
				<input type="hidden" name="post_type" value="<?php echo esc_attr( FY_Fleet_CPT::POST_TYPE ); ?>">
				<input type="hidden" name="page" value="fy-fleet-dashboard">
				<?php foreach ( array( '7', '15', '30' ) as $r ) : ?>
					<a class="button <?php echo $range === $r ? 'button-primary' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'range', $r, $base ) ); ?>"><?php printf( esc_html__( '%s days', 'fy-fleet' ), esc_html( $r ) ); ?></a>
				<?php endforeach; ?>
				<span>|</span>
				<input type="hidden" name="range" value="custom">
				<input type="date" name="from" value="<?php echo esc_attr( $from ); ?>" required>
				<input type="date" name="to" value="<?php echo esc_attr( $to ); ?>" required>
				<button class="button"><?php esc_html_e( 'Apply', 'fy-fleet' ); ?></button>
				<span class="description"><?php printf( esc_html__( 'Charters dated %1$s → %2$s', 'fy-fleet' ), esc_html( $start ), esc_html( $end ) ); ?></span>
			</form>

			<div class="fy-dash-cards">
				<div class="fy-dash-card"><h3><?php esc_html_e( 'Bookings', 'fy-fleet' ); ?></h3><div class="fy-dash-num"><?php echo esc_html( $count ); ?></div></div>
				<div class="fy-dash-card"><h3><?php esc_html_e( 'Charter revenue', 'fy-fleet' ); ?></h3><div class="fy-dash-num"><?php echo $money( $revenue ); // phpcs:ignore ?></div></div>
				<div class="fy-dash-card"><h3><?php esc_html_e( 'Deposits collected', 'fy-fleet' ); ?></h3><div class="fy-dash-num"><?php echo $money( $deposits ); // phpcs:ignore ?></div></div>
				<div class="fy-dash-card"><h3><?php esc_html_e( 'Due at dock', 'fy-fleet' ); ?></h3><div class="fy-dash-num"><?php echo $money( $balance ); // phpcs:ignore ?></div></div>
				<div class="fy-dash-card"><h3><?php esc_html_e( 'Guests hosted', 'fy-fleet' ); ?></h3><div class="fy-dash-num"><?php echo esc_html( $guests ); ?></div></div>
			</div>

			<?php if ( $per_day ) : ?>
				<div class="fy-dash-chart">
					<?php ksort( $per_day ); foreach ( $per_day as $day => $n ) : ?>
						<div class="fy-dash-bar" style="height:<?php echo esc_attr( max( 8, round( $n / $max_day * 100 ) ) ); ?>%" title="<?php echo esc_attr( $day . ' — ' . $n ); ?>"></div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<div class="fy-dash-2col">
				<div class="fy-dash-panel">
					<h2>🏆 <?php esc_html_e( 'Top yachts', 'fy-fleet' ); ?></h2>
					<ul>
						<?php if ( empty( $per_yacht ) ) : ?><li><?php esc_html_e( 'No bookings in range.', 'fy-fleet' ); ?></li><?php endif; ?>
						<?php foreach ( array_slice( $per_yacht, 0, 8, true ) as $yacht => $n ) : ?>
							<li><span><?php echo esc_html( $yacht ); ?></span><strong><?php echo esc_html( $n ); ?></strong></li>
						<?php endforeach; ?>
					</ul>
				</div>
				<div class="fy-dash-panel">
					<h2>🗓️ <?php esc_html_e( 'Next charters', 'fy-fleet' ); ?></h2>
					<ul>
						<?php
						$today   = gmdate( 'Y-m-d' );
						$printed = 0;
						foreach ( $bookings as $b ) {
							if ( $b['date'] < $today || $printed >= 8 ) { continue; }
							$printed++;
							printf(
								'<li><span>%s — %s %s</span><strong>%s</strong></li>',
								esc_html( FY_Fleet_Woo::format_date( $b['date'] ) ),
								esc_html( $b['yacht'] ),
								esc_html( $b['time'] ? '· ' . $b['time'] : '' ),
								esc_html( $b['customer'] )
							);
						}
						if ( ! $printed ) { echo '<li>' . esc_html__( 'Nothing upcoming in range.', 'fy-fleet' ) . '</li>'; }
						?>
					</ul>
				</div>
			</div>

			<?php if ( ! $show_money ) : ?>
				<p class="description" style="margin-top:14px">🔒 <?php esc_html_e( 'Dollar figures are hidden — your account lacks the "view_fy_revenue" privilege. An administrator can grant it with any role editor plugin.', 'fy-fleet' ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}
}
