<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Branded WooCommerce emails.
 *
 * Every store email (order confirmations, processing, completed, refunds,
 * account emails) gets the Feeling Yachty logo, brand colours, a charter
 * details card on booking orders, and a contact footer with Miami & Panama
 * numbers (call / SMS / WhatsApp).
 *
 * Email HTML rules apply: tables + inline-friendly CSS only. Outlook desktop
 * ignores gradients, so solid brand pink is declared first as the fallback.
 */
class FY_Fleet_Emails {

	public static function init() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}
		add_filter( 'woocommerce_email_header_image', array( __CLASS__, 'logo' ), 20 );
		add_filter( 'woocommerce_email_styles', array( __CLASS__, 'styles' ), 20, 2 );
		add_filter( 'woocommerce_email_footer_text', array( __CLASS__, 'footer' ), 20 );
		add_action( 'woocommerce_email_after_order_table', array( __CLASS__, 'charter_card' ), 5, 4 );
		add_filter( 'woocommerce_email_format_string', array( __CLASS__, 'format_string' ), 10, 2 );
	}

	private static function opts() {
		$booking = FY_Fleet_Settings::get_booking();
		return array(
			'logo'   => ! empty( $booking['email_logo'] ) ? $booking['email_logo'] : 'https://feelingyachty.com/wp-content/uploads/2024/05/feeling-yatchy-logo-1-3.png',
			'miami'  => ! empty( $booking['phone_miami'] ) ? $booking['phone_miami'] : '+1 954-246-3636',
			'panama' => ! empty( $booking['phone_panama'] ) ? $booking['phone_panama'] : '+507 202-1729',
		);
	}

	private static function digits( $phone ) {
		return preg_replace( '/[^0-9]/', '', $phone );
	}

	/**
	 * Normalize bookings from BOTH engines: this plugin's (_fy_* meta) and the
	 * store's previous booking product format ("Booking Date / Charter Start
	 * Time / Charter Duration / Passenger Count").
	 */
	public static function order_bookings( $order ) {
		$bookings = array();
		foreach ( $order->get_items() as $item ) {
			if ( $item->get_meta( '_fy_date' ) ) {
				$bookings[] = array(
					'name'     => $item->get_name(),
					'date'     => FY_Fleet_Woo::format_date( $item->get_meta( '_fy_date' ) ),
					'time'     => $item->get_meta( '_fy_time' ),
					'duration' => $item->get_meta( '_fy_duration' ),
					'guests'   => $item->get_meta( '_fy_guests' ),
					'marina'   => $item->get_meta( '_fy_marina' ),
					'occasion' => $item->get_meta( '_fy_occasion' ),
					'total'    => (float) $item->get_meta( '_fy_charter_total' ),
					'deposit'  => (float) $item->get_meta( '_fy_deposit' ),
					'balance'  => (float) $item->get_meta( '_fy_balance' ),
				);
			} elseif ( $item->get_meta( '_fy_yacht_id' ) ) {
				// Native pure-Woo charter: no date yet — scheduled after checkout.
				$bookings[] = array(
					'name'     => $item->get_name(),
					'date'     => __( 'Scheduled with our team after checkout', 'fy-fleet' ),
					'time'     => '',
					'duration' => '',
					'guests'   => '',
					'marina'   => $item->get_meta( '_fy_marina' ),
					'occasion' => '',
					'total'    => (float) $item->get_meta( '_fy_charter_total' ),
					'deposit'  => (float) $item->get_meta( '_fy_deposit' ),
					'balance'  => (float) $item->get_meta( '_fy_balance' ),
				);
			} elseif ( $item->get_meta( 'Booking Date' ) ) {
				$bookings[] = array(
					'name'     => $item->get_name(),
					'date'     => FY_Fleet_Woo::format_date( $item->get_meta( 'Booking Date' ) ),
					'time'     => $item->get_meta( 'Charter Start Time' ),
					'duration' => $item->get_meta( 'Charter Duration' ),
					'guests'   => $item->get_meta( 'Passenger Count' ),
					'marina'   => '',
					'occasion' => '',
					'total'    => 0, // Legacy bookings carry no deposit split.
					'deposit'  => (float) $item->get_total(),
					'balance'  => 0,
				);
			}
		}
		return $bookings;
	}

	/**
	 * Placeholders for ANY WooCommerce email Subject, Heading or "Additional
	 * content" box (WooCommerce → Settings → Emails → pick an email):
	 *
	 *   {yacht_name} {booking_date} {charter_start_time} {charter_duration}
	 *   {passenger_count} {marina} {occasion} {booking_number}
	 *   {deposit_paid} {balance_due} {charter_total}
	 *
	 * Example subject:  Your {yacht_name} charter on {booking_date} — #{booking_number}
	 */
	public static function format_string( $string, $email ) {
		if ( false === strpos( $string, '{' ) ) {
			return $string;
		}
		$order = ( $email && isset( $email->object ) && is_a( $email->object, 'WC_Order' ) ) ? $email->object : null;
		if ( ! $order ) {
			return $string;
		}

		$bookings = self::order_bookings( $order );
		$b        = $bookings ? $bookings[0] : array(
			'name' => '', 'date' => '', 'time' => '', 'duration' => '',
			'guests' => '', 'marina' => '', 'occasion' => '',
			'total' => 0, 'deposit' => 0, 'balance' => 0,
		);

		return strtr(
			$string,
			array(
				'{yacht_name}'         => $b['name'],
				'{booking_date}'       => $b['date'],
				'{charter_start_time}' => $b['time'],
				'{charter_duration}'   => $b['duration'],
				'{passenger_count}'    => $b['guests'],
				'{marina}'             => $b['marina'],
				'{occasion}'           => $b['occasion'],
				'{booking_number}'     => $order->get_order_number(),
				'{deposit_paid}'       => wp_strip_all_tags( wc_price( $b['deposit'] ) ),
				'{balance_due}'        => wp_strip_all_tags( wc_price( $b['balance'] ) ),
				'{charter_total}'      => wp_strip_all_tags( wc_price( $b['total'] ) ),
			)
		);
	}

	public static function logo( $image ) {
		$opts = self::opts();
		return $opts['logo'] ? $opts['logo'] : $image;
	}

	/** Brand CSS appended after Woo's generated styles (later rules win). */
	public static function styles( $css, $email = null ) {
		$css .= '
		/* Feeling Yachty email brand */
		body, #wrapper { background-color: #FFF7FB !important; }
		#template_container {
			border: 1px solid #F4D6E5 !important;
			border-radius: 16px !important;
			box-shadow: 0 8px 24px rgba(228,92,156,.12) !important;
			overflow: hidden;
		}
		#template_header {
			background-color: #C94386 !important;
			background: linear-gradient(105deg, #C94386 0%, #B83280 50%, #7C3AED 100%) !important;
			border-radius: 0 !important;
		}
		#template_header h1 {
			color: #ffffff !important;
			font-weight: 700 !important;
			text-shadow: 0 1px 3px rgba(23,32,51,.25);
		}
		#template_header_image { text-align: center; }
		#template_header_image img {
			max-width: 200px !important;
			margin: 18px auto 6px !important;
		}
		#body_content { background-color: #ffffff !important; }
		#body_content h2 {
			color: #C94386 !important;
			font-weight: 700 !important;
		}
		#body_content a { color: #7C3AED !important; font-weight: 600; }
		#body_content table td { font-size: 14px !important; }
		.td { border-color: #F4D6E5 !important; }
		#template_footer #credit {
			color: #526079 !important;
			font-size: 12px !important;
			padding: 18px 0 24px !important;
		}
		';
		return $css;
	}

	/**
	 * Charter details card on any order email whose order contains a booking.
	 * Runs before the standard order table so guests see the trip first.
	 */
	public static function charter_card( $order, $sent_to_admin, $plain_text, $email = null ) {
		if ( $plain_text || ! $order ) {
			return;
		}

		$bookings = self::order_bookings( $order );
		if ( empty( $bookings ) ) {
			return;
		}

		$label_td = 'padding:7px 12px;font-size:12px;font-weight:bold;color:#1E40AF;width:130px;vertical-align:top;';
		$value_td = 'padding:7px 12px;font-size:13px;color:#172033;vertical-align:top;';

		// Warm intro with the order number, front and centre.
		if ( ! $sent_to_admin ) {
			printf(
				'<p style="margin:0 0 16px;font-size:15px;line-height:1.6;color:#172033;">%s</p>',
				wp_kses_post(
					sprintf(
						/* translators: 1: first name, 2: order number */
						__( '🌴 %1$s, your Miami adventure is locked in! Here is everything for reservation <strong>#%2$s</strong> — save this email, it is your ticket to the dock.', 'fy-fleet' ),
						esc_html( $order->get_billing_first_name() ? $order->get_billing_first_name() : __( 'Welcome aboard', 'fy-fleet' ) ),
						esc_html( $order->get_order_number() )
					)
				)
			);
		}

		foreach ( $bookings as $b ) {
			$date     = $b['date'];
			$time     = $b['time'];
			$duration = $b['duration'];
			$guests   = $b['guests'];
			$marina   = $b['marina'];
			$occasion = $b['occasion'];
			$total    = $b['total'];
			$deposit  = $b['deposit'];
			$balance  = $b['balance'];
			?>
			<table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="margin:0 0 24px;border:1px solid #F4D6E5;border-left:5px solid #E45C9C;border-radius:14px;background-color:#FFF9FC;">
				<tr>
					<td style="padding:16px 18px 6px;">
						<span style="display:block;font-size:11px;font-weight:bold;letter-spacing:1px;text-transform:uppercase;color:#C94386;">⚓ <?php printf( esc_html__( 'Your Charter — Reservation #%s', 'fy-fleet' ), esc_html( $order->get_order_number() ) ); ?></span>
						<span style="display:block;font-size:19px;font-weight:bold;color:#172033;padding-top:3px;"><?php echo esc_html( $b['name'] ); ?></span>
					</td>
				</tr>
				<tr>
					<td style="padding:4px 6px 6px;">
						<table role="presentation" cellpadding="0" cellspacing="0" width="100%">
							<tr><td style="<?php echo esc_attr( $label_td ); ?>">📅 <?php esc_html_e( 'Date', 'fy-fleet' ); ?></td><td style="<?php echo esc_attr( $value_td ); ?>"><strong><?php echo esc_html( $date ); ?></strong><?php echo $time ? esc_html( ' · ' . $time ) : ''; ?></td></tr>
							<?php if ( $duration ) : ?><tr><td style="<?php echo esc_attr( $label_td ); ?>">⏱️ <?php esc_html_e( 'Charter', 'fy-fleet' ); ?></td><td style="<?php echo esc_attr( $value_td ); ?>"><?php echo esc_html( $duration ); ?></td></tr><?php endif; ?>
							<?php if ( $guests ) : ?><tr><td style="<?php echo esc_attr( $label_td ); ?>">👥 <?php esc_html_e( 'Guests', 'fy-fleet' ); ?></td><td style="<?php echo esc_attr( $value_td ); ?>"><?php echo esc_html( $guests ); ?></td></tr><?php endif; ?>
							<?php if ( $marina ) : ?><tr><td style="<?php echo esc_attr( $label_td ); ?>">📍 <?php esc_html_e( 'Departs from', 'fy-fleet' ); ?></td><td style="<?php echo esc_attr( $value_td ); ?>"><?php echo esc_html( $marina ); ?></td></tr><?php endif; ?>
							<?php if ( $occasion ) : ?><tr><td style="<?php echo esc_attr( $label_td ); ?>">🎉 <?php esc_html_e( 'Occasion', 'fy-fleet' ); ?></td><td style="<?php echo esc_attr( $value_td ); ?>"><?php echo esc_html( $occasion ); ?></td></tr><?php endif; ?>
						</table>
					</td>
				</tr>
				<?php if ( $total > 0 ) : ?>
				<tr>
					<td style="padding:6px 12px 16px;">
						<table role="presentation" cellpadding="0" cellspacing="0" width="100%">
							<tr>
								<td width="49%" style="padding:12px;border:2px solid #E45C9C;border-radius:12px;background-color:#ffffff;text-align:center;">
									<span style="display:block;font-size:10px;font-weight:bold;letter-spacing:1px;text-transform:uppercase;color:#C94386;">✅ <?php esc_html_e( 'Deposit paid', 'fy-fleet' ); ?></span>
									<span style="display:block;font-size:22px;font-weight:bold;color:#C94386;padding-top:2px;"><?php echo wp_kses_post( wc_price( $deposit ) ); ?></span>
								</td>
								<td width="2%">&nbsp;</td>
								<td width="49%" style="padding:12px;border:2px dashed #C4B5FD;border-radius:12px;background-color:#ffffff;text-align:center;">
									<span style="display:block;font-size:10px;font-weight:bold;letter-spacing:1px;text-transform:uppercase;color:#5B21B6;">⚓ <?php esc_html_e( 'Due at the dock', 'fy-fleet' ); ?></span>
									<span style="display:block;font-size:22px;font-weight:bold;color:#172033;padding-top:2px;"><?php echo wp_kses_post( wc_price( $balance ) ); ?></span>
								</td>
							</tr>
							<tr>
								<td colspan="3" style="padding-top:8px;text-align:center;font-size:12px;color:#526079;">
									<?php printf( esc_html__( 'Full charter price: %s — the balance is paid in person before departure.', 'fy-fleet' ), wp_kses_post( wc_price( $total ) ) ); ?>
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<?php elseif ( $deposit > 0 ) : ?>
				<tr>
					<td style="padding:6px 12px 16px;">
						<table role="presentation" cellpadding="0" cellspacing="0" width="100%">
							<tr><td style="padding:12px;border:2px solid #E45C9C;border-radius:12px;background-color:#ffffff;text-align:center;">
								<span style="display:block;font-size:10px;font-weight:bold;letter-spacing:1px;text-transform:uppercase;color:#C94386;">✅ <?php esc_html_e( 'Amount paid', 'fy-fleet' ); ?></span>
								<span style="display:block;font-size:22px;font-weight:bold;color:#C94386;padding-top:2px;"><?php echo wp_kses_post( wc_price( $deposit ) ); ?></span>
							</td></tr>
						</table>
					</td>
				</tr>
				<?php endif; ?>
			</table>
			<?php
		}

		// Bareboat reminder when not yet confirmed on the order.
		if ( ! $sent_to_admin && class_exists( 'FY_Fleet_Checkout' ) && ! FY_Fleet_Checkout::order_confirmed( $order ) ) {
			?>
			<table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="margin:0 0 24px;border:1px solid #F4C430;border-left:5px solid #F4B400;border-radius:12px;background-color:#FFFAF0;">
				<tr><td style="padding:14px 16px;font-size:13px;color:#7a5a00;">
					⚠️ <strong><?php esc_html_e( 'Action needed:', 'fy-fleet' ); ?></strong>
					<?php esc_html_e( 'Please complete the Bareboat Charter Agreement Form — your charter cannot depart until it is signed and approved.', 'fy-fleet' ); ?>
				</td></tr>
			</table>
			<?php
		}
	}

	/** Contact footer: Miami & Panama — call, SMS and WhatsApp for each. */
	public static function footer( $text ) {
		$opts     = self::opts();
		$miami    = self::digits( $opts['miami'] );
		$panama   = self::digits( $opts['panama'] );
		$link     = 'color:#7C3AED;font-weight:bold;text-decoration:none;';
		$cell     = 'padding:10px 14px;border:1px solid #F4D6E5;border-radius:12px;background-color:#ffffff;font-size:12px;color:#172033;text-align:center;';

		ob_start();
		?>
		<table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="margin:6px 0 14px;">
			<tr>
				<td width="48%" style="<?php echo esc_attr( $cell ); ?>">
					<strong style="display:block;color:#C94386;font-size:13px;padding-bottom:3px;">🌴 <?php esc_html_e( 'Miami', 'fy-fleet' ); ?></strong>
					<span style="display:block;padding-bottom:5px;color:#526079;"><?php echo esc_html( $opts['miami'] ); ?></span>
					<a style="<?php echo esc_attr( $link ); ?>" href="tel:+<?php echo esc_attr( $miami ); ?>"><?php esc_html_e( 'Call', 'fy-fleet' ); ?></a> &nbsp;·&nbsp;
					<a style="<?php echo esc_attr( $link ); ?>" href="sms:+<?php echo esc_attr( $miami ); ?>"><?php esc_html_e( 'Text', 'fy-fleet' ); ?></a> &nbsp;·&nbsp;
					<a style="<?php echo esc_attr( $link ); ?>" href="https://wa.me/<?php echo esc_attr( $miami ); ?>"><?php esc_html_e( 'WhatsApp', 'fy-fleet' ); ?></a>
				</td>
				<td width="4%">&nbsp;</td>
				<td width="48%" style="<?php echo esc_attr( $cell ); ?>">
					<strong style="display:block;color:#C94386;font-size:13px;padding-bottom:3px;">🇵🇦 <?php esc_html_e( 'Panama', 'fy-fleet' ); ?></strong>
					<span style="display:block;padding-bottom:5px;color:#526079;"><?php echo esc_html( $opts['panama'] ); ?></span>
					<a style="<?php echo esc_attr( $link ); ?>" href="tel:+<?php echo esc_attr( $panama ); ?>"><?php esc_html_e( 'Call', 'fy-fleet' ); ?></a> &nbsp;·&nbsp;
					<a style="<?php echo esc_attr( $link ); ?>" href="sms:+<?php echo esc_attr( $panama ); ?>"><?php esc_html_e( 'Text', 'fy-fleet' ); ?></a> &nbsp;·&nbsp;
					<a style="<?php echo esc_attr( $link ); ?>" href="https://wa.me/<?php echo esc_attr( $panama ); ?>"><?php esc_html_e( 'WhatsApp', 'fy-fleet' ); ?></a>
				</td>
			</tr>
		</table>
		<span style="display:block;text-align:center;color:#526079;font-size:11px;">
			⚓ Feeling Yachty · <a style="<?php echo esc_attr( $link ); ?>" href="https://www.instagram.com/feeling.yachty">@feeling.yachty</a> · <a style="<?php echo esc_attr( $link ); ?>" href="<?php echo esc_url( home_url() ); ?>">feelingyachty.com</a>
		</span>
		<?php
		return ob_get_clean();
	}
}
