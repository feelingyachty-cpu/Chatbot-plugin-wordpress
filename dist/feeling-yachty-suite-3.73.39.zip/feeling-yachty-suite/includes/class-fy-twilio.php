<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Twilio messaging: SMS and WhatsApp.
 *
 * (iMessage is not offered by Twilio or any third party — Apple does not allow
 * it. SMS delivers to iPhones as a standard text.)
 *
 * Auth token can be kept out of the database by defining FY_TWILIO_TOKEN in
 * wp-config.php; the constant wins over the saved setting.
 */
class FY_Fleet_Twilio {

	public static function init() {
		// Scheduled onto WP-Cron rather than run inline — the two Twilio
		// calls (staff alert + customer SMS) are each a blocking HTTP request
		// with up to a 10s timeout; running them synchronously here would
		// hold up the customer's checkout/thank-you request.
		add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'schedule_booking_paid' ), 20 );
		add_action( 'fy_fleet_send_booking_sms', array( __CLASS__, 'on_booking_paid' ), 10, 1 );
		add_action( 'admin_post_fy_twilio_test', array( __CLASS__, 'handle_test' ) );
	}

	/** Queue on_booking_paid() onto WP-Cron so checkout never waits on it. */
	public static function schedule_booking_paid( $order_id ) {
		if ( ! wp_next_scheduled( 'fy_fleet_send_booking_sms', array( $order_id ) ) ) {
			wp_schedule_single_event( time(), 'fy_fleet_send_booking_sms', array( $order_id ) );
		}
	}

	public static function settings() {
		$opts = FY_Fleet_Settings::get_booking();
		return array(
			'sid'        => isset( $opts['twilio_sid'] ) ? $opts['twilio_sid'] : '',
			'token'      => defined( 'FY_TWILIO_TOKEN' ) ? FY_TWILIO_TOKEN : ( isset( $opts['twilio_token'] ) ? $opts['twilio_token'] : '' ),
			'from_sms'   => isset( $opts['twilio_from_sms'] ) ? $opts['twilio_from_sms'] : '',
			'from_wa'    => isset( $opts['twilio_from_wa'] ) ? $opts['twilio_from_wa'] : '',
			'staff_to'   => isset( $opts['twilio_staff_to'] ) ? $opts['twilio_staff_to'] : '',
			'notify_staff'    => ! empty( $opts['twilio_notify_staff'] ),
			'notify_customer' => ! empty( $opts['twilio_notify_customer'] ),
			'customer_tpl'    => isset( $opts['twilio_customer_tpl'] ) ? $opts['twilio_customer_tpl'] : '',
		);
	}

	public static function configured() {
		$s = self::settings();
		return $s['sid'] && $s['token'] && ( $s['from_sms'] || $s['from_wa'] );
	}

	/**
	 * @param string $to      E.164 number, e.g. +17545551234.
	 * @param string $body    Message text.
	 * @param string $channel 'sms' or 'whatsapp'.
	 * @return true|WP_Error
	 */
	public static function send( $to, $body, $channel = 'sms' ) {
		$s = self::settings();
		if ( ! $s['sid'] || ! $s['token'] ) {
			return new WP_Error( 'fy_twilio_off', __( 'Twilio is not configured.', 'fy-fleet' ) );
		}

		$to = preg_replace( '/[^0-9+]/', '', $to );
		if ( '' === $to ) {
			return new WP_Error( 'fy_twilio_to', __( 'No destination number.', 'fy-fleet' ) );
		}
		if ( '+' !== substr( $to, 0, 1 ) ) {
			$to = '+' . $to;
		}

		if ( 'whatsapp' === $channel ) {
			$from = $s['from_wa'];
			$to   = 'whatsapp:' . $to;
			if ( 0 !== strpos( $from, 'whatsapp:' ) ) {
				$from = 'whatsapp:' . $from;
			}
		} else {
			$from = $s['from_sms'];
		}
		if ( ! $from ) {
			return new WP_Error( 'fy_twilio_from', __( 'No sender number configured for that channel.', 'fy-fleet' ) );
		}

		$response = wp_remote_post(
			'https://api.twilio.com/2010-04-01/Accounts/' . rawurlencode( $s['sid'] ) . '/Messages.json',
			array(
				'timeout' => 10,
				'headers' => array(
					'Authorization' => 'Basic ' . base64_encode( $s['sid'] . ':' . $s['token'] ),
				),
				'body'    => array(
					'To'   => $to,
					'From' => $from,
					'Body' => $body,
				),
			)
		);

		$code = wp_remote_retrieve_response_code( $response );
		$ok   = ! is_wp_error( $response ) && $code >= 200 && $code < 300;

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add(
				$ok ? 'twilio.sent' : 'twilio.failed',
				sprintf( '%s → %s (%s)', strtoupper( $channel ), $to, $ok ? 'delivered to Twilio' : ( is_wp_error( $response ) ? $response->get_error_message() : 'HTTP ' . $code ) )
			);
		}

		if ( ! $ok ) {
			$detail = is_wp_error( $response ) ? $response->get_error_message() : wp_remote_retrieve_body( $response );
			return new WP_Error( 'fy_twilio_fail', __( 'Twilio rejected the message: ', 'fy-fleet' ) . substr( (string) $detail, 0, 300 ) );
		}
		return true;
	}

	/** Booking-paid notifications: staff alert + customer confirmation. */
	public static function on_booking_paid( $order_id ) {
		if ( ! self::configured() ) {
			return;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order || 'yes' === $order->get_meta( '_fy_sms_sent' ) ) {
			return;
		}

		$booking = null;
		foreach ( $order->get_items() as $item ) {
			if ( $item->get_meta( '_fy_date' ) ) {
				$booking = $item;
				break;
			}
		}
		if ( ! $booking ) {
			return;
		}

		$s      = self::settings();
		$tokens = array(
			'{name}'    => $order->get_billing_first_name(),
			'{yacht}'   => $booking->get_name(),
			'{date}'    => FY_Fleet_Woo::format_date( $booking->get_meta( '_fy_date' ) ),
			'{time}'    => $booking->get_meta( '_fy_time' ),
			'{guests}'  => $booking->get_meta( '_fy_guests' ),
			'{marina}'  => $booking->get_meta( '_fy_marina' ),
			'{balance}' => wp_strip_all_tags( wc_price( (float) $booking->get_meta( '_fy_balance' ) ) ),
			'{order}'   => $order->get_order_number(),
		);

		if ( $s['notify_staff'] && $s['staff_to'] ) {
			self::send(
				$s['staff_to'],
				strtr( "🛥️ NEW BOOKING #{order}: {yacht} — {date} {time}, {guests} guests. Balance at dock: {balance}.", $tokens ),
				$s['from_sms'] ? 'sms' : 'whatsapp'
			);
		}

		if ( $s['notify_customer'] && $order->get_billing_phone() ) {
			$template = $s['customer_tpl'] ? $s['customer_tpl'] : "⚓ Feeling Yachty: you're booked! {yacht} on {date} at {time}. Departure: {marina}. Balance due at the dock: {balance}. Questions? Just reply here.";
			self::send( $order->get_billing_phone(), strtr( $template, $tokens ), $s['from_sms'] ? 'sms' : 'whatsapp' );
		}

		$order->update_meta_data( '_fy_sms_sent', 'yes' );
		$order->save();
	}

	public static function handle_test() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		check_admin_referer( 'fy_twilio_test' );

		$to      = isset( $_POST['fy_test_to'] ) ? sanitize_text_field( wp_unslash( $_POST['fy_test_to'] ) ) : '';
		$channel = ( isset( $_POST['fy_test_channel'] ) && 'whatsapp' === $_POST['fy_test_channel'] ) ? 'whatsapp' : 'sms';
		$result  = self::send( $to, __( 'Test message from the Feeling Yachty Command Center 🛥️', 'fy-fleet' ), $channel );

		$flag = is_wp_error( $result ) ? rawurlencode( $result->get_error_message() ) : 'ok';
		wp_safe_redirect( add_query_arg( 'fy_twilio_test', $flag, admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-booking' ) ) );
		exit;
	}
}
