/**
 * Charter add-ons on the product page.
 *
 * Reacts to the Charter Duration the customer picks: gates add-ons that need
 * a minimum charter length, and caps "hours" add-ons (jet ski) at the charter
 * length minus the hours reserved for departure and return — so a 3-hour
 * charter allows 1 hour of jet ski, 4 allows 2, 5 allows 3, and every extra
 * charter hour buys one more.
 *
 * Everything here is convenience only. FY_Fleet_Addons::resolve() re-checks
 * and re-prices every choice server-side at add-to-cart.
 */
( function ( $ ) {
	'use strict';

	if ( typeof fyAddons === 'undefined' ) {
		return;
	}

	var $wrap = null;

	/** Hours from a duration label/slug: "5 Hours" / "5-hours" -> 5. */
	function parseHours( text ) {
		if ( ! text ) {
			return 0;
		}
		var t = String( text ).replace( /[-_]/g, ' ' );
		var m = /get\s+([\d.]+)\s*hour/i.exec( t );   // "pay for 4 get 5 hours"
		if ( m ) {
			return parseFloat( m[ 1 ] );
		}
		m = /([\d.]+)\s*hour/i.exec( t );
		return m ? parseFloat( m[ 1 ] ) : 0;
	}

	/**
	 * The charter length currently selected, or 0 if none yet.
	 *
	 * Tries every place the duration shows up, because themes vary: the
	 * select's value ("7-hours"), its visible option text ("7 Hours"), and
	 * finally any duration attribute WooCommerce has written onto the form.
	 */
	function selectedHours() {
		var $sel = $( '#pa_charter-duration, [name="attribute_pa_charter-duration"], select[id*="charter-duration"], select[name*="charter-duration"]' ).first();
		if ( $sel.length ) {
			var hrs = parseHours( $sel.val() );
			if ( hrs ) { return hrs; }
			hrs = parseHours( $sel.find( 'option:selected' ).text() );
			if ( hrs ) { return hrs; }
		}
		// Last resort: the chosen variation's own attribute data.
		var $form = $( 'form.cart' );
		if ( $form.length ) {
			var raw = $form.find( '[name="attribute_pa_charter-duration"]' ).val();
			if ( raw ) { return parseHours( raw ); }
		}
		return 0;
	}

	function money( n ) {
		return '$' + Number( n ).toLocaleString( 'en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 } );
	}

	/**
	 * Max hours of an "hours" add-on for a given charter length:
	 * charter − the hours reserved for departure and return.
	 * With 2 reserved — 3h→1, 4h→2, 5h→3, and +1 per extra charter hour.
	 * Mirrors FY_Fleet_Settings::addon_max_hours().
	 */
	function capFor( reserveHours, minHours, charterHours ) {
		if ( ! charterHours ) {
			return 0;
		}
		if ( minHours && charterHours < minHours ) {
			return 0;
		}
		if ( ! reserveHours ) {
			return Math.floor( charterHours );
		}
		return Math.max( 1, Math.floor( charterHours ) - reserveHours );
	}

	/** Re-gate every add-on against the currently selected duration. */
	function refresh() {
		if ( ! $wrap || ! $wrap.length ) {
			return;
		}
		var hours = selectedHours();

		$wrap.find( '.fy-addon' ).each( function () {
			var $a        = $( this );
			var unit      = $a.data( 'unit' );
			var minHours  = parseInt( $a.data( 'min-hours' ), 10 ) || 0;
			var reserveHrs = parseInt( $a.data( 'reserve-hours' ), 10 ) || 0;
			var $check    = $a.find( '.fy-addon__check' );
			var $blocked  = $a.find( '.fy-addon__blocked' );
			var $hoursBox = $a.find( '.fy-addon__hours' );

			// Needs a longer charter than the one selected.
			if ( minHours && hours && hours < minHours ) {
				$check.prop( 'checked', false ).prop( 'disabled', true );
				$a.addClass( 'is-blocked' );
				$blocked.text( fyAddons.i18n.needHours.replace( '%d', minHours ) ).prop( 'hidden', false );
				$hoursBox.prop( 'hidden', true );
				return;
			}

			$check.prop( 'disabled', false );
			$a.removeClass( 'is-blocked' );
			$blocked.prop( 'hidden', true );

			if ( 'hours' !== unit ) {
				return;
			}

			// Rebuild the hours dropdown to the current cap.
			var cap      = capFor( reserveHrs, minHours, hours );
			var $select  = $a.find( '.fy-addon__hours-select' );
			var previous = parseInt( $select.val(), 10 ) || 1;

			if ( ! cap ) {
				$hoursBox.prop( 'hidden', true );
				return;
			}

			$select.empty();
			for ( var i = 1; i <= cap; i++ ) {
				$select.append( $( '<option>' ).attr( 'value', i ).text( i ) );
			}
			$select.val( Math.min( previous, cap ) );

			$a.find( '.fy-addon__cap' ).text(
				fyAddons.i18n.hourCap
					.replace( '%1$d', cap )
					.replace( '%2$s', hours + 'h' )
			);
			$hoursBox.prop( 'hidden', ! $check.is( ':checked' ) );
			$a.find( '.fy-addon__qty' ).prop( 'hidden', ! $check.is( ':checked' ) );
		} );

		updateTotals();
	}

	/** Running add-on total + the split, shown under the list. */
	/**
	 * A choice row (Open Bar, Videography) carries ONE checkbox whose key
	 * changes with the dropdown. Re-point the row at the picked variant.
	 *
	 * Writes through jQuery's .data() cache, not just the attribute —
	 * collect() and updateTotals() read .data(), and .attr() alone would
	 * leave them reading the variant that was picked at page load.
	 */
	function applyVariant( $a ) {
		var $sel = $a.find( '.fy-addon__variant' );
		if ( ! $sel.length ) {
			return;
		}
		var $opt = $sel.find( 'option:selected' );
		var key  = $sel.val();

		$a.data( 'addon', key ).attr( 'data-addon', key );
		$a.data( 'price', $opt.data( 'price' ) ).attr( 'data-price', $opt.attr( 'data-price' ) );
		$a.data( 'unit', $opt.attr( 'data-unit' ) ).attr( 'data-unit', $opt.attr( 'data-unit' ) );
		$a.data( 'maxQty', $opt.attr( 'data-max-qty' ) ).attr( 'data-max-qty', $opt.attr( 'data-max-qty' ) );

		$a.find( '.fy-addon__price' ).text( $opt.attr( 'data-price-label' ) || '' );

		// Rebuilt as HTML, not .text() — a "More Info" link rides along with
		// the note (both come from the SAME selected option's data-*
		// attributes, set server-side by FY_Fleet_Addons::service_url()), so
		// switching from "Photo + Video" to "+ Drone" keeps pointing at the
		// right page instead of the link staying stuck on whichever option
		// was selected at page load.
		var note = $opt.attr( 'data-note' ) || '';
		var moreInfoUrl = $opt.attr( 'data-more-info' ) || '';
		var $note = $a.find( '.fy-addon__note' );
		$note.empty().text( note );
		if ( moreInfoUrl ) {
			$note.append( ' ' ).append(
				$( '<a>', { 'class': 'fy-addon__more-info', href: moreInfoUrl, target: '_blank', rel: 'noopener', text: fyAddons.i18n.moreInfo } )
			);
		}
		$note.prop( 'hidden', ! note && ! moreInfoUrl );

		// Product page posts real field names; the cart panel saves by AJAX
		// and has none, so only rewrite when the row was rendered named.
		if ( '1' === String( $a.attr( 'data-named' ) ) ) {
			$a.find( '.fy-addon__check' ).attr( 'name', 'fy_addons[' + key + '][on]' );
			$a.find( '.fy-addon__qty-select' ).attr( 'name', 'fy_addons[' + key + '][qty]' );
		}
	}

	/** Full name for a summary line — "Open Bar — Up to 13 guests". */
	function rowLabel( $a ) {
		var base = $a.find( '.fy-addon__label' ).text().trim();
		var $opt = $a.find( '.fy-addon__variant option:selected' );
		if ( $opt.length && $opt.attr( 'data-label' ) ) {
			return base + ' — ' + $opt.attr( 'data-label' );
		}
		return base;
	}

	function updateTotals() {
		if ( ! $wrap || ! $wrap.length ) {
			return;
		}
		var hours = selectedHours();
		var total = 0;
		var any   = false;
		var lines = [];   // one entry per selected extra, for the summary box

		$wrap.find( '.fy-addon' ).each( function () {
			var $a = $( this );
			if ( ! $a.find( '.fy-addon__check' ).is( ':checked' ) ) {
				return;
			}
			any = true;
			var unit  = $a.data( 'unit' );
			var price = parseFloat( $a.data( 'price' ) ) || 0;
			var label = rowLabel( $a );
			var line  = 0;
			var detail = '';

			var qty = parseInt( $a.find( '.fy-addon__qty-select' ).val(), 10 ) || 1;

			if ( 'quote' === unit ) {
				lines.push( { label: label, detail: 'custom quote', total: 0, quote: true } );
				return; // Priced by hand later.
			}
			if ( 'hour' === unit ) {
				line   = price * ( hours || 1 );
				detail = money( price ) + '/hr × ' + ( hours || 1 ) + ' hr' + ( ( hours || 1 ) === 1 ? '' : 's' );
			} else if ( 'hours' === unit ) {
				var picked = parseInt( $a.find( '.fy-addon__hours-select' ).val(), 10 ) || 1;
				line   = price * picked * qty;
				detail = money( price ) + '/hr × ' + picked + ' hr' + ( 1 === picked ? '' : 's' ) +
					( qty > 1 ? ' × ' + qty : '' );
			} else {
				line   = price * qty;
				detail = qty > 1 ? '×' + qty : '';
			}
			total += line;
			lines.push( { label: label, detail: detail, total: line, quote: false } );
		} );

		var $out = $wrap.find( '.fy-addons__total' );
		if ( ! any || total <= 0 ) {
			$out.prop( 'hidden', true ).empty();
			$( document.body ).trigger( 'fy_addons_changed', [ 0, 0, lines ] );
			return;
		}

		// Missing/invalid localized ratio must not become NaN in the totals
		// bar — the server charges 50% online, so mirror that default.
		var ratio = Number( fyAddons.depositRatio );
		if ( ! isFinite( ratio ) || ratio < 0 || ratio > 1 ) {
			ratio = 0.5;
		}
		var now = Math.round( total * ratio * 100 ) / 100;
		$out.prop( 'hidden', false ).html(
			'<span>' + money( total ) + ' ' + 'in extras' + '</span>' +
			'<strong>' + money( now ) + ' now</strong>' +
			'<span class="fy-addons__later">' + money( total - now ) + ' at the dock</span>'
		);

		// Let the payment-summary box fold these into its figures, and list
		// each extra as its own line under Fuel.
		$( document.body ).trigger( 'fy_addons_changed', [ total, now, lines ] );
	}

	/* ------------------------------------------------------------------
	 * Cart / checkout: the same controls, saved back to the cart by AJAX.
	 * Every change is re-validated and re-priced server-side, then the
	 * totals are refreshed — the browser never sends a price.
	 * ---------------------------------------------------------------- */

	var saveTimer = null;

	function collect( $panel ) {
		var payload = {};
		$panel.find( '.fy-addon' ).each( function () {
			var $a = $( this );
			if ( ! $a.find( '.fy-addon__check' ).is( ':checked' ) ) {
				return;
			}
			var key = $a.data( 'addon' );
			payload[ key ] = { on: 1 };
			if ( 'hours' === $a.data( 'unit' ) ) {
				payload[ key ].hours = parseInt( $a.find( '.fy-addon__hours-select' ).val(), 10 ) || 1;
			}
			var $qty = $a.find( '.fy-addon__qty-select' );
			if ( $qty.length ) {
				payload[ key ].qty = parseInt( $qty.val(), 10 ) || 1;
			}
		} );
		return payload;
	}

	function saveCart( $panel ) {
		var $status = $panel.find( '.fy-addons__status' );
		$status.removeClass( 'is-error' ).text( fyAddons.i18n.saving );

		$.post( fyAddons.ajaxUrl, {
			action: 'fy_update_addons',
			nonce: fyAddons.nonce,
			cart_key: $panel.data( 'cart-key' ),
			addons: collect( $panel )
		} )
			.done( function ( res ) {
				if ( ! res || ! res.success ) {
					$status.addClass( 'is-error' ).text(
						( res && res.data && res.data.message ) ? res.data.message : fyAddons.i18n.saveFailed
					);
					return;
				}
				if ( res.data.errors && res.data.errors.length ) {
					$status.addClass( 'is-error' ).text( res.data.errors.join( ' ' ) );
				} else {
					$status.text( '' );
				}

				// Refresh the money on screen. Checkout has its own AJAX
				// refresh; the cart page needs a reload to redraw totals.
				if ( fyAddons.isCheckout ) {
					$( document.body ).trigger( 'update_checkout' );
				} else {
					window.location.reload();
				}
			} )
			.fail( function () {
				$status.addClass( 'is-error' ).text( fyAddons.i18n.saveFailed );
			} );
	}

	/** Debounced so dragging through a dropdown doesn't fire a save per step. */
	function queueSave( $panel ) {
		clearTimeout( saveTimer );
		saveTimer = setTimeout( function () {
			saveCart( $panel );
		}, 450 );
	}

	$( document ).on( 'change', '.fy-addons--cart .fy-addon__check', function () {
		var $a     = $( this ).closest( '.fy-addon' );
		var $panel = $( this ).closest( '.fy-addons--cart' );
		if ( 'hours' === $a.data( 'unit' ) ) {
			$a.find( '.fy-addon__hours' ).prop( 'hidden', ! $( this ).is( ':checked' ) );
		}
		queueSave( $panel );
	} );

	$( document ).on( 'change', '.fy-addons--cart .fy-addon__hours-select, .fy-addons--cart .fy-addon__qty-select', function () {
		queueSave( $( this ).closest( '.fy-addons--cart' ) );
	} );

	$( document ).on( 'change', '.fy-addons--cart .fy-addon__variant', function () {
		applyVariant( $( this ).closest( '.fy-addon' ) );
		queueSave( $( this ).closest( '.fy-addons--cart' ) );
	} );

	/**
	 * Put the extras panel BEFORE the payment summary, in the same full-width
	 * container the summary lives in.
	 *
	 * WooCommerce's before_add_to_cart_button hook drops it wherever the
	 * theme puts the button — here that's a narrow column, which squeezed
	 * the panel to one word per line. Relocating fixes the width; the choice
	 * of anchor decides where it lands. Extras have to be picked BEFORE the
	 * total that includes them makes sense, so this sits right after the
	 * native price block and before fy-pay-summary/fy-confirm-note/
	 * fy-deposit-faq — the reverse of where those three insert themselves.
	 */
	function relocate() {
		if ( ! $wrap || ! $wrap.length || $wrap.data( 'fy-placed' ) ) {
			return;
		}
		// The native variation price/description block always renders first
		// inside single_variation_wrap, before product-express.js has even
		// added the summary — the one anchor guaranteed to exist this early.
		var $priceBlock = $( '.woocommerce-variation' ).first();
		if ( $priceBlock.length ) {
			$wrap.insertAfter( $priceBlock ).data( 'fy-placed', true );
			return;
		}
		// Variation block missing (a simple, non-variable product) — fall
		// back to landing just before whichever summary piece exists.
		var $anchor = $( '.fy-pay-summary' ).first();
		if ( ! $anchor.length ) { $anchor = $( '.fy-confirm-note' ).first(); }
		if ( ! $anchor.length ) { $anchor = $( '.fy-deposit-faq' ).first(); }

		if ( $anchor.length ) {
			$wrap.insertBefore( $anchor ).data( 'fy-placed', true );
		}
	}

	$( function () {
		var $all = $( '#fy-addons' );
		if ( ! $all.length ) {
			return;
		}
		// Some themes render the add-to-cart form more than once (a sticky
		// mobile bar, a quick-view). That would duplicate every checkbox and
		// double-count the extras total, so keep the first panel only.
		if ( $all.length > 1 ) {
			$all.slice( 1 ).remove();
		}
		$wrap = $( '#fy-addons' ).first();

		// product-express.js builds the summary/FAQ cards, and may not have
		// run yet — retry briefly until an anchor exists.
		relocate();
		setTimeout( relocate, 350 );
		setTimeout( relocate, 1200 );

		// Total line lives at the bottom of the list.
		$wrap.append( '<div class="fy-addons__total" hidden></div>' );

		$wrap.on( 'change', '.fy-addon__check', function () {
			var $a = $( this ).closest( '.fy-addon' );
			var on = $( this ).is( ':checked' );
			$a.find( '.fy-addon__hours, .fy-addon__qty' ).prop( 'hidden', ! on );
			updateTotals();
		} );
		$wrap.on( 'change', '.fy-addon__hours-select, .fy-addon__qty-select', updateTotals );
		$wrap.on( 'change', '.fy-addon__variant', function () {
			applyVariant( $( this ).closest( '.fy-addon' ) );
			updateTotals();
		} );

		// Duration changes come through WooCommerce's variation events as
		// well as plain change events, depending on the theme.
		var $form = $( 'form.cart' );
		$form.on( 'found_variation reset_data hide_variation', function () {
			setTimeout( refresh, 60 );
		} );
		$( document.body ).on( 'change', '#pa_charter-duration, [name="attribute_pa_charter-duration"], select[id*="charter-duration"]', refresh );

		// Themed/custom dropdowns often set the underlying select without
		// firing a change event, which left the jet-ski cap stuck at its
		// server-rendered default. Poll cheaply and only rebuild when the
		// duration has actually moved. (product-express.js does the same for
		// the date field, for the same reason.)
		var lastHours = -1;
		setInterval( function () {
			var now = selectedHours();
			if ( now !== lastHours ) {
				lastHours = now;
				refresh();
			}
		}, 800 );

		refresh();
	} );
} )( jQuery );
