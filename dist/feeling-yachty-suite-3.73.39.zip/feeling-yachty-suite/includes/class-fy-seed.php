<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class FY_Fleet_Seed {

	const FLAG_OPTION = 'fy_fleet_seeded';

	public static function init() {
		add_action( 'admin_post_fy_import_fleet', array( __CLASS__, 'handle_import' ) );
	}

	public static function get_seed_data() {
		$file = FY_FLEET_DIR . 'includes/data/fleet-seed.php';
		if ( ! file_exists( $file ) ) {
			return array();
		}
		$data = include $file;
		return is_array( $data ) ? $data : array();
	}

	/**
	 * Import the starter fleet. Existing yachts matched by title are updated
	 * rather than duplicated, so re-running the import is safe.
	 *
	 * @return array{created:int,updated:int}
	 */
	public static function import() {
		$created = 0;
		$updated = 0;

		foreach ( self::get_seed_data() as $yacht ) {
			if ( empty( $yacht['title'] ) ) {
				continue;
			}

			$existing = self::find_by_title( $yacht['title'] );

			if ( $existing ) {
				$post_id = $existing;
				$updated++;
			} else {
				$post_id = wp_insert_post(
					array(
						'post_type'   => FY_Fleet_CPT::POST_TYPE,
						'post_title'  => $yacht['title'],
						'post_status' => 'publish',
					)
				);
				if ( is_wp_error( $post_id ) || ! $post_id ) {
					continue;
				}
				$created++;
			}

			self::apply_meta( $post_id, $yacht );
		}

		update_option( self::FLAG_OPTION, '1' );

		return array( 'created' => $created, 'updated' => $updated );
	}

	/**
	 * Look up an existing yacht by exact title.
	 *
	 * Avoids get_page_by_title(), which is deprecated as of WordPress 6.2.
	 *
	 * @return int Post ID, or 0 when not found.
	 */
	private static function find_by_title( $title ) {
		global $wpdb;

		$post_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_title = %s AND post_type = %s AND post_status != 'trash' LIMIT 1",
				$title,
				FY_Fleet_CPT::POST_TYPE
			)
		);

		return $post_id ? (int) $post_id : 0;
	}

	private static function apply_meta( $post_id, $yacht ) {
		update_post_meta( $post_id, '_fy_size_ft', isset( $yacht['size'] ) ? intval( $yacht['size'] ) : 0 );
		update_post_meta( $post_id, '_fy_price', isset( $yacht['price'] ) ? floatval( $yacht['price'] ) : 0 );
		update_post_meta( $post_id, '_fy_duration_label', isset( $yacht['duration'] ) ? $yacht['duration'] : '' );
		update_post_meta( $post_id, '_fy_price_note', isset( $yacht['note'] ) ? $yacht['note'] : '' );
		update_post_meta( $post_id, '_fy_image_url', isset( $yacht['image'] ) ? esc_url_raw( $yacht['image'] ) : '' );
		update_post_meta( $post_id, '_fy_button_url', isset( $yacht['url'] ) ? esc_url_raw( $yacht['url'] ) : '' );
		update_post_meta( $post_id, '_fy_search_terms', isset( $yacht['search'] ) ? $yacht['search'] : '' );
		update_post_meta( $post_id, '_fy_is_pink', ! empty( $yacht['pink'] ) ? '1' : '' );
		update_post_meta( $post_id, '_fy_is_free_hour', ! empty( $yacht['free'] ) ? '1' : '' );
		update_post_meta( $post_id, '_fy_button_label', '' );
		update_post_meta( $post_id, '_fy_button_sub', '' );

		$badges = array();
		if ( ! empty( $yacht['badges'] ) && is_array( $yacht['badges'] ) ) {
			foreach ( $yacht['badges'] as $badge ) {
				if ( ! is_array( $badge ) || count( $badge ) < 2 ) {
					continue;
				}
				$badges[] = array( 'style' => $badge[0], 'text' => $badge[1] );
			}
		}
		update_post_meta( $post_id, '_fy_badges', $badges );

		$rows = array();
		if ( ! empty( $yacht['rows'] ) && is_array( $yacht['rows'] ) ) {
			foreach ( $yacht['rows'] as $row ) {
				if ( ! is_array( $row ) || empty( $row[0] ) ) {
					continue;
				}
				if ( 'h' === $row[0] ) {
					$rows[] = array( 'type' => 'heading', 'text' => isset( $row[1] ) ? $row[1] : '' );
				} elseif ( 'n' === $row[0] ) {
					$rows[] = array( 'type' => 'note', 'text' => isset( $row[1] ) ? $row[1] : '' );
				} else {
					$rows[] = array(
						'type'     => 'price',
						'duration' => isset( $row[1] ) ? $row[1] : '',
						'price'    => isset( $row[2] ) ? floatval( $row[2] ) : 0,
						'free'     => ! empty( $row[3] ) ? '1' : '',
					);
				}
			}
		}
		update_post_meta( $post_id, '_fy_pricing', $rows );
	}

	/**
	 * Import once on activation, but never clobber an existing fleet.
	 */
	public static function maybe_seed_on_activation() {
		if ( get_option( self::FLAG_OPTION ) ) {
			return;
		}
		$existing = get_posts(
			array(
				'post_type'      => FY_Fleet_CPT::POST_TYPE,
				'post_status'    => 'any',
				'posts_per_page' => 1,
				'fields'         => 'ids',
			)
		);
		if ( ! empty( $existing ) ) {
			update_option( self::FLAG_OPTION, '1' );
			return;
		}
		self::import();
	}

	public static function handle_import() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to import the fleet.', 'fy-fleet' ) );
		}
		check_admin_referer( 'fy_import_fleet' );

		$result = self::import();

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'        => 'fy-fleet-visualizer',
					'post_type'   => FY_Fleet_CPT::POST_TYPE,
					'fy_imported' => $result['created'],
					'fy_updated'  => $result['updated'],
				),
				admin_url( 'edit.php' )
			)
		);
		exit;
	}
}
