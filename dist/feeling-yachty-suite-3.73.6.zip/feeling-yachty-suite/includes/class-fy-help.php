<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * "⭐ Start Here" — the staff manual for the whole Command Center.
 */
class FY_Fleet_Help {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ), 5 );
	}

	public static function add_menu() {
		add_submenu_page(
			'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE,
			__( 'Start Here', 'fy-fleet' ),
			__( '⭐ Start Here', 'fy-fleet' ),
			'edit_posts',
			'fy-fleet-help',
			array( __CLASS__, 'render' )
		);
	}

	private static function url( $page ) {
		return admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=' . $page );
	}

	public static function render() {
		$woo = class_exists( 'WooCommerce' );
		?>
		<div class="wrap" style="max-width:1000px">
			<h1><?php esc_html_e( '⭐ Feeling Yachty Command Center — Start Here', 'fy-fleet' ); ?></h1>
			<p style="font-size:14px;max-width:860px">
				<?php echo wp_kses_post( __( '<strong>How to use this guide:</strong> everything lives in the left menu under <strong>⚓ FY Command Center</strong>. Every blue link below jumps straight to the exact screen — you can’t get lost. When this guide says “click X”, X is the literal button text on that screen.', 'fy-fleet' ) ); ?>
			</p>

			<style>
				.fy-help-card{background:#fff;border:1px solid #dcdcde;border-left:5px solid #C7347B;border-radius:8px;padding:16px 20px;margin:14px 0}
				.fy-help-card h2{margin:0 0 8px;font-size:16px}
				.fy-help-card h3{margin:14px 0 6px;font-size:13.5px;color:#5B21B6}
				.fy-help-card p,.fy-help-card li{font-size:13.5px;line-height:1.65}
				.fy-help-card code{background:#f6f7f7;padding:1px 6px;border-radius:4px}
				.fy-help-warn{border-left-color:#dba617;background:#fffbf0}
				.fy-help-off{border-left-color:#8c8f94;background:#f9f9f9}
				.fy-help-toc{display:flex;gap:8px;flex-wrap:wrap;margin:14px 0 4px}
				.fy-help-toc a{display:inline-block;padding:6px 12px;border:1px solid #dcdcde;border-radius:999px;background:#fff;text-decoration:none;font-size:12px;font-weight:600}
				.fy-help-flow{display:flex;gap:6px;flex-wrap:wrap;align-items:center;font-size:12.5px;font-weight:700}
				.fy-help-flow span{padding:6px 11px;border-radius:9px;background:#F3E8FF;color:#5B21B6}
				.fy-help-flow em{color:#787c82;font-style:normal}
			</style>

			<?php if ( ! $woo ) : ?>
				<div class="notice notice-error"><p><strong><?php esc_html_e( 'WooCommerce is not active.', 'fy-fleet' ); ?></strong> <?php esc_html_e( 'Checkout, bookings, customers and the portal all need it. The yacht grid still displays without it.', 'fy-fleet' ); ?></p></div>
			<?php endif; ?>

			<nav class="fy-help-toc">
				<a href="#fy-h-setup">🚀 <?php esc_html_e( 'One-time setup', 'fy-fleet' ); ?></a>
				<a href="#fy-h-daily">🗓️ <?php esc_html_e( 'Daily operations', 'fy-fleet' ); ?></a>
				<a href="#fy-h-yachts">🛥️ <?php esc_html_e( 'Managing yachts', 'fy-fleet' ); ?></a>
				<a href="#fy-h-cities">🌎 <?php esc_html_e( 'Cities', 'fy-fleet' ); ?></a>
				<a href="#fy-h-desc">🧾 <?php esc_html_e( 'How descriptions work', 'fy-fleet' ); ?></a>
				<a href="#fy-h-money">💳 <?php esc_html_e( 'Money flow', 'fy-fleet' ); ?></a>
				<a href="#fy-h-portal">👤 <?php esc_html_e( 'Customer accounts', 'fy-fleet' ); ?></a>
				<a href="#fy-h-msg">📣 <?php esc_html_e( 'Messaging & automation', 'fy-fleet' ); ?></a>
				<a href="#fy-h-backup">🗄️ <?php esc_html_e( 'Backups & Excel', 'fy-fleet' ); ?></a>
				<a href="#fy-h-roles">🔐 <?php esc_html_e( 'Staff & privileges', 'fy-fleet' ); ?></a>
				<a href="#fy-h-gotchas">⚠️ <?php esc_html_e( 'Things to know', 'fy-fleet' ); ?></a>
			</nav>

			<div class="fy-help-card" id="fy-h-setup">
				<h2>🚀 <?php esc_html_e( 'One-time setup (do these once, in order)', 'fy-fleet' ); ?></h2>
				<ol>
					<li><?php printf( wp_kses_post( __( '<strong><a href="%s">WooCommerce → Settings → Payments</a></strong> → install/enable the official <em>WooCommerce Stripe Gateway</em> and <em>WooCommerce PayPal Payments</em> plugins and connect your accounts. Start in Stripe <em>test mode</em>. No payment method enabled = customers cannot pay.', 'fy-fleet' ) ), esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout' ) ) ); ?></li>
					<li><?php printf( wp_kses_post( __( '<a href="%s"><strong>Checkout &amp; Integrations</strong></a> → confirm the deposit %% (default 30), paste the GoHighLevel form URL, set the n8n webhook, review the cancellation policy.', 'fy-fleet' ) ), esc_url( self::url( 'fy-fleet-booking' ) ) ); ?></li>
					<li><?php echo wp_kses_post( __( '<strong>Settings → Permalinks → Save Changes</strong> (change nothing, just Save). Rebuilds product and account-tab URLs — skipping this is the #1 cause of 404s.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( '<strong>WooCommerce → Settings → Accounts &amp; Privacy</strong> → tick “Allow customers to create an account on the My Account page” so clients can sign up and use the portal.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( '<strong>The proof test:</strong> on the fleet page click any yacht’s <strong>“View …”</strong> button → its WooCommerce product page opens → Add to cart (the deposit price) → checkout with Stripe test card <code>4242 4242 4242 4242</code>. Then confirm the order appears under WooCommerce → Orders.', 'fy-fleet' ) ); ?></li>
				</ol>
			</div>

			<div class="fy-help-card" id="fy-h-daily">
				<h2>🗓️ <?php esc_html_e( 'Daily operations', 'fy-fleet' ); ?></h2>
				<ul>
					<li><?php printf( wp_kses_post( __( '<a href="%s"><strong>📊 Dashboard</strong></a> — bookings, revenue, deposits collected, dock balances and guests for 7/15/30 days or any custom range, plus top yachts and the next charters. Dollar figures require the <code>view_fy_revenue</code> privilege (admins have it; others see counts and a 🔒).', 'fy-fleet' ) ), esc_url( self::url( 'fy-fleet-dashboard' ) ) ); ?></li>
					<li><?php printf( wp_kses_post( __( '<a href="%s"><strong>📥 Inbox</strong></a> — every customer message, filterable by department (Sales / Billing / Cancellations / Support) and status. Replies are emailed to the customer instantly. The <strong>✨ Draft reply with AI</strong> button writes a suggested answer into the box for you to review — nothing sends automatically. The menu badge counts open tickets.', 'fy-fleet' ) ), esc_url( self::url( 'fy-fleet-inbox' ) ) ); ?></li>
					<li><?php printf( wp_kses_post( __( '<strong>Orders &amp; customers live in WooCommerce</strong> — <a href="%s">WooCommerce → Orders</a> is the one place for every sale; customer history sits on each order. (n8n still receives every booking and full customer stats through the webhook and the API.)', 'fy-fleet' ) ), esc_url( admin_url( 'admin.php?page=wc-orders' ) ) ); ?></li>
					<li><?php printf( wp_kses_post( __( '<a href="%s"><strong>Activity Log</strong></a> — every API write, webhook delivery, Twilio send, import and backup. First stop when “something changed by itself”.', 'fy-fleet' ) ), esc_url( self::url( 'fy-fleet-log' ) ) ); ?></li>
				</ul>
			</div>

			<div class="fy-help-card" id="fy-h-yachts">
				<h2>🛥️ <?php esc_html_e( 'Managing yachts', 'fy-fleet' ); ?></h2>

				<h3><?php esc_html_e( 'Fastest way: Duplicate an existing yacht', 'fy-fleet' ); ?></h3>
				<p><?php printf( wp_kses_post( __( 'New boats are usually 80%% identical to one you already have. In the <a href="%s">Fleet Visualizer</a>, find a similar yacht and click <strong>⧉ Duplicate</strong>. You get a DRAFT copy — same pricing table, add-ons, city and photo — that is invisible on the site until you publish. Change the name, size, price and photo, click <strong>Publish</strong>, done. The copy automatically gets its own product and URL, and never inherits the original’s reviews or blocked dates.', 'fy-fleet' ) ), esc_url( self::url( 'fy-fleet-visualizer' ) ) ); ?></p>

				<h3><?php esc_html_e( 'Add a yacht in 60 seconds — exact clicks', 'fy-fleet' ); ?></h3>
				<ol>
					<li><?php printf( wp_kses_post( __( '<strong>Products → <a href="%s">Add New Product</a></strong>. Type the name in the big title box exactly how customers should see it, e.g. <code>55ft Sea Ray “Palantir”</code>. The description starts pre-filled with the <code>[fy_yacht_…]</code> shortcodes — leave them. Everything below happens in the <strong>⚓ Feeling Yachty — Yacht Card</strong> box on that same screen.', 'fy-fleet' ) ), esc_url( admin_url( 'post-new.php?post_type=product' ) ) ); ?></li>
					<li><?php echo wp_kses_post( __( 'In <strong>Card Summary</strong>: fill <strong>Size (feet)</strong> (number only, e.g. <code>55</code> — this controls sorting and the size filters), <strong>Starting Price</strong> (number only, e.g. <code>1250</code>), <strong>Starting Duration Label</strong> (e.g. <code>3 Hours</code>) and <strong>Starting Price Note</strong> (e.g. <code>3-hour private charter</code>).', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( 'Tick <strong>Pink Yacht</strong> and/or <strong>Free-Hour Offer</strong> if they apply — badges and filters follow automatically.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( 'Photo: set the <strong>Product Image</strong> (right sidebar) — it becomes the card photo automatically. Or paste an <strong>Image URL</strong> in the Yacht Card box’s Card Photo section and it imports itself on save.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( 'In <strong>Hours &amp; Pricing</strong>, click <strong>+ Add Price Row</strong> for each package (e.g. <code>3 Hours</code> / <code>1250</code>). Different weekend rates? Click the quick button <strong>Weekday (Mon–Thu)</strong>, add its rows, then <strong>🌴 Weekend (Fri–Sun)</strong> and add those rows. Tick <strong>Free-hour row style</strong> on “Pay for 4 Get 5” style rows.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( 'Pick the departure marina in the <strong>Marina &amp; Map</strong> section (dropdown of saved marinas, or type a custom one) — the embedded Google map, the Google Maps link and the local-SEO map data all generate themselves.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( 'Click the blue <strong>Publish</strong> button. That’s it.', 'fy-fleet' ) ); ?></li>
				</ol>
				<p><?php echo wp_kses_post( __( '<strong>What happens by itself on Publish</strong> (do NOT do these manually): the WooCommerce product is created with the deposit price · the <strong>Button URL</strong> fills with that product’s own page — the URL customers buy on · the product description gets the <code>[fy_yacht_…]</code> shortcode stack · the yacht appears on the site, auto-sorted by size. Leave the Button URL field alone unless you want the card to link somewhere unusual.', 'fy-fleet' ) ); ?></p>

				<h3><?php esc_html_e( 'Why there is no “Add New Yacht” menu item', 'fy-fleet' ); ?></h3>
				<p><?php echo wp_kses_post( __( 'There is exactly ONE way to add a yacht — <strong>Products → Add New</strong> — so nobody can create a yacht that isn’t buyable. Publishing the product creates the yacht card behind it automatically; the Fleet Visualizer is where you edit and duplicate what already exists. (Selling merch or gift cards? Just untick “List this product in the Fleet widget” on that product.)', 'fy-fleet' ) ); ?></p>

				<h3><?php esc_html_e( 'Hours & Pricing', 'fy-fleet' ); ?></h3>
				<p><?php echo wp_kses_post( __( 'Add a price row per package. Use the <strong>Weekend quick-add buttons</strong> (Mon–Thu / Fri–Sun etc.) to split rates by day — the booking form automatically shows the right rates for the date a customer picks. Notes (e.g. “Weekend surcharge — $150”) display inside the pricing panel.', 'fy-fleet' ) ); ?></p>

				<h3><?php esc_html_e( 'Booking Options (per yacht)', 'fy-fleet' ); ?></h3>
				<ul>
					<li><?php echo wp_kses_post( __( '<strong>Blocked dates</strong> — one YYYY-MM-DD per line; customers cannot book those days online.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( '<strong>Available add-ons</strong> — untick anything this boat can’t offer (catalog lives in Checkout &amp; Integrations: jet ski, jet car, bartender, photo packages…). Add boat-only extras (water slide) below it.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( '<strong>Weekend surcharge</strong> — only for yachts WITHOUT separate weekend price rows, or weekends charge twice.', 'fy-fleet' ) ); ?></li>
				</ul>

				<h3><?php esc_html_e( 'Reviews & Marina', 'fy-fleet' ); ?></h3>
				<p><?php printf( wp_kses_post( __( '<strong>Reviews</strong>: paste real guest reviews in the yacht’s Reviews box — they show on the product page via the <code>[fy_yacht_reviews]</code> block (in the default stack). <strong>Marina &amp; Map</strong>: manage the marina library once under <a href="%s">Marinas</a> (name, address, GPS, optional custom embed), then pick from the dropdown on each product. The product page gets the “Departs from” line (<code>[fy_yacht_location]</code>) and the full Google map block with directions (<code>[fy_yacht_marina]</code>), plus invisible local-SEO data telling Google exactly where the charter departs from. Fix a marina’s address once and every yacht using it updates.', 'fy-fleet' ) ), esc_url( self::url( 'fy-fleet-marinas' ) ) ); ?></p>

				<h3><?php esc_html_e( 'Fast bulk edits', 'fy-fleet' ); ?></h3>
				<p><?php printf( wp_kses_post( __( '<a href="%s"><strong>Fleet Visualizer</strong></a> — every yacht on one screen with search and size/price/name sort. Edit prices, photos and even Hours &amp; Pricing rows inline; Save posts instantly. The <strong>Live Preview</strong> tab shows the real page with Desktop / Tablet / Mobile device frames.', 'fy-fleet' ) ), esc_url( self::url( 'fy-fleet-visualizer' ) ) ); ?></p>
			</div>

			<div class="fy-help-card" id="fy-h-cities">
				<h2>🌎 <?php esc_html_e( 'Cities — adding Panama (or any new market)', 'fy-fleet' ); ?></h2>
				<p><?php echo wp_kses_post( __( 'Every yacht belongs to a city; all current yachts were auto-assigned to <strong>Miami Yacht Rentals</strong>, and new yachts default to it. A city-set widget shows ONLY that city’s yachts. To launch Panama:', 'fy-fleet' ) ); ?></p>
				<ol>
					<li><?php printf( wp_kses_post( __( '<strong>⚓ FY Command Center → <a href="%s">Cities</a></strong> → Add New City → name it <code>Panama Yacht Rentals</code>.', 'fy-fleet' ) ), esc_url( admin_url( 'edit-tags.php?taxonomy=fy_yacht_cat&post_type=fy_yacht' ) ) ); ?></li>
					<li><?php echo wp_kses_post( __( 'On each Panama yacht, tick <strong>Panama Yacht Rentals</strong> in the Cities box (right sidebar) and untick Miami.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( 'On the Panama page in Elementor, drop the <strong>Yacht Fleet Finder</strong> widget and set <strong>City = Panama Yacht Rentals</strong> plus its own heading. Shortcode version: <code>[fy_yacht_fleet fleet="panama-yacht-rentals" heading="Compare Panama Yacht Rentals"]</code>.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( 'n8n per-city endpoint is automatic: <code>POST /wp-json/fy/v1/fleets/panama-yacht-rentals/yachts</code> creates yachts directly in Panama — the city is even auto-created if it doesn’t exist yet.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( 'Free SEO landing page per city at <code>/yacht-category/panama-yacht-rentals/</code> — H1, intro copy and meta editable on the city’s edit screen.', 'fy-fleet' ) ); ?></li>
				</ol>
			</div>

			<div class="fy-help-card" id="fy-h-desc">
				<h2>🧾 <?php esc_html_e( 'How descriptions work (read this one twice)', 'fy-fleet' ); ?></h2>
				<p><?php echo wp_kses_post( __( '<strong>The yacht is the single source of truth.</strong> Edit the yacht; every page updates. Never hand-write specs into the WooCommerce product.', 'fy-fleet' ) ); ?></p>
				<ul>
					<li><?php echo wp_kses_post( __( '<strong>Fleet grid card</strong> — built from the Card Summary fields (size, price, best-for, badges, pricing rows).', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( '<strong>No separate yacht page.</strong> The WooCommerce product page IS the yacht’s page. Any old /miami-yacht-rentals/name/ link (bookmarks, Google) automatically forwards to the product page.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( '<strong>Product page description</strong> — assembled from shortcode blocks, rendered LIVE so it can never be stale. Default stack, in order:', 'fy-fleet' ) ); ?>
						<p class="fy-help-flow" style="margin:8px 0">
							<span>[fy_yacht_special]</span><em>→</em>
							<span>[fy_yacht_specs]</span><em>→</em>
							<span>[fy_yacht_hours]</span><em>→</em>
							<span>[fy_yacht_addons]</span><em>→</em>
							<span>[fy_yacht_location]</span><em>→</em>
							<span>[fy_yacht_deposit]</span><em>→</em>
							<span>[fy_yacht_reviews]</span><em>→</em>
							<span>[fy_yacht_marina]</span>
						</p>
					</li>
					<li><?php echo wp_kses_post( __( '<strong>Yacht Page Description</strong> (Card Summary field) — your optional sales intro. Appears ONLY as the styled highlight at the top of the product description (<code>[fy_yacht_special]</code>) — never on the grid or gallery.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( '<strong>Custom order?</strong> Edit the product and rearrange/remove the shortcode lines. The moment you do, the auto-sync respects your layout and stops rewriting it (it only manages descriptions still carrying its hidden marker). All blocks also work anywhere else — pages, Elementor — with <code>yacht="123"</code>, plus <code>[fy_yacht_info]</code> for the whole stack and <code>[fy_yacht_fleet]</code> for the grid.', 'fy-fleet' ) ); ?></li>
					<li><?php printf( wp_kses_post( __( 'Changed global things (add-on prices, deposit %%)? Pages update instantly; click <strong>Re-sync all yacht products</strong> in the <a href="%s">Fleet Visualizer</a> to also refresh stored copies, prices and missing images.', 'fy-fleet' ) ), esc_url( self::url( 'fy-fleet-visualizer' ) ) ); ?></li>
				</ul>
			</div>

			<div class="fy-help-card" id="fy-h-money">
				<h2>💳 <?php esc_html_e( 'The money flow', 'fy-fleet' ); ?></h2>
				<p class="fy-help-flow">
					<span><?php esc_html_e( 'fleet widget card', 'fy-fleet' ); ?></span><em>→</em>
					<span><?php esc_html_e( 'WooCommerce product page (the shortcode stack)', 'fy-fleet' ); ?></span><em>→</em>
					<span><?php esc_html_e( 'Add to cart — deposit price', 'fy-fleet' ); ?></span><em>→</em>
					<span><?php esc_html_e( 'WooCommerce cart', 'fy-fleet' ); ?></span><em>→</em>
					<span><?php esc_html_e( 'checkout: deposit charged', 'fy-fleet' ); ?></span><em>→</em>
					<span><?php esc_html_e( 'balance due at the dock', 'fy-fleet' ); ?></span>
				</p>
				<ul>
					<li><?php echo wp_kses_post( __( 'The product price IS the deposit — set the deposit %% once under Checkout &amp; Integrations and every product price recalculates on the next re-sync. Deposit and dock balance show <strong>side by side</strong> on the cart, checkout and thank-you page.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( 'Checkout requires ticking the <strong>Bareboat Verification Form</strong> confirmation (form embeds above it — editable under Checkout &amp; Integrations → GHL Form Code). Cancellation policy shows on the cart, checkout and order page.', 'fy-fleet' ) ); ?></li>
				</ul>
			</div>

			<div class="fy-help-card" id="fy-h-portal">
				<h2>👤 <?php esc_html_e( 'Customer accounts (the portal)', 'fy-fleet' ); ?></h2>
				<p><?php echo wp_kses_post( __( 'Clients sign up / log in via WooCommerce <strong>My Account</strong> and get three extra tabs:', 'fy-fleet' ) ); ?></p>
				<ul>
					<li><?php echo wp_kses_post( __( '<strong>⚓ My Charters</strong> — each booking with date, time, marina, deposit paid vs. dock balance, and a <strong>Request cancellation</strong> button that lands in your Inbox (Cancellations dept) and notes the order.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( '<strong>📄 My Documents</strong> — their signed forms. Staff attach these on the customer’s WordPress user profile (Users → edit → Feeling Yachty Documents: title + file URL).', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( '<strong>💬 Support</strong> — open tickets by department and reply in-thread; your Inbox replies email them instantly.', 'fy-fleet' ) ); ?></li>
				</ul>
			</div>

			<div class="fy-help-card" id="fy-h-msg">
				<h2>📣 <?php esc_html_e( 'Messaging & automation', 'fy-fleet' ); ?></h2>
				<ul>
					<li><?php echo wp_kses_post( __( '<strong>Twilio</strong> (Checkout &amp; Integrations) — automatic SMS/WhatsApp when a deposit is paid: staff alert + customer confirmation with editable template and tokens like <code>{yacht} {date} {balance}</code>. Test-send box included. Note: nobody can send iMessage — Apple doesn’t allow it; SMS reaches iPhones normally.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( '<strong>Webhook → n8n → GoHighLevel</strong> — one URL receives everything, signed with HMAC: <code>booking.paid</code>, <code>ticket.created</code>, <code>ticket.reply</code>. Route on the <code>event</code> field.', 'fy-fleet' ) ); ?></li>
					<li><?php printf( wp_kses_post( __( '<strong>REST API</strong> (<a href="%s">API / n8n</a> has copy-paste docs) — yachts (every field on the card and product page, incl. add-ons, blackout dates, gallery, reviews), bookings (date, time, duration, guests, occasion, notes, marina, totals), customers, tickets. Auth = Application Passwords.', 'fy-fleet' ) ), esc_url( self::url( 'fy-fleet-api' ) ) ); ?></li>
					<li><?php echo wp_kses_post( __( '<strong>AI assist</strong> — add your Anthropic or OpenAI key under Checkout &amp; Integrations and the Inbox gains the draft button. Keys can live in wp-config (<code>FY_AI_API_KEY</code>, <code>FY_TWILIO_TOKEN</code>) instead of the database.', 'fy-fleet' ) ); ?></li>
				</ul>
			</div>

			<div class="fy-help-card" id="fy-h-backup">
				<h2>🗄️ <?php esc_html_e( 'Backups & editing in Excel', 'fy-fleet' ); ?></h2>
				<ul>
					<li><?php echo wp_kses_post( __( '<strong>Snapshots</strong> — daily automatic, newest 7 kept, plus one before every import/restore (so even restores are reversible). Restore from the list on the API / n8n page. Manual “Create backup now” any time.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( '<strong>JSON export/import</strong> — the full-fidelity file (yachts + suite settings); moves the whole fleet between sites.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( '<strong>Excel/CSV bulk edit</strong> — Export all yachts → edit in Excel → Import. Rules: <strong>blank cell = unchanged</strong>, a single <code>-</code> = clear, rows match by ID (new names create yachts), deleting a row never deletes anything. Pricing cell syntax, one per line: <code># Friday–Sunday</code> (day heading), <code>3 Hours = 845</code> (add <code>*</code> for free-hour), <code>note: …</code>.', 'fy-fleet' ) ); ?></li>
				</ul>
			</div>

			<div class="fy-help-card" id="fy-h-roles">
				<h2>🔐 <?php esc_html_e( 'Staff & privileges', 'fy-fleet' ); ?></h2>
				<ul>
					<li><?php echo wp_kses_post( __( '<strong>Fleet Staff role</strong> — give dock/sales staff this role (Users → Add New): they manage yachts, galleries, bookings and the Inbox, but not plugins, themes or site settings.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( '<strong>view_fy_revenue</strong> — dollar figures on the Dashboard are admin-only by default; grant this capability with any role-editor plugin to share revenue with a manager.', 'fy-fleet' ) ); ?></li>
				</ul>
			</div>

			<div class="fy-help-card fy-help-warn" id="fy-h-gotchas">
				<h2>⚠️ <?php esc_html_e( 'Things to know', 'fy-fleet' ); ?></h2>
				<ul>
					<li><?php esc_html_e( 'Clients message first, you confirm, then they book — the calendar shows conflicts in red, and identical date+time double-bookings are blocked, but ALWAYS check Bookings before confirming a date.', 'fy-fleet' ); ?></li>
					<li><?php esc_html_e( 'After changing the yacht URL base, open Settings → Permalinks and Save once.', 'fy-fleet' ); ?></li>
					<li><?php esc_html_e( 'Weekend surcharge OR weekend price rows — never both on one yacht.', 'fy-fleet' ); ?></li>
					<li><?php esc_html_e( 'Auto-fill never overwrites: button URLs and images you set yourself are left alone; only empty fields get defaults.', 'fy-fleet' ); ?></li>
					<li><?php esc_html_e( 'Minimum booking notice (default 1 day) blocks same-day online bookings — same-day requests still come through WhatsApp.', 'fy-fleet' ); ?></li>
				</ul>
			</div>

			<div class="fy-help-card fy-help-off">
				<h2>😴 <?php esc_html_e( 'Optional modules (currently off)', 'fy-fleet' ); ?></h2>
				<p><?php printf( wp_kses_post( __( 'Flip any of these on in the <a href="%s"><strong>⚙️ Control Panel</strong></a> — no code, takes effect on save, turning off never deletes data.', 'fy-fleet' ) ), esc_url( self::url( 'fy-fleet-control' ) ) ); ?></p>
				<ul>
					<li><?php echo wp_kses_post( __( '<strong>Tags</strong> — only the Tags taxonomy is off; Cities (multi-city fleets) are ACTIVE, see the Cities card above.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( '<strong>Built-in SEO module</strong> — Rank Math handles meta on this site. Re-enabling restores the yacht SEO metabox, templates and Product/FAQ/review-star schema.', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( '<strong>Payments hub page</strong> — gateways are managed directly in WooCommerce → Settings → Payments. (The Re-sync all yacht products button moved to the Fleet Visualizer.)', 'fy-fleet' ) ); ?></li>
					<li><?php echo wp_kses_post( __( '<strong>Photo Galleries</strong> — the reusable gallery system (grid/slider + lightbox) is off.', 'fy-fleet' ) ); ?></li>
				</ul>
			</div>
		</div>
		<?php
	}
}
