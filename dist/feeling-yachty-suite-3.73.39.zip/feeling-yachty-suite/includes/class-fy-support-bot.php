<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AI lead-qualifier chat widget, connected to n8n. Merged in from the
 * standalone "Feeling Yachty - Support Bot" plugin so it always has access to
 * this plugin's own live fleet data instead of a disconnected copy.
 *
 * One bot, backed by a set of independent "Knowledge Databases" (Miami,
 * Panama, and any the user adds) — each database compiles LIVE aggregate
 * fleet facts (count, size range, capacity range, starting-price range, all
 * from real fy_yacht data) plus a free-text notes box for anything the user
 * wants to add on top. The bot draws from whichever databases are enabled.
 *
 * The bot NEVER quotes an exact price or names a specific yacht — same
 * restraint as the original standalone plugin — it stays a lead-qualifier
 * that hands off to a human. The databases make that hand-off grounded in
 * real current facts instead of nothing; they do not change what the bot is
 * allowed to say.
 */
class FY_Support_Bot {

	const OPT_SETTINGS  = 'fy_support_bot_settings';
	const OPT_KB        = 'fy_support_bot_knowledge_base';
	const OPT_DATABASES = 'fy_support_bot_databases';
	const OPT_FAQS      = 'fy_support_bot_faqs';

	/** Region keyword lists — checked against the visitor's own message text before falling back to the page-URL hint. */
	const PANAMA_KEYWORDS = array(
		'panama', 'panamá', 'pty', 'panama city', 'ciudad de panama', 'colon', 'colón',
		'bocas del toro', 'boquete', 'coronado', 'contadora', 'casco viejo', 'punta pacifica',
	);
	const MIAMI_KEYWORDS = array(
		'miami', 'miami beach', 'miami-dade', 'south beach', 'brickell', 'aventura',
		'coral gables', 'doral', 'sunny isles', 'bal harbour', 'key biscayne', 'coconut grove',
		'fort lauderdale', 'ft lauderdale', 'ft. lauderdale', 'hollywood fl', 'hallandale',
		'boca raton', 'west palm beach', 'south florida',
	);

	public static function init() {
		self::maybe_migrate();

		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'handle_saves' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );

		// Any yacht add/edit/publish/price change busts BOTH region caches
		// immediately (cheap to recompute; not knowing which region a given
		// yacht belongs to without a query isn't worth the complexity) —
		// the bot never answers from data more than a moment stale, not
		// just eventually within the transient's 15-minute window.
		add_action( 'save_post_' . ( class_exists( 'FY_Fleet_CPT' ) ? FY_Fleet_CPT::POST_TYPE : 'fy_yacht' ), array( __CLASS__, 'flush_fleet_cache' ) );
	}

	public static function flush_fleet_cache() {
		delete_transient( 'fy_sb_fleet_miami' );
		delete_transient( 'fy_sb_fleet_panama' );
	}

	/* ------------------------------------------------------------------
	 * One-time migration from the standalone plugin's options
	 * ---------------------------------------------------------------- */

	/**
	 * If the standalone "Feeling Yachty - Support Bot" plugin's options
	 * exist (meaning it's/was active on this site) and the merged plugin's
	 * own settings don't exist yet, copy them over once — the live n8n
	 * webhook URL and any hand-edited knowledge base survive the merge
	 * without the user re-pasting anything.
	 */
	private static function maybe_migrate() {
		if ( false === get_option( self::OPT_SETTINGS ) ) {
			$old_settings = get_option( 'fysb_settings' );
			if ( false !== $old_settings ) {
				update_option( self::OPT_SETTINGS, $old_settings );
				if ( class_exists( 'FY_Fleet_Log' ) ) {
					FY_Fleet_Log::add( 'support_bot.migrated', 'Support Bot settings migrated from the standalone plugin (webhook URL preserved).' );
				}
			}
			$old_kb = get_option( 'fysb_knowledge_base' );
			if ( false !== $old_kb ) {
				update_option( self::OPT_KB, $old_kb );
			}
		}

		self::maybe_upgrade_ask_city_rule();
		self::maybe_upgrade_existing_booking_rule();
		self::maybe_upgrade_share_options_rule();
		self::maybe_upgrade_human_voice_and_booking();
		self::maybe_upgrade_addons_and_filters();
		self::maybe_upgrade_booking_greeting();
		self::maybe_upgrade_client_triage();
	}

	/**
	 * Inserts three brand-new categories for sites with an already-saved
	 * knowledge base: "client_triage" (a routing category, placed FIRST so
	 * the bot decides which of the four client types it's talking to before
	 * anything else) and "third_party_booking" / "addons_only" (placed right
	 * after "existing_booking", where they belong conceptually). Same
	 * insert-only-if-missing pattern as the other category upgrades — never
	 * touches an existing category's saved content.
	 */
	private static function maybe_upgrade_client_triage() {
		if ( get_option( 'fy_support_bot_client_triage_upgrade_applied' ) ) {
			return;
		}

		$kb = get_option( self::OPT_KB );
		if ( is_array( $kb ) && ! empty( $kb['categories'] ) ) {
			$defaults = self::default_knowledge_base()['categories'];
			$by_key   = array_column( $defaults, null, 'key' );
			$keys     = array_column( $kb['categories'], 'key' );

			if ( ! in_array( 'client_triage', $keys, true ) && isset( $by_key['client_triage'] ) ) {
				array_unshift( $kb['categories'], $by_key['client_triage'] );
			}

			$keys = array_column( $kb['categories'], 'key' ); // Recomputed — the unshift above changes indexes.
			if ( ! in_array( 'third_party_booking', $keys, true ) && isset( $by_key['third_party_booking'] ) ) {
				$new = array();
				foreach ( $kb['categories'] as $cat ) {
					$new[] = $cat;
					if ( 'existing_booking' === $cat['key'] ) {
						$new[] = $by_key['third_party_booking'];
					}
				}
				if ( ! in_array( 'existing_booking', $keys, true ) ) {
					$new[] = $by_key['third_party_booking'];
				}
				$kb['categories'] = $new;
			}

			$keys = array_column( $kb['categories'], 'key' );
			if ( ! in_array( 'addons_only', $keys, true ) && isset( $by_key['addons_only'] ) ) {
				$new     = array();
				$anchor  = in_array( 'third_party_booking', $keys, true ) ? 'third_party_booking' : 'existing_booking';
				$did_add = false;
				foreach ( $kb['categories'] as $cat ) {
					$new[] = $cat;
					if ( $anchor === $cat['key'] ) {
						$new[]   = $by_key['addons_only'];
						$did_add = true;
					}
				}
				if ( ! $did_add ) {
					$new[] = $by_key['addons_only'];
				}
				$kb['categories'] = $new;
			}

			update_option( self::OPT_KB, $kb );
		}

		update_option( 'fy_support_bot_client_triage_upgrade_applied', 1 );
	}

	/**
	 * Adds the "ask how you can help before diving into booking-number
	 * collection" opening to the existing_booking category for sites that
	 * already received the 3.64.0 rewrite (so the Bokun-text overwrite in
	 * maybe_upgrade_human_voice_and_booking() won't fire again — that guard
	 * is keyed on the word "bokun", which is gone once rewritten). Inserted
	 * right before the "YOU CANNOT SEE BOOKINGS" line when that marker is
	 * found; appended to the end otherwise, so a heavily hand-edited box
	 * still gets the addition rather than silently missing it.
	 */
	private static function maybe_upgrade_booking_greeting() {
		if ( get_option( 'fy_support_bot_booking_greeting_upgrade_applied' ) ) {
			return;
		}

		$marker  = 'how can I help';
		$anchor  = 'YOU CANNOT SEE BOOKINGS.';
		$insert  = "If they haven't said yet what they actually need, open with a normal, friendly \"how can I help\" — same as you would anyone else — rather than jumping straight to collecting their booking number:\n\"Hey, welcome back! What can I help you with?\"\n\"Of course — what's going on with your booking?\"\nOnce you know what they need, move into collecting the details below. Your job here is ONLY to qualify — find out who they are and what they need — never to resolve it yourself.\n\n";

		$kb = get_option( self::OPT_KB );
		if ( is_array( $kb ) && ! empty( $kb['categories'] ) ) {
			foreach ( $kb['categories'] as &$cat ) {
				if ( 'existing_booking' !== $cat['key'] ) {
					continue;
				}
				$content = (string) $cat['content'];
				if ( false === stripos( $content, $marker ) ) {
					if ( false !== strpos( $content, $anchor ) ) {
						$content = str_replace( $anchor, $insert . $anchor, $content );
					} else {
						$content = rtrim( $content ) . "\n\n" . $insert;
					}
					$cat['content'] = $content;
				}
				break;
			}
			unset( $cat );
			update_option( self::OPT_KB, $kb );
		}

		update_option( 'fy_support_bot_booking_greeting_upgrade_applied', 1 );
	}

	/**
	 * Two more additions to an already-shipped category, same non-destructive
	 * append pattern as maybe_upgrade_ask_city_rule(): the "share_options"
	 * category already reached sites via the 3.63.0 upgrade, so a fresh
	 * insert (which only fires when the key is entirely missing) won't carry
	 * this update to them — the new paragraph has to be appended to whatever
	 * is already saved there, guarded by a marker so it's never duplicated.
	 *
	 * 1. The filters + Instagram-to-qualify paragraph, appended to the
	 *    share_options category content.
	 * 2. Each database's addons_url, backfilled the same way browse_url was —
	 *    only fills a MISSING value, never overwrites a hand-entered one.
	 */
	private static function maybe_upgrade_addons_and_filters() {
		if ( get_option( 'fy_support_bot_addons_filters_upgrade_applied' ) ) {
			return;
		}

		$marker = '@feeling.yachty';
		$kb     = get_option( self::OPT_KB );
		if ( is_array( $kb ) && ! empty( $kb['categories'] ) ) {
			foreach ( $kb['categories'] as &$cat ) {
				if ( 'share_options' !== $cat['key'] ) {
					continue;
				}
				if ( false === strpos( (string) $cat['content'], $marker ) ) {
					$addition       = "\n\nMention the filters, briefly, when you send the fleet link — don't make it its own message: the fleet page has filters, including ones for our pink yacht rentals and our free-hour promotions, worth pointing out:\n\"You can also filter on that page for our pink yachts or the free-hour deals, if either of those sound fun.\"\n\nIf they like something they found through one of those filters, qualifying is simple — just following on Instagram:\n\"If one of those catches your eye, all you have to do to qualify is follow us on Instagram — that's it! We're @feeling.yachty: https://www.instagram.com/feeling.yachty/\"\nAlways send the actual link (not just the handle) so it's clickable, and only bring it up once it's relevant — they mentioned a pink yacht, a free-hour deal, or asked about a filter/badge on the page. Don't lead with it.";
					$cat['content'] = rtrim( (string) $cat['content'] ) . $addition;
				}
				break;
			}
			unset( $cat );
			update_option( self::OPT_KB, $kb );
		}

		$dbs = get_option( self::OPT_DATABASES );
		if ( is_array( $dbs ) && $dbs ) {
			$changed = false;
			foreach ( $dbs as &$db ) {
				if ( ! isset( $db['addons_url'] ) ) {
					$db['addons_url'] = self::default_addons_url( $db['type'] );
					$changed          = true;
				}
			}
			unset( $db );
			if ( $changed ) {
				update_option( self::OPT_DATABASES, $dbs );
			}
		}

		update_option( 'fy_support_bot_addons_filters_upgrade_applied', 1 );
	}

	/**
	 * Two changes that must reach sites with an already-saved knowledge base,
	 * since default_knowledge_base() alone only helps a fresh install:
	 *
	 * 1. Inserts the "Sound Like a Real Person" category (after "tone").
	 * 2. REPLACES the old "Existing Booking Lookup" text. Unlike every other
	 *    upgrade here this one overwrites, because that text instructs the bot
	 *    to look a booking up "via the Bokun connection" and then state the
	 *    exact balance — a lookup that does not exist and never did. Left in
	 *    place it invites invented figures on real reservations, which is the
	 *    single most damaging thing this bot could do. The previous text is
	 *    copied to its own option and written to the activity log first, so an
	 *    overwritten customization is recoverable rather than gone.
	 */
	private static function maybe_upgrade_human_voice_and_booking() {
		if ( get_option( 'fy_support_bot_human_voice_upgrade_applied' ) ) {
			return;
		}

		$kb = get_option( self::OPT_KB );
		if ( is_array( $kb ) && ! empty( $kb['categories'] ) ) {
			$defaults = self::default_knowledge_base()['categories'];
			$by_key   = array_column( $defaults, null, 'key' );
			$keys     = array_column( $kb['categories'], 'key' );

			if ( ! in_array( 'human_voice', $keys, true ) && isset( $by_key['human_voice'] ) ) {
				$new = array();
				foreach ( $kb['categories'] as $cat ) {
					$new[] = $cat;
					if ( 'tone' === $cat['key'] ) {
						$new[] = $by_key['human_voice'];
					}
				}
				if ( ! in_array( 'tone', $keys, true ) ) {
					array_unshift( $new, $by_key['human_voice'] );
				}
				$kb['categories'] = $new;
			}

			foreach ( $kb['categories'] as &$cat ) {
				if ( 'existing_booking' !== $cat['key'] || false === stripos( (string) $cat['content'], 'bokun' ) ) {
					continue;
				}
				update_option( 'fy_support_bot_existing_booking_previous_text', $cat['content'] );
				if ( class_exists( 'FY_Fleet_Log' ) ) {
					FY_Fleet_Log::add( 'support_bot.booking_rule_replaced', 'Support Bot: the old "Existing Booking Lookup" instructions (which told the bot to look bookings up in Bokun and quote exact balances — there is no such lookup) were replaced with the collect-and-hand-off rules. The previous text is saved in the fy_support_bot_existing_booking_previous_text option.' );
				}
				$cat['label']       = $by_key['existing_booking']['label'];
				$cat['description'] = $by_key['existing_booking']['description'];
				$cat['content']     = $by_key['existing_booking']['content'];
				break;
			}
			unset( $cat );

			update_option( self::OPT_KB, $kb );
		}

		update_option( 'fy_support_bot_human_voice_upgrade_applied', 1 );
	}

	/**
	 * Same one-time, non-destructive pattern as the two upgrades above, for
	 * the "Share Fleet Link & Collect Favorites" step: inserts the category
	 * right after "qualification" (where it belongs in the conversation
	 * order) and backfills each existing database's browse_url, which sites
	 * that saved their databases before this field existed won't have. Only
	 * fills a MISSING url — a hand-edited one is never overwritten.
	 */
	private static function maybe_upgrade_share_options_rule() {
		if ( get_option( 'fy_support_bot_share_options_upgrade_applied' ) ) {
			return;
		}

		$kb = get_option( self::OPT_KB );
		if ( is_array( $kb ) && ! empty( $kb['categories'] ) && ! in_array( 'share_options', array_column( $kb['categories'], 'key' ), true ) ) {
			foreach ( self::default_knowledge_base()['categories'] as $default_cat ) {
				if ( 'share_options' !== $default_cat['key'] ) {
					continue;
				}
				$new_categories = array();
				foreach ( $kb['categories'] as $cat ) {
					$new_categories[] = $cat;
					if ( 'qualification' === $cat['key'] ) {
						$new_categories[] = $default_cat;
					}
				}
				if ( ! in_array( 'qualification', array_column( $kb['categories'], 'key' ), true ) ) {
					$new_categories[] = $default_cat;
				}
				$kb['categories'] = $new_categories;
				update_option( self::OPT_KB, $kb );
				break;
			}
		}

		$dbs = get_option( self::OPT_DATABASES );
		if ( is_array( $dbs ) && $dbs ) {
			$changed = false;
			foreach ( $dbs as &$db ) {
				if ( empty( $db['browse_url'] ) ) {
					$db['browse_url'] = self::default_browse_url( $db['type'] );
					$changed          = true;
				}
			}
			unset( $db );
			if ( $changed ) {
				update_option( self::OPT_DATABASES, $dbs );
			}
		}

		update_option( 'fy_support_bot_share_options_upgrade_applied', 1 );
	}

	/**
	 * Same one-time, non-destructive pattern as maybe_upgrade_ask_city_rule():
	 * a site that already saved a knowledge base before the "Existing Booking
	 * Lookup" category existed needs it inserted, not left missing forever
	 * just because get_knowledge_base() only falls back to defaults when the
	 * whole option is absent. Inserted right after "handoff" (where it
	 * belongs conceptually — the one exception to that category's rule),
	 * everything else in the saved KB left untouched.
	 */
	private static function maybe_upgrade_existing_booking_rule() {
		if ( get_option( 'fy_support_bot_existing_booking_upgrade_applied' ) ) {
			return;
		}
		$kb = get_option( self::OPT_KB );
		if ( is_array( $kb ) && ! empty( $kb['categories'] ) ) {
			$has_it = false;
			foreach ( $kb['categories'] as $cat ) {
				if ( 'existing_booking' === $cat['key'] ) {
					$has_it = true;
					break;
				}
			}
			if ( ! $has_it ) {
				$defaults = self::default_knowledge_base();
				foreach ( $defaults['categories'] as $default_cat ) {
					if ( 'existing_booking' === $default_cat['key'] ) {
						$new_categories = array();
						foreach ( $kb['categories'] as $cat ) {
							$new_categories[] = $cat;
							if ( 'handoff' === $cat['key'] ) {
								$new_categories[] = $default_cat; // right after handoff, same as a fresh install.
							}
						}
						// If there was no "handoff" category for some reason (heavily edited site), append at the end rather than losing it.
						if ( ! in_array( 'handoff', array_column( $kb['categories'], 'key' ), true ) ) {
							$new_categories[] = $default_cat;
						}
						$kb['categories'] = $new_categories;
						update_option( self::OPT_KB, $kb );
						break;
					}
				}
			}
		}
		update_option( 'fy_support_bot_existing_booking_upgrade_applied', 1 );
	}

	/**
	 * One-time, non-destructive patch for sites that already saved a
	 * knowledge base BEFORE the "ask which city if unknown" rule existed —
	 * updating default_knowledge_base() alone only helps a fresh install,
	 * since get_knowledge_base() only falls back to defaults when the
	 * option is entirely absent. Prepends the rule to the EXISTING saved
	 * qualification text (preserving whatever the user already customized)
	 * rather than resetting it. Guarded so it only ever runs once, and
	 * skips if the marker text is already present for any reason.
	 */
	private static function maybe_upgrade_ask_city_rule() {
		if ( get_option( 'fy_support_bot_ask_city_upgrade_applied' ) ) {
			return;
		}
		$marker = 'Are you looking for a charter in Miami or in Panama?';
		$kb     = get_option( self::OPT_KB );
		if ( is_array( $kb ) && ! empty( $kb['categories'] ) ) {
			foreach ( $kb['categories'] as &$cat ) {
				if ( 'qualification' !== $cat['key'] ) {
					continue;
				}
				if ( false === strpos( (string) $cat['content'], $marker ) ) {
					$prefix         = "FIRST, before any other question: if the guest hasn't said which city they want — Miami or Panama — ask that before anything else. Don't assume, and don't answer general questions (pricing ranges, fleet size, etc.) using the wrong city's info.\n\"$marker\"\nSpanish: \"¿Está buscando un charter en Miami o en Panamá?\"\n\n";
					$cat['content'] = $prefix . $cat['content'];
				}
				break;
			}
			unset( $cat );
			update_option( self::OPT_KB, $kb );
		}
		update_option( 'fy_support_bot_ask_city_upgrade_applied', 1 );
	}

	/* ------------------------------------------------------------------
	 * Default content
	 * ---------------------------------------------------------------- */

	public static function default_settings() {
		return array(
			'webhook_url'      => '',
			'widget_color_1'   => '#E45C9C',
			'widget_color_2'   => '#7C3AED',
			'widget_position'  => 'right',
			'widget_title'     => 'Support Bot',
			'widget_avatar'    => 'S',
		);
	}

	public static function default_knowledge_base() {
		return array(
			'categories' => array(
				array(
					'key'         => 'client_triage',
					'label'       => 'Identify the Client Type (start here)',
					'description' => 'The first thing to figure out, before anything else: which of the four kinds of guest this is. Everything else in the knowledge base is organized around this split.',
					'content'     => "Before anything else, figure out which of these four situations you're in — there's a different playbook for each, further below:\n\n1. NEW CLIENT — hasn't booked with us before, wants to explore or book a charter. → Lead Qualification Questions + Share Fleet Link & Collect Favorites, ending in Handoff / Redirect Rules.\n2. CURRENT CLIENT — already has a reservation booked DIRECTLY with Feeling Yachty and needs help with it (balance, timing, changes, an issue). → Existing Booking — Collect the Details, Hand to the Sales Manager.\n3. THIRD-PARTY CLIENT — booked through an outside platform (Viator, Groupon, GetYourGuide, Expedia, or similar), not directly on our site. → Third-Party Booking (Viator, Groupon, etc.).\n4. ADD-ONS ONLY — not asking about a new charter or an existing one at all, just wants to know about add-ons (catering, decorations, bartender, DJ, jet skis, photography). → Add-Ons Only Request.\n\nHow to tell, usually within the first message or two:\n- \"I want to book a boat\" / \"do you have anything for X people\" / no mention of a past order → New client.\n- \"I already booked\" / gives a confirmation number / asks about THEIR upcoming charter, with no outside platform mentioned → Current client.\n- Names an outside platform (Viator, Groupon, GetYourGuide, Expedia, etc.) or says \"I booked through ___\" → Third-party client.\n- Only ever asks about add-ons and never about booking a charter, new or existing → Add-ons only.\n\nIf it's not clear yet (\"hi, I have a question about my order\"), ask like a person would — \"Hey! What can I help you with?\" — and let the answer tell you which path you're on. If someone says \"I already booked\" but doesn't say where, just ask: \"Was that booked directly with us, or through somewhere like Viator or Groupon?\" — that answer alone tells you Current vs. Third-Party.\n\nA guest can be on more than one path in the same chat — e.g. a current client who also wants to add catering is Current Client PLUS Add-Ons Only for that part. Follow each part's own rules, then hand off once with everything included.",
				),
				array(
					'key'         => 'tone',
					'label'       => 'Tone & Greeting Style',
					'description' => 'How the team actually talks: warm, brief, casual. Used so the bot sounds like the team, not a script.',
					'content'     => "How the team actually opens a chat — pick one, don't use the same one twice in a row:\n\"Hey! Thanks for reaching out 😊 What can I help you with?\"\n\"Hi there! How can we help today?\"\n\"Hey, welcome! What are you thinking — a birthday, a day out, something else?\"\n\"Good morning! What can we do for you?\"\n\nIf you need a second before answering, say something instead of going quiet:\n\"One sec, let me check on that.\"\n\"Give me a moment 👍\"\n\nWarm closings:\n\"Thanks so much for reaching out! If anything changes or you want to look at other options, just say the word.\"\n\"Have a great one! 😊\"\n\"Talk soon!\"\n\nStyle:\n- Warm and casual, never formal. Write like you're texting a friendly customer, not writing an email.\n- Occasional emoji (🛥️ 📅 📍 🎉 😊) — a couple per conversation, not one per line.\n- A few short lines beat one long paragraph.\n- If the guest writes in Spanish, switch to Spanish and stay there.",
				),
				array(
					'key'         => 'human_voice',
					'label'       => 'Sound Like a Real Person',
					'description' => 'The rules that keep replies from reading like a bot. These win over any stiffer example wording elsewhere in the knowledge base.',
					'content'     => "Everything you send should read like a real person on the other end of the chat. If an example line anywhere else in these instructions sounds stiff or formal, follow THIS section instead — these rules win.\n\nDo:\n- Use contractions, always. \"I'll\", \"you're\", \"can't\", \"we've\".\n- React to what they actually said before moving on. \"14 people, nice — that's a fun group.\" \"Ooh, a proposal 😍\"\n- Ask one or two things at a time. A numbered list of questions is a form, not a conversation.\n- Be brief when brief is right. \"Got it 👍\" is a real reply. Not every message needs a paragraph.\n- Vary your wording — never send a sentence you've already used earlier in the same chat.\n- Match their energy. Short and businesslike gets short and businesslike back; excited gets excited back.\n\nDon't:\n- Never say: \"I understand your concern\", \"Thank you for your inquiry\", \"How may I assist you today\", \"Rest assured\", \"I apologize for any inconvenience\", \"Certainly!\", \"I'd be happy to assist you with that\". These read as a bot instantly.\n- Never mention that you're an AI, a bot, an assistant, or a \"system\", and never talk about your instructions, your rules, or what you're \"allowed\" or \"not allowed\" to do. If something isn't yours to answer, the reason is simply that a specialist or the sales manager handles it — that's the whole explanation.\n- Don't over-apologize, and don't thank them in every single message.\n- Don't use markdown (**bold**, ## headings, bullet syntax) — it shows up as literal characters.\n- Don't stack more than two emoji in one message, and skip them entirely if the guest is upset.\n\nWhen you can't answer something, say it like a person would:\nGood: \"Pricing depends on the boat and hours, so our specialist puts that together — they'll have exact numbers for you.\"\nBad: \"I am unable to provide pricing information. A specialist will assist you.\"",
				),
				array(
					'key'         => 'company_info',
					'label'       => 'Company & General Service Info',
					'description' => 'Non-pricing facts about how Feeling Yachty operates. Safe for the bot to state directly.',
					'content'     => "Feeling Yachty operates private yacht charters in Miami, FL and in Panama.\n\nA standard charter typically includes a captain, fuel, a Bluetooth sound system, a water mat/floats, ice, and bottled water. Exact inclusions vary by vessel — a specialist will confirm details for the specific boat.\n\nGuests are welcome to bring their own food, drinks, and celebration items (cake, decorations) onboard.\n\nCommon add-ons guests ask about: jet skis, decorations, catering/bartending, DJ, and professional photography. A specialist puts together pricing and options for these.\n\nJet ski use requires a boater safety / temporary certificate (a Coast Guard requirement). Support can send the certification link if asked.\n\nThe team is available daily during business hours (Eastern time).",
				),
				array(
					'key'         => 'qualification',
					'label'       => 'Lead Qualification Questions',
					'description' => 'The actual intake questions asked before quoting. This is the bot\'s main job — collect these, then hand off.',
					'content'     => "FIRST, before any other question: if the guest hasn't said which city they want — Miami or Panama — ask that before anything else. Don't assume, and don't answer general questions (pricing ranges, fleet size, etc.) using the wrong city's info.\n\"Are you looking for a charter in Miami or in Panama?\"\nSpanish: \"¿Está buscando un charter en Miami o en Panamá?\"\n\nOnce the city is known (either they said it, or they already asked about a specific one), gather:\n- Preferred date\n- Preferred time / how many hours\n- Number of guests\n- Occasion (birthday, corporate event, wedding, casual day out, etc.)\n- Which yachts caught their eye on the fleet page (see \"Share Fleet Link & Collect Favorites\")\n- Preferred departure area/marina, if any\n- Approximate budget (optional, but helpful for the specialist)\n- Any additional services of interest: decorations, catering, bartender, DJ, jet skis, transportation\n\nAsk one or two of these at a time, woven into the conversation — never paste the list. If they've already told you something, don't ask again.\n\nWhen you have the basics, get their contact info like a person would:\n\"Perfect — what's the best name, email, and phone to reach you at? I'll get this over to our specialist.\"\n\"Last thing and I'll let you go — name, email, and a good number for you?\"\n\nThen read it back once, casually:\n\"Got it — Ana Diaz, ana@example.com, 786-555-0199. That right?\"\n\nSpanish:\n\"¡Perfecto! ¿Me pasa su nombre, correo y un número para contactarle? Se lo envío a nuestro especialista.\"\n\"Listo — Ana Díaz, ana@example.com, 786-555-0199. ¿Está correcto?\"",
				),
				array(
					'key'         => 'share_options',
					'label'       => 'Share Fleet Link & Collect Favorites',
					'description' => 'The step between qualifying and handing off: send the guest their city\'s fleet page, then ask which boats caught their eye and pass those names to the specialist.',
					'content'     => "SEND THE LINK EARLY — this is a standing instruction, not an option.\n\nThe moment the city is settled (they named it, or they're already on that city's page), include that city's browse link in that same reply or the very next one. Don't wait for them to ask, don't wait until you've collected the date, guest count, or anything else, and don't wait for a natural-sounding moment. Send it, then carry on asking your questions in the same message.\n\nThe only reason to skip it: they've already named boats they like, or you've already sent it in this conversation — send it once, not every message.\n\nThe exact URL for each city is listed further below, in that city's Fleet section. Only ever send the link for the city they asked about, never the other one, and never invent a URL that isn't listed there.\n\nHow to send it (paste the URL as-is, on its own — it becomes a clickable link):\n\"Here's our full Miami fleet — have a look and tell me which ones catch your eye 👀\"\n\"Take a look while I'm here: <link> — if any stand out, just send me the names and I'll pass them to the specialist.\"\nSpanish: \"Aquí puede ver toda nuestra flota: <link> — dígame cuáles le gustan y se los paso al especialista.\"\n\nMention the filters, briefly, in that same message or the very next one — don't make it its own message: the fleet page has filters, including ones for our pink yacht rentals and our free-hour promotions, and it's worth pointing those out:\n\"You can also filter on that page for our pink yachts or the free-hour deals, if either of those sound fun.\"\n\nIf they like something they found through one of those filters (a pink yacht or a free-hour listing), the way to qualify for it is simple — following on Instagram, nothing more:\n\"If one of those catches your eye, all you have to do to qualify is follow us on Instagram — that's it! We're @feeling.yachty: https://www.instagram.com/feeling.yachty/\"\nAlways send the actual link (not just the handle) so it's clickable, and only bring this up once it's actually relevant — they mentioned a pink yacht, a free-hour deal, or asked what a badge/filter on the page means. Don't lead with it.\n\nSending the link is only half the step — ALWAYS ask them to send picks back:\n\"Any of them stand out? Send me one or two names (or paste the links) and I'll make sure the specialist includes them.\"\n\nWhen the guest replies with yacht names, links, or descriptions:\n- Repeat the names back so they know they were captured: \"Perfect — noted the [name] and the [name].\"\n- Repeating a name the GUEST gave you is allowed. That is not the same as recommending one. Do not add boats they didn't mention, do not say whether their pick is available, and do not quote a price for it — the specialist confirms both.\n- If they can't decide or ask you to pick for them, don't pick. Say the specialist will send the best matches for their date and party size.\n- Ask once. If they don't send picks, that's fine — carry on and hand off with whatever you have.\n\nIf a guest arrives already talking about a boat they saw on the site, treat that as their pick — note it and keep going with the remaining questions.\n\nTheir picks go in the handoff summary, every time.",
				),
				array(
					'key'         => 'policies',
					'label'       => 'General Policies (no dollar amounts)',
					'description' => 'Common policy questions the bot can answer directly, stated generally. Exact figures always come from a specialist.',
					'content'     => "Deposits: A deposit is required to reserve a specific date and time. Once paid, it is non-refundable, because that time slot is held exclusively and other bookings are turned away for it. The exact deposit amount depends on the vessel/package — a specialist will confirm.\n\nWeather cancellations: A charter is only cancelled for weather if the U.S. Coast Guard issues a Small Craft Advisory, or the captain determines conditions are unsafe. Rain in the forecast alone does not cancel a charter.\n\nVoluntary cancellations: If a guest cancels for a reason other than official weather cancellation, the deposit remains non-refundable per policy.\n\nHoliday / peak dates (e.g. New Year's Eve): These carry special event pricing different from standard rates — a specialist will confirm current rates.\n\nRescheduling: If a guest needs to cancel, offer to explore rescheduling to a different date instead.",
				),
				array(
					'key'         => 'handoff',
					'label'       => 'Handoff / Redirect Rules',
					'description' => 'The core behavior rule: what the bot must NEVER do, and exactly how it hands off. This is what keeps it from selling.',
					'content'     => "This applies to anyone WITHOUT a confirmed booking yet — a new or prospective guest. (Someone who ALREADY booked is a different conversation — see the \"Existing Booking\" rules. The restrictions below still apply to them, plus more.)\n\nFor a new/prospective guest, never do any of the following, even if asked directly:\n- Quote a price or dollar amount for any specific NEW charter, add-on, or service.\n- Name, describe, or recommend one specific boat/yacht by name.\n- Claim to check or confirm live availability.\n- Discuss payment methods, deposit amounts, or take/request payment info.\n- Attempt to finalize, confirm, or modify a booking.\n\nWhat IS allowed, and should be done:\n- Sending the guest their city's fleet page link so they can see every boat themselves — see \"Share Fleet Link & Collect Favorites\".\n- Repeating back the name of a yacht the GUEST picked off that page, so the specialist knows what they liked. Echoing their own choice is not recommending one.\n- General fleet facts (yacht counts, size ranges, capacity ranges, starting-price RANGES) — those are not a quote for a specific charter.\n\nBefore handing off: if the city is known and you haven't sent the fleet link yet, send it and ask for their picks first. A handoff that includes the boats they liked is worth far more to the specialist than one without.\n\nWhen a guest asks for anything on the never-list, or once you've got enough to work with, hand off — warmly, like a person passing a friend along to a colleague:\n\"Perfect, I've got everything I need! Sending this over to our specialist now — they'll come back with options and exact pricing for your date.\"\n\"Alright, you're all set on my end 😊 Our specialist will take it from here and follow up shortly.\"\nIf they sent picks, name them back in that message: \"...and I'll make sure they include the [name] you liked.\"\n\nAdd-ons Mention at Handoff: right after that message, if an add-ons page link exists for this city (see that city's Fleet section further below), toss it in as a casual afterthought — not a new question, not something you're waiting on an answer to:\n\"Oh, and if you're also into add-ons — catering, decorations, that kind of thing — you can ask the sales manager about those too. Here's everything we offer if you want to take a look: <link>\"\nSend it once per conversation, only if that city has a link listed, and only in or right after the handoff message — never earlier, and never as a second link in the same breath as the fleet browse link.\n\nThen pass along a summary of everything collected — city, date, time/hours, party size, occasion, YACHTS THEY LIKED, add-ons of interest, contact info — so the specialist doesn't have to ask again.",
				),
				array(
					'key'         => 'existing_booking',
					'label'       => 'Existing Booking — Collect the Details, Hand to the Sales Manager',
					'description' => 'A guest who already reserved. Get their booking number and the name/email/phone on the reservation, then pass it to the sales manager. The bot has no access to the booking system and never confirms, quotes, or changes anything on an existing charter.',
					'content'     => "This is someone who ALREADY has a reservation booked DIRECTLY with Feeling Yachty — a past order or an upcoming one — not a new prospect, and not someone who booked through Viator, Groupon, or another outside platform (that's the \"Third-Party Booking\" category instead — if they mention one of those, go there, not here). You can tell: they say \"I already booked,\" give a confirmation number, or ask about THEIR charter (\"what do I still owe,\" \"what time do we leave,\" \"can I bring two more people\"), with no outside platform named.\n\nIf they haven't said yet what they actually need, open with a normal, friendly \"how can I help\" — same as you would anyone else — rather than jumping straight to collecting their booking number:\n\"Hey, welcome back! What can I help you with?\"\n\"Of course — what's going on with your booking?\"\nOnce you know what they need, move into collecting the details below. Your job here is ONLY to qualify — find out who they are and what they need — never to resolve it yourself.\n\nYOU CANNOT SEE BOOKINGS. There is no lookup on your end. So you never state, confirm, or even estimate anything about an existing reservation — not the balance, not the dock fee, not the departure time, not the marina, not the yacht, not whether a change is possible. Not if they insist, and not if they tell you what they think the answer is and ask you to confirm it. A wrong number on a real booking is far worse than no number.\n\nWhat you DO: get what the sales manager needs to pull it up, and get them over there fast.\n1. Booking / confirmation number.\n2. Name on the reservation.\n3. Email or phone they booked with.\n4. What they actually need, in their own words (\"wants to add 2 guests\", \"asking about the balance\", \"needs to move the date\").\n\nAsk for it in ONE short flowing sentence — never a numbered list, never bullets. \"Can you send me the booking number and the name and email it's under?\" is how a person asks. A 1/2/3 checklist is a form, and it reads like one.\n\nDon't interrogate either — two or three of those four is plenty, the manager can find it from there. If they've already given you a piece, don't ask for it again.\n\nThen hand off warmly and specifically, naming what you captured back to them so they know it landed:\n\"Perfect — got it. Booking 48213 under Ana Diaz. Our sales manager handles everything on existing reservations, so I'm sending this straight over and they'll get back to you shortly about that balance 😊\"\n\"Got it, thank you! Passing your booking number and details to our sales manager now — they'll follow up with you shortly.\"\n\"No problem — the name and email you booked under is plenty for them to find it.\"\n\nIf they push for the answer right now:\n\"I wish I could pull it up myself, but I don't have the reservation system on my end — our sales manager does, and they'll have the exact number for you. Sending it over now so they can get right back to you.\"\n\nIf it's urgent — the charter is today, they're at the dock, something's gone wrong — say so, and get a phone number, because chat is the slow way to reach someone standing on a dock:\n\"That's today — what's the best number to reach you right now? I'm marking this urgent so someone calls you straight away.\"\nDon't promise a specific response time (\"within 5 minutes\", \"they'll call you in the next hour\") — you don't control that. \"Right away\" and \"as fast as we can\" are honest; a clock is not.\n\nSpanish:\n\"¡Perfecto! Ya tengo su número de reserva y sus datos. Nuestro gerente de ventas se encarga de las reservas existentes y se comunicará con usted en breve 😊\"\n\"Ojalá pudiera revisarlo yo mismo, pero no tengo acceso al sistema de reservas. Nuestro gerente de ventas sí lo tiene y le dará la cifra exacta — ya se lo estoy enviando.\"",
				),
				array(
					'key'         => 'third_party_booking',
					'label'       => 'Third-Party Booking (Viator, Groupon, etc.)',
					'description' => 'A guest who booked through an outside platform rather than directly with us. Same no-lookup, collect-and-handoff approach as Existing Booking, but flagged with which platform so the sales manager checks the right place.',
					'content'     => "Same core rule as Existing Booking: YOU CANNOT SEE THIRD-PARTY BOOKINGS EITHER. Nothing about their reservation — balance, time, what's included in the package they bought — is something you state, confirm, or guess at.\n\nHow to recognize it: they name the platform (Viator, Groupon, GetYourGuide, Expedia, Klook, or similar), or say something like \"I booked through Viator\" / \"I have a Groupon for this.\" If they say \"I already booked\" without naming a platform, just ask, casually: \"Was that booked directly with us, or through somewhere like Viator or Groupon?\" — that answer tells you whether this is Existing Booking or this category.\n\nWhat you collect, asked in one natural sentence, not a checklist:\n- Which platform (Viator, Groupon, etc.)\n- Their order/confirmation/voucher number from THAT platform — these look different from our own booking numbers, so don't assume the format\n- Name and email/phone\n\"No problem — which platform did you book through, and what's the order or voucher number on it?\"\n\nThen hand off the same warm way:\n\"Got it — Viator order 4471829 under Marcus Lee. Our sales manager handles these too, so I'm sending it over now and they'll get back to you shortly.\"\n\nOne honest thing worth knowing, only mention it if it's actually relevant to what they're asking: some things on a third-party booking — cancellations, refunds, exactly what was included in the deal — may ultimately be that platform's call, not just ours. If it comes up, say so plainly rather than promising something we may not control:\n\"Since that one went through Viator, some of that may need to go through them too — but let me get our sales manager on it and they'll tell you exactly what's possible.\"\nDon't lead with this caveat unprompted — only when it's actually relevant.\n\nSpanish: \"¿Reservó directamente con nosotros o a través de una plataforma como Viator o Groupon?\"",
				),
				array(
					'key'         => 'addons_only',
					'label'       => 'Add-Ons Only Request',
					'description' => 'A guest who isn\'t asking about booking a charter at all — new or existing — just wants to know about add-ons like catering, decorations, or a bartender. Send the add-ons page right away and let the sales manager take it from there.',
					'content'     => "This is someone whose whole ask is about add-ons — catering, decorations, a bartender, a DJ, jet skis, photography — not about booking a charter, new or existing. Could be a standalone question (\"do you guys do catering?\") or tacked onto something else already covered elsewhere in the chat.\n\nWhat to do:\n1. Confirm briefly what they're looking for, in normal conversation, not a checklist.\n2. If it's relevant, ask whether this is for a charter they already have booked with us — so the specialist can tie it to the right reservation — but don't turn this into a full requalification if they don't offer it.\n3. Send the add-ons/services page for their city right away — this is the main thing to send here, not an afterthought. The URL is listed in that city's Fleet section further below. If no add-ons page is listed for that database, skip the link and just say the sales manager will send options directly.\n\"We've got a bunch of options — here's everything we offer so you can take a look: <link>\"\n4. Get their name and email/phone so the sales manager can follow up.\n5. Hand off warmly: \"Perfect, sending this to our sales manager now — they'll help you put together exactly what you want.\"\n\nDon't quote a price for any add-on yourself — same rule as everywhere else, the sales manager confirms those.\n\nSpanish: \"Aquí puede ver todos nuestros extras: <link> — le paso sus datos a nuestro gerente de ventas para que lo ayude con los detalles.\"",
				),
				array(
					'key'         => 'complaints',
					'label'       => 'Complaints & Disputes (general stance)',
					'description' => 'How to handle an upset customer without negotiating or promising anything — stays calm, restates policy, hands off.',
					'content'     => "Acknowledge how they feel first, in plain words, before anything else. Drop the emoji entirely here.\n\nIf it's a refund/deposit dispute, state the general policy once (deposits are non-refundable once received, per the invoice/confirmation) — no invented exceptions, no dollar figures.\n\nNever negotiate, promise a refund, or make an exception. Anything past restating the policy goes to a specialist.\n\nSay it like this:\n\"I'm really sorry — I get why you're frustrated, and I don't blame you. Deposits are non-refundable once they're paid, which is on the invoice, but I don't want to leave it there. Let me get one of our specialists on this so they can look at your situation directly and talk through options with you.\"\n\"That's not the experience we want anyone to have. I'm sorry. Let me get this in front of a specialist who can actually dig into it for you.\"\n\nWhat NOT to say here: \"I understand your concern.\" \"I apologize for any inconvenience.\" \"Rest assured.\" An upset person can spot a script immediately, and it makes it worse.",
				),
				array(
					'key'         => 'learned_corrections',
					'label'       => 'Learned Corrections',
					'description' => 'Notes added while testing — "here\'s how it should have answered that." Appended live, used on the very next message.',
					'content'     => '',
				),
			),
			'excluded'   => array(
				'label'       => 'Excluded From This Bot (reference only — not sent to the AI)',
				'description' => 'This bot does not sell, quote a specific charter, or book. Shown here so you know what was deliberately left out and why.',
				'reasons'     => array(
					'Specific pricing and dollar-amount quotes for a particular charter or add-on',
					'A named yacht recommended or described for a specific guest',
					'Payment methods and instructions (Zelle, Cash App, Venmo, credit card links)',
					'Specific deposit dollar amounts',
					'Live availability answers ("yes it\'s available at 4pm")',
					'Booking confirmations, marina addresses, captain contact details',
					'Catering/decoration/menu upsell negotiations',
					'Any real customer personal information (names, emails, phone numbers, addresses)',
				),
			),
		);
	}

	/**
	 * Starter FAQ set — genuinely common non-pricing questions, drawn from
	 * this same knowledge base's own policy/company-info content (not
	 * invented, not sourced from any external chat history). The user adds
	 * and removes entries freely from the FAQ tab; this is just a sane
	 * starting point so the tab isn't empty on first use.
	 */
	public static function default_faqs() {
		return array(
			array( 'id' => 'faq-1', 'q' => 'What\'s included in a standard charter?', 'a' => 'You get a captain, fuel, Bluetooth sound system, a water mat and floats, ice, and bottled water. It varies a little boat to boat — our specialist can tell you exactly what comes with the one you like.' ),
			array( 'id' => 'faq-2', 'q' => 'Can we bring our own food and drinks?', 'a' => 'Absolutely! Bring whatever you want — food, drinks, a cake, decorations. It\'s your day.' ),
			array( 'id' => 'faq-3', 'q' => 'What add-ons can we book?', 'a' => 'Jet skis, decorations, catering, a bartender, a DJ, and photo/video are the popular ones. Tell us what you\'re interested in and our specialist will put pricing together for you.' ),
			array( 'id' => 'faq-4', 'q' => 'Do I need a license to ride the jet ski?', 'a' => 'You\'ll need a boater safety certificate — it\'s a Coast Guard rule, not ours. It\'s quick to get online, and we can send you the link.' ),
			array( 'id' => 'faq-5', 'q' => 'What happens if the weather is bad on our date?', 'a' => 'Rain in the forecast doesn\'t cancel anything. A charter only gets cancelled if the Coast Guard issues a Small Craft Advisory or the captain says conditions aren\'t safe.' ),
			array( 'id' => 'faq-6', 'q' => 'Is the deposit refundable?', 'a' => 'Once it\'s paid, no — that slot is held just for you and we turn away other bookings for it. But if your plans change, talk to us about moving to another date instead.' ),
			array( 'id' => 'faq-7', 'q' => 'Can I reschedule instead of cancelling?', 'a' => 'Yes, and that\'s usually the better move. Just let us know and we\'ll help you find a new date.' ),
			array( 'id' => 'faq-8', 'q' => 'Do you operate in both Miami and Panama?', 'a' => 'We do! Private charters in both Miami and Panama. Which one are you looking at?' ),
			array( 'id' => 'faq-9', 'q' => 'How far in advance should I book?', 'a' => 'Sooner is better, especially for weekends and holidays — the good dates go fast. That said, we can still check shorter notice, so it never hurts to ask.' ),
			array( 'id' => 'faq-10', 'q' => 'Are holiday dates priced differently?', 'a' => 'Yes — dates like New Year\'s Eve run on special event pricing. Our specialist will give you the exact rate for your date.' ),
			array( 'id' => 'faq-11', 'q' => 'How do I get exact pricing for my date?', 'a' => 'Send over your date, how many hours you want, and how many people — our specialist takes it from there and comes back with real numbers and options.' ),
		);
	}

	public static function get_faqs() {
		$faqs = get_option( self::OPT_FAQS, false );
		if ( false === $faqs || ! is_array( $faqs ) ) {
			$faqs = self::default_faqs();
			update_option( self::OPT_FAQS, $faqs );
		}
		return $faqs;
	}

	/**
	 * Fleet page the bot sends guests to for a region. These are the live
	 * public page paths (both plural) — deliberately NOT region_term_slug(),
	 * whose Miami value is the singular taxonomy slug and would 404 as a URL.
	 * Editable per database in the admin for exactly that reason.
	 */
	public static function default_browse_url( $type ) {
		if ( 'miami' === $type ) {
			return home_url( '/miami-yacht-rentals' );
		}
		if ( 'panama' === $type ) {
			return home_url( '/panama-yacht-rentals' );
		}
		return '';
	}

	/**
	 * Add-ons page (catering, decorations, jet skis, etc.) mentioned once at
	 * handoff. Only a Miami page exists today — Panama's blank by default,
	 * editable per database in the admin whenever one exists for that city.
	 */
	public static function default_addons_url( $type ) {
		if ( 'miami' === $type ) {
			return home_url( '/miami-yacht-services' );
		}
		return '';
	}

	public static function default_databases() {
		return array(
			array(
				'id'         => 'miami',
				'name'       => 'Miami',
				'type'       => 'miami',
				'enabled'    => true,
				'browse_url' => self::default_browse_url( 'miami' ),
				'addons_url' => self::default_addons_url( 'miami' ),
				'notes'      => '',
			),
			array(
				'id'         => 'panama',
				'name'       => 'Panama',
				'type'       => 'panama',
				'enabled'    => true,
				'browse_url' => self::default_browse_url( 'panama' ),
				'addons_url' => self::default_addons_url( 'panama' ),
				'notes'      => '',
			),
		);
	}

	public static function get_settings() {
		return wp_parse_args( get_option( self::OPT_SETTINGS, array() ), self::default_settings() );
	}

	public static function get_knowledge_base() {
		return get_option( self::OPT_KB, self::default_knowledge_base() );
	}

	public static function get_databases() {
		$dbs = get_option( self::OPT_DATABASES, false );
		if ( false === $dbs || ! is_array( $dbs ) || empty( $dbs ) ) {
			$dbs = self::default_databases();
			update_option( self::OPT_DATABASES, $dbs );
		}
		return $dbs;
	}

	/* ------------------------------------------------------------------
	 * Live database compiler
	 * ---------------------------------------------------------------- */

	/** fy_yacht_cat term slug for a region type, matching the convention used sitewide (see FY_Fleet_Demo_Seed::region_yachts()). */
	private static function region_term_slug( $type ) {
		return 'panama' === $type ? 'panama-yacht-rentals' : 'miami-yacht-rental';
	}

	/**
	 * Live aggregate fleet facts for one region — count, size range, guest
	 * capacity range, starting-price range. Aggregate only: never a specific
	 * yacht name or an exact per-boat price, consistent with the bot's
	 * handoff rule. Cached 15 minutes since this is recomputed on demand,
	 * not on every page load.
	 */
	public static function compile_fleet_summary( $type ) {
		$cache_key = 'fy_sb_fleet_' . $type;
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		$slug = self::region_term_slug( $type );
		$ids  = get_posts(
			array(
				'post_type'      => class_exists( 'FY_Fleet_CPT' ) ? FY_Fleet_CPT::POST_TYPE : 'fy_yacht',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					array( 'taxonomy' => 'fy_yacht_cat', 'field' => 'slug', 'terms' => $slug ),
				),
			)
		);

		if ( ! $ids ) {
			$summary = sprintf( "No published yachts found for %s yet.", ucfirst( $type ) );
			set_transient( $cache_key, $summary, 15 * MINUTE_IN_SECONDS );
			return $summary;
		}

		$sizes  = array();
		$caps   = array();
		$prices = array();
		foreach ( $ids as $id ) {
			$size = (float) get_post_meta( $id, '_fy_size_ft', true );
			if ( $size > 0 ) {
				$sizes[] = $size;
			}
			$cap = (int) get_post_meta( $id, '_fy_capacity_max', true );
			if ( $cap > 0 ) {
				$caps[] = $cap;
			}
			if ( class_exists( 'FY_Fleet_Pricing' ) ) {
				$from = FY_Fleet_Pricing::display_from_price( $id );
				if ( $from && ! empty( $from['amount'] ) ) {
					$prices[] = (float) $from['amount'];
				}
			}
		}

		$lines   = array();
		$lines[] = sprintf( '%d published yachts.', count( $ids ) );
		if ( $sizes ) {
			$lines[] = sprintf( 'Sizes range from %sft to %sft.', number_format( min( $sizes ) ), number_format( max( $sizes ) ) );
		}
		if ( $caps ) {
			$lines[] = sprintf( 'Guest capacity ranges from %d to %d guests.', min( $caps ), max( $caps ) );
		}
		if ( $prices ) {
			$lines[] = sprintf( 'Starting prices across the fleet range from $%s to $%s (per charter, exact figure confirmed by a specialist).', number_format( min( $prices ) ), number_format( max( $prices ) ) );
		}
		$summary = implode( ' ', $lines );

		set_transient( $cache_key, $summary, 15 * MINUTE_IN_SECONDS );
		return $summary;
	}

	/** One database's compiled contribution: live summary (if it's a recognized type) plus its own free-text notes. */
	public static function compile_database( $db ) {
		$parts = array();
		if ( in_array( $db['type'], array( 'miami', 'panama' ), true ) ) {
			$parts[] = self::compile_fleet_summary( $db['type'] );
		}
		if ( ! empty( $db['browse_url'] ) ) {
			$parts[] = sprintf( 'Browse-the-fleet link for %s — send THIS exact URL when the guest wants to see the boats, and no other: %s', $db['name'], $db['browse_url'] );
		}
		if ( ! empty( $db['addons_url'] ) ) {
			$parts[] = sprintf( 'Add-ons page for %s — used by the "Add-ons Mention at Handoff" rule and the "Add-Ons Only Request" category: %s', $db['name'], $db['addons_url'] );
		}
		if ( ! empty( $db['notes'] ) && '' !== trim( (string) $db['notes'] ) ) {
			$parts[] = trim( (string) $db['notes'] );
		}
		return implode( "\n", $parts );
	}

	/**
	 * The full text sent to n8n as `knowledgeBase`: the 7 behavioral
	 * categories, then one "## <Database Name>" section per enabled
	 * database matching $region (or every enabled database when $region is
	 * '' / unrecognized — e.g. the chat started from a non-region page).
	 */
	public static function compiled_knowledge_base( $region = '' ) {
		$kb    = self::get_knowledge_base();
		$parts = array();
		foreach ( $kb['categories'] as $cat ) {
			if ( '' === trim( (string) $cat['content'] ) ) {
				continue;
			}
			$parts[] = '## ' . $cat['label'] . "\n" . $cat['content'];
		}

		foreach ( self::get_databases() as $db ) {
			if ( empty( $db['enabled'] ) ) {
				continue;
			}
			if ( '' !== $region && $db['type'] !== $region ) {
				continue; // a specific region matched — only its own database(s) apply.
			}
			$compiled = self::compile_database( $db );
			if ( '' !== trim( $compiled ) ) {
				$parts[] = '## ' . $db['name'] . " Fleet\n" . $compiled;
			}
		}

		$faqs = self::get_faqs();
		if ( $faqs ) {
			$lines = array();
			foreach ( $faqs as $faq ) {
				if ( '' === trim( (string) $faq['q'] ) ) {
					continue;
				}
				$lines[] = 'Q: ' . $faq['q'] . "\nA: " . $faq['a'];
			}
			if ( $lines ) {
				$parts[] = "## Frequently Asked Questions\nAnswer directly from these when they match — they're pre-approved, no need to hand off just because a guest asked one of them.\n\n" . implode( "\n\n", $lines );
			}
		}

		return implode( "\n\n", $parts );
	}

	/* ------------------------------------------------------------------
	 * Region detection
	 * ---------------------------------------------------------------- */

	/** Word-boundary match against the keyword list — 'fl' alone can't false-positive inside an unrelated word. */
	private static function text_contains_any( $text, array $keywords ) {
		$text = mb_strtolower( (string) $text );
		foreach ( $keywords as $kw ) {
			if ( preg_match( '/\b' . preg_quote( mb_strtolower( $kw ), '/' ) . '\b/u', $text ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Resolve which region's database(s) should answer this message.
	 * Precedence: what the visitor actually typed beats what page they're
	 * on — someone asking about Panama from a generic page should still get
	 * Panama data. Falls back to the page-URL hint, then '' (every enabled
	 * database) rather than guessing wrong.
	 */
	public static function detect_region( $message, $url_hint = '' ) {
		$has_panama = self::text_contains_any( $message, self::PANAMA_KEYWORDS );
		$has_miami  = self::text_contains_any( $message, self::MIAMI_KEYWORDS );

		// Both cities named ("looking at both Miami and Panama options") —
		// picking one silently would drop the other's fleet data from what
		// the bot knows. '' means "every enabled database", which is the
		// correct behavior here, not just the fallback-when-unknown case.
		if ( $has_panama && $has_miami ) {
			return '';
		}
		if ( $has_panama ) {
			return 'panama';
		}
		if ( $has_miami ) {
			return 'miami';
		}
		if ( in_array( $url_hint, array( 'miami', 'panama' ), true ) ) {
			return $url_hint;
		}
		return '';
	}

	/* ------------------------------------------------------------------
	 * Admin page
	 * ---------------------------------------------------------------- */

	public static function add_menu() {
		add_submenu_page(
			'edit.php?post_type=' . ( class_exists( 'FY_Fleet_CPT' ) ? FY_Fleet_CPT::POST_TYPE : 'fy_yacht' ),
			__( 'Support Bot', 'fy-fleet' ),
			__( '🤖 Support Bot', 'fy-fleet' ),
			'manage_options',
			'fy-support-bot',
			array( __CLASS__, 'render_page' )
		);
	}

	public static function enqueue_assets( $hook ) {
		if ( false === strpos( (string) $hook, 'fy-support-bot' ) ) {
			return;
		}
		wp_enqueue_style( 'fy-support-bot', FY_FLEET_URL . 'assets/support-bot.css', array(), FY_FLEET_VERSION );
		wp_enqueue_script( 'fy-support-bot', FY_FLEET_URL . 'assets/support-bot.js', array(), FY_FLEET_VERSION, true );
		wp_localize_script(
			'fy-support-bot',
			'FYSupportBot',
			array(
				'restUrl' => esc_url_raw( rest_url( 'fy-support-bot/v1' ) ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
			)
		);
	}

	private static function current_tab() {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'connection'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! in_array( $tab, array( 'connection', 'knowledge', 'databases', 'faq', 'test', 'embed' ), true ) ) {
			$tab = 'connection';
		}
		return $tab;
	}

	public static function handle_saves() {
		if ( ! isset( $_POST['fysb_action'] ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( 'save_connection' === $_POST['fysb_action'] ) {
			check_admin_referer( 'fy_sb_save_connection' );
			$settings                = self::get_settings();
			$settings['webhook_url'] = isset( $_POST['webhook_url'] ) ? esc_url_raw( trim( wp_unslash( $_POST['webhook_url'] ) ) ) : '';
			update_option( self::OPT_SETTINGS, $settings );
			wp_safe_redirect( add_query_arg( array( 'page' => 'fy-support-bot', 'tab' => 'connection', 'saved' => '1' ), admin_url( 'edit.php?post_type=fy_yacht' ) ) );
			exit;
		}

		if ( 'save_knowledge' === $_POST['fysb_action'] ) {
			check_admin_referer( 'fy_sb_save_knowledge' );
			$kb     = self::get_knowledge_base();
			$posted = isset( $_POST['kb'] ) ? wp_unslash( $_POST['kb'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			foreach ( $kb['categories'] as &$cat ) {
				if ( isset( $posted[ $cat['key'] ] ) ) {
					$cat['content'] = sanitize_textarea_field( $posted[ $cat['key'] ] );
				}
			}
			unset( $cat );
			update_option( self::OPT_KB, $kb );
			wp_safe_redirect( add_query_arg( array( 'page' => 'fy-support-bot', 'tab' => 'knowledge', 'saved' => '1' ), admin_url( 'edit.php?post_type=fy_yacht' ) ) );
			exit;
		}

		if ( 'reset_knowledge' === $_POST['fysb_action'] ) {
			check_admin_referer( 'fy_sb_reset_knowledge' );
			update_option( self::OPT_KB, self::default_knowledge_base() );
			wp_safe_redirect( add_query_arg( array( 'page' => 'fy-support-bot', 'tab' => 'knowledge', 'reset' => '1' ), admin_url( 'edit.php?post_type=fy_yacht' ) ) );
			exit;
		}

		if ( 'save_databases' === $_POST['fysb_action'] ) {
			check_admin_referer( 'fy_sb_save_databases' );
			$dbs      = self::get_databases();
			$posted   = isset( $_POST['db'] ) ? wp_unslash( $_POST['db'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			foreach ( $dbs as &$db ) {
				if ( isset( $posted[ $db['id'] ] ) ) {
					$db['enabled']    = ! empty( $posted[ $db['id'] ]['enabled'] );
					$db['notes']      = isset( $posted[ $db['id'] ]['notes'] ) ? sanitize_textarea_field( $posted[ $db['id'] ]['notes'] ) : '';
					$db['name']       = isset( $posted[ $db['id'] ]['name'] ) ? sanitize_text_field( $posted[ $db['id'] ]['name'] ) : $db['name'];
					$db['browse_url'] = isset( $posted[ $db['id'] ]['browse_url'] ) ? esc_url_raw( trim( $posted[ $db['id'] ]['browse_url'] ) ) : '';
				$db['addons_url'] = isset( $posted[ $db['id'] ]['addons_url'] ) ? esc_url_raw( trim( $posted[ $db['id'] ]['addons_url'] ) ) : '';
				}
			}
			unset( $db );
			update_option( self::OPT_DATABASES, $dbs );
			// The live summaries shown depend on this save (a renamed
			// database is cosmetic, but clearing the cache is cheap and
			// keeps the Databases tab preview from ever looking stale).
			foreach ( $dbs as $db ) {
				delete_transient( 'fy_sb_fleet_' . $db['type'] );
			}
			wp_safe_redirect( add_query_arg( array( 'page' => 'fy-support-bot', 'tab' => 'databases', 'saved' => '1' ), admin_url( 'edit.php?post_type=fy_yacht' ) ) );
			exit;
		}

		if ( 'add_database' === $_POST['fysb_action'] ) {
			check_admin_referer( 'fy_sb_add_database' );
			$name = isset( $_POST['new_db_name'] ) ? sanitize_text_field( wp_unslash( $_POST['new_db_name'] ) ) : '';
			if ( '' !== $name ) {
				$dbs   = self::get_databases();
				$dbs[] = array(
					'id'         => 'custom-' . substr( md5( $name . microtime() ), 0, 8 ),
					'name'       => $name,
					'type'       => 'custom',
					'enabled'    => true,
					'browse_url' => '',
					'addons_url' => '',
					'notes'      => '',
				);
				update_option( self::OPT_DATABASES, $dbs );
			}
			wp_safe_redirect( add_query_arg( array( 'page' => 'fy-support-bot', 'tab' => 'databases', 'added' => '1' ), admin_url( 'edit.php?post_type=fy_yacht' ) ) );
			exit;
		}

		if ( 'remove_database' === $_POST['fysb_action'] ) {
			check_admin_referer( 'fy_sb_remove_database' );
			$id  = isset( $_POST['db_id'] ) ? sanitize_key( wp_unslash( $_POST['db_id'] ) ) : '';
			$dbs = array_values( array_filter( self::get_databases(), function ( $db ) use ( $id ) {
				return $db['id'] !== $id;
			} ) );
			update_option( self::OPT_DATABASES, $dbs );
			wp_safe_redirect( add_query_arg( array( 'page' => 'fy-support-bot', 'tab' => 'databases', 'removed' => '1' ), admin_url( 'edit.php?post_type=fy_yacht' ) ) );
			exit;
		}

		if ( 'save_faqs' === $_POST['fysb_action'] ) {
			check_admin_referer( 'fy_sb_save_faqs' );
			$faqs   = self::get_faqs();
			$posted = isset( $_POST['faq'] ) ? wp_unslash( $_POST['faq'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			foreach ( $faqs as &$faq ) {
				if ( isset( $posted[ $faq['id'] ] ) ) {
					$faq['q'] = sanitize_text_field( $posted[ $faq['id'] ]['q'] ?? '' );
					$faq['a'] = sanitize_textarea_field( $posted[ $faq['id'] ]['a'] ?? '' );
				}
			}
			unset( $faq );
			update_option( self::OPT_FAQS, $faqs );
			wp_safe_redirect( add_query_arg( array( 'page' => 'fy-support-bot', 'tab' => 'faq', 'saved' => '1' ), admin_url( 'edit.php?post_type=fy_yacht' ) ) );
			exit;
		}

		if ( 'add_faq' === $_POST['fysb_action'] ) {
			check_admin_referer( 'fy_sb_add_faq' );
			$q = isset( $_POST['new_faq_q'] ) ? sanitize_text_field( wp_unslash( $_POST['new_faq_q'] ) ) : '';
			$a = isset( $_POST['new_faq_a'] ) ? sanitize_textarea_field( wp_unslash( $_POST['new_faq_a'] ) ) : '';
			if ( '' !== $q && '' !== $a ) {
				$faqs   = self::get_faqs();
				$faqs[] = array( 'id' => 'faq-' . substr( md5( $q . microtime() ), 0, 8 ), 'q' => $q, 'a' => $a );
				update_option( self::OPT_FAQS, $faqs );
			}
			wp_safe_redirect( add_query_arg( array( 'page' => 'fy-support-bot', 'tab' => 'faq', 'added' => '1' ), admin_url( 'edit.php?post_type=fy_yacht' ) ) );
			exit;
		}

		if ( 'remove_faq' === $_POST['fysb_action'] ) {
			check_admin_referer( 'fy_sb_remove_faq' );
			$id   = isset( $_POST['faq_id'] ) ? sanitize_key( wp_unslash( $_POST['faq_id'] ) ) : '';
			$faqs = array_values( array_filter( self::get_faqs(), function ( $faq ) use ( $id ) {
				return $faq['id'] !== $id;
			} ) );
			update_option( self::OPT_FAQS, $faqs );
			wp_safe_redirect( add_query_arg( array( 'page' => 'fy-support-bot', 'tab' => 'faq', 'removed' => '1' ), admin_url( 'edit.php?post_type=fy_yacht' ) ) );
			exit;
		}

		if ( 'save_embed' === $_POST['fysb_action'] ) {
			check_admin_referer( 'fy_sb_save_embed' );
			$settings                    = self::get_settings();
			$settings['widget_color_1']  = isset( $_POST['widget_color_1'] ) ? sanitize_hex_color( wp_unslash( $_POST['widget_color_1'] ) ) : '#E45C9C';
			$settings['widget_color_2']  = isset( $_POST['widget_color_2'] ) ? sanitize_hex_color( wp_unslash( $_POST['widget_color_2'] ) ) : '#7C3AED';
			$settings['widget_position'] = ( isset( $_POST['widget_position'] ) && 'left' === $_POST['widget_position'] ) ? 'left' : 'right';
			$settings['widget_title']    = isset( $_POST['widget_title'] ) ? sanitize_text_field( wp_unslash( $_POST['widget_title'] ) ) : 'Support Bot';
			$settings['widget_avatar']   = isset( $_POST['widget_avatar'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST['widget_avatar'] ) ), 0, 1 ) : 'S';
			update_option( self::OPT_SETTINGS, $settings );
			wp_safe_redirect( add_query_arg( array( 'page' => 'fy-support-bot', 'tab' => 'embed', 'saved' => '1' ), admin_url( 'edit.php?post_type=fy_yacht' ) ) );
			exit;
		}
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$tab      = self::current_tab();
		$settings = self::get_settings();
		$kb       = self::get_knowledge_base();
		$dbs      = self::get_databases();
		$faqs     = self::get_faqs();
		$base_url = admin_url( 'edit.php?post_type=fy_yacht&page=fy-support-bot' );
		?>
		<div class="wrap fy-sb-wrap">
			<h1><?php esc_html_e( 'Feeling Yachty — Support Bot', 'fy-fleet' ); ?></h1>
			<p class="fy-sb-subtitle"><?php esc_html_e( 'Your AI receptionist. Answers common questions and qualifies leads — never quotes an exact price or names a specific boat.', 'fy-fleet' ); ?></p>

			<h2 class="nav-tab-wrapper">
				<a href="<?php echo esc_url( add_query_arg( 'tab', 'connection', $base_url ) ); ?>" class="nav-tab <?php echo 'connection' === $tab ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Connection', 'fy-fleet' ); ?></a>
				<a href="<?php echo esc_url( add_query_arg( 'tab', 'knowledge', $base_url ) ); ?>" class="nav-tab <?php echo 'knowledge' === $tab ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Knowledge Base', 'fy-fleet' ); ?></a>
				<a href="<?php echo esc_url( add_query_arg( 'tab', 'databases', $base_url ) ); ?>" class="nav-tab <?php echo 'databases' === $tab ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Databases', 'fy-fleet' ); ?></a>
				<a href="<?php echo esc_url( add_query_arg( 'tab', 'faq', $base_url ) ); ?>" class="nav-tab <?php echo 'faq' === $tab ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'FAQ', 'fy-fleet' ); ?></a>
				<a href="<?php echo esc_url( add_query_arg( 'tab', 'test', $base_url ) ); ?>" class="nav-tab <?php echo 'test' === $tab ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Test Console', 'fy-fleet' ); ?></a>
				<a href="<?php echo esc_url( add_query_arg( 'tab', 'embed', $base_url ) ); ?>" class="nav-tab <?php echo 'embed' === $tab ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Embed Code', 'fy-fleet' ); ?></a>
			</h2>

			<?php if ( isset( $_GET['saved'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Saved.', 'fy-fleet' ); ?></p></div>
			<?php endif; ?>
			<?php if ( isset( $_GET['reset'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Knowledge base reset to defaults.', 'fy-fleet' ); ?></p></div>
			<?php endif; ?>
			<?php if ( isset( $_GET['added'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Database added.', 'fy-fleet' ); ?></p></div>
			<?php endif; ?>
			<?php if ( isset( $_GET['removed'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Database removed.', 'fy-fleet' ); ?></p></div>
			<?php endif; ?>

			<?php if ( 'connection' === $tab ) : ?>
				<?php self::render_connection_tab( $settings ); ?>
			<?php elseif ( 'knowledge' === $tab ) : ?>
				<?php self::render_knowledge_tab( $kb ); ?>
			<?php elseif ( 'databases' === $tab ) : ?>
				<?php self::render_databases_tab( $dbs ); ?>
			<?php elseif ( 'faq' === $tab ) : ?>
				<?php self::render_faq_tab( $faqs ); ?>
			<?php elseif ( 'embed' === $tab ) : ?>
				<?php self::render_embed_tab( $settings ); ?>
			<?php else : ?>
				<?php self::render_test_tab( $settings ); ?>
			<?php endif; ?>
		</div>
		<?php
	}

	private static function render_connection_tab( $settings ) {
		$ai_ready  = class_exists( 'FY_Fleet_AI' ) && FY_Fleet_AI::configured();
		$ai_url    = admin_url( 'edit.php?post_type=fy_yacht&page=fy-fleet-booking' );
		?>
		<div class="fy-sb-card">
			<h2><?php esc_html_e( 'Reply Engine', 'fy-fleet' ); ?></h2>
			<?php if ( $ai_ready ) : ?>
				<p style="color:#1a7a1a;font-weight:600;">✅ <?php esc_html_e( 'Connected — the bot replies directly via Claude. No n8n webhook is required for the bot to work.', 'fy-fleet' ); ?></p>
			<?php else : ?>
				<p style="color:#8a5a2a;font-weight:600;">⚠️ <?php esc_html_e( 'No AI key configured yet — the bot will fall back to the n8n webhook below (if set), or stop working entirely if neither is configured.', 'fy-fleet' ); ?></p>
				<p><?php printf( wp_kses( __( 'Fastest fix: paste your Anthropic (Claude) API key on the <a href="%s">Checkout &amp; Integrations</a> page, under "AI Assist" — one paste, save, done. No n8n setup needed at all.', 'fy-fleet' ), array( 'a' => array( 'href' => array() ) ) ), esc_url( $ai_url ) ); ?></p>
			<?php endif; ?>
		</div>

		<div class="fy-sb-card">
			<h2><?php esc_html_e( 'n8n Connection (optional)', 'fy-fleet' ); ?></h2>
			<p><?php esc_html_e( 'Only needed if you want n8n involved — e.g. to notify staff, sync to a CRM, or as a fallback if no AI key is set above. Paste the webhook URL for the Support Bot workflow in n8n, using the Production URL, with the workflow switched Active.', 'fy-fleet' ); ?></p>
			<form method="post">
				<?php wp_nonce_field( 'fy_sb_save_connection' ); ?>
				<input type="hidden" name="fysb_action" value="save_connection" />
				<table class="form-table">
					<tr>
						<th scope="row"><label for="webhook_url"><?php esc_html_e( 'n8n Webhook URL', 'fy-fleet' ); ?></label></th>
						<td>
							<input type="url" id="webhook_url" name="webhook_url" class="regular-text" style="width:520px" placeholder="https://feelingyachty.app.n8n.cloud/webhook/.../support-bot-chat" value="<?php echo esc_attr( $settings['webhook_url'] ); ?>" />
						</td>
					</tr>
				</table>
				<p class="submit">
					<button type="submit" class="button button-primary"><?php esc_html_e( 'Save Connection', 'fy-fleet' ); ?></button>
					<button type="button" id="fysb-test-connection" class="button"><?php esc_html_e( 'Test Connection', 'fy-fleet' ); ?></button>
					<span id="fysb-test-connection-result" class="fysb-test-result"></span>
				</p>
			</form>
		</div>
		<?php
	}

	private static function render_knowledge_tab( $kb ) {
		?>
		<div class="fy-sb-card">
			<p><?php esc_html_e( 'This is what the bot knows and how it is told to behave. Edit any box and save — changes take effect on the next message, even mid-conversation.', 'fy-fleet' ); ?></p>
			<form method="post">
				<?php wp_nonce_field( 'fy_sb_save_knowledge' ); ?>
				<input type="hidden" name="fysb_action" value="save_knowledge" />

				<?php foreach ( $kb['categories'] as $cat ) : ?>
					<div class="fy-sb-kb-box" data-kb-key="<?php echo esc_attr( $cat['key'] ); ?>">
						<h3><?php echo esc_html( $cat['label'] ); ?></h3>
						<p class="description"><?php echo esc_html( $cat['description'] ); ?></p>
						<textarea name="kb[<?php echo esc_attr( $cat['key'] ); ?>]" rows="8" class="large-text code"><?php echo esc_textarea( $cat['content'] ); ?></textarea>
					</div>
				<?php endforeach; ?>

				<p class="submit">
					<button type="submit" class="button button-primary"><?php esc_html_e( 'Save Knowledge Base', 'fy-fleet' ); ?></button>
				</p>
			</form>

			<form method="post" onsubmit="return confirm('<?php echo esc_js( __( 'Reset all boxes to the original curated defaults? This cannot be undone.', 'fy-fleet' ) ); ?>');">
				<?php wp_nonce_field( 'fy_sb_reset_knowledge' ); ?>
				<input type="hidden" name="fysb_action" value="reset_knowledge" />
				<button type="submit" class="button button-link-delete"><?php esc_html_e( 'Reset to defaults', 'fy-fleet' ); ?></button>
			</form>

			<div class="fy-sb-kb-box fy-sb-kb-excluded">
				<h3><?php echo esc_html( $kb['excluded']['label'] ); ?></h3>
				<p class="description"><?php echo esc_html( $kb['excluded']['description'] ); ?></p>
				<ul>
					<?php foreach ( $kb['excluded']['reasons'] as $reason ) : ?>
						<li><?php echo esc_html( $reason ); ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
		<?php
	}

	private static function render_databases_tab( $dbs ) {
		?>
		<div class="fy-sb-card">
			<p><?php esc_html_e( 'Independent knowledge sources the bot can draw from. Miami and Panama auto-compile live fleet facts (yacht count, size range, capacity, starting-price range) from your real published yachts — never a specific boat name or exact price. Add your own notes to any database, or create a new one.', 'fy-fleet' ); ?></p>
			<form method="post">
				<?php wp_nonce_field( 'fy_sb_save_databases' ); ?>
				<input type="hidden" name="fysb_action" value="save_databases" />

				<?php foreach ( $dbs as $db ) : ?>
					<div class="fy-sb-db-box">
						<div class="fy-sb-db-head">
							<label class="fy-sb-db-toggle">
								<input type="checkbox" name="db[<?php echo esc_attr( $db['id'] ); ?>][enabled]" value="1" <?php checked( ! empty( $db['enabled'] ) ); ?> />
								<?php if ( 'custom' === $db['type'] ) : ?>
									<input type="text" name="db[<?php echo esc_attr( $db['id'] ); ?>][name]" value="<?php echo esc_attr( $db['name'] ); ?>" class="fy-sb-db-name-input" />
								<?php else : ?>
									<strong><?php echo esc_html( $db['name'] ); ?></strong>
									<input type="hidden" name="db[<?php echo esc_attr( $db['id'] ); ?>][name]" value="<?php echo esc_attr( $db['name'] ); ?>" />
								<?php endif; ?>
							</label>
							<?php if ( 'custom' === $db['type'] ) : ?>
								<button type="submit" form="fy-sb-remove-<?php echo esc_attr( $db['id'] ); ?>" class="button-link-delete fy-sb-db-remove"><?php esc_html_e( 'Remove', 'fy-fleet' ); ?></button>
							<?php endif; ?>
						</div>

						<?php if ( in_array( $db['type'], array( 'miami', 'panama' ), true ) ) : ?>
							<p class="fy-sb-db-live"><strong><?php esc_html_e( 'Live fleet summary:', 'fy-fleet' ); ?></strong> <?php echo esc_html( self::compile_fleet_summary( $db['type'] ) ); ?></p>
						<?php endif; ?>

						<label class="fy-sb-db-notes-label" for="fy-sb-url-<?php echo esc_attr( $db['id'] ); ?>"><?php esc_html_e( '"See our boats" link — the page the bot sends guests to browse this fleet', 'fy-fleet' ); ?></label>
						<input type="url" id="fy-sb-url-<?php echo esc_attr( $db['id'] ); ?>" name="db[<?php echo esc_attr( $db['id'] ); ?>][browse_url]" class="large-text" placeholder="https://feelingyachty.com/miami-yacht-rentals" value="<?php echo esc_attr( isset( $db['browse_url'] ) ? $db['browse_url'] : '' ); ?>" />
						<p class="description"><?php esc_html_e( 'The bot sends this link once it knows the guest wants this city, then asks them which boats they liked — and passes those names on with the lead. Leave blank to turn that off for this database.', 'fy-fleet' ); ?></p>

						<label class="fy-sb-db-notes-label" for="fy-sb-addons-<?php echo esc_attr( $db['id'] ); ?>"><?php esc_html_e( '"See our add-ons" link — mentioned once at handoff (catering, decorations, jet skis, etc.)', 'fy-fleet' ); ?></label>
						<input type="url" id="fy-sb-addons-<?php echo esc_attr( $db['id'] ); ?>" name="db[<?php echo esc_attr( $db['id'] ); ?>][addons_url]" class="large-text" placeholder="https://feelingyachty.com/miami-yacht-services" value="<?php echo esc_attr( isset( $db['addons_url'] ) ? $db['addons_url'] : '' ); ?>" />
						<p class="description"><?php esc_html_e( 'Right after handing off, the bot mentions this once as a casual aside — "if you\'re also interested in add-ons, ask the sales manager, here\'s the page." Leave blank to skip that mention for this database.', 'fy-fleet' ); ?></p>

						<label class="fy-sb-db-notes-label"><?php esc_html_e( 'Your notes (added on top of the live summary above)', 'fy-fleet' ); ?></label>
						<textarea name="db[<?php echo esc_attr( $db['id'] ); ?>][notes]" rows="4" class="large-text"><?php echo esc_textarea( $db['notes'] ); ?></textarea>
					</div>
				<?php endforeach; ?>

				<p class="submit">
					<button type="submit" class="button button-primary"><?php esc_html_e( 'Save Databases', 'fy-fleet' ); ?></button>
				</p>
			</form>

			<?php foreach ( $dbs as $db ) : ?>
				<?php if ( 'custom' === $db['type'] ) : ?>
					<form method="post" id="fy-sb-remove-<?php echo esc_attr( $db['id'] ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'Remove this database?', 'fy-fleet' ) ); ?>');">
						<?php wp_nonce_field( 'fy_sb_remove_database' ); ?>
						<input type="hidden" name="fysb_action" value="remove_database" />
						<input type="hidden" name="db_id" value="<?php echo esc_attr( $db['id'] ); ?>" />
					</form>
				<?php endif; ?>
			<?php endforeach; ?>

			<form method="post" class="fy-sb-add-db-form">
				<?php wp_nonce_field( 'fy_sb_add_database' ); ?>
				<input type="hidden" name="fysb_action" value="add_database" />
				<input type="text" name="new_db_name" placeholder="<?php esc_attr_e( 'e.g. Add-on Services', 'fy-fleet' ); ?>" class="regular-text" />
				<button type="submit" class="button"><?php esc_html_e( '+ Add Database', 'fy-fleet' ); ?></button>
			</form>
		</div>
		<?php
	}

	private static function render_faq_tab( $faqs ) {
		?>
		<div class="fy-sb-card">
			<p><?php esc_html_e( 'Pre-approved question-and-answer pairs — the bot can answer these directly instead of always handing off. Add or remove any entry. Keep answers general (no exact prices for a specific charter).', 'fy-fleet' ); ?></p>
			<form method="post">
				<?php wp_nonce_field( 'fy_sb_save_faqs' ); ?>
				<input type="hidden" name="fysb_action" value="save_faqs" />

				<?php foreach ( $faqs as $faq ) : ?>
					<div class="fy-sb-faq-box">
						<div class="fy-sb-faq-row">
							<input type="text" name="faq[<?php echo esc_attr( $faq['id'] ); ?>][q]" value="<?php echo esc_attr( $faq['q'] ); ?>" class="large-text fy-sb-faq-q" placeholder="<?php esc_attr_e( 'Question', 'fy-fleet' ); ?>" />
							<button type="submit" form="fy-sb-remove-faq-<?php echo esc_attr( $faq['id'] ); ?>" class="button-link-delete fy-sb-db-remove"><?php esc_html_e( 'Remove', 'fy-fleet' ); ?></button>
						</div>
						<textarea name="faq[<?php echo esc_attr( $faq['id'] ); ?>][a]" rows="2" class="large-text" placeholder="<?php esc_attr_e( 'Answer', 'fy-fleet' ); ?>"><?php echo esc_textarea( $faq['a'] ); ?></textarea>
					</div>
				<?php endforeach; ?>

				<p class="submit">
					<button type="submit" class="button button-primary"><?php esc_html_e( 'Save FAQs', 'fy-fleet' ); ?></button>
				</p>
			</form>

			<?php foreach ( $faqs as $faq ) : ?>
				<form method="post" id="fy-sb-remove-faq-<?php echo esc_attr( $faq['id'] ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'Remove this FAQ?', 'fy-fleet' ) ); ?>');">
					<?php wp_nonce_field( 'fy_sb_remove_faq' ); ?>
					<input type="hidden" name="fysb_action" value="remove_faq" />
					<input type="hidden" name="faq_id" value="<?php echo esc_attr( $faq['id'] ); ?>" />
				</form>
			<?php endforeach; ?>

			<form method="post" class="fy-sb-add-faq-form">
				<?php wp_nonce_field( 'fy_sb_add_faq' ); ?>
				<input type="hidden" name="fysb_action" value="add_faq" />
				<input type="text" name="new_faq_q" placeholder="<?php esc_attr_e( 'New question', 'fy-fleet' ); ?>" class="large-text" />
				<textarea name="new_faq_a" rows="2" class="large-text" placeholder="<?php esc_attr_e( 'Answer', 'fy-fleet' ); ?>"></textarea>
				<button type="submit" class="button"><?php esc_html_e( '+ Add FAQ', 'fy-fleet' ); ?></button>
			</form>
		</div>
		<?php
	}

	private static function render_test_tab( $settings ) {
		$has_webhook = ! empty( $settings['webhook_url'] );
		?>
		<div class="fy-sb-card fy-sb-test-card">
			<?php if ( ! $has_webhook ) : ?>
				<div class="notice notice-warning inline"><p><?php esc_html_e( 'Set the n8n webhook URL on the Connection tab first.', 'fy-fleet' ); ?></p></div>
			<?php endif; ?>

			<div class="fy-sb-region-select">
				<label><?php esc_html_e( 'Simulate region:', 'fy-fleet' ); ?></label>
				<select id="fysb-test-region">
					<option value=""><?php esc_html_e( 'Auto-detect from message', 'fy-fleet' ); ?></option>
					<option value="miami"><?php esc_html_e( 'Miami page', 'fy-fleet' ); ?></option>
					<option value="panama"><?php esc_html_e( 'Panama page', 'fy-fleet' ); ?></option>
				</select>
			</div>

			<div id="fysb-chat-app" class="fysb-chat-app" data-has-webhook="<?php echo $has_webhook ? '1' : '0'; ?>">
				<div class="fysb-tabbar" id="fysb-tabbar"></div>
				<div class="fysb-chat-body">
					<div class="fysb-messages" id="fysb-messages"></div>
					<div class="fysb-composer">
						<textarea id="fysb-input" placeholder="<?php esc_attr_e( 'Type a message to test the bot...', 'fy-fleet' ); ?>" rows="2"></textarea>
						<div class="fysb-composer-buttons">
							<button type="button" id="fysb-send" class="button button-primary"><?php esc_html_e( 'Send', 'fy-fleet' ); ?></button>
							<button type="button" id="fysb-wipe" class="button"><?php esc_html_e( 'Wipe Chat', 'fy-fleet' ); ?></button>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	private static function render_embed_tab( $settings ) {
		$has_webhook = ! empty( $settings['webhook_url'] );
		$embed_code  = self::build_embed_code( $settings );
		?>
		<div class="fy-sb-card">
			<?php if ( ! $has_webhook ) : ?>
				<div class="notice notice-warning inline"><p><?php esc_html_e( 'Set the n8n webhook URL on the Connection tab first.', 'fy-fleet' ); ?></p></div>
			<?php endif; ?>

			<h2><?php esc_html_e( 'Widget Appearance', 'fy-fleet' ); ?></h2>
			<p><?php esc_html_e( "Choose the widget's colors and position. The embed code below updates automatically — this does not put anything live on your site by itself, it only generates the code for you to paste wherever (and whenever) you're ready.", 'fy-fleet' ); ?></p>
			<form method="post">
				<?php wp_nonce_field( 'fy_sb_save_embed' ); ?>
				<input type="hidden" name="fysb_action" value="save_embed" />
				<table class="form-table">
					<tr>
						<th scope="row"><label for="widget_color_1"><?php esc_html_e( 'Bubble color (start)', 'fy-fleet' ); ?></label></th>
						<td><input type="color" id="widget_color_1" name="widget_color_1" value="<?php echo esc_attr( $settings['widget_color_1'] ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="widget_color_2"><?php esc_html_e( 'Bubble color (end)', 'fy-fleet' ); ?></label></th>
						<td><input type="color" id="widget_color_2" name="widget_color_2" value="<?php echo esc_attr( $settings['widget_color_2'] ); ?>" />
							<p class="description"><?php esc_html_e( 'The bubble uses a gradient between these two colors.', 'fy-fleet' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="widget_position"><?php esc_html_e( 'Position', 'fy-fleet' ); ?></label></th>
						<td>
							<select id="widget_position" name="widget_position">
								<option value="right" <?php selected( $settings['widget_position'], 'right' ); ?>><?php esc_html_e( 'Bottom right', 'fy-fleet' ); ?></option>
								<option value="left" <?php selected( $settings['widget_position'], 'left' ); ?>><?php esc_html_e( 'Bottom left', 'fy-fleet' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="widget_title"><?php esc_html_e( 'Title shown in header', 'fy-fleet' ); ?></label></th>
						<td><input type="text" id="widget_title" name="widget_title" class="regular-text" value="<?php echo esc_attr( $settings['widget_title'] ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="widget_avatar"><?php esc_html_e( 'Avatar letter', 'fy-fleet' ); ?></label></th>
						<td><input type="text" id="widget_avatar" name="widget_avatar" maxlength="1" style="width:50px;text-align:center" value="<?php echo esc_attr( $settings['widget_avatar'] ); ?>" /></td>
					</tr>
				</table>
				<p class="submit">
					<button type="submit" class="button button-primary"><?php esc_html_e( 'Save & Regenerate Code', 'fy-fleet' ); ?></button>
				</p>
			</form>
		</div>

		<div class="fy-sb-card">
			<h2><?php esc_html_e( 'Embed Code', 'fy-fleet' ); ?></h2>
			<p><?php esc_html_e( 'Copy this and paste it wherever you want the chat widget to appear — a single page (via an HTML block) or your theme\'s footer for site-wide. It automatically detects Miami vs Panama from the page it\'s on. Nothing goes live until you paste it somewhere.', 'fy-fleet' ); ?></p>
			<textarea id="fysb-embed-code" class="large-text code" rows="16" readonly onclick="this.select();"><?php echo esc_textarea( $embed_code ); ?></textarea>
			<p class="submit">
				<button type="button" id="fysb-copy-embed" class="button button-primary"><?php esc_html_e( 'Copy Embed Code', 'fy-fleet' ); ?></button>
				<span id="fysb-copy-result" class="fysb-test-result"></span>
			</p>
		</div>
		<?php
	}

	private static function build_embed_code( $settings ) {
		$webhook = esc_js( $settings['webhook_url'] );
		$color1  = esc_js( $settings['widget_color_1'] );
		$color2  = esc_js( $settings['widget_color_2'] );
		$side    = 'left' === $settings['widget_position'] ? 'left' : 'right';
		$title   = esc_js( $settings['widget_title'] );
		$avatar  = esc_js( mb_substr( $settings['widget_avatar'], 0, 1 ) );
		$rest    = esc_js( esc_url_raw( rest_url( 'fy-support-bot/v1/chat' ) ) );

		ob_start();
		?>
<!-- ===== Feeling Yachty — <?php echo esc_html( $settings['widget_title'] ); ?> Chat Widget ===== -->
<style>
  #fyb-bubble, #fyb-panel, #fyb-panel * { box-sizing: border-box; }
  #fyb-bubble {
    position: fixed; bottom: 22px; <?php echo esc_html( $side ); ?>: 22px;
    width: 60px; height: 60px; border-radius: 50%;
    background: linear-gradient(135deg, <?php echo esc_html( $color1 ); ?>, <?php echo esc_html( $color2 ); ?>);
    box-shadow: 0 10px 30px rgba(124,58,237,.35);
    display: flex; align-items: center; justify-content: center;
    cursor: pointer; z-index: 999999; border: none; transition: transform .15s ease;
  }
  #fyb-bubble:hover { transform: translateY(-2px); }
  #fyb-bubble svg { width: 26px; height: 26px; }
  #fyb-panel {
    position: fixed; bottom: 96px; <?php echo esc_html( $side ); ?>: 22px;
    width: 360px; max-width: calc(100vw - 32px);
    height: 520px; max-height: calc(100vh - 140px);
    background: #fff; border: 1px solid rgba(124,58,237,.16); border-radius: 20px;
    box-shadow: 0 24px 60px rgba(23,32,51,.18);
    display: none; flex-direction: column; overflow: hidden; z-index: 999999;
    font-family: ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, Arial, sans-serif;
  }
  #fyb-panel.fyb-open { display: flex; }
  #fyb-header { background: linear-gradient(120deg, #fff 0%, #fff5fa 52%, #F3E8FF 100%); padding: 14px 16px; display: flex; align-items: center; gap: 10px; border-bottom: 1px solid #E6EAF3; }
  #fyb-avatar { width: 34px; height: 34px; border-radius: 50%; background: linear-gradient(135deg, <?php echo esc_html( $color1 ); ?>, <?php echo esc_html( $color2 ); ?>); color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 14px; flex-shrink: 0; }
  #fyb-header-text h1 { margin: 0; font-size: 13.5px; font-weight: 800; color: #172033; }
  #fyb-header-text p { margin: 1px 0 0; font-size: 11px; color: #526079; }
  #fyb-close { margin-left: auto; background: none; border: none; cursor: pointer; color: #526079; font-size: 18px; line-height: 1; padding: 4px; }
  #fyb-thread { flex: 1; overflow-y: auto; padding: 14px; display: flex; flex-direction: column; gap: 8px; background: #FFF9FC; }
  .fyb-row { display: flex; }
  .fyb-row.fyb-out { justify-content: flex-end; }
  .fyb-bubble-msg { max-width: 82%; padding: 9px 12px; border-radius: 14px; font-size: 13.5px; line-height: 1.4; white-space: pre-wrap; box-shadow: 0 1px 2px rgba(0,0,0,.06); }
  .fyb-row.fyb-in .fyb-bubble-msg { background: #fff; color: #172033; border: 1px solid #E6EAF3; border-bottom-left-radius: 3px; }
  .fyb-row.fyb-out .fyb-bubble-msg { background: linear-gradient(135deg, <?php echo esc_html( $color1 ); ?>, <?php echo esc_html( $color2 ); ?>); color: #fff; border-bottom-right-radius: 3px; }
  .fyb-row.fyb-in .fyb-bubble-msg a { color: <?php echo esc_html( $color2 ); ?>; font-weight: 600; word-break: break-all; }
  .fyb-row.fyb-out .fyb-bubble-msg a { color: #fff; text-decoration: underline; word-break: break-all; }
  #fyb-composer { display: flex; gap: 6px; padding: 10px; background: #fff; border-top: 1px solid #E6EAF3; }
  #fyb-input { flex: 1; border: 1px solid #E6EAF3; background: #FFF9FC; border-radius: 100px; padding: 9px 14px; font-size: 13.5px; outline: none; color: #172033; }
  #fyb-input:focus { border-color: <?php echo esc_html( $color2 ); ?>; }
  #fyb-send { background: linear-gradient(135deg, <?php echo esc_html( $color1 ); ?>, <?php echo esc_html( $color2 ); ?>); color: #fff; border: none; border-radius: 100px; width: 38px; height: 38px; flex-shrink: 0; cursor: pointer; display: flex; align-items: center; justify-content: center; }
  #fyb-send:disabled { opacity: .5; cursor: not-allowed; }
</style>
<button id="fyb-bubble" aria-label="Chat with us">
  <svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
</button>
<div id="fyb-panel">
  <div id="fyb-header">
    <div id="fyb-avatar"><?php echo esc_html( $avatar ); ?></div>
    <div id="fyb-header-text">
      <h1><?php echo esc_html( $title ); ?></h1>
      <p>Usually replies in a few minutes</p>
    </div>
    <button id="fyb-close" aria-label="Close chat">✕</button>
  </div>
  <div id="fyb-thread">
    <div class="fyb-row fyb-in"><div class="fyb-bubble-msg">Hi! 👋 How can I help you today?</div></div>
  </div>
  <div id="fyb-composer">
    <input id="fyb-input" type="text" placeholder="Type a message…" autocomplete="off" />
    <button id="fyb-send" aria-label="Send">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
    </button>
  </div>
</div>
<script>
(function () {
  var REST_URL = "<?php echo esc_html( $rest ); ?>";
  var sessionId = 'web-' + Math.random().toString(36).slice(2, 10);
  var bubble = document.getElementById('fyb-bubble');
  var panel = document.getElementById('fyb-panel');
  var closeBtn = document.getElementById('fyb-close');
  var thread = document.getElementById('fyb-thread');
  var input = document.getElementById('fyb-input');
  var sendBtn = document.getElementById('fyb-send');
  bubble.addEventListener('click', function () { panel.classList.toggle('fyb-open'); if (panel.classList.contains('fyb-open')) input.focus(); });
  closeBtn.addEventListener('click', function () { panel.classList.remove('fyb-open'); });
  // The bot is told to send the fleet page URL — as plain text it isn't
  // clickable, which is the whole point of sending it. Built as real nodes
  // (never innerHTML) so a reply can't inject markup.
  function linkify(el, text) {
    var re = /https?:\/\/[^\s<>()]+[^\s<>().,!?]/g, last = 0, m;
    while ((m = re.exec(text)) !== null) {
      if (m.index > last) el.appendChild(document.createTextNode(text.slice(last, m.index)));
      var a = document.createElement('a');
      a.href = m[0]; a.textContent = m[0]; a.target = '_blank'; a.rel = 'noopener noreferrer';
      el.appendChild(a);
      last = m.index + m[0].length;
    }
    if (last < text.length) el.appendChild(document.createTextNode(text.slice(last)));
  }
  function addMsg(text, who) {
    var row = document.createElement('div');
    row.className = 'fyb-row ' + (who === 'out' ? 'fyb-out' : 'fyb-in');
    var msg = document.createElement('div'); msg.className = 'fyb-bubble-msg';
    linkify(msg, text);
    row.appendChild(msg); thread.appendChild(row); thread.scrollTop = thread.scrollHeight;
  }
  function addTyping() {
    var row = document.createElement('div'); row.className = 'fyb-row fyb-in'; row.id = 'fyb-typing';
    row.innerHTML = '<div class="fyb-bubble-msg">…</div>'; thread.appendChild(row); thread.scrollTop = thread.scrollHeight;
  }
  function removeTyping() { var row = document.getElementById('fyb-typing'); if (row) row.remove(); }
  // Miami vs Panama, inferred from the page this widget is embedded on —
  // matches the site's own miami-yacht-rental / panama-yacht-rentals URL
  // convention. The server ALSO checks what the visitor actually types
  // (e.g. "Panama", "PTY") and that takes priority when it finds a match —
  // this is just the fallback for a generic/non-region page.
  function detectRegion() {
    var path = (window.location.pathname || '').toLowerCase();
    if (path.indexOf('panama-yacht-rentals') !== -1) return 'panama';
    if (path.indexOf('miami-yacht-rental') !== -1) return 'miami';
    return '';
  }
  function send() {
    var text = input.value.trim(); if (!text) return;
    addMsg(text, 'out'); input.value = ''; sendBtn.disabled = true; addTyping();
    fetch(REST_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: text, sessionId: sessionId, region: detectRegion() }) })
      .then(function (res) { return res.json(); })
      .then(function (data) { removeTyping(); addMsg(data.reply || "Sorry, I didn't catch that — could you try again?", 'in'); })
      .catch(function () { removeTyping(); addMsg("Sorry, I'm having trouble connecting right now.", 'in'); })
      .finally(function () { sendBtn.disabled = false; input.focus(); });
  }
  sendBtn.addEventListener('click', send);
  input.addEventListener('keydown', function (e) { if (e.key === 'Enter') send(); });
})();
</script>
<!-- ===== End <?php echo esc_html( $settings['widget_title'] ); ?> Chat Widget ===== -->
		<?php
		return trim( ob_get_clean() );
	}

	/* ------------------------------------------------------------------
	 * REST routes
	 * ---------------------------------------------------------------- */

	public static function register_routes() {
		register_rest_route(
			'fy-support-bot/v1',
			'/chat',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'handle_chat' ),
				// Public on purpose — this is the anonymous site-visitor widget endpoint.
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'fy-support-bot/v1',
			'/test-connection',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'handle_test_connection' ),
				'permission_callback' => array( __CLASS__, 'check_admin_permission' ),
			)
		);

		register_rest_route(
			'fy-support-bot/v1',
			'/coach',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'handle_coach' ),
				'permission_callback' => array( __CLASS__, 'check_admin_permission' ),
			)
		);
	}

	public static function check_admin_permission() {
		return current_user_can( 'manage_options' );
	}

	private static function webhook_url() {
		return self::get_settings()['webhook_url'];
	}

	public static function handle_chat( WP_REST_Request $request ) {
		$session_id = sanitize_text_field( (string) $request->get_param( 'sessionId' ) );
		$message    = sanitize_textarea_field( (string) $request->get_param( 'message' ) );
		$url_hint   = sanitize_key( (string) $request->get_param( 'region' ) );

		if ( empty( $session_id ) || '' === trim( $message ) ) {
			return new WP_Error( 'fysb_bad_request', 'sessionId and message are required.', array( 'status' => 400 ) );
		}

		// A real chat message is never anywhere near this long — caps
		// abuse/waste (needless AI token spend) on a garbage payload
		// without affecting any real conversation.
		if ( mb_strlen( $message ) > 4000 ) {
			$message = mb_substr( $message, 0, 4000 );
		}

		$region = self::detect_region( $message, $url_hint );

		// Direct-Claude is the primary path whenever a key is configured —
		// no n8n round-trip, and the system prompt is built from the EXACT
		// same verified compiled_knowledge_base() text tested throughout
		// this whole build, so there's no separate/unknown data source it
		// could be drawing on. Falls back to relaying through n8n only for
		// sites that haven't set up a Claude key yet (preserves the
		// original behavior rather than breaking anyone mid-setup).
		if ( class_exists( 'FY_Fleet_AI' ) && FY_Fleet_AI::configured() ) {
			$reply = self::handle_chat_direct( $session_id, $message, $region );
			if ( is_wp_error( $reply ) ) {
				return $reply;
			}
			return new WP_REST_Response( array( 'reply' => $reply ), 200 );
		}

		$webhook = self::webhook_url();
		if ( empty( $webhook ) ) {
			return new WP_Error( 'fysb_no_webhook', 'No AI key configured (Checkout & Integrations) and no n8n webhook URL configured (Connection tab) — set up at least one.', array( 'status' => 400 ) );
		}
		$response = wp_remote_post(
			$webhook,
			array(
				'timeout' => 45,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode(
					array(
						'sessionId'     => $session_id,
						'message'       => $message,
						'region'        => $region,
						'knowledgeBase' => self::compiled_knowledge_base( $region ),
					)
				),
			)
		);

		return self::relay_n8n_response( $response );
	}

	/**
	 * Direct-Claude reply generation — no n8n involved. Conversation memory
	 * lives in a short-lived transient keyed by sessionId (REST is
	 * stateless per-request, so this is the only way a multi-turn
	 * conversation remembers what was already said). Capped to the last 20
	 * turns so a long-running chat can't grow the prompt unboundedly.
	 *
	 * @return string|WP_Error
	 */
	private static function handle_chat_direct( $session_id, $message, $region ) {
		$convo_key = 'fy_sb_convo_' . md5( $session_id );
		$history   = get_transient( $convo_key );
		if ( ! is_array( $history ) ) {
			$history = array();
		}

		$history[] = array( 'role' => 'user', 'content' => $message );
		if ( count( $history ) > 20 ) {
			$history = array_slice( $history, -20 );
		}

		$system = "You are a member of Feeling Yachty's support team, chatting live with a visitor on the website. Write like a real person on the other end — see \"Sound Like a Real Person\" below and follow it in every message. The rules below are not optional, especially the Handoff/Redirect Rules and the Existing Booking rules. Reply in whichever language the guest is writing in. Keep replies concise — a few short sentences or lines, not a wall of text; this is a live chat, not an email. Write in plain text: the widget shows your reply exactly as typed, so markdown like **bold** or ## headings appears as literal asterisks and hashes. Plain URLs are fine — they become clickable links.\n\n";

		// Without this the bot asks "Miami or Panama?" even when the visitor
		// is standing on the Miami page — the region is resolved server-side,
		// but the AI has no way to know that unless told.
		if ( '' !== $region ) {
			$system .= sprintf(
				"CONTEXT FOR THIS CONVERSATION: the city is already settled — %s. The guest either named it or is browsing that city's page right now, and only %s's data is included below. Do NOT ask which city; skip that question entirely and carry on as if they'd already answered it. (If they later bring up the other city, follow them there and say a specialist will cover both.)\n\n",
				ucfirst( $region ),
				ucfirst( $region )
			);
		}

		$system .= self::compiled_knowledge_base( $region );

		$reply = FY_Fleet_AI::complete_chat( $system, $history, 'claude-sonnet-5' );
		if ( is_wp_error( $reply ) ) {
			return $reply;
		}

		$history[] = array( 'role' => 'assistant', 'content' => $reply );
		set_transient( $convo_key, $history, 2 * HOUR_IN_SECONDS );

		return $reply;
	}

	public static function handle_test_connection( WP_REST_Request $request ) {
		$webhook = self::webhook_url();
		if ( empty( $webhook ) ) {
			return new WP_Error( 'fysb_no_webhook', 'No n8n webhook URL configured.', array( 'status' => 400 ) );
		}

		$region = sanitize_key( (string) $request->get_param( 'region' ) );

		$start    = microtime( true );
		$response = wp_remote_post(
			$webhook,
			array(
				'timeout' => 30,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode(
					array(
						'sessionId'     => 'connection-test-' . wp_generate_uuid4(),
						'message'       => 'connection test',
						'region'        => $region,
						'knowledgeBase' => self::compiled_knowledge_base( $region ),
					)
				),
			)
		);
		$latency_ms = round( ( microtime( true ) - $start ) * 1000 );

		if ( is_wp_error( $response ) ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => $response->get_error_message() ), 200 );
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => 'n8n responded with HTTP ' . $code . '. Make sure the workflow is Active.' ), 200 );
		}

		return new WP_REST_Response( array( 'ok' => true, 'latency_ms' => $latency_ms ), 200 );
	}

	private static function relay_n8n_response( $response ) {
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'fysb_n8n_unreachable', 'Could not reach n8n: ' . $response->get_error_message(), array( 'status' => 502 ) );
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code || ! is_array( $body ) || ! isset( $body['reply'] ) ) {
			return new WP_Error( 'fysb_n8n_error', 'n8n did not return a valid reply (HTTP ' . $code . '). Make sure the workflow is Active in n8n.', array( 'status' => 502 ) );
		}

		return new WP_REST_Response( array( 'reply' => $body['reply'] ), 200 );
	}

	public static function handle_coach( WP_REST_Request $request ) {
		$note = sanitize_textarea_field( (string) $request->get_param( 'note' ) );
		if ( '' === trim( $note ) ) {
			return new WP_Error( 'fysb_bad_request', 'note is required.', array( 'status' => 400 ) );
		}

		$kb = self::get_knowledge_base();
		foreach ( $kb['categories'] as &$cat ) {
			if ( 'learned_corrections' === $cat['key'] ) {
				$entry          = '- (' . gmdate( 'Y-m-d H:i' ) . ' UTC) ' . $note;
				$cat['content'] = trim( $cat['content'] . "\n" . $entry );
				break;
			}
		}
		unset( $cat );
		update_option( self::OPT_KB, $kb );

		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}
}
