<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Customer database for the sales team.
 *
 * Built live from WooCommerce booking orders — one row per email, always in
 * sync, nothing to maintain by hand. Searchable, exportable to CSV, and served
 * over REST at /fy/v1/customers for n8n → GoHighLevel sync.
 */
class FY_Fleet_Customers {

	public static function init() {
		// Owner's call: no Customers screen — WooCommerce keeps its own customer
		// list. This class stays as the DATA layer only: get_customers() still
		// powers the /fy/v1/customers API and the customer_stats block inside
		// every n8n webhook.
		add_action( 'rest_api_init', array( __CLASS__, 'register_route' ) );
	}

	public static function add_menu() {
		add_submenu_page(
			'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE,
			__( 'Customers', 'fy-fleet' ),
			__( 'Customers', 'fy-fleet' ),
			'edit_shop_orders',
			'fy-fleet-customers',
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * One row per customer email, aggregated across their bookings.
	 *
	 * @return array[] Sorted by most recent charter first.
	 */
	public static function get_customers() {
		$customers = array();

		foreach ( FY_Fleet_Bookings_Admin::get_bookings() as $booking ) {
			$email = strtolower( trim( (string) $booking['email'] ) );
			if ( '' === $email ) {
				$email = 'no-email-order-' . $booking['order_id'];
			}

			if ( ! isset( $customers[ $email ] ) ) {
				$customers[ $email ] = array(
					'name'          => $booking['customer'],
					'email'         => $booking['email'],
					'phone'         => $booking['phone'],
					'bookings'      => 0,
					'charter_total' => 0.0,
					'deposits_paid' => 0.0,
					'balance_open'  => 0.0,
					'first_date'    => $booking['date'],
					'last_date'     => $booking['date'],
					'yachts'        => array(),
					'occasions'     => array(),
					'form_ok'       => true,
				);
			}

			$row = &$customers[ $email ];
			$row['bookings']++;
			$row['charter_total'] += (float) $booking['total'];
			$row['deposits_paid'] += (float) $booking['deposit'];
			if ( 'completed' !== $booking['status'] ) {
				$row['balance_open'] += (float) $booking['balance'];
			}
			if ( $booking['date'] < $row['first_date'] ) {
				$row['first_date'] = $booking['date'];
			}
			if ( $booking['date'] > $row['last_date'] ) {
				$row['last_date'] = $booking['date'];
				// Most recent contact details win.
				if ( $booking['phone'] ) {
					$row['phone'] = $booking['phone'];
				}
				if ( $booking['customer'] ) {
					$row['name'] = $booking['customer'];
				}
			}
			if ( $booking['yacht'] && ! in_array( $booking['yacht'], $row['yachts'], true ) ) {
				$row['yachts'][] = $booking['yacht'];
			}
			if ( ! $booking['confirmed'] ) {
				$row['form_ok'] = false;
			}
			unset( $row );
		}

		$customers = array_values( $customers );
		usort(
			$customers,
			function ( $a, $b ) {
				return strcmp( $b['last_date'], $a['last_date'] );
			}
		);

		return $customers;
	}

	public static function render_page() {
		if ( ! FY_Fleet_Woo::active() ) {
			echo '<div class="wrap"><h1>' . esc_html__( 'Customers', 'fy-fleet' ) . '</h1><p>' . esc_html__( 'WooCommerce must be active.', 'fy-fleet' ) . '</p></div>';
			return;
		}

		$customers = self::get_customers();
		$search    = isset( $_GET['s'] ) ? strtolower( sanitize_text_field( wp_unslash( $_GET['s'] ) ) ) : '';
		if ( '' !== $search ) {
			$customers = array_filter(
				$customers,
				function ( $c ) use ( $search ) {
					return false !== strpos( strtolower( $c['name'] . ' ' . $c['email'] . ' ' . $c['phone'] . ' ' . implode( ' ', $c['yachts'] ) ), $search );
				}
			);
		}

		$repeat = count( array_filter( $customers, function ( $c ) { return $c['bookings'] > 1; } ) );
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline">👥 <?php esc_html_e( 'Customers', 'fy-fleet' ); ?></h1>
			<a class="page-title-action" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=fy_export_customers' ), 'fy_export_customers' ) ); ?>">⬇️ <?php esc_html_e( 'Export CSV', 'fy-fleet' ); ?></a>

			<p class="description">
				<?php printf( esc_html__( '%1$d customers · %2$d repeat clients. Built live from paid bookings — always current, nothing to maintain. Also available to n8n at /wp-json/fy/v1/customers for GoHighLevel sync.', 'fy-fleet' ), count( $customers ), $repeat ); ?>
			</p>

			<form method="get" style="margin:10px 0">
				<input type="hidden" name="post_type" value="<?php echo esc_attr( FY_Fleet_CPT::POST_TYPE ); ?>">
				<input type="hidden" name="page" value="fy-fleet-customers">
				<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search name, email, phone, yacht…', 'fy-fleet' ); ?>" style="min-width:300px">
				<button class="button"><?php esc_html_e( 'Search', 'fy-fleet' ); ?></button>
			</form>

			<table class="widefat striped">
				<thead><tr>
					<th><?php esc_html_e( 'Customer', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'Contact', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'Charters', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'Lifetime value', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'Balance open', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'Last charter', 'fy-fleet' ); ?></th>
					<th><?php esc_html_e( 'Yachts', 'fy-fleet' ); ?></th>
				</tr></thead>
				<tbody>
				<?php if ( empty( $customers ) ) : ?>
					<tr><td colspan="7"><?php esc_html_e( 'No customers yet — they appear automatically after the first paid booking.', 'fy-fleet' ); ?></td></tr>
				<?php else : ?>
					<?php foreach ( $customers as $c ) : ?>
						<tr>
							<td><strong><?php echo esc_html( $c['name'] ? $c['name'] : '—' ); ?></strong>
								<?php if ( $c['bookings'] > 1 ) : ?><span style="color:#00a32a;font-weight:700"> ★ <?php esc_html_e( 'repeat', 'fy-fleet' ); ?></span><?php endif; ?>
								<?php if ( ! $c['form_ok'] ) : ?><span title="<?php esc_attr_e( 'A booking is missing the bareboat form confirmation', 'fy-fleet' ); ?>"> ⚠️</span><?php endif; ?>
							</td>
							<td>
								<a href="mailto:<?php echo esc_attr( $c['email'] ); ?>"><?php echo esc_html( $c['email'] ); ?></a><br>
								<?php if ( $c['phone'] ) : ?>
									<a href="https://wa.me/<?php echo esc_attr( preg_replace( '/[^0-9]/', '', $c['phone'] ) ); ?>" target="_blank" rel="noopener">💬 <?php echo esc_html( $c['phone'] ); ?></a>
								<?php endif; ?>
							</td>
							<td><?php echo esc_html( $c['bookings'] ); ?></td>
							<td><?php echo wp_kses_post( wc_price( $c['charter_total'] ) ); ?></td>
							<td><?php echo $c['balance_open'] > 0 ? wp_kses_post( wc_price( $c['balance_open'] ) ) : '—'; ?></td>
							<td><?php echo esc_html( FY_Fleet_Woo::format_date( $c['last_date'] ) ); ?></td>
							<td><small><?php echo esc_html( implode( ', ', array_slice( $c['yachts'], 0, 3 ) ) ); ?></small></td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	public static function export_csv() {
		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		check_admin_referer( 'fy_export_customers' );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=feeling-yachty-customers-' . gmdate( 'Y-m-d' ) . '.csv' );

		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array( 'Name', 'Email', 'Phone', 'Bookings', 'Lifetime Value', 'Deposits Paid', 'Balance Open', 'First Charter', 'Last Charter', 'Yachts' ) );
		foreach ( self::get_customers() as $c ) {
			fputcsv(
				$out,
				array(
					$c['name'], $c['email'], $c['phone'], $c['bookings'],
					number_format( $c['charter_total'], 2, '.', '' ),
					number_format( $c['deposits_paid'], 2, '.', '' ),
					number_format( $c['balance_open'], 2, '.', '' ),
					$c['first_date'], $c['last_date'], implode( ' | ', $c['yachts'] ),
				)
			);
		}
		fclose( $out ); // phpcs:ignore
		exit;
	}

	public static function register_route() {
		register_rest_route(
			'fy/v1',
			'/customers',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => function () {
					return rest_ensure_response( self::get_customers() );
				},
				'permission_callback' => array( 'FY_Fleet_REST', 'can_read_orders' ),
			)
		);
	}
}
