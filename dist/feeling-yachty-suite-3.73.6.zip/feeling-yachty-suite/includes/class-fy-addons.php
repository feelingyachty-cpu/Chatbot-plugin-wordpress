<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Charter add-ons on the WooCommerce product page.
 *
 * The add-on CATALOG (jet ski, open bar, photo packages…) already lives in
 * Checkout & Integrations, and FY_Fleet_Pricing uses it for the plugin's own
 * booking form. This class wires that same catalog into the NATIVE product
 * page — checkboxes under the Charter Duration selector — and carries the
 * choices through cart → checkout → order.
 *
 * Money split: a configurable share of the add-ons total (50% by default) is
 * charged online with the crew + fuel; the remainder is paid in person at the
 * dock along with the boat cost. Every figure below is recalculated
 * server-side at add-to-cart — the browser is never trusted.
 */
class FY_Fleet_Addons {

	/** Cart-item key holding the chosen add-ons. */
	const CART_KEY = 'fy_addons';

	public static function init() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		// Product page: the checkboxes, plus the data the JS needs.
		add_action( 'woocommerce_before_add_to_cart_button', array( __CLASS__, 'render_fields' ), 20 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ), 21 );

		// Cart: capture, validate, price, display.
		add_filter( 'woocommerce_add_to_cart_validation', array( __CLASS__, 'validate' ), 10, 4 );
		add_filter( 'woocommerce_add_cart_item_data', array( __CLASS__, 'capture' ), 10, 3 );
		add_action( 'woocommerce_before_calculate_totals', array( __CLASS__, 'apply_price' ), 25 );
		add_filter( 'woocommerce_get_item_data', array( __CLASS__, 'display' ), 20, 2 );

		// Order: persist so emails, the webhook and staff all see it.
		add_action( 'woocommerce_checkout_create_order_line_item', array( __CLASS__, 'order_line_meta' ), 20, 4 );

		// Editable again on the cart and checkout pages — same controls,
		// same server-side re-validation, then the totals refresh in place.
		add_action( 'woocommerce_before_cart_totals', array( __CLASS__, 'render_cart_panel' ), 10 );
		add_action( 'woocommerce_checkout_before_order_review', array( __CLASS__, 'render_cart_panel' ), 5 );
		add_action( 'wp_ajax_fy_update_addons', array( __CLASS__, 'ajax_update' ) );
		add_action( 'wp_ajax_nopriv_fy_update_addons', array( __CLASS__, 'ajax_update' ) );
	}

	/* ------------------------------------------------------------------
	 * Catalog
	 * ---------------------------------------------------------------- */

	/** The yacht behind the product currently being viewed, or 0. */
	public static function yacht_for_product( $product_id ) {
		$yacht_id = (int) get_post_meta( $product_id, '_fy_yacht_id', true );
		if ( $yacht_id && class_exists( 'FY_Fleet_CPT' ) && FY_Fleet_CPT::POST_TYPE === get_post_type( $yacht_id ) ) {
			return $yacht_id;
		}
		return 0;
	}

	/**
	 * Marketing page on feelingyachty.com for this add-on, or '' when the
	 * add-on has no dedicated page (e.g. jet-ski). Keyed off the same
	 * catalog keys the pricing/settings code already uses (see
	 * FY_Fleet_Settings' $shipped_keys), so this stays correct if the
	 * catalog is ever reordered or relabeled — a renamed LABEL doesn't
	 * break the link, only a changed KEY would, and keys are stable by
	 * design (they're what orders and pricing are keyed on too).
	 */
	public static function service_url( $key ) {
		static $map = array(
			'decorations'      => 'https://feelingyachty.com/miami-yacht-services/decorations/',
			'photo-video'      => 'https://feelingyachty.com/miami-yacht-services/photography/',
			'photo-video-drone' => 'https://feelingyachty.com/miami-yacht-services/photography/',
			'photography'      => 'https://feelingyachty.com/miami-yacht-services/photography/',
			'photography-drone' => 'https://feelingyachty.com/miami-yacht-services/photography/',
			'private-chef'     => 'https://feelingyachty.com/miami-yacht-services/private-chef/',
			'transportation'   => 'https://feelingyachty.com/miami-yacht-services/black-car',
			'bartender'        => 'https://feelingyachty.com/miami-yacht-services/bartender/',
			'open-bar-6'       => 'https://feelingyachty.com/miami-yacht-services/bartender/',
			'open-bar-13'      => 'https://feelingyachty.com/miami-yacht-services/bartender/',
		);
		if ( isset( $map[ $key ] ) ) {
			return $map[ $key ];
		}
		// Every catering line (cat-*) points at the one catering page rather
		// than needing 39 individual dish URLs.
		if ( 0 === strpos( $key, 'cat-' ) ) {
			return 'https://feelingyachty.com/miami-yacht-services/catering/';
		}
		return '';
	}

	/** The "More Info" link markup for one add-on, or '' when it has none. */
	private static function more_info_link( $key ) {
		$url = self::service_url( $key );
		if ( ! $url ) {
			return '';
		}
		return sprintf(
			' <a class="fy-addon__more-info" href="%s" target="_blank" rel="noopener">%s</a>',
			esc_url( $url ),
			esc_html__( 'More Info', 'fy-fleet' )
		);
	}

	/** Group prefix marking a set of alternatives rather than a menu section. */
	const CHOICE_PREFIX = 'choice:';

	/**
	 * Split a catalog into the blocks shown up front and the menu hidden
	 * behind the expander.
	 *
	 * Three kinds of entry:
	 *  - no group            → its own checkbox row, in catalog order.
	 *  - group "choice:Name" → alternatives of ONE add-on (Open Bar 6 vs 13,
	 *                          Videography with or without drone). They render
	 *                          as a single row with a dropdown, because the
	 *                          customer picks one, never both.
	 *  - any other group     → the catering menu, collapsed behind one
	 *                          expandable section so 39 dishes don't push the
	 *                          booking button off the screen.
	 *
	 * Blocks keep catalog order, and a choice set lands where its first
	 * member sits — so renaming two entries into a set doesn't move the row.
	 *
	 * @return array{blocks:array<int,array>,groups:array<string,array>}
	 */
	public static function partition( $catalog ) {
		$blocks    = array();
		$groups    = array();
		$choice_at = array(); // set label => index into $blocks

		foreach ( $catalog as $key => $addon ) {
			$group = ! empty( $addon['group'] ) ? (string) $addon['group'] : '';

			if ( '' === $group ) {
				$blocks[] = array( 'type' => 'item', 'key' => $key, 'addon' => $addon );
				continue;
			}

			if ( 0 === strpos( $group, self::CHOICE_PREFIX ) ) {
				$label = trim( substr( $group, strlen( self::CHOICE_PREFIX ) ) );
				if ( '' === $label ) {
					$blocks[] = array( 'type' => 'item', 'key' => $key, 'addon' => $addon );
					continue;
				}
				if ( ! isset( $choice_at[ $label ] ) ) {
					$choice_at[ $label ] = count( $blocks );
					$blocks[]            = array( 'type' => 'choice', 'label' => $label, 'items' => array() );
				}
				$blocks[ $choice_at[ $label ] ]['items'][ $key ] = $addon;
				continue;
			}

			$groups[ $group ][ $key ] = $addon;
		}

		// A "set" with a single member is just an item — don't make the
		// customer use a dropdown to pick the only option there is.
		foreach ( $blocks as $i => $block ) {
			if ( 'choice' === $block['type'] && count( $block['items'] ) < 2 ) {
				$only         = key( $block['items'] );
				$blocks[ $i ] = array( 'type' => 'item', 'key' => $only, 'addon' => $block['items'][ $only ] );
			}
		}

		return array( 'blocks' => $blocks, 'groups' => $groups );
	}

	/**
	 * Name to show once an add-on is BOOKED — cart line, order, admin, email.
	 *
	 * A choice member's own label is only half a name ("Up to 13 guests"),
	 * because the set heading carries the rest. On the product page the two
	 * sit together so that reads fine, but an order line has no heading — so
	 * rejoin them here.
	 */
	public static function full_label( $addon ) {
		$group = isset( $addon['group'] ) ? (string) $addon['group'] : '';
		if ( 0 === strpos( $group, self::CHOICE_PREFIX ) ) {
			$set = trim( substr( $group, strlen( self::CHOICE_PREFIX ) ) );
			if ( '' !== $set ) {
				/* translators: 1: add-on set name, 2: chosen option */
				return sprintf( __( '%1$s — %2$s', 'fy-fleet' ), $set, $addon['label'] );
			}
		}
		return (string) $addon['label'];
	}

	/**
	 * Which member of a choice set is currently picked, and its saved state.
	 *
	 * @return array{key:string,selected:?array}
	 */
	public static function choice_state( $items, $selected ) {
		if ( is_array( $selected ) ) {
			foreach ( $items as $key => $addon ) {
				if ( isset( $selected[ $key ] ) ) {
					return array( 'key' => (string) $key, 'selected' => $selected[ $key ] );
				}
			}
		}
		return array( 'key' => (string) key( $items ), 'selected' => null );
	}

	/**
	 * Whether $addon has enough to show a real card — a non-blank label, at
	 * minimum. Every renderer below calls this BEFORE printing any markup, so
	 * a catalog entry that fails to resolve produces no wrapper div at all,
	 * rather than a same-height card with nothing in it. `trim()` alone
	 * wouldn't catch a label consisting only of a non-breaking space or other
	 * non-ASCII whitespace (e.g. pasted from a rich-text source), so this
	 * also rejects a label that has no visible characters once entities are
	 * stripped and Unicode whitespace is normalized.
	 */
	private static function addon_is_renderable( $addon ) {
		if ( ! is_array( $addon ) || empty( $addon['label'] ) ) {
			return false;
		}
		$stripped = preg_replace( '/[\s\x{00A0}\x{200B}-\x{200D}\x{FEFF}]+/u', '', wp_strip_all_tags( (string) $addon['label'] ) );
		if ( '' === $stripped ) {
			return false;
		}
		$unit = isset( $addon['unit'] ) ? $addon['unit'] : '';
		return in_array( $unit, array( 'flat', 'hour', 'hours', 'quote' ), true );
	}

	/** Price label for one add-on row. */
	public static function price_label( $addon ) {
		if ( 'quote' === $addon['unit'] ) {
			return __( 'Custom quote', 'fy-fleet' );
		}
		if ( 'hour' === $addon['unit'] || 'hours' === $addon['unit'] ) {
			/* translators: %s: money amount */
			return sprintf( __( '$%s / hour', 'fy-fleet' ), number_format( (float) $addon['price'] ) );
		}
		return '$' . number_format( (float) $addon['price'] );
	}

	/** Add-ons offered on this yacht, with defaults filled in. */
	public static function catalog( $yacht_id ) {
		if ( ! class_exists( 'FY_Fleet_Pricing' ) ) {
			return array();
		}
		$out = array();
		foreach ( FY_Fleet_Pricing::addons_for_yacht( $yacht_id ) as $key => $addon ) {
			$out[ $key ] = wp_parse_args(
				$addon,
				array(
					'key'       => $key,
					'label'     => '',
					'price'     => 0,
					'unit'      => 'flat',
					'note'      => '',
					'max'       => 1,
					'min_hours' => 0,
					'reserve_hours' => 0,
					'group'     => '',
				)
			);
		}
		return $out;
	}

	/* ------------------------------------------------------------------
	 * Product page
	 * ---------------------------------------------------------------- */

	public static function enqueue() {
		$on_product = function_exists( 'is_product' ) && is_product() && self::yacht_for_product( get_the_ID() );
		$on_cart    = ( function_exists( 'is_cart' ) && is_cart() ) || ( function_exists( 'is_checkout' ) && is_checkout() );

		if ( ! $on_product && ! $on_cart ) {
			return;
		}
		// Nothing to show on a cart that holds no yacht bookings.
		if ( ! $on_product && $on_cart && ! self::cart_has_yacht() ) {
			return;
		}

		wp_enqueue_script( 'fy-fleet-addons', FY_FLEET_URL . 'assets/addons.js', array( 'jquery' ), FY_FLEET_VERSION, true );
		wp_enqueue_style( 'fy-fleet-addons', FY_FLEET_URL . 'assets/addons.css', array(), FY_FLEET_VERSION );

		wp_localize_script(
			'fy-fleet-addons',
			'fyAddons',
			array(
				'depositRatio' => FY_Fleet_Settings::get_addon_deposit_ratio(),
				'depositPct'   => round( FY_Fleet_Settings::get_addon_deposit_ratio() * 100 ),
				'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
				'nonce'        => wp_create_nonce( 'fy_addons_cart' ),
				'isCheckout'   => ( function_exists( 'is_checkout' ) && is_checkout() ) ? 1 : 0,
				'isCart'       => ( function_exists( 'is_cart' ) && is_cart() ) ? 1 : 0,
				'i18n'         => array(
					/* translators: %1$d max add-on hours, %2$s charter length */
					'hourCap'    => __( 'Up to %1$d hours on a %2$s charter — about 2 hours goes to departure and return.', 'fy-fleet' ),
					'needHours'  => __( 'Available on charters of %d hours or more.', 'fy-fleet' ),
					'quote'      => __( 'Custom quote — we’ll contact you', 'fy-fleet' ),
					'saving'     => __( 'Updating…', 'fy-fleet' ),
					'saveFailed' => __( 'Could not update your extras — please try again.', 'fy-fleet' ),
					'moreInfo'   => __( 'More Info', 'fy-fleet' ),
				),
			)
		);
	}

	/** True when at least one cart line is a yacht booking. */
	public static function cart_has_yacht() {
		if ( ! WC()->cart ) {
			return false;
		}
		foreach ( WC()->cart->get_cart() as $item ) {
			$product_id = ! empty( $item['product_id'] ) ? (int) $item['product_id'] : 0;
			if ( $product_id && self::yacht_for_product( $product_id ) ) {
				return true;
			}
		}
		return false;
	}

	/** Heading for the collapsed menu — "Catering Menu" unless renamed. */
	public static function menu_title( $groups ) {
		return ( count( $groups ) > 1 ) ? __( 'Catering Menu', 'fy-fleet' ) : (string) key( $groups );
	}

	/** True when something inside the menu is already chosen — so it opens. */
	public static function group_has_selection( $groups, $selected ) {
		if ( empty( $selected ) || ! is_array( $selected ) ) {
			return false;
		}
		foreach ( $groups as $items ) {
			foreach ( array_keys( $items ) as $key ) {
				if ( isset( $selected[ $key ] ) ) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * One add-on row: checkbox, price, and (where relevant) the hours and
	 * quantity selectors. Shared by the product page and the cart/checkout
	 * panel so the two can never drift apart.
	 *
	 * @param bool  $named    Whether to emit form field names (product page
	 *                        posts them; the cart panel saves over AJAX).
	 * @param array $selected Current selection, when re-rendering the cart.
	 */
	public static function render_row( $key, $addon, $named = true, $selected = null, $charter_hours = 0 ) {
		// Validate BEFORE printing anything — the wrapper below must never
		// exist for an add-on that didn't resolve to something showable.
		if ( ! self::addon_is_renderable( $addon ) ) {
			return;
		}
		$is_hours = ( 'hours' === $addon['unit'] );
		$max_qty  = max( 1, (int) $addon['max'] );
		$is_on    = is_array( $selected );
		$name     = $named ? 'fy_addons[' . $key . ']' : '';

		$cap = 0;
		if ( $is_hours ) {
			$cap = $charter_hours ? FY_Fleet_Settings::addon_max_hours( $addon, $charter_hours ) : 0;
		}
		$chosen_hours = ( $is_on && ! empty( $selected['hours'] ) ) ? (int) $selected['hours'] : 1;
		$chosen_qty   = ( $is_on && ! empty( $selected['qty'] ) ) ? (int) $selected['qty'] : 1;
		$blocked      = ( ! empty( $addon['min_hours'] ) && $charter_hours && $charter_hours < (float) $addon['min_hours'] );
		?>
		<div class="fy-addon<?php echo $blocked ? ' is-blocked' : ''; ?>"
			data-addon="<?php echo esc_attr( $key ); ?>"
			data-unit="<?php echo esc_attr( $addon['unit'] ); ?>"
			data-price="<?php echo esc_attr( $addon['price'] ); ?>"
			data-max-qty="<?php echo esc_attr( $max_qty ); ?>"
			data-min-hours="<?php echo esc_attr( $addon['min_hours'] ); ?>"
			data-reserve-hours="<?php echo esc_attr( $addon['reserve_hours'] ); ?>">

			<label class="fy-addon__row">
				<input type="checkbox" class="fy-addon__check" value="1"
					<?php echo $name ? 'name="' . esc_attr( $name ) . '[on]"' : ''; ?>
					<?php checked( $is_on ); ?> <?php disabled( $blocked ); ?>>
				<span class="fy-addon__label"><?php echo esc_html( $addon['label'] ); ?></span>
				<span class="fy-addon__price"><?php echo esc_html( self::price_label( $addon ) ); ?></span>
			</label>

			<?php if ( $is_hours ) : ?>
				<div class="fy-addon__hours" <?php echo $is_on ? '' : 'hidden'; ?>>
					<label>
						<?php esc_html_e( 'Hours:', 'fy-fleet' ); ?>
						<select class="fy-addon__hours-select" <?php echo $name ? 'name="' . esc_attr( $name ) . '[hours]"' : ''; ?>>
							<?php for ( $i = 1; $i <= max( 1, $cap ); $i++ ) : ?>
								<option value="<?php echo esc_attr( $i ); ?>" <?php selected( $chosen_hours, $i ); ?>><?php echo esc_html( $i ); ?></option>
							<?php endfor; ?>
						</select>
					</label>
					<?php if ( $max_qty > 1 ) : ?>
						<label>
							<?php esc_html_e( 'How many:', 'fy-fleet' ); ?>
							<select class="fy-addon__qty-select" <?php echo $name ? 'name="' . esc_attr( $name ) . '[qty]"' : ''; ?>>
								<?php for ( $q = 1; $q <= $max_qty; $q++ ) : ?>
									<option value="<?php echo esc_attr( $q ); ?>" <?php selected( $chosen_qty, $q ); ?>><?php echo esc_html( $q ); ?></option>
								<?php endfor; ?>
							</select>
						</label>
					<?php endif; ?>
					<span class="fy-addon__cap"></span>
				</div>
			<?php elseif ( $max_qty > 1 ) : ?>
				<div class="fy-addon__qty" <?php echo $is_on ? '' : 'hidden'; ?>>
					<label>
						<?php esc_html_e( 'Qty:', 'fy-fleet' ); ?>
						<select class="fy-addon__qty-select" <?php echo $name ? 'name="' . esc_attr( $name ) . '[qty]"' : ''; ?>>
							<?php for ( $q = 1; $q <= $max_qty; $q++ ) : ?>
								<option value="<?php echo esc_attr( $q ); ?>" <?php selected( $chosen_qty, $q ); ?>><?php echo esc_html( $q ); ?></option>
							<?php endfor; ?>
						</select>
					</label>
				</div>
			<?php endif; ?>

			<?php
			$more_info = self::more_info_link( $key );
			if ( ! empty( $addon['note'] ) || $more_info ) :
				?>
				<p class="fy-addon__note"><?php echo esc_html( $addon['note'] ); ?><?php echo wp_kses( $more_info, array( 'a' => array( 'class' => true, 'href' => true, 'target' => true, 'rel' => true ) ) ); ?></p>
			<?php endif; ?>

			<p class="fy-addon__blocked" <?php echo $blocked ? '' : 'hidden'; ?>>
				<?php
				if ( $blocked ) {
					printf(
						/* translators: %d: minimum charter hours */
						esc_html__( 'Available on charters of %d hours or more.', 'fy-fleet' ),
						(int) $addon['min_hours']
					);
				}
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * One choice set: a single checkbox for the add-on, plus a dropdown
	 * naming which version of it. Only the picked member is ever posted, so
	 * resolve() sees exactly what it sees for a plain row and needs no
	 * special case.
	 */
	public static function render_choice_row( $label, $items, $named = true, $selected = null, $charter_hours = 0 ) {
		// Drop any member that didn't resolve, same as a plain row would —
		// a choice set is just several add-ons sharing one card, so it needs
		// the same "nothing to show, print nothing" guarantee.
		$items = array_filter( $items, array( __CLASS__, 'addon_is_renderable' ) );
		if ( '' === trim( (string) $label ) || empty( $items ) ) {
			return;
		}

		$state    = self::choice_state( $items, $selected );
		$key      = $state['key'];
		if ( '' === $key || ! isset( $items[ $key ] ) ) {
			return;
		}
		$addon    = $items[ $key ];
		$is_on    = is_array( $state['selected'] );
		$name     = $named ? 'fy_addons[' . $key . ']' : '';
		$max_qty  = max( 1, (int) $addon['max'] );
		$chosen_q = ( $is_on && ! empty( $state['selected']['qty'] ) ) ? (int) $state['selected']['qty'] : 1;
		?>
		<div class="fy-addon fy-addon--choice"
			data-addon="<?php echo esc_attr( $key ); ?>"
			data-choice="<?php echo esc_attr( $label ); ?>"
			data-named="<?php echo $named ? '1' : '0'; ?>"
			data-unit="<?php echo esc_attr( $addon['unit'] ); ?>"
			data-price="<?php echo esc_attr( $addon['price'] ); ?>"
			data-max-qty="<?php echo esc_attr( $max_qty ); ?>"
			data-min-hours="0"
			data-reserve-hours="0">

			<label class="fy-addon__row">
				<input type="checkbox" class="fy-addon__check" value="1"
					<?php echo $name ? 'name="' . esc_attr( $name ) . '[on]"' : ''; ?>
					<?php checked( $is_on ); ?>>
				<span class="fy-addon__label"><?php echo esc_html( $label ); ?></span>
				<span class="fy-addon__price"><?php echo esc_html( self::price_label( $addon ) ); ?></span>
			</label>

			<div class="fy-addon__variant-wrap">
				<label>
					<?php esc_html_e( 'Option:', 'fy-fleet' ); ?>
					<select class="fy-addon__variant">
						<?php foreach ( $items as $opt_key => $opt ) : ?>
							<option value="<?php echo esc_attr( $opt_key ); ?>"
								data-price="<?php echo esc_attr( $opt['price'] ); ?>"
								data-unit="<?php echo esc_attr( $opt['unit'] ); ?>"
								data-max-qty="<?php echo esc_attr( max( 1, (int) $opt['max'] ) ); ?>"
								data-note="<?php echo esc_attr( $opt['note'] ); ?>"
								data-more-info="<?php echo esc_url( self::service_url( $opt_key ) ); ?>"
								data-label="<?php echo esc_attr( $opt['label'] ); ?>"
								data-price-label="<?php echo esc_attr( self::price_label( $opt ) ); ?>"
								<?php selected( $key, $opt_key ); ?>>
								<?php
								printf(
									/* translators: %1$s: option name, %2$s: price */
									esc_html__( '%1$s — %2$s', 'fy-fleet' ),
									esc_html( $opt['label'] ),
									esc_html( self::price_label( $opt ) )
								);
								?>
							</option>
						<?php endforeach; ?>
					</select>
				</label>
				<?php if ( $max_qty > 1 ) : ?>
					<label class="fy-addon__qty" <?php echo $is_on ? '' : 'hidden'; ?>>
						<?php esc_html_e( 'Qty:', 'fy-fleet' ); ?>
						<select class="fy-addon__qty-select" <?php echo $name ? 'name="' . esc_attr( $name ) . '[qty]"' : ''; ?>>
							<?php for ( $q = 1; $q <= $max_qty; $q++ ) : ?>
								<option value="<?php echo esc_attr( $q ); ?>" <?php selected( $chosen_q, $q ); ?>><?php echo esc_html( $q ); ?></option>
							<?php endfor; ?>
						</select>
					</label>
				<?php endif; ?>
			</div>

			<?php $choice_more_info = self::more_info_link( $key ); ?>
			<p class="fy-addon__note" <?php echo ( empty( $addon['note'] ) && ! $choice_more_info ) ? 'hidden' : ''; ?>><?php echo esc_html( $addon['note'] ); ?><?php echo wp_kses( $choice_more_info, array( 'a' => array( 'class' => true, 'href' => true, 'target' => true, 'rel' => true ) ) ); ?></p>
		</div>
		<?php
	}

	/**
	 * Render whichever kind of block partition() handed back.
	 *
	 * render_row()/render_choice_row() already refuse to print anything for
	 * an add-on that doesn't resolve, so this dispatcher needs no extra
	 * validation of its own — it just needs to never be the reason a
	 * malformed block reaches them with the wrong shape (e.g. a 'choice'
	 * block whose 'items' key went missing).
	 */
	public static function render_block( $block, $named = true, $selected = null, $charter_hours = 0 ) {
		if ( 'choice' === $block['type'] ) {
			self::render_choice_row( $block['label'], isset( $block['items'] ) ? $block['items'] : array(), $named, $selected, $charter_hours );
			return;
		}
		$key = isset( $block['key'] ) ? $block['key'] : '';
		$one = ( is_array( $selected ) && isset( $selected[ $key ] ) ) ? $selected[ $key ] : null;
		self::render_row( $key, isset( $block['addon'] ) ? $block['addon'] : array(), $named, $one, $charter_hours );
	}

	/** Checkboxes under the variation selectors. */
	public static function render_fields() {
		global $product;
		if ( ! $product ) {
			return;
		}
		$yacht_id = self::yacht_for_product( $product->get_id() );
		if ( ! $yacht_id ) {
			return;
		}
		$catalog = self::catalog( $yacht_id );
		if ( empty( $catalog ) ) {
			return;
		}

		$ratio = FY_Fleet_Settings::get_addon_deposit_ratio();
		$pct   = round( $ratio * 100 );
		?>
		<div class="fy-addons" id="fy-addons">
			<h4 class="fy-addons__title">✨ <?php esc_html_e( 'Add to your experience', 'fy-fleet' ); ?></h4>
			<p class="fy-addons__intro">
				<?php
				printf(
					/* translators: %d: percentage charged online */
					esc_html__( 'Optional extras. %d%% is charged with your booking, the rest is paid at the dock.', 'fy-fleet' ),
					(int) $pct
				);
				?>
			</p>

			<?php $split = self::partition( $catalog ); ?>

			<?php foreach ( $split['blocks'] as $block ) : ?>
				<?php self::render_block( $block, true ); ?>
			<?php endforeach; ?>

			<?php foreach ( $split['groups'] as $group_name => $items ) : ?>
				<?php /* Whole catering menu behind one obvious expander. */ ?>
				<details class="fy-addon-menu">
					<summary class="fy-addon-menu__summary">
						<span class="fy-addon-menu__title">🍽️ <?php echo esc_html( self::menu_title( $split['groups'] ) ); ?></span>
						<span class="fy-addon-menu__hint"><?php esc_html_e( 'Tap to browse the menu', 'fy-fleet' ); ?></span>
						<span class="fy-addon-menu__arrow" aria-hidden="true">▾</span>
					</summary>
					<?php
					// Every group renders inside this ONE expander.
					foreach ( $split['groups'] as $section => $section_items ) :
						?>
						<p class="fy-addon-menu__section"><?php echo esc_html( $section ); ?></p>
						<?php foreach ( $section_items as $key => $addon ) : ?>
							<?php self::render_row( $key, $addon, true ); ?>
						<?php endforeach; ?>
					<?php endforeach; ?>
					<p class="fy-addon-menu__foot"><?php esc_html_e( 'Setup and delivery available on request — every menu can be customised for your charter.', 'fy-fleet' ); ?></p>
				</details>
				<?php break; // The loop above already printed every section. ?>
			<?php endforeach; ?>

			<?php if ( isset( $catalog['jet-ski'] ) ) : ?>
				<p class="fy-addons__watersports">
					🌊 <strong><?php esc_html_e( 'About water sports:', 'fy-fleet' ); ?></strong>
					<?php esc_html_e( 'Jet skis run on a set schedule, usually 1–1½ hours after departure, and are booked back-to-back with other charters. If you arrive late that time can’t always be made up — we’ll do our best, but we can’t promise it.', 'fy-fleet' ); ?>
				</p>
			<?php endif; ?>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------
	 * Cart / checkout — the same controls, editable in place
	 * ---------------------------------------------------------------- */

	/** Charter length for a cart line (stored at add-to-cart, else derived). */
	public static function cart_item_hours( $cart_item ) {
		if ( ! empty( $cart_item[ self::CART_KEY ]['hours'] ) ) {
			return (float) $cart_item[ self::CART_KEY ]['hours'];
		}
		$variation_id = ! empty( $cart_item['variation_id'] ) ? (int) $cart_item['variation_id'] : 0;
		return self::charter_hours( $variation_id );
	}

	/** The add-ons currently on a cart line, keyed by add-on key. */
	private static function selected_map( $cart_item ) {
		$map = array();
		if ( empty( $cart_item[ self::CART_KEY ]['lines'] ) ) {
			return $map;
		}
		foreach ( $cart_item[ self::CART_KEY ]['lines'] as $line ) {
			$map[ $line['key'] ] = $line;
		}
		return $map;
	}

	/**
	 * Editable add-ons for every yacht line in the cart. Rendered above the
	 * totals on the cart page and above the order review at checkout, so a
	 * customer can still change their mind without going back to the product.
	 */
	public static function render_cart_panel() {
		if ( ! WC()->cart || WC()->cart->is_empty() ) {
			return;
		}

		foreach ( WC()->cart->get_cart() as $cart_key => $cart_item ) {
			$product_id = ! empty( $cart_item['product_id'] ) ? (int) $cart_item['product_id'] : 0;
			$yacht_id   = $product_id ? self::yacht_for_product( $product_id ) : 0;
			if ( ! $yacht_id ) {
				continue;
			}
			$catalog = self::catalog( $yacht_id );
			if ( empty( $catalog ) ) {
				continue;
			}

			$hours    = self::cart_item_hours( $cart_item );
			$selected = self::selected_map( $cart_item );
			$pct      = round( FY_Fleet_Settings::get_addon_deposit_ratio() * 100 );
			?>
			<div class="fy-addons fy-addons--cart"
				data-cart-key="<?php echo esc_attr( $cart_key ); ?>"
				data-hours="<?php echo esc_attr( $hours ); ?>">

				<h4 class="fy-addons__title">✨ <?php echo esc_html( sprintf( __( 'Extras for %s', 'fy-fleet' ), get_the_title( $product_id ) ) ); ?></h4>
				<p class="fy-addons__intro">
					<?php
					printf(
						/* translators: %d: percentage charged online */
						esc_html__( 'Change these any time before you pay. %d%% is charged now, the rest at the dock.', 'fy-fleet' ),
						(int) $pct
					);
					?>
				</p>

				<?php $split = self::partition( $catalog ); ?>

				<?php foreach ( $split['blocks'] as $block ) : ?>
					<?php self::render_block( $block, false, $selected, $hours ); ?>
				<?php endforeach; ?>

				<?php if ( ! empty( $split['groups'] ) ) : ?>
					<details class="fy-addon-menu"<?php echo self::group_has_selection( $split['groups'], $selected ) ? ' open' : ''; ?>>
						<summary class="fy-addon-menu__summary">
							<span class="fy-addon-menu__title">🍽️ <?php echo esc_html( self::menu_title( $split['groups'] ) ); ?></span>
							<span class="fy-addon-menu__hint"><?php esc_html_e( 'Tap to browse the menu', 'fy-fleet' ); ?></span>
							<span class="fy-addon-menu__arrow" aria-hidden="true">▾</span>
						</summary>
						<?php foreach ( $split['groups'] as $section => $section_items ) : ?>
							<p class="fy-addon-menu__section"><?php echo esc_html( $section ); ?></p>
							<?php foreach ( $section_items as $key => $addon ) : ?>
								<?php self::render_row( $key, $addon, false, isset( $selected[ $key ] ) ? $selected[ $key ] : null, $hours ); ?>
							<?php endforeach; ?>
						<?php endforeach; ?>
						<p class="fy-addon-menu__foot"><?php esc_html_e( 'Setup and delivery available on request — every menu can be customised for your charter.', 'fy-fleet' ); ?></p>
					</details>
				<?php endif; ?>

				<?php if ( isset( $catalog['jet-ski'] ) ) : ?>
					<p class="fy-addons__watersports">
						🌊 <strong><?php esc_html_e( 'About water sports:', 'fy-fleet' ); ?></strong>
						<?php esc_html_e( 'Jet skis run on a set schedule, usually 1–1½ hours after departure, and are booked back-to-back with other charters. If you arrive late that time can’t always be made up — we’ll do our best, but we can’t promise it.', 'fy-fleet' ); ?>
					</p>
				<?php endif; ?>

				<p class="fy-addons__status" aria-live="polite"></p>
			</div>
			<?php
		}
	}

	/**
	 * Save an edited add-on selection for one cart line.
	 *
	 * Re-resolves everything from the catalog and the line's own charter
	 * length — the posted values only say WHICH add-ons and how many hours,
	 * never the price, so this cannot be used to discount a booking.
	 */
	public static function ajax_update() {
		check_ajax_referer( 'fy_addons_cart', 'nonce' );

		if ( ! WC()->cart ) {
			wp_send_json_error( array( 'message' => __( 'Your cart is not available.', 'fy-fleet' ) ) );
		}

		$cart_key = isset( $_POST['cart_key'] ) ? sanitize_text_field( wp_unslash( $_POST['cart_key'] ) ) : '';
		$contents = WC()->cart->get_cart();
		if ( '' === $cart_key || ! isset( $contents[ $cart_key ] ) ) {
			wp_send_json_error( array( 'message' => __( 'That booking is no longer in your cart.', 'fy-fleet' ) ) );
		}

		$cart_item  = $contents[ $cart_key ];
		$product_id = ! empty( $cart_item['product_id'] ) ? (int) $cart_item['product_id'] : 0;
		$yacht_id   = $product_id ? self::yacht_for_product( $product_id ) : 0;
		if ( ! $yacht_id ) {
			wp_send_json_error( array( 'message' => __( 'That item does not take add-ons.', 'fy-fleet' ) ) );
		}

		$posted = isset( $_POST['addons'] ) && is_array( $_POST['addons'] ) ? wp_unslash( $_POST['addons'] ) : array();
		$hours  = self::cart_item_hours( $cart_item );
		$result = self::resolve( $yacht_id, $posted, $hours );

		if ( empty( $result['lines'] ) ) {
			unset( WC()->cart->cart_contents[ $cart_key ][ self::CART_KEY ] );
		} else {
			WC()->cart->cart_contents[ $cart_key ][ self::CART_KEY ] = array(
				'lines' => $result['lines'],
				'total' => $result['total'],
				'hours' => $hours,
			);
		}

		WC()->cart->set_session();
		WC()->cart->calculate_totals();

		$ratio = FY_Fleet_Settings::get_addon_deposit_ratio();
		wp_send_json_success(
			array(
				'total'  => $result['total'],
				'now'    => round( $result['total'] * $ratio, 2 ),
				'later'  => round( $result['total'] - ( $result['total'] * $ratio ), 2 ),
				'errors' => $result['errors'],
			)
		);
	}

	/* ------------------------------------------------------------------
	 * Cart
	 * ---------------------------------------------------------------- */

	/**
	 * Read the submitted add-ons and price them against the charter length
	 * — the authoritative pass. Anything the customer could not legitimately
	 * have selected (charter too short, more hours than the cap) is rejected
	 * here regardless of what the form posted.
	 *
	 * @return array{lines:array,total:float,errors:string[]}
	 */
	public static function resolve( $yacht_id, $posted, $charter_hours ) {
		$catalog = self::catalog( $yacht_id );
		$lines   = array();
		$total   = 0.0;
		$errors  = array();

		if ( ! is_array( $posted ) ) {
			return array( 'lines' => $lines, 'total' => $total, 'errors' => $errors );
		}

		// One pick per choice set. The dropdown can only ever post a single
		// member, but the cart accepts whatever is sent, so enforce it here —
		// otherwise a hand-made request could book Open Bar twice.
		$choice_taken = array();

		foreach ( $posted as $key => $data ) {
			$key = sanitize_text_field( $key );
			if ( ! isset( $catalog[ $key ] ) || empty( $data['on'] ) ) {
				continue;
			}
			$addon = $catalog[ $key ];

			$group = isset( $addon['group'] ) ? (string) $addon['group'] : '';
			if ( 0 === strpos( $group, self::CHOICE_PREFIX ) ) {
				if ( isset( $choice_taken[ $group ] ) ) {
					continue;
				}
				$choice_taken[ $group ] = true;
			}

			// Charter long enough for this add-on?
			if ( ! empty( $addon['min_hours'] ) && $charter_hours < (float) $addon['min_hours'] ) {
				$errors[] = sprintf(
					/* translators: 1: add-on name, 2: minimum hours */
					__( '%1$s is only available on charters of %2$d hours or more.', 'fy-fleet' ),
					$addon['label'],
					(int) $addon['min_hours']
				);
				continue;
			}

			$hours = 0;
			$qty   = 1;
			$line  = 0.0;

			switch ( $addon['unit'] ) {
				case 'quote':
					$line = 0.0; // Priced by hand after booking.
					break;

				case 'hour':
					$line = (float) $addon['price'] * max( 1, $charter_hours );
					break;

				case 'hours':
					$cap   = FY_Fleet_Settings::addon_max_hours( $addon, $charter_hours );
					$hours = isset( $data['hours'] ) ? max( 1, intval( $data['hours'] ) ) : 1;
					if ( $cap < 1 ) {
						continue 2;
					}
					if ( $hours > $cap ) {
						$hours    = $cap;
						$errors[] = sprintf(
							/* translators: 1: add-on name, 2: capped hours */
							__( '%1$s was reduced to %2$d hours — departure and return take about 2 hours of your charter.', 'fy-fleet' ),
							self::full_label( $addon ),
							$cap
						);
					}
					// Several of the same toy can be booked (6 jet skis), and
					// each one is charged for the full hours picked.
					$max_qty = max( 1, (int) $addon['max'] );
					$qty     = isset( $data['qty'] ) ? max( 1, min( $max_qty, intval( $data['qty'] ) ) ) : 1;
					$line    = (float) $addon['price'] * $hours * $qty;
					break;

				default: // flat
					$max  = max( 1, (int) $addon['max'] );
					$qty  = isset( $data['qty'] ) ? max( 1, min( $max, intval( $data['qty'] ) ) ) : 1;
					$line = (float) $addon['price'] * $qty;
			}

			$lines[] = array(
				'key'   => $key,
				'label' => self::full_label( $addon ),
				'unit'  => $addon['unit'],
				'price' => (float) $addon['price'],
				'hours' => $hours,
				'qty'   => $qty,
				'total' => round( $line, 2 ),
				'quote' => ( 'quote' === $addon['unit'] ),
			);
			$total += $line;
		}

		return array( 'lines' => $lines, 'total' => round( $total, 2 ), 'errors' => $errors );
	}

	/** Charter hours for a product/variation pair. */
	public static function charter_hours( $variation_id ) {
		if ( ! $variation_id || ! class_exists( 'FY_Fleet_Pricing' ) ) {
			return 0.0;
		}
		$variation = wc_get_product( $variation_id );
		if ( ! $variation ) {
			return 0.0;
		}
		foreach ( $variation->get_attributes() as $name => $value ) {
			if ( false === stripos( (string) $name, 'charter-duration' ) ) {
				continue;
			}
			$hours = FY_Fleet_Pricing::hours_from_label( str_replace( array( '-', '_' ), ' ', (string) $value ) );
			if ( $hours > 0 ) {
				return $hours;
			}
		}
		return 0.0;
	}

	/** Block add-to-cart with a clear message when a choice isn't allowed. */
	public static function validate( $passed, $product_id, $quantity, $variation_id = 0 ) {
		if ( empty( $_POST['fy_addons'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce owns this form's nonce
			return $passed;
		}
		$yacht_id = self::yacht_for_product( $product_id );
		if ( ! $yacht_id ) {
			return $passed;
		}

		$hours  = self::charter_hours( $variation_id );
		$result = self::resolve( $yacht_id, wp_unslash( $_POST['fy_addons'] ), $hours ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

		// Only a hard block (charter too short) stops the add; an
		// over-cap selection is silently corrected down and reported.
		foreach ( $result['errors'] as $message ) {
			wc_add_notice( $message, 'notice' );
		}
		return $passed;
	}

	public static function capture( $cart_item_data, $product_id, $variation_id ) {
		if ( empty( $_POST['fy_addons'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce owns this form's nonce
			return $cart_item_data;
		}
		$yacht_id = self::yacht_for_product( $product_id );
		if ( ! $yacht_id ) {
			return $cart_item_data;
		}

		$hours  = self::charter_hours( $variation_id );
		$result = self::resolve( $yacht_id, wp_unslash( $_POST['fy_addons'] ), $hours ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( empty( $result['lines'] ) ) {
			return $cart_item_data;
		}

		$cart_item_data[ self::CART_KEY ] = array(
			'lines' => $result['lines'],
			'total' => $result['total'],
			'hours' => $hours,
		);
		// Two identical yachts with different extras must stay separate lines.
		$cart_item_data['fy_addons_hash'] = md5( wp_json_encode( $result['lines'] ) );

		return $cart_item_data;
	}

	/**
	 * Add the online share of the add-ons to the line price. Runs at
	 * priority 25 — after FY_Fleet_Woo::apply_deposit_price (20) has settled
	 * the base charge, so this only ever adds on top.
	 */
	public static function apply_price( $cart ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
			return;
		}
		$ratio = FY_Fleet_Settings::get_addon_deposit_ratio();

		foreach ( $cart->get_cart() as $item ) {
			if ( empty( $item[ self::CART_KEY ]['total'] ) || empty( $item['data'] ) ) {
				continue;
			}
			$addons_now = round( (float) $item[ self::CART_KEY ]['total'] * $ratio, 2 );
			if ( $addons_now <= 0 ) {
				continue;
			}
			$item['data']->set_price( (float) $item['data']->get_price() + $addons_now );
		}
	}

	/** Show the chosen extras in the cart and on the checkout review table. */
	public static function display( $item_data, $cart_item ) {
		if ( empty( $cart_item[ self::CART_KEY ]['lines'] ) ) {
			return $item_data;
		}
		$ratio = FY_Fleet_Settings::get_addon_deposit_ratio();
		$total = (float) $cart_item[ self::CART_KEY ]['total'];

		$lines = array();
		foreach ( $cart_item[ self::CART_KEY ]['lines'] as $line ) {
			$lines[] = self::line_label( $line );
		}

		$item_data[] = array(
			'key'   => __( '✨ Add-ons', 'fy-fleet' ),
			'value' => implode( '<br>', $lines ),
		);
		if ( $total > 0 ) {
			$item_data[] = array(
				'key'   => __( 'Add-ons charged today', 'fy-fleet' ),
				'value' => sprintf(
					/* translators: 1: amount now, 2: amount at the dock */
					__( '%1$s now · %2$s at the dock', 'fy-fleet' ),
					wp_strip_all_tags( wc_price( round( $total * $ratio, 2 ) ) ),
					wp_strip_all_tags( wc_price( round( $total - ( $total * $ratio ), 2 ) ) )
				),
			);
		}
		return $item_data;
	}

	/** "Jet Ski — 2 hrs — $300" / "Private Chef — custom quote". */
	public static function line_label( $line ) {
		if ( ! empty( $line['quote'] ) ) {
			return esc_html( $line['label'] ) . ' — <em>' . esc_html__( 'custom quote, we’ll contact you', 'fy-fleet' ) . '</em>';
		}
		$bits = array( esc_html( $line['label'] ) );
		if ( 'hours' === $line['unit'] && ! empty( $line['hours'] ) ) {
			/* translators: %d: hours */
			$bits[] = sprintf( esc_html__( '%d hrs', 'fy-fleet' ), (int) $line['hours'] );
		}
		if ( ! empty( $line['qty'] ) && $line['qty'] > 1 ) {
			$bits[] = '×' . (int) $line['qty'];
		}
		$bits[] = wp_strip_all_tags( wc_price( (float) $line['total'] ) );
		return implode( ' — ', $bits );
	}

	/** Persist onto the order so emails, staff and the webhook all see it. */
	public static function order_line_meta( $item, $cart_item_key, $values, $order ) {
		if ( empty( $values[ self::CART_KEY ]['lines'] ) ) {
			return;
		}
		$data  = $values[ self::CART_KEY ];
		$ratio = FY_Fleet_Settings::get_addon_deposit_ratio();
		$total = (float) $data['total'];
		$now   = round( $total * $ratio, 2 );

		$item->add_meta_data( '_fy_addons_raw', wp_json_encode( $data['lines'] ), true );
		$item->add_meta_data( '_fy_addons_total', $total, true );
		$item->add_meta_data( '_fy_addons_paid', $now, true );
		$item->add_meta_data( '_fy_addons_due', round( $total - $now, 2 ), true );

		$labels = array();
		foreach ( $data['lines'] as $line ) {
			$labels[] = wp_strip_all_tags( self::line_label( $line ) );
		}
		$item->add_meta_data( __( 'Add-ons', 'fy-fleet' ), implode( ' · ', $labels ), true );
	}
}
