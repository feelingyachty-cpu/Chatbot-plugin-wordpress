<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * City fleet landing pages at /yacht-category/{fleet}/.
 *
 * Each fleet term gets an editable H1, intro copy (the term description) and
 * SEO title/description; the page renders that intro above the live grid,
 * filtered to the fleet.
 */
class FY_Fleet_Pages {

	public static function init() {
		add_filter( 'template_include', array( __CLASS__, 'template' ) );

		add_action( 'fy_yacht_cat_add_form_fields', array( __CLASS__, 'add_fields' ) );
		add_action( 'fy_yacht_cat_edit_form_fields', array( __CLASS__, 'edit_fields' ) );
		add_action( 'created_fy_yacht_cat', array( __CLASS__, 'save_fields' ) );
		add_action( 'edited_fy_yacht_cat', array( __CLASS__, 'save_fields' ) );

		add_action( 'wp_head', array( __CLASS__, 'seo_head' ), 1 );
		add_filter( 'document_title_parts', array( __CLASS__, 'seo_title' ) );

		// City hubs had no description at all — the term description is
		// empty, so Rank Math had nothing to work from. Feed it a real one
		// rather than printing a competing tag of our own.
		add_filter( 'rank_math/frontend/description', array( __CLASS__, 'fleet_description' ) );
		add_filter( 'wpseo_metadesc', array( __CLASS__, 'fleet_description' ) );
	}

	public static function template( $template ) {
		if ( is_tax( 'fy_yacht_cat' ) ) {
			$plugin_template = FY_FLEET_DIR . 'templates/taxonomy-fleet.php';
			if ( file_exists( $plugin_template ) ) {
				return $plugin_template;
			}
		}
		return $template;
	}

	/* ------------------------------------------------------------------
	 * Term fields
	 * ---------------------------------------------------------------- */

	public static function add_fields() {
		wp_nonce_field( 'fy_fleet_term', 'fy_fleet_term_nonce' );
		?>
		<div class="form-field">
			<label for="fy_page_h1"><?php esc_html_e( 'Landing page H1', 'fy-fleet' ); ?></label>
			<input type="text" id="fy_page_h1" name="fy_page_h1" value="">
			<p><?php esc_html_e( 'Big heading on this fleet\'s landing page, e.g. "Panama Yacht Rentals & Charters". Leave blank to use the category name. The Description box above becomes the intro copy under the heading.', 'fy-fleet' ); ?></p>
		</div>
		<div class="form-field">
			<label for="fy_term_seo_title"><?php esc_html_e( 'Meta title', 'fy-fleet' ); ?></label>
			<input type="text" id="fy_term_seo_title" name="fy_term_seo_title" value="">
		</div>
		<div class="form-field">
			<label for="fy_term_seo_desc"><?php esc_html_e( 'Meta description', 'fy-fleet' ); ?></label>
			<textarea id="fy_term_seo_desc" name="fy_term_seo_desc" rows="3"></textarea>
		</div>
		<?php
	}

	public static function edit_fields( $term ) {
		wp_nonce_field( 'fy_fleet_term', 'fy_fleet_term_nonce' );
		$h1    = get_term_meta( $term->term_id, 'fy_page_h1', true );
		$title = get_term_meta( $term->term_id, 'fy_term_seo_title', true );
		$desc  = get_term_meta( $term->term_id, 'fy_term_seo_desc', true );
		?>
		<tr class="form-field">
			<th><label for="fy_page_h1"><?php esc_html_e( 'Landing page H1', 'fy-fleet' ); ?></label></th>
			<td><input type="text" id="fy_page_h1" name="fy_page_h1" value="<?php echo esc_attr( $h1 ); ?>">
			<p class="description"><?php esc_html_e( 'Big heading on the landing page. The Description above is the intro copy. View the page at the URL shown in the Slug row: /yacht-category/{slug}/', 'fy-fleet' ); ?></p></td>
		</tr>
		<tr class="form-field">
			<th><label for="fy_term_seo_title"><?php esc_html_e( 'Meta title', 'fy-fleet' ); ?></label></th>
			<td><input type="text" id="fy_term_seo_title" name="fy_term_seo_title" value="<?php echo esc_attr( $title ); ?>"></td>
		</tr>
		<tr class="form-field">
			<th><label for="fy_term_seo_desc"><?php esc_html_e( 'Meta description', 'fy-fleet' ); ?></label></th>
			<td><textarea id="fy_term_seo_desc" name="fy_term_seo_desc" rows="3"><?php echo esc_textarea( $desc ); ?></textarea></td>
		</tr>
		<?php
	}

	public static function save_fields( $term_id ) {
		if ( ! isset( $_POST['fy_fleet_term_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fy_fleet_term_nonce'] ) ), 'fy_fleet_term' ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_categories' ) ) {
			return;
		}
		update_term_meta( $term_id, 'fy_page_h1', isset( $_POST['fy_page_h1'] ) ? sanitize_text_field( wp_unslash( $_POST['fy_page_h1'] ) ) : '' );
		update_term_meta( $term_id, 'fy_term_seo_title', isset( $_POST['fy_term_seo_title'] ) ? sanitize_text_field( wp_unslash( $_POST['fy_term_seo_title'] ) ) : '' );
		update_term_meta( $term_id, 'fy_term_seo_desc', isset( $_POST['fy_term_seo_desc'] ) ? sanitize_textarea_field( wp_unslash( $_POST['fy_term_seo_desc'] ) ) : '' );
	}

	/* ------------------------------------------------------------------
	 * SEO output for the landing page
	 * ---------------------------------------------------------------- */

	/**
	 * A city term's display name, humanized when it looks like a raw slug.
	 *
	 * A term created programmatically (bulk import, REST, WP-CLI) can end up
	 * with its slug AS its name — "miami-yacht-rental" instead of "Miami
	 * Yacht Rental" — because nobody typed a real name in at creation time.
	 * That raw string then leaks into the page title, the H1 fallback and
	 * any auto-built meta description, which is the kind of thin, unpolished
	 * signal on-page SEO wants to avoid. Detect that shape (all lowercase,
	 * hyphen-joined, no spaces) and title-case it; a term someone already
	 * named properly is returned untouched.
	 */
	public static function readable_term_name( $term ) {
		$name = $term->name;
		if ( preg_match( '/^[a-z0-9]+(-[a-z0-9]+)+$/', $name ) ) {
			return ucwords( str_replace( '-', ' ', $name ) );
		}
		return $name;
	}

	/**
	 * Description for a city hub: the term's own intro copy when it has one,
	 * otherwise a sentence built from what's actually in that fleet.
	 */
	public static function fleet_description( $desc ) {
		if ( ! is_tax( 'fy_yacht_cat' ) ) {
			return $desc;
		}
		if ( '' !== trim( (string) $desc ) ) {
			return $desc;
		}
		$term   = get_queried_object();
		$custom = get_term_meta( $term->term_id, 'fy_term_seo_desc', true );
		if ( $custom ) {
			return $custom;
		}
		$intro = trim( wp_strip_all_tags( term_description( $term ) ) );
		if ( '' !== $intro ) {
			return wp_trim_words( $intro, 30, '…' );
		}
		$city  = self::readable_term_name( $term );
		$count = (int) $term->count;
		return $count
			? sprintf(
				/* translators: 1: number of yachts, 2: city name */
				__( 'Browse %1$d private yachts available to charter in %2$s. Compare sizes, guest capacity and hourly pricing, then book your date online.', 'fy-fleet' ),
				$count,
				$city
			)
			: sprintf(
				/* translators: %s: city name */
				__( 'Browse private yachts available to charter in %s. Compare sizes, guest capacity and hourly pricing, then book your date online.', 'fy-fleet' ),
				$city
			);
	}

	public static function seo_title( $parts ) {
		if ( is_tax( 'fy_yacht_cat' ) ) {
			$term   = get_queried_object();
			$custom = get_term_meta( $term->term_id, 'fy_term_seo_title', true );
			$parts['title'] = $custom ? $custom : self::readable_term_name( $term );
		}
		return $parts;
	}

	public static function seo_head() {
		if ( ! is_tax( 'fy_yacht_cat' ) ) {
			return;
		}
		if ( ! FY_Fleet_SEO::should_output_meta() ) {
			return; // Rank Math/Yoast/etc. already own canonical + description here — a second copy of either is worse than neither.
		}
		$term = get_queried_object();

		// One canonical URL per fleet even if the same yachts are ever
		// reachable through more than one term or page — a real risk here,
		// since duplicate/near-duplicate city terms are how this plugin's
		// bulk importer can end up naming things (e.g. a plural and a
		// singular variant of the same city).
		echo '<link rel="canonical" href="' . esc_url( get_term_link( $term ) ) . '">' . "\n";

		$desc = get_term_meta( $term->term_id, 'fy_term_seo_desc', true );
		if ( ! $desc ) {
			$intro = wp_strip_all_tags( term_description( $term ) );
			$desc  = $intro ? $intro : sprintf(
				/* translators: %s: fleet/city name */
				__( 'Browse the %s fleet and book a private yacht charter online.', 'fy-fleet' ),
				self::readable_term_name( $term )
			);
		}
		echo '<meta name="description" content="' . esc_attr( wp_trim_words( wp_strip_all_tags( $desc ), 30 ) ) . '">' . "\n";
	}
}
