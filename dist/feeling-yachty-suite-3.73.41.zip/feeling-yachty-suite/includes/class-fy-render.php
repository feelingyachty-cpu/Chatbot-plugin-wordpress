<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class FY_Fleet_Render {

	private static $instance_counter = 0;
	private static $assets_printed  = false;
	private static $meta_flush_done = false;

	public static function init() {
		add_shortcode( 'fy_yacht_fleet', array( __CLASS__, 'shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'wp_ajax_fy_yacht_photos', array( __CLASS__, 'ajax_yacht_photos' ) );
		add_action( 'wp_ajax_nopriv_fy_yacht_photos', array( __CLASS__, 'ajax_yacht_photos' ) );
		add_action( 'wp_ajax_fy_saved_summary', array( __CLASS__, 'ajax_saved_summary' ) );
		add_action( 'wp_ajax_nopriv_fy_saved_summary', array( __CLASS__, 'ajax_saved_summary' ) );

		/*
		 * Cache invalidation. A grid showing yesterday's price is worse than
		 * a slow grid, so this errs heavily toward flushing:
		 *  - any yacht created/edited/trashed/restored/deleted
		 *  - any yacht meta written directly (importer, bulk re-sync, the
		 *    marina coordinate migration) — save_post does NOT fire for
		 *    update_post_meta(), which would otherwise leave prices stale
		 *    after a "Re-sync all yacht products" run
		 *  - the plugin's own settings (headings, colours, deposit rule)
		 *  - a yacht's featured image or gallery attachment being edited
		 */
		add_action( 'save_post_' . FY_Fleet_CPT::POST_TYPE, array( __CLASS__, 'flush_cache' ) );
		add_action( 'deleted_post', array( __CLASS__, 'flush_cache_for_post' ) );
		add_action( 'trashed_post', array( __CLASS__, 'flush_cache_for_post' ) );
		add_action( 'untrashed_post', array( __CLASS__, 'flush_cache_for_post' ) );
		add_action( 'updated_post_meta', array( __CLASS__, 'flush_cache_on_meta' ), 10, 3 );
		add_action( 'added_post_meta', array( __CLASS__, 'flush_cache_on_meta' ), 10, 3 );
		add_action( 'update_option_fy_fleet_options', array( __CLASS__, 'flush_cache' ) );
		add_action( 'update_option_fy_fleet_booking', array( __CLASS__, 'flush_cache' ) );
		add_action( 'edit_attachment', array( __CLASS__, 'flush_cache' ) );
		add_action( 'admin_post_fy_flush_grid_cache', array( __CLASS__, 'handle_flush_cache' ) );
	}

	/** "Refresh fleet page" button — the manual escape hatch. */
	public static function handle_flush_cache() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		check_admin_referer( 'fy_flush_grid_cache' );

		self::flush_cache();

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'cache.flush', 'Fleet page cache cleared manually' );
		}

		wp_safe_redirect(
			add_query_arg(
				array( 'page' => 'fy-fleet-visualizer', 'post_type' => FY_Fleet_CPT::POST_TYPE, 'fy_cache_cleared' => 1 ),
				admin_url( 'edit.php' )
			)
		);
		exit;
	}

	/** Only bother flushing when the post that changed is actually a yacht. */
	public static function flush_cache_for_post( $post_id ) {
		if ( FY_Fleet_CPT::POST_TYPE === get_post_type( $post_id ) ) {
			self::flush_cache();
		}
	}

	/**
	 * Meta writes are how the importer and the product re-sync change
	 * prices, so they have to invalidate too — but they fire in bulk, and
	 * flushing per row would bump the version hundreds of times in one
	 * request. Flush once per request instead.
	 */
	public static function flush_cache_on_meta( $meta_id, $post_id, $meta_key ) {
		if ( self::$meta_flush_done ) {
			return;
		}
		if ( 0 !== strpos( (string) $meta_key, '_fy_' ) ) {
			return;
		}
		if ( FY_Fleet_CPT::POST_TYPE !== get_post_type( $post_id ) ) {
			return;
		}
		self::$meta_flush_done = true;
		self::flush_cache();
	}

	/**
	 * Grid styles/behaviour ship as static files so browsers and page caches
	 * keep them, instead of ~30KB of inline code re-sent with every page view.
	 * Enqueued site-wide (front end only): tiny gzipped, always in the <head>,
	 * and pages without a grid simply have no matching elements.
	 */
	public static function enqueue_assets() {
		wp_enqueue_style( 'fy-fleet', FY_FLEET_URL . 'assets/fleet.css', array(), FY_FLEET_VERSION );
		wp_add_inline_style( 'fy-fleet', FY_Fleet_Settings::color_override_css() );
		wp_enqueue_script( 'fy-fleet', FY_FLEET_URL . 'assets/fleet.js', array(), FY_FLEET_VERSION, true );
		wp_localize_script(
			'fy-fleet',
			'fyFleetPhotos',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'fy_yacht_photos' ),
			)
		);
		wp_localize_script(
			'fy-fleet',
			'fySavedPopupData',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'fy_saved_summary' ),
			)
		);
		// Strings + fleet URL for the "Your Saved Yachts" section, so the JS
		// fallback (used when an Elementor-built product page bypasses the
		// woocommerce_after_single_product_summary hook) can build the same
		// markup with the same translated copy as the PHP version.
		$saved_fleet_url = home_url( '/miami-yacht-rental/' );
		if ( class_exists( 'FY_Fleet_Account' ) && is_user_logged_in() ) {
			$saved_fleet_url = FY_Fleet_Account::region_fleet_url( get_current_user_id() );
		}
		wp_localize_script(
			'fy-fleet',
			'fySavedSectionData',
			array(
				'title'    => __( '❤️ Your Saved Yachts', 'fy-fleet' ),
				'desc'     => __( 'The yachts you saved while browsing our Miami and Panama fleet — compare them side by side, then pick the one for your charter.', 'fy-fleet' ),
				'browse'   => __( '🛥️ Browse the full fleet', 'fy-fleet' ),
				'fleetUrl' => $saved_fleet_url,
			)
		);
	}

	/**
	 * Card-sized summaries for the "Saved" popup — name, price, thumbnail,
	 * link — for a list of yacht IDs read out of the visitor's own
	 * localStorage shortlist. That list only ever holds IDs; the popup
	 * needs this endpoint to turn them into something showable, which
	 * matters most on a product page, where there is no grid of cards to
	 * read it from.
	 */
	public static function ajax_saved_summary() {
		// Same reasoning as ajax_yacht_photos(): a cached page can carry a
		// stale nonce, and this only ever reads data that's already public.
		check_ajax_referer( 'fy_saved_summary', 'nonce', false );

		$raw = isset( $_POST['ids'] ) ? (array) wp_unslash( $_POST['ids'] ) : array();
		// A visitor's own localStorage is outside our control — cap it well
		// above any real shortlist so a corrupted or tampered list can't
		// turn one request into hundreds of post lookups.
		$ids = array_slice( array_unique( array_filter( array_map( 'absint', $raw ) ) ), 0, 60 );

		$items = array();
		foreach ( $ids as $yacht_id ) {
			if ( FY_Fleet_CPT::POST_TYPE !== get_post_type( $yacht_id ) || 'publish' !== get_post_status( $yacht_id ) ) {
				continue; // Unpublished/deleted since it was saved — quietly drop it.
			}
			$thumb_id = get_post_thumbnail_id( $yacht_id );
			$image    = $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'medium' ) : '';
			if ( ! $image ) {
				$image = get_post_meta( $yacht_id, '_fy_image_url', true );
			}
			$from = class_exists( 'FY_Fleet_Pricing' ) ? FY_Fleet_Pricing::display_from_price( $yacht_id ) : null;
			$url  = get_post_meta( $yacht_id, '_fy_button_url', true );
			if ( ! $url ) {
				$product_id = (int) get_post_meta( $yacht_id, '_fy_product_id', true );
				$url        = $product_id ? get_permalink( $product_id ) : '';
			}
			$items[] = array(
				'id'    => $yacht_id,
				'title' => get_the_title( $yacht_id ),
				// esc_url_raw(), not esc_url(): this value is going into a
				// JSON response the browser will read with JS, not straight
				// into HTML — esc_url()'s &amp;-encoding of ampersands would
				// end up literally in the URL instead of being decoded back.
				'image' => $image ? esc_url_raw( $image ) : '',
				'price' => $from ? '$' . number_format( $from['amount'] ) : '',
				// Raw number alongside the formatted string: the saved-yachts
				// section sorts cheapest-first, and parsing "$1,375" back into
				// a number in JS is the kind of thing that quietly breaks on
				// a thousands separator.
				'amount' => $from ? (float) $from['amount'] : 0.0,
				'unit'  => ( $from && class_exists( 'FY_Fleet_Pricing' ) ) ? FY_Fleet_Pricing::display_from_unit( $yacht_id, $from ) : '',
				'url'   => $url ? esc_url_raw( $url ) : '',
			);
		}

		// Cheapest first — the order a shopper comparing their shortlist
		// actually wants. Yachts with no computed price sort last rather
		// than leading the list at $0.
		usort(
			$items,
			function ( $a, $b ) {
				if ( ( $a['amount'] > 0 ) !== ( $b['amount'] > 0 ) ) {
					return $a['amount'] > 0 ? -1 : 1;
				}
				return $a['amount'] <=> $b['amount'];
			}
		);

		wp_send_json_success( array( 'items' => $items ) );
	}

	/**
	 * Photos for one yacht, for the fleet grid's click-the-photo lightbox.
	 *
	 * Fetched on demand rather than printed into the grid: a city page lists
	 * ~180 yachts and a single yacht can carry 40+ photos, so embedding them
	 * all would add megabytes to a page most visitors never open a gallery on.
	 */
	public static function ajax_yacht_photos() {
		// Deliberately non-fatal: a page served from cache can carry a stale
		// nonce, and this endpoint only reads photos that are already public.
		check_ajax_referer( 'fy_yacht_photos', 'nonce', false );

		$yacht_id = isset( $_GET['yacht'] ) ? absint( $_GET['yacht'] ) : 0;

		if ( ! $yacht_id || FY_Fleet_CPT::POST_TYPE !== get_post_type( $yacht_id ) || 'publish' !== get_post_status( $yacht_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Yacht not found.', 'fy-fleet' ) ), 404 );
		}

		$photos = self::yacht_photos( $yacht_id );

		if ( ! $photos ) {
			wp_send_json_error( array( 'message' => __( 'No photos yet for this yacht.', 'fy-fleet' ) ), 404 );
		}

		wp_send_json_success(
			array(
				'title'  => get_the_title( $yacht_id ),
				'photos' => $photos,
			)
		);
	}

	/**
	 * Every photo we can find for a yacht, best source first, de-duplicated.
	 *
	 * Photos live in different places depending on how a yacht was created —
	 * imported yachts keep their own list, older ones point at a shared
	 * gallery post, and a yacht edited by hand may only have its pictures on
	 * the WooCommerce product. Checking all three keeps the lightbox working
	 * regardless of which route a yacht took.
	 */
	private static function yacht_photos( $yacht_id ) {
		$ids   = array();
		$loose = array();

		$own = get_post_meta( $yacht_id, '_fy_gallery_image_ids', true );
		if ( is_array( $own ) ) {
			$ids = array_map( 'intval', $own );
		}

		if ( count( $ids ) < 2 ) {
			$gallery_id = (int) get_post_meta( $yacht_id, '_fy_gallery_id', true );
			if ( $gallery_id && class_exists( 'FY_Fleet_Gallery' ) ) {
				foreach ( FY_Fleet_Gallery::get_images( $gallery_id ) as $image ) {
					if ( ! empty( $image['id'] ) ) {
						$ids[] = (int) $image['id'];
					} elseif ( ! empty( $image['url'] ) ) {
						// Shared galleries can hold a bare URL with no attachment behind it.
						$loose[] = array(
							'url' => $image['url'],
							'alt' => isset( $image['alt'] ) ? $image['alt'] : '',
						);
					}
				}
			}
		}

		if ( count( $ids ) < 2 ) {
			$product_id = (int) get_post_meta( $yacht_id, '_fy_product_id', true );
			if ( $product_id && function_exists( 'wc_get_product' ) ) {
				$product = wc_get_product( $product_id );
				if ( $product ) {
					$ids[] = (int) $product->get_image_id();
					foreach ( $product->get_gallery_image_ids() as $gid ) {
						$ids[] = (int) $gid;
					}
				}
			}
		}

		// The card's own picture opens first, so the lightbox continues from
		// the image the visitor just clicked instead of jumping to another.
		array_unshift( $ids, (int) get_post_thumbnail_id( $yacht_id ) );

		$photos = array();
		$seen   = array();

		foreach ( $ids as $id ) {
			if ( ! $id || isset( $seen[ $id ] ) ) {
				continue;
			}
			$seen[ $id ] = true;

			$url = wp_get_attachment_image_url( $id, 'large' );
			if ( ! $url ) {
				continue;
			}

			$photos[] = array(
				'url'    => $url,
				'srcset' => (string) wp_get_attachment_image_srcset( $id, 'large' ),
				'alt'    => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
			);
		}

		foreach ( $loose as $image ) {
			$photos[] = array(
				'url'    => $image['url'],
				'srcset' => '',
				'alt'    => $image['alt'],
			);
		}

		if ( ! $photos ) {
			$raw = get_post_meta( $yacht_id, '_fy_image_url', true );
			if ( $raw ) {
				$photos[] = array(
					'url'    => $raw,
					'srcset' => '',
					'alt'    => get_the_title( $yacht_id ),
				);
			}
		}

		return $photos;
	}

	public static function shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'fleet'    => '',
				'category' => '',
				'heading'  => '',
			),
			$atts,
			'fy_yacht_fleet'
		);
		$fleet = $atts['fleet'] ? $atts['fleet'] : $atts['category'];
		return self::render( array( 'fleet' => $fleet, 'heading' => $atts['heading'] ) );
	}

	/**
	 * Fetch published yachts and order them cheapest to most expensive by
	 * the same "From $…" trip total the cards show (shortest Hours &
	 * Pricing row). Unpriced yachts sort last. Same-price ties are A–Z.
	 *
	 * Sorting happens in PHP rather than via meta_key so that a yacht which
	 * somehow lacks price meta still appears instead of vanishing from an
	 * INNER JOIN.
	 */
	private static function get_yachts( $fleet = '' ) {
		$args = array(
			'post_type'        => FY_Fleet_CPT::POST_TYPE,
			'post_status'      => 'publish',
			'posts_per_page'   => -1,
			'orderby'          => 'title',
			'order'            => 'ASC',
			'suppress_filters' => false,
		);

		// Limit to one fleet (category) when asked, e.g. fleet="panama-yacht-rentals".
		if ( '' !== trim( (string) $fleet ) ) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'fy_yacht_cat',
					'field'    => is_numeric( $fleet ) ? 'term_id' : 'slug',
					'terms'    => is_numeric( $fleet ) ? intval( $fleet ) : array_map( 'trim', explode( ',', $fleet ) ),
				),
			);
		}

		$yachts = get_posts( $args );

		// Pull every card's featured image into the object cache in ONE
		// query instead of two per card. get_posts() primes the yachts'
		// own posts and meta, but an attachment is a separate post: the
		// first wp_get_attachment_image_url() per card then cost a
		// `SELECT * FROM wp_posts WHERE ID = n` plus a meta read for the
		// alt text. Measured on this fleet: 360 queries down to ~6.
		$thumb_ids = array();
		foreach ( $yachts as $yacht ) {
			$tid = get_post_thumbnail_id( $yacht->ID );
			if ( $tid ) {
				$thumb_ids[] = (int) $tid;
			}
		}
		if ( $thumb_ids ) {
			_prime_post_caches( array_unique( $thumb_ids ), false, true );
		}

		$priced = array();
		foreach ( $yachts as $yacht ) {
			$from     = class_exists( 'FY_Fleet_Pricing' ) ? FY_Fleet_Pricing::display_from_price( $yacht->ID ) : null;
			$priced[] = array(
				'yacht'  => $yacht,
				'amount' => $from ? (float) $from['amount'] : 0.0,
				'title'  => get_the_title( $yacht ),
			);
		}
		usort(
			$priced,
			function ( $a, $b ) {
				if ( ( $a['amount'] > 0 ) !== ( $b['amount'] > 0 ) ) {
					return $a['amount'] > 0 ? -1 : 1;
				}
				if ( $a['amount'] === $b['amount'] ) {
					return strcasecmp( $a['title'], $b['title'] );
				}
				return $a['amount'] <=> $b['amount'];
			}
		);

		return array_map(
			function ( $row ) {
				return $row['yacht'];
			},
			$priced
		);
	}

	private static function size_bucket( $ft ) {
		$ft = (float) $ft;
		if ( $ft < 40 ) {
			return 'under-40';
		} elseif ( $ft < 50 ) {
			return '40-49';
		} elseif ( $ft < 60 ) {
			return '50-59';
		} elseif ( $ft < 70 ) {
			return '60-69';
		}
		return '70-plus';
	}

	private static function badge_class( $style ) {
		$map = array(
			'pink'       => 'badge-pink',
			'free'       => 'badge-free',
			'hot'        => 'badge-hot',
			'commercial' => 'badge-commercial',
			'size'       => 'badge-size',
		);
		return isset( $map[ $style ] ) ? $map[ $style ] : 'badge-hot';
	}

	private static function build_card( $post, $index, $instance ) {
		$id          = $post->ID;
		$title       = get_the_title( $post );
		$size_ft     = get_post_meta( $id, '_fy_size_ft', true );
		$price       = (float) get_post_meta( $id, '_fy_price', true );
		$duration    = get_post_meta( $id, '_fy_duration_label', true );
		$note        = get_post_meta( $id, '_fy_price_note', true );
		$is_pink     = (bool) get_post_meta( $id, '_fy_is_pink', true );
		$is_free     = (bool) get_post_meta( $id, '_fy_is_free_hour', true );
		$badges_meta = get_post_meta( $id, '_fy_badges', true );
		$rows        = get_post_meta( $id, '_fy_pricing', true );
		$button_url  = get_post_meta( $id, '_fy_button_url', true );
		$button_label = get_post_meta( $id, '_fy_button_label', true );
		$button_sub   = get_post_meta( $id, '_fy_button_sub', true );
		$search_extra = get_post_meta( $id, '_fy_search_terms', true );

		if ( ! is_array( $badges_meta ) ) {
			$badges_meta = array();
		}
		if ( ! is_array( $rows ) ) {
			$rows = array();
		}

		// How many photos this yacht has, for the card's "📷 24 photos" cue.
		// A Featured Image wins; otherwise fall back to the plain image URL field.
		$thumb_id  = get_post_thumbnail_id( $id );
		$image_url = $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'large' ) : '';
		$image_alt = $thumb_id ? get_post_meta( $thumb_id, '_wp_attachment_image_alt', true ) : '';
		if ( ! $image_url ) {
			$image_url = get_post_meta( $id, '_fy_image_url', true );
		}
		if ( ! $image_alt ) {
			$image_alt = $title;
		}

		// How many photos the popup will actually show, for the card's
		// "📷 24 photos" cue: the same gallery-ID list the popup reads,
		// plus the featured image if it isn't already in that list (the
		// popup always prepends it — see FY_Fleet_Render::yacht_photos()).
		// Deliberately NOT validated against the Media Library here (that
		// would cost a query per photo per card, ~180 times over) — an
		// owner who deletes a photo from Media Library without removing it
		// from the gallery will see the count run slightly ahead of the
		// popup until the gallery list is cleaned up.
		$gallery_ids  = get_post_meta( $id, '_fy_gallery_image_ids', true );
		$gallery_ids  = is_array( $gallery_ids ) ? array_unique( array_filter( array_map( 'intval', $gallery_ids ) ) ) : array();
		$photo_count  = count( $gallery_ids );
		if ( $thumb_id && ! in_array( (int) $thumb_id, $gallery_ids, true ) ) {
			++$photo_count;
		}

		$size_bucket = self::size_bucket( $size_ft );

		$features = array();
		if ( $is_pink ) {
			$features[] = 'pink';
		}
		if ( $is_free ) {
			$features[] = 'free-hour';
		}
		// Judge the bracket on the price the card SHOWS (the shortest real
		// charter), not the hourly rate — on the rate, a $475/hr yacht
		// counted as "under $1,200" while its card advertised $1,425.
		$feature_from  = class_exists( 'FY_Fleet_Pricing' ) ? FY_Fleet_Pricing::display_from_price( $id ) : null;
		$feature_price = $feature_from ? $feature_from['amount'] : $price;
		if ( $feature_price > 0 && $feature_price < 1400 ) {
			$features[] = 'under-1400';
		}
		// A small, deliberately visible group: yachts whose shortest
		// bookable charter is 2 hours. Most of the fleet starts at 3, so
		// without a dedicated filter these few boats never surface for
		// someone specifically wanting a shorter charter.
		if ( $feature_from && abs( $feature_from['hours'] - 2 ) < 0.01 ) {
			$features[] = 'two-hour';
		}

		$search_bits = array( $title, $search_extra );
		if ( $is_pink ) {
			$search_bits[] = 'pink yacht';
		}
		if ( $is_free ) {
			$search_bits[] = '+1 free hour';
		}
		foreach ( $badges_meta as $b ) {
			$search_bits[] = isset( $b['text'] ) ? $b['text'] : '';
		}
		// Index the price the card actually SHOWS (feature_price, computed
		// above), not the raw hourly rate — searching the number printed on
		// a yacht's own card must find that yacht.
		if ( $feature_price > 0 ) {
			$search_bits[] = '$' . number_format( $feature_price );
		}
		$search_string = strtolower( trim( implode( ' ', array_filter( $search_bits ) ) ) );

		$title_id = 'fy-yacht-title-' . $instance . '-' . $index;

		// Badge row. Manually added pink/free badges win so their position is
		// controllable; otherwise the checkboxes add them automatically up front.
		$badge_html   = '';
		$badge_items  = array();
		$manual_styles = array();
		foreach ( $badges_meta as $b ) {
			if ( ! empty( $b['text'] ) && ! empty( $b['style'] ) ) {
				$manual_styles[] = $b['style'];
			}
		}
		if ( $is_pink && ! in_array( 'pink', $manual_styles, true ) ) {
			$badge_items[] = '<span class="fy-badge badge-pink">Pink Yacht</span>';
		}
		if ( $is_free && ! in_array( 'free', $manual_styles, true ) ) {
			$badge_items[] = '<span class="fy-badge badge-free">+1 Free Hour</span>';
		}
		foreach ( $badges_meta as $b ) {
			$text = isset( $b['text'] ) ? $b['text'] : '';
			if ( '' === $text ) {
				continue;
			}
			$class         = self::badge_class( isset( $b['style'] ) ? $b['style'] : 'hot' );
			$badge_items[] = '<span class="fy-badge ' . esc_attr( $class ) . '">' . esc_html( $text ) . '</span>';
		}
		if ( $badge_items ) {
			$badge_html = '<div class="fy-badge-row" aria-label="Yacht highlights">' . implode( '', $badge_items ) . '</div>';
		}

		// Guest capacity row (fleet default unless the yacht overrides it; 0 hides).
		$capacity  = FY_Fleet_CPT::capacity( $id );
		$meta_rows = '';

		// Size · Brand · Model ride on one compact line under the yacht name
		// rather than three full meta rows — same information, a fraction of
		// the card height. Any piece the yacht hasn't got is simply omitted.
		$subtitle_bits = array();
		if ( '' !== trim( (string) $size_ft ) && (float) $size_ft > 0 ) {
			$subtitle_bits[] = esc_html( $size_ft ) . ' ft';
		}
		$brand = trim( (string) get_post_meta( $id, '_fy_brand', true ) );
		if ( '' !== $brand ) {
			$subtitle_bits[] = esc_html( $brand );
		}
		$model = trim( (string) get_post_meta( $id, '_fy_model', true ) );
		if ( '' !== $model ) {
			$subtitle_bits[] = esc_html( $model );
		}
		$card_subtitle = $subtitle_bits ? implode( ' · ', $subtitle_bits ) : '';

		if ( $capacity > 0 ) {
			$meta_rows .= '<div class="fy-meta-row"><span class="fy-meta-label">👥 Max capacity</span><strong>'
				. sprintf( esc_html__( '%d guests', 'fy-fleet' ), $capacity ) . '</strong></div>';
		}

		// Pricing panel rows.
		$panel_html = '';
		foreach ( $rows as $row ) {
			$type = isset( $row['type'] ) ? $row['type'] : 'price';
			if ( 'heading' === $type ) {
				$panel_html .= '<div class="fy-day-heading">' . esc_html( $row['text'] ) . '</div>';
			} elseif ( 'note' === $type ) {
				$panel_html .= '<div class="fy-price-note">' . esc_html( $row['text'] ) . '</div>';
			} else {
				$row_class = ( ! empty( $row['free'] ) ) ? ' is-free-hour' : '';
				$boat      = isset( $row['price'] ) ? (float) $row['price'] : 0;
				$hours     = class_exists( 'FY_Fleet_Pricing' ) ? FY_Fleet_Pricing::hours_from_label( isset( $row['duration'] ) ? $row['duration'] : '' ) : 0;
				$listed    = class_exists( 'FY_Fleet_Pricing' ) ? FY_Fleet_Pricing::listed_total( $id, $boat, $hours ) : $boat;
				$row_price = $listed > 0 ? '$' . number_format( $listed ) : '';
				$panel_html .= '<div class="fy-price-row' . esc_attr( $row_class ) . '"><div class="fy-price-duration">' . esc_html( $row['duration'] ) . '</div><div class="fy-price-value"><span class="fy-price-number">' . esc_html( $row_price ) . '</span><span class="fy-price-total">Boat price</span></div></div>';
			}
		}

		$button_label = $button_label ? $button_label : ( 'View ' . $title );
		$button_sub   = $button_sub ? $button_sub : 'Photos, amenities & booking';

		// Sorting and the "Under $1,400" filter must work on the SAME figure
		// the card displays, or a yacht shown at $360 would sort by its $120
		// hourly rate and slip into a price bracket it doesn't belong in.
		$sort_price = class_exists( 'FY_Fleet_Pricing' ) ? FY_Fleet_Pricing::display_from_price( $id ) : null;
		$sort_price = $sort_price ? $sort_price['amount'] : $price;

		ob_start();
		?>
<article class="fy-card" aria-labelledby="<?php echo esc_attr( $title_id ); ?>"
	  data-index="<?php echo esc_attr( $index ); ?>" data-size="<?php echo esc_attr( $size_bucket ); ?>" data-yacht-size="<?php echo esc_attr( $size_ft ); ?>"
	  data-feature="<?php echo esc_attr( implode( ' ', $features ) ); ?>" data-starting-price="<?php echo esc_attr( $sort_price ); ?>"
	  data-starting-duration="<?php echo esc_attr( $duration ); ?>"
	  data-yacht-id="<?php echo esc_attr( $id ); ?>"
	  data-search="<?php echo esc_attr( $search_string ); ?>">
  <div class="fy-card-media">
	<div class="fy-card-image"><?php if ( $image_url ) : ?><img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $image_alt ); ?>" loading="<?php echo $index < 3 ? 'eager' : 'lazy'; ?>" decoding="async" width="800" height="600"/><?php endif; ?>
	  <?php if ( $image_url ) : ?>
		<?php
		/*
		 * A button, not a link: this opens the yacht's photos right here on
		 * the page. The card's "View <yacht>" button below is still the one
		 * real link to the product page, so nothing changes for search
		 * engines or for anyone browsing without JavaScript.
		 */
		?>
		<button type="button" class="fy-photo-open" data-fy-photos="<?php echo esc_attr( $id ); ?>" data-fy-name="<?php echo esc_attr( $title ); ?>" data-fy-url="<?php echo esc_url( $button_url ); ?>"
		  aria-label="<?php echo esc_attr( $photo_count > 1
			  /* translators: 1: number of photos, 2: yacht name */
			  ? sprintf( __( 'See all %1$d photos of %2$s', 'fy-fleet' ), $photo_count, $title )
			  : sprintf( __( 'See photos of %s', 'fy-fleet' ), $title ) ); ?>">
		  <span class="fy-photo-open__cue" aria-hidden="true">📷 <?php echo $photo_count > 1
			  ? esc_html( sprintf( _n( '%d photo', '%d photos', $photo_count, 'fy-fleet' ), $photo_count ) )
			  : esc_html__( 'See photos', 'fy-fleet' ); ?></span>
		</button>
	  <?php endif; ?>
	  <?php
	  /*
	   * Shortlist toggle. Saved yachts live in the visitor's own browser
	   * (localStorage) — no account, no cookie, nothing stored on the
	   * server — so this renders in its "not saved" state and fleet.js
	   * marks the saved ones once it reads that list.
	   */
	  ?>
	  <button type="button" class="fy-save-toggle" data-fy-save="<?php echo esc_attr( $id ); ?>" aria-pressed="false"
		aria-label="<?php echo esc_attr( sprintf( __( 'Save %s to compare later', 'fy-fleet' ), $title ) ); ?>">
		<span class="fy-save-toggle__icon" aria-hidden="true">♡</span>
	  </button>
	</div>
	<?php echo $badge_html; // phpcs:ignore -- built from escaped parts above ?>
  </div>
  <h3 class="fy-card-title" id="<?php echo esc_attr( $title_id ); ?>"><?php echo esc_html( $title ); ?></h3>
  <?php if ( $card_subtitle ) : ?>
	<p class="fy-card-subtitle"><?php echo $card_subtitle; // phpcs:ignore -- each part escaped above ?></p>
  <?php endif; ?>
  <?php
	// Quote the shortest real charter (the 3-hour price), not the hourly
	// rate — see FY_Fleet_Pricing::display_from_price().
	$from_price = class_exists( 'FY_Fleet_Pricing' ) ? FY_Fleet_Pricing::display_from_price( $id ) : null;
	$from_amount = $from_price ? $from_price['amount'] : $price;
	$price_unit  = $from_price && class_exists( 'FY_Fleet_Pricing' ) ? FY_Fleet_Pricing::display_from_unit( $id, $from_price ) : '';
	?>
  <div class="fy-starting-price" aria-label="<?php echo esc_attr( $title . ' starts at $' . number_format( $from_amount ) . ( $price_unit ? ' ' . $price_unit : '' ) ); ?>">
	<span class="fy-starting-label">From</span>
	<span class="fy-starting-amount">$<?php echo esc_html( number_format( $from_amount ) ); ?><?php if ( $price_unit ) : ?> <span class="fy-starting-unit"><?php echo esc_html( $price_unit ); ?></span><?php endif; ?></span>
	<span class="fy-starting-note"><?php echo esc_html( $note ); ?></span>
  </div>
  <?php if ( $meta_rows ) : ?>
  <div class="fy-card-meta">
	<?php echo $meta_rows; // phpcs:ignore -- built from escaped parts above ?>
  </div>
  <?php endif; ?>
  <?php if ( $panel_html ) : ?>
  <details class="fy-pricing-details" name="fy-yacht-pricing-<?php echo esc_attr( $instance ); ?>">
	<summary class="fy-pricing-summary">
	  <span class="fy-summary-copy">
		<span class="fy-summary-main fy-when-closed">View Hours &amp; Pricing</span>
		<span class="fy-summary-main fy-when-open">Hide Hours &amp; Pricing</span>
		<span class="fy-summary-sub fy-when-closed">Exact durations — boat price. Crew + fuel added at checkout.</span>
		<span class="fy-summary-sub fy-when-open">Click to close pricing</span>
	  </span>
	  <span class="fy-summary-arrow" aria-hidden="true"></span>
	</summary>
	<div class="fy-price-panel" aria-label="Charter hours and prices for <?php echo esc_attr( $title ); ?>">
	  <?php echo $panel_html; // phpcs:ignore -- built from escaped parts above ?>
	</div>
  </details>
  <?php endif; ?>
  <div class="fy-card-cta">
	<a class="fy-card-button" href="<?php echo esc_url( $button_url ); ?>" aria-label="View photos, amenities and booking for <?php echo esc_attr( $title ); ?>">
	  <span class="fy-card-button-main"><?php echo esc_html( $button_label ); ?></span>
	  <span class="fy-card-button-sub"><?php echo esc_html( $button_sub ); ?></span>
	</a>
  </div>
</article>
		<?php
		return ob_get_clean();
	}



	/** Bumped on any edit that changes the grid; part of every cache key. */
	const CACHE_VERSION_OPTION = 'fy_fleet_grid_cache_version';

	public static function cache_version() {
		return (int) get_option( self::CACHE_VERSION_OPTION, 1 );
	}

	/**
	 * Throw away every cached grid by moving the version the keys are built
	 * from. Cheaper and safer than hunting individual transients: the old
	 * entries are simply never read again and expire on their own.
	 */
	public static function flush_cache() {
		update_option( self::CACHE_VERSION_OPTION, self::cache_version() + 1, false );
	}

	public static function render( $args = array() ) {
		$args = wp_parse_args( $args, array( 'fleet' => '', 'heading' => '', 'hide_heading' => false ) );

		self::$instance_counter++;
		$instance = self::$instance_counter;

		// CSS/JS are identical for every instance, so emit them only once per page load.
		$print_assets        = ! self::$assets_printed;
		self::$assets_printed = true;

		/*
		 * Serve the finished HTML from cache when we can. Rebuilding the
		 * whole grid means re-reading every yacht's price, badges and photo
		 * on every single visit — the markup is identical for every
		 * logged-out visitor, so it only has to be built once.
		 *
		 * Anyone who can edit posts always gets a fresh build: the owner
		 * editing a yacht must see the change immediately, and they are a
		 * handful of requests a day rather than the traffic this protects.
		 *
		 * $instance is in the key because element IDs (search box, sort
		 * select, card headings) are numbered from it. The counter restarts
		 * at 1 each request, so the first grid on a page is always
		 * instance 1 — without this, a second grid sharing the same atts
		 * would be handed the first one's markup and duplicate its IDs.
		 */
		$can_cache = ! is_user_logged_in() || ! current_user_can( 'edit_posts' );
		$cache_key = '';
		if ( $can_cache ) {
			// FY_FLEET_VERSION is part of the key: a plugin upload changes
			// what the cards show (pricing model, labels, markup), so grids
			// built by an older version must never be served by a newer one.
			// Without this, Allegra kept showing the retired $2,520
			// fees-included figure for up to 12 hours after the boat-only
			// release — and no Cloudflare purge could clear it, because the
			// stale HTML came from the ORIGIN's own transient.
			$cache_key = 'fy_fleet_grid_' . FY_FLEET_VERSION . '_' . self::cache_version() . '_' . md5(
				wp_json_encode( array( $args['fleet'], $args['heading'], $args['hide_heading'], $instance, get_locale() ) )
			);
			$cached = get_transient( $cache_key );
			if ( is_string( $cached ) && '' !== $cached ) {
				return $cached;
			}
		}

		$opts   = FY_Fleet_Settings::get();
		$yachts = self::get_yachts( $args['fleet'] );

		// A widget can override the headline, e.g. "Panama Yacht Rentals".
		if ( ! empty( $args['heading'] ) ) {
			$opts['heading'] = $args['heading'];
		}


		$cards_html = '';
		$ld_items   = array();
		foreach ( $yachts as $i => $yacht ) {
			$cards_html .= self::build_card( $yacht, $i, $instance );

			$ld_image = get_the_post_thumbnail_url( $yacht, 'large' );
			if ( ! $ld_image ) {
				$ld_image = get_post_meta( $yacht->ID, '_fy_image_url', true );
			}
			$ld_item = array(
				'@type' => 'Thing',
				'name'  => get_the_title( $yacht ),
			);
			$ld_url = get_post_meta( $yacht->ID, '_fy_button_url', true );
			if ( $ld_url ) {
				$ld_item['url'] = $ld_url;
			}
			if ( $ld_image ) {
				$ld_item['image'] = $ld_image;
			}
			$ld_items[] = array(
				'@type'    => 'ListItem',
				'position' => $i + 1,
				'item'     => $ld_item,
			);
		}

		$whatsapp_number  = preg_replace( '/[^0-9]/', '', $opts['whatsapp_number'] );
		$whatsapp_url      = 'https://wa.me/' . $whatsapp_number . '?text=' . rawurlencode( $opts['whatsapp_message'] );
		$phone_url          = 'tel:' . preg_replace( '/[^0-9+]/', '', $opts['phone_number'] );

		ob_start();
		?>
<section id="fy-miami-yacht-rentals-neon" class="fy-fleet-root"
	<?php if ( $args['hide_heading'] ) : ?>
	aria-label="<?php echo esc_attr( $opts['heading'] ); ?>"
	<?php else : ?>
	aria-labelledby="fy-title-<?php echo esc_attr( $instance ); ?>"
	<?php endif; ?>
>
<?php // Styles/JS ship from assets/fleet.css + fleet.js, enqueued in the <head>. ?>
<div class="fy-shell">
  <div class="fy-frame">
	<header class="fy-intro">
	  <?php // A caller with its own headline (the fleet landing template) sets hide_heading — showing this h2 there would repeat that headline verbatim as a second, identically-worded heading. ?>
	  <?php if ( ! $args['hide_heading'] ) : ?>
	  <h2 id="fy-title-<?php echo esc_attr( $instance ); ?>"><?php echo esc_html( $opts['heading'] ); ?></h2>
	  <?php endif; ?>
	  <p class="fy-sub"><?php echo esc_html( $opts['subheading'] ); ?></p>
	</header>

	<section class="fy-pricing-info" aria-labelledby="fy-pricing-info-title-<?php echo esc_attr( $instance ); ?>">
	  <h3 id="fy-pricing-info-title-<?php echo esc_attr( $instance ); ?>"><?php echo esc_html( $opts['pricing_title'] ); ?></h3>
	  <p><?php echo wp_kses_post( $opts['pricing_body'] ); ?></p>
	  <p class="fy-payment-highlight"><?php echo wp_kses_post( $opts['pricing_highlight'] ); ?></p>
	  <p class="fy-free-hour-note"><?php echo esc_html( $opts['free_hour_note'] ); ?></p>
	</section>

	<section class="fy-inventory-panel" aria-label="Search, sort and filter yacht rentals">
	  <div class="fy-search-row">
		<div class="fy-search-wrap">
		  <label class="fy-sr-only" for="fy-miami-yacht-search-<?php echo esc_attr( $instance ); ?>">Search yacht rentals</label>
		  <input class="fy-search" id="fy-miami-yacht-search-<?php echo esc_attr( $instance ); ?>" type="search" autocomplete="off" placeholder="Search by yacht name, size, price, pink, Azimut, Sea Ray..."/>
		</div>
		<div>
		  <label class="fy-sr-only" for="fy-miami-yacht-sort-<?php echo esc_attr( $instance ); ?>">Sort yacht rentals</label>
		  <select class="fy-sort" id="fy-miami-yacht-sort-<?php echo esc_attr( $instance ); ?>">
			<option value="price-low" selected="selected">Price: Low to High</option>
			<option value="price-high">Price: High to Low</option>
			<option value="size-small">Size: Small to Large</option>
			<option value="size-large">Size: Large to Small</option>
			<option value="featured">Sort: Featured</option>
		  </select>
		</div>
		<div>
		  <label class="fy-sr-only" for="fy-miami-yacht-size-<?php echo esc_attr( $instance ); ?>">Filter by yacht size</label>
		  <select class="fy-sort fy-size-select" id="fy-miami-yacht-size-<?php echo esc_attr( $instance ); ?>">
			<option value="all">Size: All yachts</option>
			<option value="under-40">Under 40ft</option>
			<option value="40-49">40–49ft</option>
			<option value="50-59">50–59ft</option>
			<option value="60-69">60–69ft</option>
			<option value="70-plus">70ft+</option>
		  </select>
		</div>
	  </div>


	  <p class="fy-filter-label">Popular filters</p>
	  <div class="fy-filter-bar">
		<div class="fy-filter-row-wrap">
		<div class="fy-filter-row" role="group" aria-label="Popular yacht filters">
		  <button class="fy-filter-button is-active" type="button" data-feature-filter="all" aria-pressed="true" data-label-default="✅ All styles" data-label-saved="🛥️ View All Yachts">✅ All styles</button>
		  <button class="fy-filter-button" type="button" data-feature-filter="pink" aria-pressed="false">🎀 Pink yachts</button>
		  <button class="fy-filter-button" type="button" data-feature-filter="free-hour" aria-pressed="false">⏱️ Free-hour offers</button>
		  <button class="fy-filter-button" type="button" data-feature-filter="under-1400" aria-pressed="false">💸 Under $1,400</button>
		  <button class="fy-filter-button" type="button" data-feature-filter="two-hour" aria-pressed="false">⏳ 2-hour rentals</button>
		</div>
		<?php // Fades in over the right edge only while there's more to scroll to — fleet.js turns it off once you've reached the end. ?>
		<span class="fy-filter-row-hint" aria-hidden="true">›</span>
		</div>
		<?php
		/*
		 * Deliberately OUTSIDE .fy-filter-row: the shortlist is the
		 * visitor's own list, not another way to slice the fleet, and
		 * buried among five identical pills nobody noticed it. Its own
		 * slot and its own styling make it read as a separate thing.
		 * Always shown, even at zero — a control that only appears once
		 * used is one nobody discovers. fleet.js keeps the count current
		 * from localStorage.
		 */
		?>
		<button class="fy-saved-filter" type="button" data-feature-filter="saved" aria-pressed="false">
		  <span class="fy-saved-filter__heart" aria-hidden="true">♥</span>
		  <span class="fy-saved-filter__text"><?php esc_html_e( 'Saved Yachts', 'fy-fleet' ); ?></span>
		  <span class="fy-saved-count">0</span>
		</button>
	  </div>
	</section>

	<p class="fy-legend"><?php echo esc_html( $opts['legend'] ); ?></p>
	<button class="fy-mobile-view-all" id="fy-mobile-view-all-<?php echo esc_attr( $instance ); ?>" type="button" aria-controls="fy-yacht-grid-<?php echo esc_attr( $instance ); ?>" aria-expanded="false" hidden>View all yachts</button>

	<div class="fy-no-results" data-fy-no-results id="fy-miami-no-results-<?php echo esc_attr( $instance ); ?>" hidden>
	  <span class="fy-no-results-default">
		<strong>No yachts match those filters.</strong>
		Clear the search or reset the filters to view the complete fleet.
	  </span>
	  <span class="fy-no-results-saved" hidden>
		<strong>You haven't saved any yachts yet.</strong>
		Tap the ♡ on a photo to add it to your shortlist.
	  </span>
	  <button class="fy-clear-filters" id="fy-clear-filters-<?php echo esc_attr( $instance ); ?>" type="button">Clear filters</button>
	</div>

	<?php if ( empty( $yachts ) ) : ?>
	  <div class="fy-no-results">
		<strong>No yachts published yet.</strong>
		Add yachts under Yacht Fleet &rarr; Add New Yacht.
	  </div>
	<?php else : ?>
	<div class="fy-grid" id="fy-yacht-grid-<?php echo esc_attr( $instance ); ?>">
	  <?php echo $cards_html; // phpcs:ignore -- built from escaped card fragments ?>
	</div>

	<div class="fy-view-all-wrap" id="fy-view-all-wrap-<?php echo esc_attr( $instance ); ?>" hidden>
	  <button class="fy-view-all" id="fy-view-all-<?php echo esc_attr( $instance ); ?>" type="button" aria-controls="fy-yacht-grid-<?php echo esc_attr( $instance ); ?>" aria-expanded="false">
		<span class="fy-view-all-copy"><span class="fy-view-all-line-one">View More</span><span class="fy-view-all-line-two">Yacht Rentals</span></span>
		<span class="fy-view-all-arrow" aria-hidden="true">↓</span>
	  </button>
	  <p class="fy-view-all-note" id="fy-view-all-note-<?php echo esc_attr( $instance ); ?>">Showing featured yachts first. Open the complete fleet to compare every available option.</p>
	</div>
	<?php endif; ?>

	<aside class="fy-bottom-cta" aria-label="Get help choosing a yacht">
	  <p><?php echo wp_kses_post( $opts['bottom_text'] ); ?></p>
	  <div class="fy-bottom-actions">
		<a class="fy-help-button fy-help-whatsapp" href="<?php echo esc_url( $whatsapp_url ); ?>" rel="noopener" target="_blank">💬 WhatsApp Yacht Options</a>
		<a class="fy-help-button fy-help-call" href="<?php echo esc_attr( $phone_url ); ?>">📞 Call For Yacht Rentals</a>
	  </div>
	</aside>
  </div>
</div>
<?php if ( ! empty( $ld_items ) ) : ?>
<script type="application/ld+json"><?php echo wp_json_encode( array(
	'@context'        => 'https://schema.org',
	'@type'           => 'ItemList',
	'name'             => 'Yacht rentals',
	'numberOfItems'    => count( $ld_items ),
	'itemListOrder'    => 'https://schema.org/ItemListOrderAscending',
	'itemListElement'  => $ld_items,
) ); ?></script>
<?php endif; ?>
</section>
		<?php
		$html = ob_get_clean();

		// Twelve hours is only a backstop — every edit that changes the grid
		// bumps the version in the key (see flush_cache()), so a stale copy
		// is normally replaced the moment the owner saves, not on expiry.
		if ( $can_cache && '' !== $cache_key ) {
			set_transient( $cache_key, $html, 12 * HOUR_IN_SECONDS );
		}

		return $html;
	}
}
