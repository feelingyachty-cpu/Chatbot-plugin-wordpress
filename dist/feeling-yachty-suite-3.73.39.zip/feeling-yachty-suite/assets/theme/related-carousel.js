/* Feeling Yachty Experiences carousel: lazy-loads more cards as the row is
   scrolled, and on phones nudges itself a couple of cards to make clear the
   row moves before handing control back to the visitor. */
jQuery( function ( $ ) {
	var $section = $( '.fy-related-carousel' );
	if ( ! $section.length || typeof fyRelated === 'undefined' ) {
		return;
	}
	var $list     = $section.find( 'ul.products' ).first();
	var $sentinel = $list.find( '.fy-related-sentinel' );
	var queue     = [];
	try {
		queue = JSON.parse( $section.attr( 'data-fy-queue' ) || '[]' );
	} catch ( e ) {
		queue = [];
	}
	var nonce   = $section.attr( 'data-fy-nonce' ) || '';
	var loading = false;
	var BATCH   = 8;

	function loadMore() {
		if ( loading || ! queue.length ) {
			if ( ! queue.length ) {
				$sentinel.remove();
			}
			return;
		}
		loading = true;
		var batch = queue.splice( 0, BATCH );
		$.post( fyRelated.ajaxUrl, { action: 'fy_load_related', nonce: nonce, ids: batch } )
			.done( function ( res ) {
				if ( res && res.success && res.data && res.data.html ) {
					$( res.data.html ).insertBefore( $sentinel );
				}
			} )
			.always( function () {
				loading = false;
				if ( ! queue.length ) {
					$sentinel.remove();
				}
			} );
	}

	if ( queue.length && $sentinel.length && 'IntersectionObserver' in window ) {
		// rootMargin extends the trigger zone to the right, so the next
		// batch is already loading by the time the sentinel would actually
		// become visible — no blank gap while a swipe is still in motion.
		var io = new IntersectionObserver(
			function ( entries ) {
				entries.forEach( function ( entry ) {
					if ( entry.isIntersecting ) {
						loadMore();
					}
				} );
			},
			{ root: $list[ 0 ], rootMargin: '0px 600px 0px 0px', threshold: 0 }
		);
		io.observe( $sentinel[ 0 ] );
	} else if ( queue.length ) {
		// No IntersectionObserver (very old browser) — fetch the whole
		// remainder in ONE request rather than leave it unreachable.
		//
		// Deliberately not a loop: loadMore() is async and guards on a
		// `loading` flag, so calling it repeatedly in a synchronous loop
		// returns early every time after the first without ever shrinking
		// the queue — the condition never goes false and the tab hangs.
		BATCH = queue.length;
		loadMore();
	}

	/* ------------------------------------------------------------------
	 * Phone-only: nudge the row a couple of cards so it's obvious it
	 * scrolls, then get out of the way for good the moment a real person
	 * touches it.
	 * ---------------------------------------------------------------- */
	var isMobile      = window.matchMedia( '(max-width: 767px)' ).matches;
	var reduceMotion  = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	var el            = $list[ 0 ];
	var canScroll     = el && el.scrollWidth > el.clientWidth + 4;

	// "Swipe to see more" is a lie when everything already fits — a short
	// related list (a yacht with only one or two siblings) would otherwise
	// still be told to swipe. The markup ships it visible so it's there
	// without waiting on JS; hide it when there's genuinely nothing to reach.
	if ( ! canScroll ) {
		$section.find( '.fy-related-hint' ).hide();
	}

	if ( isMobile && ! reduceMotion && canScroll ) {
		var cancelled = false;
		var steps     = 0;
		var MAX_STEPS = 2;

		function cancel() {
			cancelled = true;
		}
		el.addEventListener( 'touchstart', cancel, { passive: true } );
		el.addEventListener( 'pointerdown', cancel, { passive: true } );
		el.addEventListener( 'wheel', cancel, { passive: true } );

		function nudge() {
			if ( cancelled || steps >= MAX_STEPS ) {
				return;
			}
			var $card = $list.find( 'li.product' ).first();
			var step  = $card.length ? $card.outerWidth( true ) : 0;
			if ( ! step ) {
				return;
			}
			steps++;
			el.scrollBy( { left: step, behavior: 'smooth' } );
			setTimeout( nudge, 1700 );
		}
		// Let the page settle (images, layout) before the row starts moving.
		setTimeout( nudge, 1400 );
	}
} );
