(function () {
	'use strict';

	function buildEmbed( row ) {
		var lat    = ( row.querySelector( '.fy-marina-lat-input' ) || {} ).value || '';
		var lng    = ( row.querySelector( '.fy-marina-lng-input' ) || {} ).value || '';
		var name   = ( row.querySelector( '.fy-marina-name-input' ) || {} ).value || '';
		var addr   = ( row.querySelector( '.fy-marina-address-input' ) || {} ).value || '';
		var custom = row.querySelector( 'input[name*="[embed]"]' );

		if ( custom && custom.value.trim() ) {
			return custom.value.trim();
		}

		lat = lat.trim();
		lng = lng.trim();

		if ( lat !== '' && lng !== '' && ! isNaN( lat ) && ! isNaN( lng ) ) {
			return 'https://www.google.com/maps?q=' + encodeURIComponent( lat + ',' + lng ) + '&z=15&output=embed';
		}

		var search = ( name + ( addr ? ', ' + addr : '' ) ).trim();
		if ( ! search ) {
			return '';
		}
		return 'https://www.google.com/maps?q=' + encodeURIComponent( search ) + '&z=14&output=embed';
	}

	function togglePreview( row ) {
		var box = row.querySelector( '.fy-marina-row-map' );
		if ( ! box ) {
			return;
		}
		if ( box.innerHTML.trim() ) {
			box.innerHTML = '';
			return;
		}
		var src = buildEmbed( row );
		if ( ! src ) {
			box.innerHTML = '<p class="description">Enter a name, address or coordinates first.</p>';
			return;
		}
		var frame = document.createElement( 'iframe' );
		frame.src = src;
		frame.loading = 'lazy';
		frame.referrerPolicy = 'no-referrer-when-downgrade';
		box.innerHTML = '';
		box.appendChild( frame );
	}

	function nextIndex() {
		return 'new' + Date.now() + Math.floor( Math.random() * 1000 );
	}

	document.addEventListener( 'click', function ( e ) {
		var target = e.target;

		if ( target.id === 'fy-add-marina' ) {
			e.preventDefault();
			var container = document.getElementById( 'fy-marina-rows' );
			var template  = document.getElementById( 'fy-marina-template' );
			if ( ! container || ! template ) {
				return;
			}
			var html = template.innerHTML.split( '__INDEX__' ).join( nextIndex() );
			var wrap = document.createElement( 'div' );
			wrap.innerHTML = html.trim();
			var row = wrap.firstElementChild;
			if ( row ) {
				container.appendChild( row );
				var nameField = row.querySelector( '.fy-marina-name-input' );
				if ( nameField ) { nameField.focus(); }
			}
			return;
		}

		if ( target.classList.contains( 'fy-marina-remove' ) ) {
			e.preventDefault();
			var toRemove = target.closest( '.fy-marina-row' );
			if ( toRemove && window.confirm( 'Remove this marina? It will disappear when you save.' ) ) {
				toRemove.parentNode.removeChild( toRemove );
			}
			return;
		}

		if ( target.classList.contains( 'fy-marina-row-preview' ) ) {
			e.preventDefault();
			var previewRow = target.closest( '.fy-marina-row' );
			if ( previewRow ) {
				togglePreview( previewRow );
			}
		}
	} );

	// Keep the row heading in step with the name field.
	document.addEventListener( 'input', function ( e ) {
		if ( ! e.target.classList.contains( 'fy-marina-name-input' ) ) {
			return;
		}
		var row = e.target.closest( '.fy-marina-row' );
		if ( ! row ) {
			return;
		}
		var label = row.querySelector( '.fy-marina-row-name' );
		if ( label ) {
			label.textContent = e.target.value || 'New marina';
		}
	} );
})();
