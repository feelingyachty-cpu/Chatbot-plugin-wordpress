<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * SEO layer for yachts.
 *
 * Leans on an entity/semantic model rather than keyword stuffing: every yacht
 * declares a main entity, an attribute set, a contextual hierarchy (breadcrumb)
 * and question/answer pairs, which are emitted as structured data so search
 * engines can resolve the entity and its relations.
 *
 * If Rank Math / Yoast / AIOSEO / SEOPress is active, meta tag output is
 * suppressed by default so tags are never duplicated.
 */
class FY_Fleet_SEO {

	const OPTION = 'fy_fleet_seo';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_meta' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_box' ) );
		add_action( 'save_post_' . FY_Fleet_CPT::POST_TYPE, array( __CLASS__, 'save' ), 10, 2 );
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'wp_head', array( __CLASS__, 'output_head' ), 1 );
	}

	/** SEO fields, exposed to the REST API for n8n and other automations. */
	public static function fields() {
		return array(
			'_fy_seo_title'       => array( 'label' => __( 'Meta title', 'fy-fleet' ), 'type' => 'text' ),
			'_fy_seo_description' => array( 'label' => __( 'Meta description', 'fy-fleet' ), 'type' => 'textarea' ),
			'_fy_page_title'      => array( 'label' => __( 'Page H1 (if different from the yacht name)', 'fy-fleet' ), 'type' => 'text' ),
			'_fy_main_entity'     => array( 'label' => __( 'Main entity', 'fy-fleet' ), 'type' => 'text' ),
			'_fy_entity_attributes' => array( 'label' => __( 'Entity attributes', 'fy-fleet' ), 'type' => 'textarea' ),
			'_fy_focus_keyphrase' => array( 'label' => __( 'Focus keyphrase', 'fy-fleet' ), 'type' => 'text' ),
			'_fy_secondary_terms' => array( 'label' => __( 'Secondary / related terms', 'fy-fleet' ), 'type' => 'textarea' ),
			'_fy_canonical'       => array( 'label' => __( 'Canonical URL', 'fy-fleet' ), 'type' => 'url' ),
			'_fy_robots'          => array( 'label' => __( 'Robots', 'fy-fleet' ), 'type' => 'text' ),
			'_fy_og_title'        => array( 'label' => __( 'Open Graph title', 'fy-fleet' ), 'type' => 'text' ),
			'_fy_og_description'  => array( 'label' => __( 'Open Graph description', 'fy-fleet' ), 'type' => 'textarea' ),
			'_fy_og_image'        => array( 'label' => __( 'Open Graph image URL', 'fy-fleet' ), 'type' => 'url' ),
			'_fy_breadcrumb'      => array( 'label' => __( 'Contextual hierarchy (breadcrumb)', 'fy-fleet' ), 'type' => 'textarea' ),
			'_fy_faq'             => array( 'label' => __( 'Questions & answers', 'fy-fleet' ), 'type' => 'textarea' ),
			'_fy_seo_content'     => array( 'label' => __( 'Description / body copy', 'fy-fleet' ), 'type' => 'textarea' ),
		);
	}

	public static function register_meta() {
		foreach ( self::fields() as $key => $field ) {
			register_post_meta(
				FY_Fleet_CPT::POST_TYPE,
				$key,
				array(
					'show_in_rest'      => true,
					'single'            => true,
					'type'              => 'string',
					'sanitize_callback' => 'url' === $field['type'] ? 'esc_url_raw' : 'wp_kses_post',
					'auth_callback'     => function () {
						return current_user_can( 'edit_posts' );
					},
				)
			);
		}
	}

	/* ------------------------------------------------------------------
	 * Global settings
	 * ---------------------------------------------------------------- */

	public static function defaults() {
		return array(
			'title_template'  => '{yacht} | {site}',
			'desc_template'   => 'Charter the {yacht} in Miami from {price}. Compare hours, pricing and add-ons, then reserve with a deposit.',
			'output_meta'     => 'auto',
			'output_schema'   => 1,
			'brand_name'      => 'Feeling Yachty',
			'org_url'         => 'https://feelingyachty.com',
			'org_logo'        => '',
			'org_phone'       => '+1 754-325-3827',
			'area_served'     => 'Miami, Florida',
			'twitter_site'    => '',
		);
	}

	public static function get() {
		return wp_parse_args( get_option( self::OPTION, array() ), self::defaults() );
	}

	public static function add_menu() {
		add_submenu_page(
			'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE,
			__( 'SEO Settings', 'fy-fleet' ),
			__( 'SEO', 'fy-fleet' ),
			'manage_options',
			'fy-fleet-seo',
			array( __CLASS__, 'render_settings' )
		);
	}

	public static function register_settings() {
		register_setting( 'fy_fleet_seo_group', self::OPTION, array( __CLASS__, 'sanitize_settings' ) );
	}

	public static function sanitize_settings( $input ) {
		$out = array();
		foreach ( array( 'title_template', 'brand_name', 'org_phone', 'area_served', 'twitter_site' ) as $key ) {
			$out[ $key ] = isset( $input[ $key ] ) ? sanitize_text_field( $input[ $key ] ) : '';
		}
		$out['desc_template'] = isset( $input['desc_template'] ) ? sanitize_textarea_field( $input['desc_template'] ) : '';
		$out['org_url']       = isset( $input['org_url'] ) ? esc_url_raw( $input['org_url'] ) : '';
		$out['org_logo']      = isset( $input['org_logo'] ) ? esc_url_raw( $input['org_logo'] ) : '';
		$out['output_meta']   = isset( $input['output_meta'] ) && in_array( $input['output_meta'], array( 'auto', 'always', 'never' ), true ) ? $input['output_meta'] : 'auto';
		$out['output_schema'] = ! empty( $input['output_schema'] ) ? 1 : 0;
		return $out;
	}

	/** Another SEO plugin already handling meta tags? */
	public static function other_seo_plugin() {
		return (
			class_exists( 'RankMath' ) ||
			defined( 'WPSEO_VERSION' ) ||
			defined( 'AIOSEO_VERSION' ) ||
			defined( 'SEOPRESS_VERSION' )
		);
	}

	public static function should_output_meta() {
		$opts = self::get();
		if ( 'never' === $opts['output_meta'] ) {
			return false;
		}
		if ( 'always' === $opts['output_meta'] ) {
			return true;
		}
		return ! self::other_seo_plugin();
	}

	public static function render_settings() {
		$opts = self::get();
		$name = esc_attr( self::OPTION );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Yacht SEO Settings', 'fy-fleet' ); ?></h1>

			<?php if ( self::other_seo_plugin() ) : ?>
				<div class="notice notice-info"><p>
					<?php esc_html_e( 'Another SEO plugin (Rank Math, Yoast, AIOSEO or SEOPress) is active. Meta tag output is switched off automatically so tags are never duplicated — structured data below is still emitted. Override this with the setting further down if you prefer.', 'fy-fleet' ); ?>
				</p></div>
			<?php endif; ?>

			<form method="post" action="options.php">
				<?php settings_fields( 'fy_fleet_seo_group' ); ?>
				<table class="form-table">
					<tr><th><label for="title_template"><?php esc_html_e( 'Meta title template', 'fy-fleet' ); ?></label></th>
						<td><input type="text" class="large-text" id="title_template" name="<?php echo $name; ?>[title_template]" value="<?php echo esc_attr( $opts['title_template'] ); ?>">
						<p class="description"><?php esc_html_e( 'Tokens: {yacht} {size} {price} {capacity} {site}', 'fy-fleet' ); ?></p></td></tr>
					<tr><th><label for="desc_template"><?php esc_html_e( 'Meta description template', 'fy-fleet' ); ?></label></th>
						<td><textarea class="large-text" rows="3" id="desc_template" name="<?php echo $name; ?>[desc_template]"><?php echo esc_textarea( $opts['desc_template'] ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Used when a yacht has no meta description of its own. Same tokens.', 'fy-fleet' ); ?></p></td></tr>
					<tr><th><?php esc_html_e( 'Meta tag output', 'fy-fleet' ); ?></th>
						<td>
							<select name="<?php echo $name; ?>[output_meta]">
								<option value="auto" <?php selected( $opts['output_meta'], 'auto' ); ?>><?php esc_html_e( 'Auto — skip if another SEO plugin is active (recommended)', 'fy-fleet' ); ?></option>
								<option value="always" <?php selected( $opts['output_meta'], 'always' ); ?>><?php esc_html_e( 'Always output', 'fy-fleet' ); ?></option>
								<option value="never" <?php selected( $opts['output_meta'], 'never' ); ?>><?php esc_html_e( 'Never output', 'fy-fleet' ); ?></option>
							</select>
						</td></tr>
					<tr><th><?php esc_html_e( 'Structured data', 'fy-fleet' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo $name; ?>[output_schema]" value="1" <?php checked( $opts['output_schema'], 1 ); ?>> <?php esc_html_e( 'Emit Product/Service, Breadcrumb and FAQ JSON-LD for yachts', 'fy-fleet' ); ?></label></td></tr>
					<tr><th><label for="brand_name"><?php esc_html_e( 'Brand name', 'fy-fleet' ); ?></label></th>
						<td><input type="text" class="regular-text" id="brand_name" name="<?php echo $name; ?>[brand_name]" value="<?php echo esc_attr( $opts['brand_name'] ); ?>"></td></tr>
					<tr><th><label for="org_url"><?php esc_html_e( 'Organisation URL', 'fy-fleet' ); ?></label></th>
						<td><input type="url" class="regular-text" id="org_url" name="<?php echo $name; ?>[org_url]" value="<?php echo esc_attr( $opts['org_url'] ); ?>"></td></tr>
					<tr><th><label for="org_logo"><?php esc_html_e( 'Organisation logo URL', 'fy-fleet' ); ?></label></th>
						<td><input type="url" class="regular-text" id="org_logo" name="<?php echo $name; ?>[org_logo]" value="<?php echo esc_attr( $opts['org_logo'] ); ?>"></td></tr>
					<tr><th><label for="org_phone"><?php esc_html_e( 'Phone', 'fy-fleet' ); ?></label></th>
						<td><input type="text" class="regular-text" id="org_phone" name="<?php echo $name; ?>[org_phone]" value="<?php echo esc_attr( $opts['org_phone'] ); ?>"></td></tr>
					<tr><th><label for="area_served"><?php esc_html_e( 'Area served', 'fy-fleet' ); ?></label></th>
						<td><input type="text" class="regular-text" id="area_served" name="<?php echo $name; ?>[area_served]" value="<?php echo esc_attr( $opts['area_served'] ); ?>"></td></tr>
					<tr><th><label for="twitter_site"><?php esc_html_e( 'X / Twitter handle', 'fy-fleet' ); ?></label></th>
						<td><input type="text" class="regular-text" id="twitter_site" name="<?php echo $name; ?>[twitter_site]" value="<?php echo esc_attr( $opts['twitter_site'] ); ?>" placeholder="@feelingyachty"></td></tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------
	 * Per-yacht meta box
	 * ---------------------------------------------------------------- */

	public static function add_meta_box() {
		add_meta_box( 'fy_seo', __( 'SEO & Semantic Data', 'fy-fleet' ), array( __CLASS__, 'render_meta_box' ), FY_Fleet_CPT::POST_TYPE, 'normal', 'default' );
	}

	public static function render_meta_box( $post ) {
		wp_nonce_field( 'fy_seo_save', 'fy_seo_nonce' );
		$get = function ( $key ) use ( $post ) {
			return get_post_meta( $post->ID, $key, true );
		};
		?>
		<p class="description"><?php esc_html_e( 'Leave blank to fall back to the templates in Yacht Fleet → SEO. All of these fields are readable and writable over the REST API.', 'fy-fleet' ); ?></p>
		<table class="form-table fy-form-table">
			<tr><th><label for="fy_seo_title"><?php esc_html_e( 'Meta title', 'fy-fleet' ); ?></label></th>
				<td><input type="text" class="large-text" id="fy_seo_title" name="fy_seo_title" value="<?php echo esc_attr( $get( '_fy_seo_title' ) ); ?>">
				<p class="description"><?php esc_html_e( 'Aim for roughly 50–60 characters.', 'fy-fleet' ); ?></p></td></tr>
			<tr><th><label for="fy_seo_description"><?php esc_html_e( 'Meta description', 'fy-fleet' ); ?></label></th>
				<td><textarea class="large-text" rows="3" id="fy_seo_description" name="fy_seo_description"><?php echo esc_textarea( $get( '_fy_seo_description' ) ); ?></textarea>
				<p class="description"><?php esc_html_e( 'Roughly 140–160 characters. Answer the query directly in the first sentence.', 'fy-fleet' ); ?></p></td></tr>
			<tr><th><label for="fy_page_title"><?php esc_html_e( 'Page H1', 'fy-fleet' ); ?></label></th>
				<td><input type="text" class="large-text" id="fy_page_title" name="fy_page_title" value="<?php echo esc_attr( $get( '_fy_page_title' ) ); ?>"></td></tr>
			<tr><th><label for="fy_main_entity"><?php esc_html_e( 'Main entity', 'fy-fleet' ); ?></label></th>
				<td><input type="text" class="large-text" id="fy_main_entity" name="fy_main_entity" value="<?php echo esc_attr( $get( '_fy_main_entity' ) ); ?>" placeholder="<?php esc_attr_e( 'e.g. 50ft Azimut yacht charter', 'fy-fleet' ); ?>">
				<p class="description"><?php esc_html_e( 'The single thing this page is about. Everything else on the page should be an attribute of it.', 'fy-fleet' ); ?></p></td></tr>
			<tr><th><label for="fy_entity_attributes"><?php esc_html_e( 'Entity attributes', 'fy-fleet' ); ?></label></th>
				<td><textarea class="large-text" rows="3" id="fy_entity_attributes" name="fy_entity_attributes" placeholder="length: 50ft&#10;capacity: 13 guests&#10;marina: Rickenbacker"><?php echo esc_textarea( $get( '_fy_entity_attributes' ) ); ?></textarea>
				<p class="description"><?php esc_html_e( 'One per line, "name: value". Emitted as additionalProperty in structured data.', 'fy-fleet' ); ?></p></td></tr>
			<tr><th><label for="fy_focus_keyphrase"><?php esc_html_e( 'Focus keyphrase', 'fy-fleet' ); ?></label></th>
				<td><input type="text" class="large-text" id="fy_focus_keyphrase" name="fy_focus_keyphrase" value="<?php echo esc_attr( $get( '_fy_focus_keyphrase' ) ); ?>"></td></tr>
			<tr><th><label for="fy_secondary_terms"><?php esc_html_e( 'Secondary / related terms', 'fy-fleet' ); ?></label></th>
				<td><textarea class="large-text" rows="2" id="fy_secondary_terms" name="fy_secondary_terms"><?php echo esc_textarea( $get( '_fy_secondary_terms' ) ); ?></textarea>
				<p class="description"><?php esc_html_e( 'Comma separated. Use terms that co-occur with the main entity, not synonyms of the same query.', 'fy-fleet' ); ?></p></td></tr>
			<tr><th><label for="fy_faq"><?php esc_html_e( 'Questions & answers', 'fy-fleet' ); ?></label></th>
				<td><textarea class="large-text" rows="5" id="fy_faq" name="fy_faq" placeholder="How many guests fit on this yacht?|Up to 13 guests plus crew."><?php echo esc_textarea( $get( '_fy_faq' ) ); ?></textarea>
				<p class="description"><?php esc_html_e( 'One per line: Question|Answer. Output as FAQPage structured data. Answer in the first sentence, then expand.', 'fy-fleet' ); ?></p></td></tr>
			<tr><th><label for="fy_breadcrumb"><?php esc_html_e( 'Contextual hierarchy', 'fy-fleet' ); ?></label></th>
				<td><textarea class="large-text" rows="3" id="fy_breadcrumb" name="fy_breadcrumb" placeholder="Home|https://feelingyachty.com/&#10;Miami Yacht Rentals|https://feelingyachty.com/miami-yacht-charters/"><?php echo esc_textarea( $get( '_fy_breadcrumb' ) ); ?></textarea>
				<p class="description"><?php esc_html_e( 'One per line: Label|URL. The yacht itself is appended automatically.', 'fy-fleet' ); ?></p></td></tr>
			<tr><th><label for="fy_seo_content"><?php esc_html_e( 'Description / body copy', 'fy-fleet' ); ?></label></th>
				<td><textarea class="large-text" rows="6" id="fy_seo_content" name="fy_seo_content"><?php echo esc_textarea( $get( '_fy_seo_content' ) ); ?></textarea>
				<p class="description"><?php esc_html_e( 'Shown on the yacht booking page and used as the product description. Editable over the API.', 'fy-fleet' ); ?></p></td></tr>
			<tr><th><label for="fy_canonical"><?php esc_html_e( 'Canonical URL', 'fy-fleet' ); ?></label></th>
				<td><input type="url" class="large-text" id="fy_canonical" name="fy_canonical" value="<?php echo esc_attr( $get( '_fy_canonical' ) ); ?>"></td></tr>
			<tr><th><label for="fy_robots"><?php esc_html_e( 'Robots', 'fy-fleet' ); ?></label></th>
				<td><input type="text" class="regular-text" id="fy_robots" name="fy_robots" value="<?php echo esc_attr( $get( '_fy_robots' ) ); ?>" placeholder="index, follow"></td></tr>
			<tr><th><label for="fy_og_title"><?php esc_html_e( 'Open Graph title', 'fy-fleet' ); ?></label></th>
				<td><input type="text" class="large-text" id="fy_og_title" name="fy_og_title" value="<?php echo esc_attr( $get( '_fy_og_title' ) ); ?>"></td></tr>
			<tr><th><label for="fy_og_description"><?php esc_html_e( 'Open Graph description', 'fy-fleet' ); ?></label></th>
				<td><textarea class="large-text" rows="2" id="fy_og_description" name="fy_og_description"><?php echo esc_textarea( $get( '_fy_og_description' ) ); ?></textarea></td></tr>
			<tr><th><label for="fy_og_image"><?php esc_html_e( 'Open Graph image URL', 'fy-fleet' ); ?></label></th>
				<td><input type="url" class="large-text" id="fy_og_image" name="fy_og_image" value="<?php echo esc_attr( $get( '_fy_og_image' ) ); ?>"></td></tr>
		</table>
		<?php
	}

	public static function save( $post_id, $post ) {
		if ( ! isset( $_POST['fy_seo_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fy_seo_nonce'] ) ), 'fy_seo_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$text_fields = array( 'fy_seo_title', 'fy_page_title', 'fy_main_entity', 'fy_focus_keyphrase', 'fy_robots', 'fy_og_title' );
		foreach ( $text_fields as $field ) {
			update_post_meta( $post_id, '_' . $field, isset( $_POST[ $field ] ) ? sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) : '' );
		}

		$area_fields = array( 'fy_seo_description', 'fy_entity_attributes', 'fy_secondary_terms', 'fy_faq', 'fy_breadcrumb', 'fy_seo_content', 'fy_og_description' );
		foreach ( $area_fields as $field ) {
			update_post_meta( $post_id, '_' . $field, isset( $_POST[ $field ] ) ? sanitize_textarea_field( wp_unslash( $_POST[ $field ] ) ) : '' );
		}

		foreach ( array( 'fy_canonical', 'fy_og_image' ) as $field ) {
			update_post_meta( $post_id, '_' . $field, isset( $_POST[ $field ] ) ? esc_url_raw( wp_unslash( $_POST[ $field ] ) ) : '' );
		}
	}

	/* ------------------------------------------------------------------
	 * Front-end output
	 * ---------------------------------------------------------------- */

	/** Resolve the yacht behind the current request, if any. */
	private static function current_yacht_id() {
		if ( is_singular( FY_Fleet_CPT::POST_TYPE ) ) {
			return get_the_ID();
		}
		if ( function_exists( 'is_product' ) && is_product() ) {
			$yacht_id = (int) get_post_meta( get_the_ID(), '_fy_yacht_id', true );
			if ( $yacht_id ) {
				return $yacht_id;
			}
		}
		return 0;
	}

	public static function tokens( $yacht_id ) {
		$price    = (float) get_post_meta( $yacht_id, '_fy_price', true );
		$capacity = FY_Fleet_CPT::capacity( $yacht_id );
		return array(
			'{yacht}'    => get_the_title( $yacht_id ),
			'{size}'     => get_post_meta( $yacht_id, '_fy_size_ft', true ) . 'ft',
			'{price}'    => '$' . number_format( $price ),
			'{capacity}' => $capacity > 0 ? $capacity . ' guests' : '',
			'{site}'     => get_bloginfo( 'name' ),
		);
	}

	public static function meta_title( $yacht_id ) {
		$custom = get_post_meta( $yacht_id, '_fy_seo_title', true );
		if ( $custom ) {
			return $custom;
		}
		$opts = self::get();
		return strtr( $opts['title_template'], self::tokens( $yacht_id ) );
	}

	public static function meta_description( $yacht_id ) {
		$custom = get_post_meta( $yacht_id, '_fy_seo_description', true );
		if ( $custom ) {
			return $custom;
		}
		$opts = self::get();
		return strtr( $opts['desc_template'], self::tokens( $yacht_id ) );
	}

	public static function output_head() {
		$yacht_id = self::current_yacht_id();
		if ( ! $yacht_id ) {
			return;
		}
		$opts = self::get();

		if ( self::should_output_meta() ) {
			$title = self::meta_title( $yacht_id );
			$desc  = self::meta_description( $yacht_id );
			$image = get_post_meta( $yacht_id, '_fy_og_image', true );
			if ( ! $image ) {
				$image = FY_Fleet_Pricing::yacht_image( $yacht_id );
			}
			$canonical = get_post_meta( $yacht_id, '_fy_canonical', true );
			$robots    = get_post_meta( $yacht_id, '_fy_robots', true );

			echo "\n<!-- Feeling Yachty Fleet SEO -->\n";
			echo '<meta name="description" content="' . esc_attr( wp_strip_all_tags( $desc ) ) . '">' . "\n";
			if ( $robots ) {
				echo '<meta name="robots" content="' . esc_attr( $robots ) . '">' . "\n";
			}
			if ( $canonical ) {
				echo '<link rel="canonical" href="' . esc_url( $canonical ) . '">' . "\n";
			}

			$og_title = get_post_meta( $yacht_id, '_fy_og_title', true );
			$og_desc  = get_post_meta( $yacht_id, '_fy_og_description', true );
			echo '<meta property="og:type" content="product">' . "\n";
			echo '<meta property="og:title" content="' . esc_attr( $og_title ? $og_title : $title ) . '">' . "\n";
			echo '<meta property="og:description" content="' . esc_attr( wp_strip_all_tags( $og_desc ? $og_desc : $desc ) ) . '">' . "\n";
			if ( $image ) {
				echo '<meta property="og:image" content="' . esc_url( $image ) . '">' . "\n";
			}
			echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
			if ( ! empty( $opts['twitter_site'] ) ) {
				echo '<meta name="twitter:site" content="' . esc_attr( $opts['twitter_site'] ) . '">' . "\n";
			}
		}

		if ( ! empty( $opts['output_schema'] ) ) {
			self::output_schema( $yacht_id, $opts );
		}
	}

	private static function output_schema( $yacht_id, $opts ) {
		$price    = (float) get_post_meta( $yacht_id, '_fy_price', true );
		$image    = FY_Fleet_Pricing::yacht_image( $yacht_id );
		$name     = get_the_title( $yacht_id );
		$entity   = get_post_meta( $yacht_id, '_fy_main_entity', true );
		$currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD';

		$properties = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) get_post_meta( $yacht_id, '_fy_entity_attributes', true ) ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || false === strpos( $line, ':' ) ) {
				continue;
			}
			list( $prop_name, $prop_value ) = array_map( 'trim', explode( ':', $line, 2 ) );
			if ( '' === $prop_name || '' === $prop_value ) {
				continue;
			}
			$properties[] = array(
				'@type' => 'PropertyValue',
				'name'  => $prop_name,
				'value' => $prop_value,
			);
		}

		$size = get_post_meta( $yacht_id, '_fy_size_ft', true );
		if ( $size ) {
			$properties[] = array( '@type' => 'PropertyValue', 'name' => 'Length', 'value' => $size . ' ft' );
		}
		$capacity = FY_Fleet_CPT::capacity( $yacht_id );
		if ( $capacity > 0 ) {
			$properties[] = array( '@type' => 'PropertyValue', 'name' => 'Maximum guests', 'value' => (string) $capacity );
		}

		$graph = array();

		$product = array(
			'@type'       => 'Product',
			'@id'         => get_permalink( $yacht_id ) . '#yacht',
			'name'        => $name,
			'description' => wp_strip_all_tags( self::meta_description( $yacht_id ) ),
			'brand'       => array( '@type' => 'Brand', 'name' => $opts['brand_name'] ),
		);
		if ( $entity ) {
			$product['alternateName'] = $entity;
		}
		if ( $image ) {
			$product['image'] = $image;
		}
		if ( $properties ) {
			$product['additionalProperty'] = $properties;
		}
		// Star ratings in search results, when reviews exist.
		if ( class_exists( 'FY_Fleet_Reviews' ) ) {
			$review_parts = FY_Fleet_Reviews::schema_parts( $yacht_id );
			if ( ! empty( $review_parts ) ) {
				$product['aggregateRating'] = $review_parts['aggregateRating'];
				$product['review']          = $review_parts['review'];
			}
		}

		// _fy_price is an HOURLY RATE, not a charter total. Publishing it as
		// the Offer price advertised a $225 yacht day for $225 — so build the
		// real range (boat + crew + fuel per duration) from the same rows the
		// booking form charges from, and only fall back to the raw rate when
		// a yacht has no duration rows at all.
		$charter_offers = class_exists( 'FY_Fleet_Schema' ) ? FY_Fleet_Schema::charter_offers( $yacht_id ) : array();
		if ( ! empty( $charter_offers ) ) {
			$product['offers'] = array(
				'@type'         => 'AggregateOffer',
				'priceCurrency' => $currency,
				'lowPrice'      => (string) $charter_offers[0]['total'],
				'highPrice'     => (string) $charter_offers[ count( $charter_offers ) - 1 ]['total'],
				'offerCount'    => count( $charter_offers ),
				'availability'  => 'https://schema.org/InStock',
				'url'           => get_permalink( $yacht_id ),
				'areaServed'    => $opts['area_served'],
			);
		} elseif ( $price > 0 ) {
			$product['offers'] = array(
				'@type'         => 'Offer',
				'price'         => $price,
				'priceCurrency' => $currency,
				'availability'  => 'https://schema.org/InStock',
				'url'           => get_permalink( $yacht_id ),
				'areaServed'    => $opts['area_served'],
			);
		}
		$graph[] = $product;

		// Contextual hierarchy.
		$crumbs = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) get_post_meta( $yacht_id, '_fy_breadcrumb', true ) ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || false === strpos( $line, '|' ) ) {
				continue;
			}
			list( $label, $url ) = array_map( 'trim', explode( '|', $line, 2 ) );
			$crumbs[] = array( 'label' => $label, 'url' => $url );
		}
		if ( $crumbs ) {
			$elements = array();
			foreach ( $crumbs as $i => $crumb ) {
				$elements[] = array(
					'@type'    => 'ListItem',
					'position' => $i + 1,
					'name'     => $crumb['label'],
					'item'     => $crumb['url'],
				);
			}
			$elements[] = array(
				'@type'    => 'ListItem',
				'position' => count( $elements ) + 1,
				'name'     => $name,
			);
			$graph[] = array( '@type' => 'BreadcrumbList', 'itemListElement' => $elements );
		}

		// Question / answer pairs.
		$faqs = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) get_post_meta( $yacht_id, '_fy_faq', true ) ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || false === strpos( $line, '|' ) ) {
				continue;
			}
			list( $question, $answer ) = array_map( 'trim', explode( '|', $line, 2 ) );
			if ( '' === $question || '' === $answer ) {
				continue;
			}
			$faqs[] = array(
				'@type'          => 'Question',
				'name'           => $question,
				'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $answer ),
			);
		}
		if ( $faqs ) {
			$graph[] = array( '@type' => 'FAQPage', 'mainEntity' => $faqs );
		}

		if ( empty( $graph ) ) {
			return;
		}

		echo '<script type="application/ld+json">' . wp_json_encode(
			array( '@context' => 'https://schema.org', '@graph' => $graph )
		) . '</script>' . "\n";
	}
}
