(function () {
	'use strict';

	var STORAGE_KEY = 'fy_sb_test_tabs_v1';

	function uid() {
		if ( window.crypto && window.crypto.randomUUID ) {
			return window.crypto.randomUUID();
		}
		return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace( /[xy]/g, function ( c ) {
			var r = ( Math.random() * 16 ) | 0, v = c === 'x' ? r : ( r & 0x3 ) | 0x8;
			return v.toString( 16 );
		} );
	}

	function newTab( n ) {
		return { id: uid(), title: 'Session ' + n, sessionId: uid(), messages: [] };
	}

	var copyBtn = document.getElementById( 'fysb-copy-embed' );
	var copyResult = document.getElementById( 'fysb-copy-result' );
	if ( copyBtn ) {
		copyBtn.addEventListener( 'click', function () {
			var ta = document.getElementById( 'fysb-embed-code' );
			if ( ! ta ) {
				return;
			}
			ta.select();
			ta.setSelectionRange( 0, ta.value.length );
			var done = function () {
				if ( copyResult ) {
					copyResult.textContent = 'Copied!';
					copyResult.className = 'fysb-test-result ok';
					setTimeout( function () { copyResult.textContent = ''; }, 2000 );
				}
			};
			if ( navigator.clipboard && navigator.clipboard.writeText ) {
				navigator.clipboard.writeText( ta.value ).then( done ).catch( function () {
					document.execCommand( 'copy' );
					done();
				} );
			} else {
				document.execCommand( 'copy' );
				done();
			}
		} );
	}

	var app = document.getElementById( 'fysb-chat-app' );
	if ( ! app ) {
		return;
	}

	var hasWebhook = app.getAttribute( 'data-has-webhook' ) === '1';
	var regionSelect = document.getElementById( 'fysb-test-region' );
	var tabbar = document.getElementById( 'fysb-tabbar' );
	var messagesEl = document.getElementById( 'fysb-messages' );
	var inputEl = document.getElementById( 'fysb-input' );
	var sendBtn = document.getElementById( 'fysb-send' );
	var wipeBtn = document.getElementById( 'fysb-wipe' );

	var state = loadState();
	if ( ! state || ! state.tabs || ! state.tabs.length ) {
		state = { tabs: [ newTab( 1 ) ], activeId: null };
		state.activeId = state.tabs[ 0 ].id;
	}
	if ( ! state.activeId || ! findTab( state.activeId ) ) {
		state.activeId = state.tabs[ 0 ].id;
	}

	function loadState() {
		try {
			var raw = window.localStorage.getItem( STORAGE_KEY );
			return raw ? JSON.parse( raw ) : null;
		} catch ( e ) {
			return null;
		}
	}

	function saveState() {
		try {
			window.localStorage.setItem( STORAGE_KEY, JSON.stringify( state ) );
		} catch ( e ) {
			/* ignore quota errors */
		}
	}

	function findTab( id ) {
		for ( var i = 0; i < state.tabs.length; i++ ) {
			if ( state.tabs[ i ].id === id ) {
				return state.tabs[ i ];
			}
		}
		return null;
	}

	function activeTab() {
		return findTab( state.activeId );
	}

	function renderTabs() {
		tabbar.innerHTML = '';
		state.tabs.forEach( function ( tab ) {
			var el = document.createElement( 'div' );
			el.className = 'fysb-tab' + ( tab.id === state.activeId ? ' active' : '' );
			el.dataset.tabId = tab.id;

			var titleSpan = document.createElement( 'span' );
			titleSpan.textContent = tab.title;
			el.appendChild( titleSpan );

			if ( state.tabs.length > 1 ) {
				var closeSpan = document.createElement( 'span' );
				closeSpan.className = 'fysb-tab-close';
				closeSpan.textContent = '×';
				closeSpan.addEventListener( 'click', function ( ev ) {
					ev.stopPropagation();
					closeTab( tab.id );
				} );
				el.appendChild( closeSpan );
			}

			el.addEventListener( 'click', function () {
				state.activeId = tab.id;
				saveState();
				renderAll();
			} );

			tabbar.appendChild( el );
		} );

		var addBtn = document.createElement( 'button' );
		addBtn.type = 'button';
		addBtn.className = 'fysb-tab-add';
		addBtn.title = 'New session (fresh chat memory)';
		addBtn.textContent = '+';
		addBtn.addEventListener( 'click', function () {
			var t = newTab( state.tabs.length + 1 );
			state.tabs.push( t );
			state.activeId = t.id;
			saveState();
			renderAll();
		} );
		tabbar.appendChild( addBtn );
	}

	function closeTab( id ) {
		var idx = state.tabs.findIndex( function ( t ) {
			return t.id === id;
		} );
		if ( idx === -1 ) {
			return;
		}
		state.tabs.splice( idx, 1 );
		if ( state.activeId === id ) {
			var next = state.tabs[ idx ] || state.tabs[ idx - 1 ] || state.tabs[ 0 ];
			state.activeId = next.id;
		}
		saveState();
		renderAll();
	}

	function escapeHtml( str ) {
		var div = document.createElement( 'div' );
		div.textContent = str;
		return div.innerHTML;
	}

	/** Runs on already-escaped text, so nothing here can introduce markup the bot controls. */
	function linkifyEscaped( escaped ) {
		return escaped.replace( /https?:\/\/[^\s<>()]+[^\s<>().,!?]/g, function ( url ) {
			return '<a href="' + url + '" target="_blank" rel="noopener noreferrer">' + url + '</a>';
		} );
	}

	function renderMessages() {
		var tab = activeTab();
		messagesEl.innerHTML = '';
		if ( ! tab ) {
			return;
		}
		tab.messages.forEach( function ( msg, idx ) {
			var bubble = document.createElement( 'div' );
			bubble.className = 'fysb-msg ' + msg.role;
			bubble.innerHTML = linkifyEscaped( escapeHtml( msg.text ) ).replace( /\n/g, '<br>' );

			if ( msg.role === 'bot' ) {
				var coachLink = document.createElement( 'div' );
				coachLink.className = 'fysb-coach-link';
				coachLink.textContent = 'Coach this reply →';
				coachLink.addEventListener( 'click', function () {
					toggleCoachBox( bubble, msg, idx );
				} );
				bubble.appendChild( coachLink );
			}

			messagesEl.appendChild( bubble );
		} );
		messagesEl.scrollTop = messagesEl.scrollHeight;
	}

	function toggleCoachBox( bubble, msg, idx ) {
		var existing = bubble.querySelector( '.fysb-coach-box' );
		if ( existing ) {
			existing.remove();
			return;
		}
		var box = document.createElement( 'div' );
		box.className = 'fysb-coach-box';

		var ta = document.createElement( 'textarea' );
		ta.rows = 2;
		ta.placeholder = 'What should it have said, or what should it know for next time?';
		box.appendChild( ta );

		var saveBtn = document.createElement( 'button' );
		saveBtn.type = 'button';
		saveBtn.className = 'button button-small';
		saveBtn.textContent = 'Save Note';
		box.appendChild( saveBtn );

		var savedMsg = document.createElement( 'div' );
		savedMsg.className = 'fysb-coach-saved';
		box.appendChild( savedMsg );

		saveBtn.addEventListener( 'click', function () {
			var note = ta.value.trim();
			if ( ! note ) {
				return;
			}
			var tab = activeTab();
			var context = tab && tab.messages[ idx - 1 ] && tab.messages[ idx - 1 ].role === 'user' ? 'Guest asked: "' + tab.messages[ idx - 1 ].text + '". ' : '';
			saveBtn.disabled = true;
			apiPost( '/coach', { note: context + note } )
				.then( function () {
					savedMsg.textContent = 'Saved — used from your next message.';
					ta.value = '';
					saveBtn.disabled = false;
				} )
				.catch( function ( err ) {
					savedMsg.textContent = 'Could not save: ' + err;
					savedMsg.style.color = '#c0392b';
					saveBtn.disabled = false;
				} );
		} );

		bubble.appendChild( box );
	}

	function apiPost( path, body ) {
		return fetch( FYSupportBot.restUrl + path, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': FYSupportBot.nonce,
			},
			body: JSON.stringify( body ),
		} ).then( function ( res ) {
			return res.json().then( function ( data ) {
				if ( ! res.ok ) {
					throw ( data && data.message ) || 'Request failed (' + res.status + ')';
				}
				return data;
			} );
		} );
	}

	function sendMessage() {
		var text = inputEl.value.trim();
		if ( ! text ) {
			return;
		}
		if ( ! hasWebhook ) {
			alert( 'Set the n8n webhook URL on the Connection tab first.' );
			return;
		}
		var tab = activeTab();
		tab.messages.push( { role: 'user', text: text } );
		tab.messages.push( { role: 'pending', text: 'Thinking...' } );
		inputEl.value = '';
		saveState();
		renderMessages();

		// A test-console "Simulate region" pick stands in for the real
		// embed widget's own window.location.pathname detection — lets the
		// user verify Miami/Panama grounding without leaving wp-admin.
		var region = regionSelect ? regionSelect.value : '';

		apiPost( '/chat', { sessionId: tab.sessionId, message: text, region: region } )
			.then( function ( data ) {
				var pendingIdx = tab.messages.findIndex( function ( m ) {
					return m.role === 'pending';
				} );
				if ( pendingIdx !== -1 ) {
					tab.messages.splice( pendingIdx, 1 );
				}
				tab.messages.push( { role: 'bot', text: data.reply || '(empty reply)' } );
				saveState();
				renderMessages();
			} )
			.catch( function ( err ) {
				var pendingIdx = tab.messages.findIndex( function ( m ) {
					return m.role === 'pending';
				} );
				if ( pendingIdx !== -1 ) {
					tab.messages.splice( pendingIdx, 1 );
				}
				tab.messages.push( { role: 'error', text: String( err ) } );
				saveState();
				renderMessages();
			} );
	}

	function wipeChat() {
		var tab = activeTab();
		if ( ! tab ) {
			return;
		}
		if ( tab.messages.length && ! confirm( 'Clear this chat and start a fresh session?' ) ) {
			return;
		}
		tab.messages = [];
		tab.sessionId = uid();
		saveState();
		renderMessages();
	}

	function renderAll() {
		renderTabs();
		renderMessages();
	}

	sendBtn.addEventListener( 'click', sendMessage );
	wipeBtn.addEventListener( 'click', wipeChat );
	inputEl.addEventListener( 'keydown', function ( ev ) {
		if ( ev.key === 'Enter' && ! ev.shiftKey ) {
			ev.preventDefault();
			sendMessage();
		}
	} );

	// Test Connection button (Connection tab)
	var testBtn = document.getElementById( 'fysb-test-connection' );
	if ( testBtn ) {
		var resultEl = document.getElementById( 'fysb-test-connection-result' );
		testBtn.addEventListener( 'click', function () {
			resultEl.className = 'fysb-test-result pending';
			resultEl.textContent = 'Testing…';
			apiPost( '/test-connection', {} )
				.then( function ( data ) {
					if ( data.ok ) {
						resultEl.className = 'fysb-test-result ok';
						resultEl.textContent = 'Connected (' + data.latency_ms + 'ms)';
					} else {
						resultEl.className = 'fysb-test-result fail';
						resultEl.textContent = data.error;
					}
				} )
				.catch( function ( err ) {
					resultEl.className = 'fysb-test-result fail';
					resultEl.textContent = String( err );
				} );
		} );
	}

	renderAll();
})();
