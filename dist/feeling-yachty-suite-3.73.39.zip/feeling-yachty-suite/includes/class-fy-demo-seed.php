<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One-click QA tool: creates two real, fully-functional demo accounts — one
 * Miami, one Panama — each acting as BOTH a client (with a past reviewable
 * booking and an upcoming one) and a yacht owner (with their own live
 * listing, a blocked date, and an incoming guest booking on it). Everything
 * goes through the real WooCommerce/WordPress APIs (wc_create_order(),
 * set_status(), etc.), so the SAME hooks a genuine booking fires — the
 * webhook, SMS, cache invalidation — fire for these too. Nothing here is a
 * mockup; it's the fastest way to log in and see the whole account portal
 * exactly as a real user would.
 *
 * Safe to run repeatedly: each run resets these two accounts' demo data
 * (orders, yacht ownership, reviews) rather than piling up duplicates.
 */
class FY_Fleet_Demo_Seed {

	const USERS = array(
		'miami'  => array( 'login' => 'demo-miami', 'name' => 'Dana Miami' ),
		'panama' => array( 'login' => 'demo-panama', 'name' => 'Pedro Panama' ),
	);

	public static function init() {
		add_action( 'admin_post_fy_seed_demo_account', array( __CLASS__, 'handle' ) );
	}

	public static function handle() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		check_admin_referer( 'fy_seed_demo_account' );

		$creds = array();
		foreach ( self::USERS as $region => $spec ) {
			$creds[ $region ] = self::seed_one( $region, $spec );
		}

		// A demo password only needs to survive one redirect — a transient,
		// not a URL query arg, so it's never sitting in browser history.
		set_transient( 'fy_demo_seed_result_' . get_current_user_id(), $creds, 5 * MINUTE_IN_SECONDS );

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'demo.seeded', 'Demo accounts (re)seeded for QA — Miami and Panama, each an owner + client.' );
		}

		wp_safe_redirect(
			add_query_arg(
				array( 'page' => 'fy-fleet-visualizer', 'post_type' => FY_Fleet_CPT::POST_TYPE, 'fy_demo_seeded' => '1' ),
				admin_url( 'edit.php' )
			)
		);
		exit;
	}

	private static function seed_one( $region, $spec ) {
		$login = $spec['login'];
		$email = $login . '@feelingyachty.demo';
		$user  = get_user_by( 'login', $login );

		$password = wp_generate_password( 14, false );

		if ( $user ) {
			wp_set_password( $password, $user->ID );
			wp_update_user( array( 'ID' => $user->ID, 'display_name' => $spec['name'] ) );
			$user_id = $user->ID;
			self::reset_previous_demo_data( $user_id );
		} else {
			$user_id = wp_insert_user(
				array(
					'user_login'   => $login,
					'user_email'   => $email,
					'user_pass'    => $password,
					'display_name' => $spec['name'],
					'role'         => 'customer',
				)
			);
			if ( is_wp_error( $user_id ) ) {
				return array( 'error' => $user_id->get_error_message() );
			}
		}

		update_user_meta( $user_id, '_fy_region', $region );
		if ( ! get_role( 'fy_yacht_owner' ) && class_exists( 'FY_Fleet_CPT' ) ) {
			FY_Fleet_CPT::ensure_roles();
		}
		$wp_user = get_userdata( $user_id );
		if ( $wp_user && ! in_array( 'fy_yacht_owner', (array) $wp_user->roles, true ) ) {
			$wp_user->add_role( 'fy_yacht_owner' );
		}

		// A random existing photo as their profile picture — real avatar
		// filtering (pre_get_avatar_data) shown working, not a placeholder.
		$photo = get_posts( array( 'post_type' => 'attachment', 'post_mime_type' => 'image', 'posts_per_page' => 1, 'orderby' => 'rand', 'fields' => 'ids' ) );
		if ( $photo ) {
			update_user_meta( $user_id, '_fy_avatar_id', $photo[0] );
		}

		$region_yachts = self::region_yachts( $region );
		if ( count( $region_yachts ) < 3 ) {
			return array( 'error' => sprintf( 'Not enough published %s yachts to seed demo data (need 3, found %d).', $region, count( $region_yachts ) ) );
		}
		shuffle( $region_yachts );
		$owned_yacht  = $region_yachts[0];
		$booked_yacht = $region_yachts[1]; // the PAST/reviewable booking
		$future_yacht = $region_yachts[2]; // the UPCOMING booking

		// --- Make them the owner of one yacht -------------------------------
		wp_update_post( array( 'ID' => $owned_yacht, 'post_author' => $user_id ) );
		update_post_meta( $owned_yacht, '_fy_blackout_dates', gmdate( 'Y-m-d', strtotime( '+12 days' ) ) );

		// A guest booking ON their yacht, so "My Yacht Bookings" has real
		// data — a plain guest order, not tied to any account, exactly like
		// a real customer who booked without signing up.
		self::create_order( $owned_yacht, '', gmdate( 'Y-m-d', strtotime( '+5 days' ) ), '2:00 PM', 4 );

		// --- Their OWN bookings as a client ----------------------------------
		self::create_order( $booked_yacht, $user_id, gmdate( 'Y-m-d', strtotime( '-3 days' ) ), '9:00 AM', 6, true );
		self::create_order( $future_yacht, $user_id, gmdate( 'Y-m-d', strtotime( '+7 days' ) ), '12:00 PM', 3 );

		return array(
			'login'        => $login,
			'password'     => $password,
			'owned_yacht'  => get_the_title( $owned_yacht ),
			'booked_yacht' => get_the_title( $booked_yacht ),
			'future_yacht' => get_the_title( $future_yacht ),
		);
	}

	/** Published yachts in this region, by the fy_yacht_cat term slug convention used sitewide. */
	private static function region_yachts( $region ) {
		$slug = 'panama' === $region ? 'panama-yacht-rentals' : 'miami-yacht-rental';
		$ids  = get_posts(
			array(
				'post_type'      => FY_Fleet_CPT::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					array( 'taxonomy' => 'fy_yacht_cat', 'field' => 'slug', 'terms' => $slug ),
				),
			)
		);
		// Fall back to any published yacht if this region's own term is
		// empty on this install — better a working demo than a dead button.
		return $ids ? $ids : get_posts( array( 'post_type' => FY_Fleet_CPT::POST_TYPE, 'post_status' => 'publish', 'posts_per_page' => 20, 'fields' => 'ids' ) );
	}

	/**
	 * A real WooCommerce order through the normal API — set_status() below
	 * fires WooCommerce's own order-status hooks exactly like a real
	 * checkout, so the existing webhook/SMS/cache-bump logic in this plugin
	 * runs for these too, not a parallel fake path.
	 */
	private static function create_order( $yacht_id, $customer_id, $date, $time, $hours, $mark_reviewed_source = false ) {
		if ( ! class_exists( 'FY_Fleet_Woo' ) ) {
			return 0;
		}
		$product_id = (int) get_post_meta( $yacht_id, '_fy_product_id', true );
		$product    = $product_id ? wc_get_product( $product_id ) : null;

		$order = wc_create_order();
		if ( $customer_id ) {
			$order->set_customer_id( $customer_id );
		}
		$order->set_billing_first_name( $customer_id ? get_userdata( $customer_id )->display_name : 'Guest Demo' );
		$order->set_billing_email( $customer_id ? get_userdata( $customer_id )->user_email : 'guest-demo@feelingyachty.demo' );

		$item = new WC_Order_Item_Product();
		if ( $product ) {
			$item->set_product( $product );
		}
		$item->set_name( get_the_title( $yacht_id ) );
		$item->set_quantity( 1 );
		$rate  = (float) get_post_meta( $yacht_id, '_fy_price', true );
		$total = round( ( $rate ?: 300 ) * $hours * 0.35, 2 ); // a plausible-looking deposit, not the real engine — this is demo data.
		$item->set_total( $total );
		$item->add_meta_data( '_fy_yacht_id', $yacht_id, true );
		$item->add_meta_data( '_fy_date', $date, true );
		$item->add_meta_data( '_fy_time', $time, true );
		$item->add_meta_data( '_fy_hours', $hours, true );
		$item->add_meta_data( '_fy_guests', min( 8, $hours + 2 ), true );
		$item->add_meta_data( '_fy_marina', 'Demo Marina', true );
		$item->add_meta_data( '_fy_charter_total', round( $total * 2.8, 2 ), true );
		$item->add_meta_data( '_fy_deposit', $total, true );
		$item->add_meta_data( '_fy_balance', round( $total * 1.8, 2 ), true );
		$order->add_item( $item );
		$order->calculate_totals();
		$order->update_meta_data( '_fy_demo_seed', '1' ); // marks it for cleanup on the next reseed.
		$order->save();
		$order->set_status( 'processing' ); // fires the real WooCommerce order-status hooks.
		$order->save();

		if ( $mark_reviewed_source && $customer_id && class_exists( 'FY_Fleet_Reviews' ) ) {
			$items    = $order->get_items();
			$item_id  = array_key_first( $items );
			FY_Fleet_Reviews::submit_customer_review(
				$yacht_id,
				$customer_id,
				$order->get_id(),
				$item_id,
				5,
				'Incredible day on the water — the crew took care of everything and the boat was spotless. Already planning our next charter!'
			);
		}

		return $order->get_id();
	}

	/**
	 * Undoes the PREVIOUS run's demo orders/reviews/ownership before
	 * reseeding, so clicking the button twice doesn't pile up duplicate
	 * bookings on whichever yacht got randomly picked last time.
	 */
	private static function reset_previous_demo_data( $user_id ) {
		// Release any yacht this demo user was previously made the owner of.
		$owned = get_posts(
			array(
				'post_type'      => FY_Fleet_CPT::POST_TYPE,
				'post_status'    => 'publish',
				'author'         => $user_id,
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);
		foreach ( $owned as $yacht_id ) {
			wp_update_post( array( 'ID' => $yacht_id, 'post_author' => 1 ) );
			update_post_meta( $yacht_id, '_fy_blackout_dates', '' );

			// Strip any demo customer review left on it.
			if ( class_exists( 'FY_Fleet_Reviews' ) ) {
				$reviews  = FY_Fleet_Reviews::get( $yacht_id );
				$filtered = array_values( array_filter( $reviews, function ( $r ) {
					return ! ( isset( $r['source'] ) && 'customer' === $r['source'] && strpos( $r['text'], 'Incredible day on the water' ) === 0 );
				} ) );
				if ( count( $filtered ) !== count( $reviews ) ) {
					update_post_meta( $yacht_id, '_fy_reviews', $filtered );
				}
			}
		}

		// Remove this account's demo orders (tagged _fy_demo_seed) and any
		// demo GUEST orders left on a yacht it used to own.
		$orders = wc_get_orders( array( 'limit' => -1, 'return' => 'ids', 'meta_key' => '_fy_demo_seed', 'meta_value' => '1' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		foreach ( $orders as $order_id ) {
			$order = wc_get_order( $order_id );
			if ( $order && ( (int) $order->get_customer_id() === (int) $user_id || 0 === (int) $order->get_customer_id() ) ) {
				$order->delete( true );
			}
		}
	}
}
