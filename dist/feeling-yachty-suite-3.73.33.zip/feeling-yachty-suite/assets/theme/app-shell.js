/* Feeling Yachty — app shell script. Two jobs, both about speed:
 *
 * 1. Hover/touch prefetch (instant.page-style): the moment a visitor's
 *    pointer settles on an internal link, the next page's HTML is
 *    prefetched — by the time they finish the click it's already in the
 *    browser cache, so navigation feels app-instant.
 * 2. Nothing else. The floating checkout pill is server-rendered and kept
 *    live by WooCommerce's own cart-fragments script; the press feedback
 *    and view transitions are pure CSS. No jQuery, loaded deferred.
 */
( function () {
	'use strict';

	if ( ! ( 'requestIdleCallback' in window ) && ! ( 'requestAnimationFrame' in window ) ) {
		return;
	}

	// Respect data-saver mode and very slow connections — prefetching
	// there costs the visitor real money/time for pages they may not open.
	var conn = navigator.connection || {};
	if ( conn.saveData || /(^|-)2g$/.test( conn.effectiveType || '' ) ) {
		return;
	}

	var prefetched = Object.create( null );
	var count = 0;
	var MAX_PREFETCH = 60;
	var HOVER_DELAY = 65; // ms — long enough to skip drive-by pointer moves.
	var timer = 0;

	function prefetchable( a ) {
		if ( ! a || ! a.href || count >= MAX_PREFETCH ) {
			return '';
		}
		// Hash-only links (submenu toggles, Elementor popup/lightbox
		// actions) never navigate — prefetching their base URL is waste.
		var rawHref = a.getAttribute( 'href' ) || '';
		if ( '#' === rawHref.charAt( 0 ) || -1 !== rawHref.indexOf( 'elementor-action' ) ) {
			return '';
		}
		if ( a.origin !== location.origin ) {
			return '';
		}
		if ( a.target && '_self' !== a.target ) {
			return '';
		}
		var url = a.href.split( '#' )[ 0 ];
		if ( ! url || url === location.href.split( '#' )[ 0 ] || prefetched[ url ] ) {
			return '';
		}
		var path = a.pathname || '';
		// Never prefetch state-changing or per-visitor URLs: cart/checkout
		// (nonces + totals), account, login/admin, or anything with an
		// action-looking query string.
		if ( /wp-admin|wp-login|logout|\/cart\b|\/checkout\b|\/my-account\b|\/login\b/i.test( path ) ) {
			return '';
		}
		if ( /(\?|&)(add-to-cart|remove_item|logout|_wpnonce)=/i.test( a.search || '' ) ) {
			return '';
		}
		// Skip obvious binaries.
		if ( /\.(pdf|zip|jpe?g|png|webp|gif|mp4|apk)$/i.test( path ) ) {
			return '';
		}
		return url;
	}

	function prefetch( url ) {
		prefetched[ url ] = true;
		count++;
		var link = document.createElement( 'link' );
		link.rel = 'prefetch';
		link.href = url;
		link.as = 'document';
		document.head.appendChild( link );
	}

	document.addEventListener(
		'mouseover',
		function ( e ) {
			var a = e.target && e.target.closest ? e.target.closest( 'a[href]' ) : null;
			var url = prefetchable( a );
			if ( ! url ) {
				return;
			}
			clearTimeout( timer );
			timer = setTimeout( function () {
				if ( ! prefetched[ url ] ) {
					prefetch( url );
				}
			}, HOVER_DELAY );
		},
		{ passive: true }
	);

	document.addEventListener(
		'mouseout',
		function () {
			clearTimeout( timer );
		},
		{ passive: true }
	);

	// On touch there is no hover — prefetch on first contact instead;
	// the ~100ms between touchstart and the click event is enough of a
	// head start to matter.
	document.addEventListener(
		'touchstart',
		function ( e ) {
			var a = e.target && e.target.closest ? e.target.closest( 'a[href]' ) : null;
			var url = prefetchable( a );
			if ( url ) {
				prefetch( url );
			}
		},
		{ passive: true }
	);

	/* ---- Menu rescue: expandable parents that don't expand ----
	 * WordPress menus mark expandable parents with .menu-item-has-children.
	 * Inside the Elementor menu popup nothing handles the tap, so parents
	 * like Destinations → Miami / Panama City did nothing (or worse: a
	 * WordPress "Custom Link" placeholder like "https://site.com/#" counts
	 * as a real URL and navigates to the homepage).
	 *
	 * Rules, at every nesting depth:
	 *  - Placeholder link ("", "#", "#anything", ".../#") → tap toggles the
	 *    submenu, anywhere on the site.
	 *  - REAL link inside the menu popup → first tap EXPANDS the submenu,
	 *    a second tap on the open parent navigates (the standard mobile
	 *    dual-tap pattern — children stay reachable, the page too).
	 *  - Real links outside popups (desktop hover menus) are untouched.
	 */
	function fyIsPlaceholderHref( href ) {
		href = ( href || '' ).trim();
		if ( '' === href || '#' === href.charAt( 0 ) ) {
			return true;
		}
		// "https://site.com/#", "http://#", "/#" — hash-suffixed non-links.
		if ( /\/#$/.test( href ) || /^https?:\/\/#/.test( href ) ) {
			return true;
		}
		return false;
	}
	document.addEventListener( 'click', function ( e ) {
		var a = e.target && e.target.closest
			? e.target.closest( 'li.menu-item-has-children > a, li.page_item_has_children > a' )
			: null;
		if ( ! a ) {
			return;
		}
		var li          = a.parentElement;
		var placeholder = fyIsPlaceholderHref( a.getAttribute( 'href' ) );
		var inPopup     = !! ( a.closest && a.closest( '.elementor-popup-modal' ) );
		if ( ! placeholder && ! inPopup ) {
			return; // Desktop hover menu with a real link — navigate.
		}
		if ( ! placeholder && li.classList.contains( 'fy-submenu-open' ) ) {
			return; // Second tap on an open real-link parent — navigate.
		}
		e.preventDefault();
		var open = li.classList.toggle( 'fy-submenu-open' );
		a.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
	} );

	/* ---- Step aside while an Elementor popup (e.g. the menu) is open —
	 * the floating checkout pill must never sit on top of menu items. */
	function watchPopups() {
		if ( ! window.jQuery ) {
			return;
		}
		window.jQuery( document )
			.on( 'elementor/popup/show', function () {
				document.body.classList.add( 'fy-popup-open' );
			} )
			.on( 'elementor/popup/hide', function () {
				document.body.classList.remove( 'fy-popup-open' );
			} );
	}
	if ( window.jQuery ) {
		watchPopups();
	} else {
		window.addEventListener( 'load', watchPopups );
	}
} )();
