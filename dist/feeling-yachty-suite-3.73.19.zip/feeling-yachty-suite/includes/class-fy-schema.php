<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Search-engine data for yacht PRODUCT pages — the pages customers actually
 * land on.
 *
 * Everything here is derived at render time from the same live values the
 * [fy_yacht_*] shortcodes read (pricing rows, crew/fuel rates, capacity,
 * marina, add-ons). Nothing is cached or copied into a second place, so
 * editing a yacht in the Visualizer updates its schema on the next page
 * view — no re-sync, no re-import.
 *
 * Division of labour with Rank Math (or Yoast/AIOSEO):
 *  - Titles, descriptions, Open Graph, sitemaps, breadcrumbs → theirs.
 *  - Anything that needs FLEET data they cannot know — real charter totals,
 *    departure coordinates, charter policies → ours.
 * Where both would describe the same thing (the Product entity), this class
 * CORRECTS theirs rather than publishing a second, competing copy.
 */
class FY_Fleet_Schema {

	public static function init() {
		// Yacht products are catalog-hidden on purpose (180 yachts would bury
		// the shop). Rank Math reads "hidden" as "noindex", which took every
		// yacht page out of Google. They are real, public, linkable pages —
		// say so explicitly.
		add_filter( 'rank_math/frontend/robots', array( __CLASS__, 'force_index' ) );

		// Rank Math falls back to page content for the description, and that
		// content is our shortcode stack — so every yacht was describing
		// itself as "[fy_yacht_layout] [fy_yacht_reviews] [fy_yacht_marina]".
		add_filter( 'rank_math/frontend/description', array( __CLASS__, 'real_description' ) );
		add_filter( 'wpseo_metadesc', array( __CLASS__, 'real_description' ) );

		// Correct the Product entity in place instead of adding a second one.
		add_filter( 'rank_math/snippet/rich_snippet_product_entity', array( __CLASS__, 'enrich_product_entity' ) );

		// Sitemap hygiene — verified live: the yacht CPT sitemap was offering
		// Google 458 URLs that are every one of them noindex and canonical to
		// the product page instead, while the city hubs (the pages that list
		// the whole fleet) were in no sitemap at all.
		add_filter( 'rank_math/sitemap/exclude_post_type', array( __CLASS__, 'exclude_yacht_cpt_sitemap' ), 10, 2 );
		add_filter( 'rank_math/sitemap/exclude_taxonomy', array( __CLASS__, 'include_city_sitemap' ), 10, 2 );

		// The structured data itself IS optional — it follows the SEO module's
		// own switch, unlike the two corrections above.
		if ( class_exists( 'FY_Fleet_Features' ) && ! FY_Fleet_Features::on( 'seo' ) ) {
			return;
		}
		// Our own graph: the parts no SEO plugin can derive.
		add_action( 'wp_head', array( __CLASS__, 'output_graph' ), 20 );
	}

	/* ------------------------------------------------------------------
	 * Context
	 * ---------------------------------------------------------------- */

	/** The yacht behind the page being viewed, or 0. */
	public static function yacht_id() {
		if ( class_exists( 'FY_Fleet_CPT' ) && is_singular( FY_Fleet_CPT::POST_TYPE ) ) {
			return (int) get_the_ID();
		}
		if ( function_exists( 'is_product' ) && is_product() ) {
			return (int) get_post_meta( get_the_ID(), '_fy_yacht_id', true );
		}
		return 0;
	}

	/* ------------------------------------------------------------------
	 * Indexability + description
	 * ---------------------------------------------------------------- */

	public static function force_index( $robots ) {
		if ( ! self::yacht_id() ) {
			return $robots;
		}
		if ( ! is_array( $robots ) ) {
			$robots = array();
		}
		$robots['index']  = 'index';
		$robots['follow'] = 'follow';
		unset( $robots['noindex'], $robots['nofollow'] );
		return $robots;
	}

	/**
	 * Plain-text summary of this yacht: the unique description written for it
	 * at import, trimmed to a sensible meta length.
	 */
	public static function description_text( $yacht_id, $words = 30 ) {
		$text = trim( (string) get_post_meta( $yacht_id, '_fy_special_desc', true ) );
		if ( '' === $text ) {
			$text = trim( (string) get_post_meta( $yacht_id, '_fy_price_note', true ) );
		}
		if ( '' === $text ) {
			$size     = (int) get_post_meta( $yacht_id, '_fy_size_ft', true );
			$capacity = class_exists( 'FY_Fleet_CPT' ) ? FY_Fleet_CPT::capacity( $yacht_id ) : 0;
			$bits     = array_filter(
				array(
					$size ? $size . 'ft' : '',
					get_the_title( $yacht_id ),
					__( 'private yacht charter', 'fy-fleet' ),
					$capacity ? sprintf( __( 'for up to %d guests', 'fy-fleet' ), $capacity ) : '',
				)
			);
			$text = implode( ' ', $bits ) . '.';
		}
		// Shortcodes must never leak into a description — stripping tags is
		// not enough, they are plain text at this point.
		$text = preg_replace( '/\[[^\]]*\]/', '', wp_strip_all_tags( $text ) );
		return trim( wp_trim_words( $text, $words, '…' ) );
	}

	public static function real_description( $desc ) {
		$yacht_id = self::yacht_id();
		if ( ! $yacht_id ) {
			return $desc;
		}
		// Only step in when what's there is empty or is our own shortcode
		// stack leaking through — a description written by hand wins.
		$looks_broken = ( '' === trim( (string) $desc ) ) || ( false !== strpos( (string) $desc, '[fy_yacht' ) );
		return $looks_broken ? self::description_text( $yacht_id ) : $desc;
	}

	/* ------------------------------------------------------------------
	 * Sitemap
	 * ---------------------------------------------------------------- */

	/**
	 * Keep the yacht CPT out of the sitemap.
	 *
	 * Those pages are noindex and canonical to the WooCommerce product, so
	 * submitting them asks Google to crawl hundreds of URLs it is then told
	 * to ignore. The product pages are the real, indexable destination and
	 * are already in product-sitemap.xml.
	 */
	public static function exclude_yacht_cpt_sitemap( $exclude, $post_type ) {
		if ( class_exists( 'FY_Fleet_CPT' ) && FY_Fleet_CPT::POST_TYPE === $post_type ) {
			return true;
		}
		return $exclude;
	}

	/** City hubs list the whole fleet — they belong in the sitemap. */
	public static function include_city_sitemap( $exclude, $taxonomy ) {
		if ( 'fy_yacht_cat' === $taxonomy ) {
			return false;
		}
		return $exclude;
	}

	/* ------------------------------------------------------------------
	 * Charter pricing — the same numbers the booking form charges
	 * ---------------------------------------------------------------- */

	/**
	 * Bookable durations with their REAL total cost.
	 *
	 * The WooCommerce variation price is crew + boat deposit only (the part
	 * paid online); the remaining boat balance is paid at the dock.
	 * Publishing the variation price as "the price" would advertise a
	 * 5-hour charter at $875 when it actually costs $2,375 — so the full
	 * total is rebuilt here from the yacht's own pricing rows plus crew
	 * (listed total). Boat deposits are credited, so they are not added.
	 *
	 * @return array<int,array{hours:float,total:float}>
	 */
	public static function charter_offers( $yacht_id ) {
		if ( ! class_exists( 'FY_Fleet_Pricing' ) || ! class_exists( 'FY_Fleet_Settings' ) ) {
			return array();
		}
		$rows = get_post_meta( $yacht_id, '_fy_pricing', true );
		if ( ! is_array( $rows ) ) {
			return array();
		}
		$offers = array();
		foreach ( $rows as $row ) {
			if ( ! isset( $row['type'] ) || 'price' !== $row['type'] ) {
				continue;
			}
			$hours = FY_Fleet_Pricing::hours_from_label( isset( $row['duration'] ) ? $row['duration'] : '' );
			$boat  = isset( $row['price'] ) ? (float) $row['price'] : 0;
			if ( $hours <= 0 || $boat <= 0 ) {
				continue;
			}
			$offers[] = array(
				'hours' => (float) $hours,
				'total' => FY_Fleet_Pricing::listed_total( $yacht_id, $boat, $hours ),
			);
		}
		usort(
			$offers,
			function ( $a, $b ) {
				return ( $a['total'] < $b['total'] ) ? -1 : ( ( $a['total'] > $b['total'] ) ? 1 : 0 );
			}
		);
		return $offers;
	}

	private static function currency() {
		return function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD';
	}

	/* ------------------------------------------------------------------
	 * Rank Math's Product entity, corrected
	 * ---------------------------------------------------------------- */

	public static function enrich_product_entity( $entity ) {
		$yacht_id = self::yacht_id();
		if ( ! $yacht_id || ! is_array( $entity ) ) {
			return $entity;
		}

		$offers = self::charter_offers( $yacht_id );
		if ( ! empty( $offers ) ) {
			$low  = $offers[0]['total'];
			$high = $offers[ count( $offers ) - 1 ]['total'];

			$entity['offers'] = array(
				'@type'         => 'AggregateOffer',
				'priceCurrency' => self::currency(),
				'lowPrice'      => (string) $low,
				'highPrice'     => (string) $high,
				'offerCount'    => count( $offers ),
				'availability'  => 'https://schema.org/InStock',
				'url'           => get_permalink(),
				'seller'        => array(
					'@type' => 'Organization',
					'name'  => get_bloginfo( 'name' ),
				),
			);
		}

		$entity['description'] = self::description_text( $yacht_id, 55 );

		$props = array();
		$size  = (int) get_post_meta( $yacht_id, '_fy_size_ft', true );
		if ( $size ) {
			$props[] = array( '@type' => 'PropertyValue', 'name' => __( 'Length', 'fy-fleet' ), 'value' => $size . ' ft' );
		}
		$capacity = class_exists( 'FY_Fleet_CPT' ) ? FY_Fleet_CPT::capacity( $yacht_id ) : 0;
		if ( $capacity ) {
			$props[] = array( '@type' => 'PropertyValue', 'name' => __( 'Maximum guests', 'fy-fleet' ), 'value' => (string) $capacity );
		}
		foreach ( array( '_fy_brand' => __( 'Builder', 'fy-fleet' ), '_fy_model' => __( 'Model', 'fy-fleet' ), '_fy_year' => __( 'Year', 'fy-fleet' ) ) as $meta_key => $label ) {
			$value = trim( (string) get_post_meta( $yacht_id, $meta_key, true ) );
			if ( '' !== $value ) {
				$props[] = array( '@type' => 'PropertyValue', 'name' => $label, 'value' => $value );
			}
		}
		if ( $props ) {
			$entity['additionalProperty'] = $props;
		}

		return $entity;
	}

	/* ------------------------------------------------------------------
	 * Our own graph
	 * ---------------------------------------------------------------- */

	/** Departure marina as a real place, with coordinates when we have them. */
	public static function marina_place( $yacht_id ) {
		if ( ! class_exists( 'FY_Fleet_Marina' ) ) {
			return null;
		}
		$marina = FY_Fleet_Marina::for_yacht( $yacht_id );
		if ( ! $marina || empty( $marina['title'] ) ) {
			return null;
		}
		$place = array(
			'@type' => 'Place',
			'name'  => $marina['title'],
		);
		if ( ! empty( $marina['address'] ) ) {
			$place['address'] = array(
				'@type'         => 'PostalAddress',
				'streetAddress' => $marina['address'],
			);
		}
		if ( ! empty( $marina['lat'] ) && ! empty( $marina['lng'] ) ) {
			$place['geo'] = array(
				'@type'     => 'GeoCoordinates',
				'latitude'  => (string) $marina['lat'],
				'longitude' => (string) $marina['lng'],
			);
		}
		return $place;
	}

	/**
	 * Charter policies as FAQ entries, built from the LIVE settings — change
	 * the crew rate or the deposit split and every yacht's FAQ follows.
	 */
	public static function faq_entries( $yacht_id ) {
		if ( ! class_exists( 'FY_Fleet_Settings' ) ) {
			return array();
		}
		// A yacht with hand-written Q&A already emits its own FAQPage from
		// FY_Fleet_SEO — two FAQPage nodes on one URL is worse than none, and
		// what the owner typed should win over anything generated here.
		if ( '' !== trim( (string) get_post_meta( $yacht_id, '_fy_faq', true ) ) ) {
			return array();
		}
		$faqs     = array();
		$capacity = class_exists( 'FY_Fleet_CPT' ) ? FY_Fleet_CPT::capacity( $yacht_id ) : 0;
		$name     = get_the_title( $yacht_id );
		if ( $capacity > 0 ) {
			$faqs[] = array(
				sprintf( __( 'How many guests can %s carry?', 'fy-fleet' ), $name ),
				sprintf( __( '%1$s is licensed for up to %2$d guests, including children.', 'fy-fleet' ), $name, $capacity ),
			);
		}

		$faqs[] = array(
			__( 'What do I pay when I book online?', 'fy-fleet' ),
			FY_Fleet_Settings::threshold_rule_text(),
		);

		$faqs[] = array(
			__( 'What time should I arrive?', 'fy-fleet' ),
			__( 'Please arrive at least 30 minutes before departure to check in and sign the charter agreement. Charters run back to back, so arriving early protects your full time on the water.', 'fy-fleet' ),
		);

		$offers = self::charter_offers( $yacht_id );
		if ( ! empty( $offers ) ) {
			$first = $offers[0];
			$faqs[] = array(
				sprintf( __( 'How much does it cost to charter %s?', 'fy-fleet' ), $name ),
				sprintf(
					__( 'A %1$d-hour charter on %2$s is $%3$s in total (boat + crew + deposit). Longer charters are priced per hour and shown on the booking form.', 'fy-fleet' ),
					(int) $first['hours'],
					$name,
					number_format( $first['total'] )
				),
			);
		}

		$out = array();
		foreach ( $faqs as $faq ) {
			$out[] = array(
				'@type'          => 'Question',
				'name'           => $faq[0],
				'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $faq[1] ),
			);
		}
		return $out;
	}

	public static function output_graph() {
		$yacht_id = self::yacht_id();
		if ( ! $yacht_id ) {
			return;
		}
		if ( class_exists( 'FY_Fleet_SEO' ) ) {
			$opts = FY_Fleet_SEO::get();
			if ( empty( $opts['output_schema'] ) ) {
				return;
			}
		}

		$url   = get_permalink();
		$graph = array();

		// The charter itself as a service, with where it leaves from and the
		// area it covers — none of which an SEO plugin can infer.
		$service = array(
			'@type'       => 'Service',
			'@id'         => $url . '#charter',
			'serviceType' => __( 'Private yacht charter', 'fy-fleet' ),
			'name'        => get_the_title( $yacht_id ),
			'description' => self::description_text( $yacht_id, 55 ),
			'provider'    => array(
				'@type' => 'Organization',
				'name'  => get_bloginfo( 'name' ),
				'url'   => home_url( '/' ),
			),
		);

		$place = self::marina_place( $yacht_id );
		if ( $place ) {
			$service['areaServed'] = $place;
			$graph[]               = $place + array( '@id' => $url . '#departure' );
		}

		$offers = self::charter_offers( $yacht_id );
		if ( ! empty( $offers ) ) {
			$list = array();
			foreach ( $offers as $offer ) {
				$list[] = array(
					'@type'         => 'Offer',
					'name'          => sprintf( __( '%d-hour private charter', 'fy-fleet' ), (int) $offer['hours'] ),
					'price'         => (string) $offer['total'],
					'priceCurrency' => self::currency(),
					'availability'  => 'https://schema.org/InStock',
					'url'           => $url,
				);
			}
			$service['offers'] = $list;
		}
		$graph[] = $service;

		$faqs = self::faq_entries( $yacht_id );
		if ( ! empty( $faqs ) ) {
			$graph[] = array(
				'@type'      => 'FAQPage',
				'@id'        => $url . '#faq',
				'mainEntity' => $faqs,
			);
		}

		if ( empty( $graph ) ) {
			return;
		}

		echo "\n<!-- Feeling Yachty fleet schema -->\n";
		echo '<script type="application/ld+json">'
			. wp_json_encode(
				array( '@context' => 'https://schema.org', '@graph' => $graph ),
				JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
			)
			. '</script>' . "\n";
	}
}
