(function ( $ ) {
	'use strict';

	function newIndex() {
		return 'n' + Date.now() + Math.floor( Math.random() * 1000 );
	}

	function appendItem( data ) {
		var container = document.getElementById( 'fy-gallery-items' );
		var template  = document.getElementById( 'fy-gallery-item-template' );
		if ( ! container || ! template ) {
			return null;
		}
		var html = template.innerHTML.split( '__INDEX__' ).join( newIndex() );
		var wrap = document.createElement( 'div' );
		wrap.innerHTML = html.trim();
		var item = wrap.firstElementChild;
		if ( ! item ) {
			return null;
		}
		container.appendChild( item );

		if ( data ) {
			var idField  = item.querySelector( '.fy-gallery-id' );
			var urlField = item.querySelector( '.fy-gallery-url' );
			var img      = item.querySelector( '.fy-gallery-thumb img' );
			if ( idField ) { idField.value = data.id || ''; }
			if ( urlField ) { urlField.value = data.url || ''; }
			if ( img && data.url ) {
				img.src = data.url;
				img.style.display = '';
			}
		}
		return item;
	}

	document.addEventListener( 'click', function ( e ) {
		if ( e.target.id === 'fy-gallery-add' ) {
			e.preventDefault();
			if ( ! window.wp || ! window.wp.media ) {
				return;
			}
			var frame = window.wp.media( {
				title: 'Select photos',
				multiple: 'add',
				library: { type: 'image' }
			} );
			frame.on( 'select', function () {
				frame.state().get( 'selection' ).each( function ( attachment ) {
					var a = attachment.toJSON();
					var url = ( a.sizes && a.sizes.large ) ? a.sizes.large.url : a.url;
					appendItem( { id: a.id, url: url } );
				} );
			} );
			frame.open();
			return;
		}

		if ( e.target.id === 'fy-gallery-add-url' ) {
			e.preventDefault();
			var item = appendItem( null );
			if ( item ) {
				var field = item.querySelector( '.fy-gallery-url' );
				if ( field ) { field.focus(); }
			}
			return;
		}

		if ( e.target.classList.contains( 'fy-gallery-remove' ) ) {
			e.preventDefault();
			var row = e.target.closest( '.fy-gallery-item' );
			if ( row ) {
				row.parentNode.removeChild( row );
			}
		}
	} );

	// Live thumbnail when a URL is typed or pasted.
	document.addEventListener( 'input', function ( e ) {
		if ( ! e.target.classList.contains( 'fy-gallery-url' ) ) {
			return;
		}
		var row = e.target.closest( '.fy-gallery-item' );
		if ( ! row ) {
			return;
		}
		var img = row.querySelector( '.fy-gallery-thumb img' );
		if ( ! img ) {
			return;
		}
		if ( e.target.value.trim() ) {
			img.src = e.target.value.trim();
			img.style.display = '';
		} else {
			img.style.display = 'none';
		}
	} );

	// Reorder by dragging, when jQuery UI is available.
	$( function () {
		if ( $.fn.sortable ) {
			$( '#fy-gallery-items' ).sortable( { items: '.fy-gallery-item', cursor: 'move' } );
		}
	} );
})( jQuery );
