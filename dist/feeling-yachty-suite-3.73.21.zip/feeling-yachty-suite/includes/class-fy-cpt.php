<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class FY_Fleet_CPT {

	const POST_TYPE = 'fy_yacht';

	/** Guest capacity shown when a yacht has not been given its own number. */
	const DEFAULT_CAPACITY = 13;

	/**
	 * Max guests for a yacht: its own value, or the fleet default.
	 * Type "0" on a yacht to hide the figure on that one yacht.
	 */
	public static function capacity( $yacht_id ) {
		$value = get_post_meta( $yacht_id, '_fy_capacity_max', true );
		if ( '' === $value || null === $value ) {
			return self::DEFAULT_CAPACITY;
		}
		return (int) $value;
	}

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_post_type' ) );
		add_filter( 'post_type_link', array( __CLASS__, 'resolve_permalink' ), 10, 2 );
		add_action( 'admin_init', array( __CLASS__, 'maybe_flush' ) );
		add_action( 'admin_init', array( __CLASS__, 'ensure_roles' ) );
		add_action( 'admin_init', array( __CLASS__, 'backfill_default_city' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_flag_pink_yachts' ) );
		add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'assign_default_city' ), 30, 2 );
		// Yacht records are data only — there is no public yacht page. Any old
		// yacht URL (bookmarks, Google results) 301s to its WooCommerce product.
		add_action( 'template_redirect', array( __CLASS__, 'redirect_yacht_page' ) );
		// And no "All Yachts" list either: the bare list URL (including the
		// top-level ⚓ menu click) lands on the Fleet Visualizer.
		add_action( 'current_screen', array( __CLASS__, 'redirect_list_to_visualizer' ) );
		add_filter( 'post_row_actions', array( __CLASS__, 'duplicate_row_action' ), 10, 2 );
		add_action( 'admin_post_fy_duplicate_yacht', array( __CLASS__, 'handle_duplicate' ) );
		add_action( 'admin_post_fy_delete_yacht', array( __CLASS__, 'handle_delete' ) );
		add_action( 'admin_menu', array( __CLASS__, 'reorder_submenu' ), 999 );
		add_filter( 'manage_' . self::POST_TYPE . '_posts_columns', array( __CLASS__, 'admin_columns' ) );
		add_action( 'manage_' . self::POST_TYPE . '_posts_custom_column', array( __CLASS__, 'admin_column_content' ), 10, 2 );
		add_filter( 'manage_edit-' . self::POST_TYPE . '_sortable_columns', array( __CLASS__, 'sortable_columns' ) );
		add_action( 'pre_get_posts', array( __CLASS__, 'admin_sort' ) );
	}

	public static function activate() {
		self::register_post_type();
		self::ensure_roles();
		flush_rewrite_rules();
	}

	/** The yacht list screen is retired — send it to the Fleet Visualizer. */
	public static function redirect_list_to_visualizer( $screen ) {
		if ( ! $screen || 'edit-' . self::POST_TYPE !== $screen->id || ! empty( $_GET['page'] ) ) {
			return;
		}
		wp_safe_redirect( admin_url( 'edit.php?post_type=' . self::POST_TYPE . '&page=fy-fleet-visualizer' ) );
		exit;
	}

	/** Old /miami-yacht-rentals/name/ links land on the product buy page. */
	public static function redirect_yacht_page() {
		if ( ! is_singular( self::POST_TYPE ) ) {
			return;
		}
		$yacht_id = get_queried_object_id();
		$self_url = get_permalink( $yacht_id );

		$target     = '';
		$product_id = (int) get_post_meta( $yacht_id, '_fy_product_id', true );
		if ( $product_id && 'product' === get_post_type( $product_id ) && 'publish' === get_post_status( $product_id ) ) {
			$target = get_permalink( $product_id );
		}
		if ( ! $target ) {
			$target = (string) get_post_meta( $yacht_id, '_fy_button_url', true );
		}
		// No product and no button URL — serve the page as-is rather than
		// bouncing to the homepage. A 301 from a content URL to the homepage
		// is read by search engines as a soft 404: the URL stays in the index
		// as a dead end, and any authority it had is thrown away instead of
		// passed on. The page itself is already noindex and canonicalised to
		// the product, so leaving it be is both safer and more honest than a
		// redirect that answers a different question than the one asked.
		if ( ! $target || untrailingslashit( $target ) === untrailingslashit( (string) $self_url ) ) {
			return;
		}
		wp_safe_redirect( $target, 301 );
		exit;
	}

	public static function register_post_type() {
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'          => array(
					'name'               => __( 'Yachts', 'fy-fleet' ),
					'singular_name'      => __( 'Yacht', 'fy-fleet' ),
					'add_new'            => __( 'Add New Yacht', 'fy-fleet' ),
					'add_new_item'       => __( 'Add New Yacht', 'fy-fleet' ),
					'edit_item'          => __( 'Edit Yacht', 'fy-fleet' ),
					'new_item'           => __( 'New Yacht', 'fy-fleet' ),
					'view_item'          => __( 'View Yacht', 'fy-fleet' ),
					'search_items'       => __( 'Search Yachts', 'fy-fleet' ),
					'not_found'          => __( 'No yachts yet. Add one under Products → Add New — the yacht card is created automatically.', 'fy-fleet' ),
					'menu_name'          => __( '⚓ FY Command Center', 'fy-fleet' ),
					'all_items'          => __( 'All Yachts', 'fy-fleet' ),
				),
				'public'             => true,
				'publicly_queryable' => true,
				'show_ui'            => true,
				'show_in_menu'       => true,
				'menu_icon'          => 'dashicons-palmtree',
				'supports'           => array( 'title', 'thumbnail', 'editor', 'excerpt' ),
				'capability_type'    => 'post',
				// Yachts are created from Products → Add New (or by Duplicate /
				// import / API, which bypass this cap on purpose). Blocking
				// create_posts removes every "Add New Yacht" menu item and button.
				'map_meta_cap'       => true,
				'capabilities'       => array( 'create_posts' => 'do_not_allow' ),
				'hierarchical'       => false,
				'has_archive'        => false,
				'show_in_rest'       => true,
				'rewrite'            => array(
					'slug'       => self::get_url_base(),
					'with_front' => false,
				),
			)
		);
	}

	/**
	 * URL base for yacht pages, e.g. "miami-yacht-rentals" gives
	 * /miami-yacht-rentals/50ft-azimut-coco/. Editable in Display Settings.
	 */
	public static function get_url_base() {
		$opts = FY_Fleet_Settings::get();
		$base = isset( $opts['url_base'] ) ? trim( (string) $opts['url_base'], '/ ' ) : '';
		/*
		 * Defaults to %fleet% so each city generates its own base from its own
		 * fleet category — Miami yachts under the Miami slug, Panama under
		 * Panama, and any city added later without touching a setting.
		 *
		 * The old default was the literal "miami-yacht-rentals", which put
		 * EVERY yacht under Miami's URL regardless of city, and left any yacht
		 * outside that one category redirecting between its yacht page and its
		 * product page forever.
		 */
		return $base ? $base : '%fleet%';
	}

	/**
	 * Swap %fleet% in the URL base for the yacht's fleet/category slug, so one
	 * post type can serve /miami-yacht-rentals/… and /panama-yacht-rentals/…
	 */
	public static function resolve_permalink( $permalink, $post ) {
		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return $permalink;
		}
		if ( false === strpos( $permalink, '%fleet%' ) ) {
			return $permalink;
		}

		$slug  = 'yachts';
		$terms = get_the_terms( $post->ID, 'fy_yacht_cat' );
		if ( $terms && ! is_wp_error( $terms ) ) {
			$term = reset( $terms );
			$slug = $term->slug;
		}

		return str_replace( '%fleet%', $slug, $permalink );
	}

	/**
	 * "Fleet Staff" role + capability backfill.
	 *
	 * Dock staff get a role that can manage yachts, galleries and bookings but
	 * cannot touch blog posts, pages or plugins. Runs on admin_init (cheap
	 * has_cap check) so plugin updates — which never fire activation — still
	 * grant the capability to admins.
	 */
	public static function ensure_roles() {
		$grant = array( 'administrator', 'editor', 'shop_manager' );
		foreach ( $grant as $role_name ) {
			$role = get_role( $role_name );
			if ( $role && ! $role->has_cap( 'manage_fleet' ) ) {
				$role->add_cap( 'manage_fleet' );
			}
		}

		if ( ! get_role( 'fleet_staff' ) ) {
			add_role(
				'fleet_staff',
				__( 'Fleet Staff', 'fy-fleet' ),
				array(
					'read'                   => true,
					'manage_fleet'           => true,
					'upload_files'           => true,
					// Yachts/galleries use capability_type 'post', so staff
					// need the post caps; the admin menu they see is trimmed
					// to the Yacht Fleet area because they lack list caps for
					// everything else that matters (plugins, themes, options).
					'edit_posts'             => true,
					'edit_published_posts'   => true,
					'publish_posts'          => true,
					'delete_posts'           => true,
					'delete_published_posts' => true,
					'edit_shop_orders'       => true,
				)
			);
		}

		// Yacht owners: outside affiliates who submit and later track their
		// own listings through the front-end portal. Deliberately NO
		// edit_posts/publish_posts — they never touch wp-admin; everything
		// they can do goes through FY_Fleet_Submissions' front-end form and
		// FY_Fleet_Account's "My Yacht Bookings" tab, both of which check
		// post_author / this role directly rather than post-edit capabilities.
		if ( ! get_role( 'fy_yacht_owner' ) ) {
			add_role(
				'fy_yacht_owner',
				__( 'Yacht Owner', 'fy-fleet' ),
				array(
					'read'         => true,
					'upload_files' => true,
				)
			);
		}
	}

	/**
	 * Order the Command Center menu the way a sales team works:
	 * daily operations first, fleet content second, configuration last.
	 */
	public static function reorder_submenu() {
		global $submenu;
		$parent = 'edit.php?post_type=' . self::POST_TYPE;
		if ( empty( $submenu[ $parent ] ) || ! is_array( $submenu[ $parent ] ) ) {
			return;
		}

		$order = array(
			'fy-fleet-help',                // ⭐ Start Here
			'fy-fleet-control',             // ⚙️ Control Panel
			'fy-fleet-dashboard',           // 📊 Sales dashboard
			'fy-fleet-inbox',               // 📥 Messages / tickets
			'fy-fleet-payments',            // Stripe / PayPal hub
			'fy-fleet-visualizer',          // Fleet Visualizer
			'fy-fleet-import',              // 📥 Import Fleet Spreadsheet
			'edit.php?post_type=fy_gallery',                // Galleries
			'fy-fleet-marinas',
			'edit-tags.php?taxonomy=fy_yacht_cat&post_type=' . self::POST_TYPE,
			'edit-tags.php?taxonomy=fy_yacht_tag&post_type=' . self::POST_TYPE,
			'fy-fleet-booking',             // Checkout & Integrations settings
			'fy-fleet-settings',            // Display Settings
			'fy-fleet-seo',
			'fy-fleet-api',
			'fy-fleet-log',
		);

		$rank = array_flip( $order );
		$max  = count( $order );

		// Stable sort: known slugs by rank, unknown ones keep their position after.
		$items = $submenu[ $parent ];
		$index = 0;
		foreach ( $items as $key => $item ) {
			$slug = isset( $item[2] ) ? $item[2] : '';
			// Owner's call: no "All Yachts" menu item — the Fleet Visualizer is
			// the editing hub (the bare list URL redirects there too).
			if ( $parent === $slug ) {
				unset( $items[ $key ] );
				continue;
			}
			$items[ $key ][] = isset( $rank[ $slug ] ) ? $rank[ $slug ] : $max + $index;
			$index++;
		}
		usort(
			$items,
			function ( $a, $b ) {
				return end( $a ) <=> end( $b );
			}
		);
		foreach ( $items as $key => $item ) {
			array_pop( $items[ $key ] );
		}

		$submenu[ $parent ] = $items; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
	}

	/**
	 * The city every yacht belongs to unless staff picks another.
	 * Created on demand; slug matches the default URL base.
	 */
	public static function default_city_term_id() {
		if ( ! taxonomy_exists( 'fy_yacht_cat' ) ) {
			return 0;
		}
		$term = get_term_by( 'slug', 'miami-yacht-rentals', 'fy_yacht_cat' );
		if ( $term ) {
			return (int) $term->term_id;
		}
		$created = wp_insert_term( __( 'Miami Yacht Rentals', 'fy-fleet' ), 'fy_yacht_cat', array( 'slug' => 'miami-yacht-rentals' ) );
		return is_wp_error( $created ) ? 0 : (int) $created['term_id'];
	}

	/** New yacht saved with no city → it goes to the default city. */
	public static function assign_default_city( $post_id, $post ) {
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || 'auto-draft' === $post->post_status ) {
			return;
		}
		if ( ! taxonomy_exists( 'fy_yacht_cat' ) ) {
			return;
		}
		$terms = wp_get_object_terms( $post_id, 'fy_yacht_cat', array( 'fields' => 'ids' ) );
		if ( is_wp_error( $terms ) || ! empty( $terms ) ) {
			return;
		}
		$default = self::default_city_term_id();
		if ( $default ) {
			wp_set_object_terms( $post_id, array( $default ), 'fy_yacht_cat', false );
		}
	}

	/** One-time migration: put every city-less yacht into the default city. */
	/**
	 * One-time backfill of the pink-yacht flag.
	 *
	 * The bulk import shipped every yacht with the flag unset — the source
	 * sheet has no pink column — so the front-end "Pink yachts" filter
	 * matched nothing while a dozen boats had "pink" written right in their
	 * name, description or tags. Same detection the importer now applies to
	 * new rows; here it sweeps yachts that already exist. Only ever SETS the
	 * flag, so a yacht the owner deliberately un-pinked stays un-pinked
	 * (the option guard means this never re-runs to fight that choice).
	 */
	public static function maybe_flag_pink_yachts() {
		if ( fy_fleet_is_plugin_admin_screen() ) {
			return;
		}
		if ( 1 === (int) get_option( 'fy_fleet_pink_flag_fix', 0 ) ) {
			return;
		}
		update_option( 'fy_fleet_pink_flag_fix', 1 );

		$yacht_ids = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);

		$flagged = 0;
		foreach ( $yacht_ids as $yacht_id ) {
			if ( get_post_meta( $yacht_id, '_fy_is_pink', true ) ) {
				continue;
			}
			$tag_names = wp_get_post_terms( $yacht_id, 'fy_yacht_tag', array( 'fields' => 'names' ) );
			$haystack  = get_the_title( $yacht_id ) . ' '
				. get_post_meta( $yacht_id, '_fy_special_desc', true ) . ' '
				. get_post_meta( $yacht_id, '_fy_model', true ) . ' '
				. ( is_wp_error( $tag_names ) ? '' : implode( ' ', $tag_names ) );
			if ( false !== stripos( $haystack, 'pink' ) ) {
				update_post_meta( $yacht_id, '_fy_is_pink', '1' );
				$flagged++;
			}
		}

		if ( $flagged && class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'yachts.pink_flagged', sprintf( 'Flagged %d yachts as pink from their name/description/tags — the Pink filter now finds them', $flagged ) );
		}
	}

	public static function backfill_default_city() {
		if ( fy_fleet_is_plugin_admin_screen() ) {
			return;
		}
		if ( '1' === get_option( 'fy_cities_seeded_v1' ) || ! taxonomy_exists( 'fy_yacht_cat' ) ) {
			return;
		}
		update_option( 'fy_cities_seeded_v1', '1' );

		$default = self::default_city_term_id();
		if ( ! $default ) {
			return;
		}

		$yachts = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => array( 'publish', 'draft', 'pending' ),
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);
		$moved = 0;
		foreach ( $yachts as $yacht_id ) {
			$terms = wp_get_object_terms( $yacht_id, 'fy_yacht_cat', array( 'fields' => 'ids' ) );
			if ( ! is_wp_error( $terms ) && empty( $terms ) ) {
				wp_set_object_terms( $yacht_id, array( $default ), 'fy_yacht_cat', false );
				$moved++;
			}
		}

		if ( $moved && class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'cities.migrated', sprintf( 'Assigned %d yachts to the default city (Miami Yacht Rentals)', $moved ) );
		}
	}

	/* ------------------------------------------------------------------
	 * Duplicate yacht — most new boats are 80% identical to an existing one.
	 * ---------------------------------------------------------------- */

	public static function duplicate_url( $yacht_id ) {
		return wp_nonce_url(
			admin_url( 'admin-post.php?action=fy_duplicate_yacht&yacht=' . (int) $yacht_id ),
			'fy_duplicate_' . (int) $yacht_id
		);
	}

	public static function delete_url( $yacht_id ) {
		return wp_nonce_url(
			admin_url( 'admin-post.php?action=fy_delete_yacht&yacht=' . (int) $yacht_id ),
			'fy_delete_' . (int) $yacht_id
		);
	}

	/**
	 * Remove a yacht from the fleet: the card goes to the trash, which fires
	 * FY_Fleet_Woo::on_yacht_trashed and hides its WooCommerce product by
	 * setting it PRIVATE. Neither is deleted, so past orders referencing the
	 * product keep working and both are recoverable.
	 */
	public static function handle_delete() {
		$yacht_id = isset( $_GET['yacht'] ) ? intval( $_GET['yacht'] ) : 0;
		check_admin_referer( 'fy_delete_' . $yacht_id );

		if ( ! $yacht_id || ! current_user_can( 'delete_post', $yacht_id ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		$yacht = get_post( $yacht_id );
		if ( ! $yacht || self::POST_TYPE !== $yacht->post_type ) {
			wp_die( esc_html__( 'Yacht not found.', 'fy-fleet' ) );
		}

		$title = $yacht->post_title;

		// Trashing the yacht is enough: on_yacht_trashed sets the linked
		// product to private. Doing it here too would only be overwritten.
		wp_trash_post( $yacht_id );

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'yacht.removed', sprintf( 'Yacht "%s" removed from the fleet (card trashed, product set to private)', $title ) );
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'       => 'fy-fleet-visualizer',
					'post_type'  => self::POST_TYPE,
					'fy_removed' => rawurlencode( $title ),
				),
				admin_url( 'edit.php' )
			)
		);
		exit;
	}

	public static function duplicate_row_action( $actions, $post ) {
		if ( self::POST_TYPE === $post->post_type && current_user_can( 'edit_post', $post->ID ) ) {
			$actions['fy_duplicate'] = '<a href="' . esc_url( self::duplicate_url( $post->ID ) ) . '">⧉ ' . esc_html__( 'Duplicate', 'fy-fleet' ) . '</a>';
		}
		return $actions;
	}

	public static function handle_duplicate() {
		$source_id = isset( $_GET['yacht'] ) ? intval( $_GET['yacht'] ) : 0;
		check_admin_referer( 'fy_duplicate_' . $source_id );
		if ( ! $source_id || ! current_user_can( 'edit_post', $source_id ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}

		$source = get_post( $source_id );
		if ( ! $source || self::POST_TYPE !== $source->post_type ) {
			wp_die( esc_html__( 'Yacht not found.', 'fy-fleet' ) );
		}

		// Always a DRAFT: never visible on the site until staff reviews it.
		$new_id = wp_insert_post(
			array(
				'post_type'    => self::POST_TYPE,
				'post_status'  => 'draft',
				'post_title'   => sprintf( /* translators: %s: yacht name */ __( '%s (Copy)', 'fy-fleet' ), $source->post_title ),
				'post_content' => $source->post_content,
				'post_excerpt' => $source->post_excerpt,
			),
			true
		);
		if ( is_wp_error( $new_id ) ) {
			wp_die( esc_html( $new_id->get_error_message() ) );
		}

		// Copy meta — except values that must be unique to each yacht:
		// its own Woo product, its own page URL, and never another boat's
		// reviews, blackout dates or canonical URL.
		$skip = array(
			'_fy_product_id',
			'_fy_button_url',
			'_fy_reviews',
			'_fy_blackout_dates',
			'_fy_canonical',
			'_fy_image_sideloaded',
			'_edit_lock',
			'_edit_last',
			'_wp_old_slug',
		);
		foreach ( get_post_meta( $source_id ) as $key => $values ) {
			if ( in_array( $key, $skip, true ) ) {
				continue;
			}
			foreach ( $values as $value ) {
				add_post_meta( $new_id, $key, maybe_unserialize( $value ) );
			}
		}

		// Same city as the original.
		$cities = wp_get_object_terms( $source_id, 'fy_yacht_cat', array( 'fields' => 'ids' ) );
		if ( ! is_wp_error( $cities ) && ! empty( $cities ) ) {
			wp_set_object_terms( $new_id, $cities, 'fy_yacht_cat', false );
		}

		// The copy gets its own WooCommerce product with correct pricing now
		// (the insert-time sync ran before the meta existed).
		if ( class_exists( 'FY_Fleet_Woo' ) && FY_Fleet_Woo::active() ) {
			FY_Fleet_Woo::sync_product( $new_id );
		}

		if ( class_exists( 'FY_Fleet_Log' ) ) {
			FY_Fleet_Log::add( 'yacht.duplicated', sprintf( '"%s" duplicated → draft #%d', $source->post_title, $new_id ) );
		}

		wp_safe_redirect( get_edit_post_link( $new_id, 'raw' ) );
		exit;
	}

	/** Rebuild permalinks once after the URL base changes. */
	public static function maybe_flush() {
		if ( fy_fleet_is_plugin_admin_screen() ) {
			return;
		}
		if ( get_option( 'fy_fleet_flush_needed' ) ) {
			delete_option( 'fy_fleet_flush_needed' );
			self::register_post_type();
			flush_rewrite_rules();
		}
	}

	public static function admin_columns( $columns ) {
		$new = array();
		foreach ( $columns as $key => $label ) {
			$new[ $key ] = $label;
			if ( 'title' === $key ) {
				$new['fy_thumb']    = __( 'Photo', 'fy-fleet' );
				$new['fy_size']     = __( 'Size (ft)', 'fy-fleet' );
				$new['fy_price']    = __( 'Starting Price', 'fy-fleet' );
				$new['fy_flags']    = __( 'Flags', 'fy-fleet' );
				$new['fy_shortcut'] = __( 'Button URL', 'fy-fleet' );
			}
		}
		return $new;
	}

	public static function admin_column_content( $column, $post_id ) {
		switch ( $column ) {
			case 'fy_thumb':
				if ( has_post_thumbnail( $post_id ) ) {
					echo get_the_post_thumbnail( $post_id, array( 60, 45 ) );
				} else {
					echo '&mdash;';
				}
				break;
			case 'fy_size':
				$ft = get_post_meta( $post_id, '_fy_size_ft', true );
				echo $ft !== '' ? esc_html( $ft . ' ft' ) : '&mdash;';
				break;
			case 'fy_price':
				$price = get_post_meta( $post_id, '_fy_price', true );
				echo $price !== '' ? esc_html( '$' . number_format_i18n( (float) $price ) ) : '&mdash;';
				break;
			case 'fy_flags':
				$flags = array();
				if ( get_post_meta( $post_id, '_fy_is_pink', true ) ) {
					$flags[] = 'Pink';
				}
				if ( get_post_meta( $post_id, '_fy_is_free_hour', true ) ) {
					$flags[] = 'Free-hour';
				}
				echo $flags ? esc_html( implode( ', ', $flags ) ) : '&mdash;';
				break;
			case 'fy_shortcut':
				$url = get_post_meta( $post_id, '_fy_button_url', true );
				if ( $url ) {
					echo '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( wp_parse_url( $url, PHP_URL_PATH ) ? wp_parse_url( $url, PHP_URL_PATH ) : $url ) . '</a>';
				} else {
					echo '&mdash;';
				}
				break;
		}
	}

	public static function sortable_columns( $columns ) {
		$columns['fy_size']  = 'fy_size';
		$columns['fy_price'] = 'fy_price';
		return $columns;
	}

	public static function admin_sort( $query ) {
		if ( ! is_admin() || ! $query->is_main_query() ) {
			return;
		}
		if ( self::POST_TYPE !== $query->get( 'post_type' ) ) {
			return;
		}
		$orderby = $query->get( 'orderby' );
		if ( 'fy_size' === $orderby ) {
			$query->set( 'meta_key', '_fy_size_ft' );
			$query->set( 'orderby', 'meta_value_num' );
		} elseif ( 'fy_price' === $orderby ) {
			$query->set( 'meta_key', '_fy_price' );
			$query->set( 'orderby', 'meta_value_num' );
		} elseif ( '' === $orderby ) {
			$query->set( 'meta_key', '_fy_size_ft' );
			$query->set( 'orderby', 'meta_value_num' );
			$query->set( 'order', 'ASC' );
		}
	}
}
