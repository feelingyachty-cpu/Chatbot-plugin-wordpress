<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class FY_Fleet_Elementor_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'fy_yacht_fleet';
	}

	public function get_title() {
		return __( 'Yacht Fleet Finder', 'fy-fleet' );
	}

	public function get_icon() {
		return 'eicon-post-list';
	}

	public function get_categories() {
		return array( 'feeling-yachty', 'general' );
	}

	public function get_keywords() {
		return array( 'yacht', 'boat', 'fleet', 'charter', 'rental' );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'fy_section_info',
			array(
				'label' => __( 'Yacht Fleet', 'fy-fleet' ),
			)
		);

		$this->add_control(
			'fy_info',
			array(
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw'  => sprintf(
					/* translators: %s: admin URL */
					__( 'Displays your published yachts, smallest to largest. Manage them under <a href="%s" target="_blank">Yacht Fleet</a>.', 'fy-fleet' ),
					esc_url( admin_url( 'edit.php?post_type=fy_yacht' ) )
				),
			)
		);

		$this->add_control(
			'fy_fleet',
			array(
				'label'       => __( 'City', 'fy-fleet' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'options'     => $this->get_fleet_options(),
				'default'     => '',
				'description' => __( 'Show every yacht, or ONE city only — pick "Panama Yacht Rentals" and this grid shows nothing but Panama yachts. Manage cities under FY Command Center → Cities.', 'fy-fleet' ),
			)
		);

		$this->add_control(
			'fy_heading',
			array(
				'label'       => __( 'Heading override', 'fy-fleet' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'placeholder' => __( 'e.g. Compare Panama Yacht Rentals', 'fy-fleet' ),
				'label_block' => true,
			)
		);

		$this->end_controls_section();
	}

	/** Fleet dropdown, built from the yacht categories. */
	private function get_fleet_options() {
		$options = array( '' => __( 'All yachts', 'fy-fleet' ) );

		$terms = get_terms(
			array(
				'taxonomy'   => 'fy_yacht_cat',
				'hide_empty' => false,
			)
		);
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$options[ $term->slug ] = $term->name . ' (' . $term->count . ')';
			}
		}

		return $options;
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		echo FY_Fleet_Render::render( // phpcs:ignore -- render() self-escapes all dynamic content
			array(
				'fleet'   => isset( $settings['fy_fleet'] ) ? $settings['fy_fleet'] : '',
				'heading' => isset( $settings['fy_heading'] ) ? $settings['fy_heading'] : '',
			)
		);
	}
}
