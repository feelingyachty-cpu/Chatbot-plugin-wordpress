(function () {
	'use strict';

	if ( typeof fyVisualizer === 'undefined' ) {
		return;
	}

	/** Live-update the card thumbnail as an image URL is typed. */
	function bindImagePreview( card ) {
		var input = card.querySelector( '.fy-vis-image-input' );
		var img   = card.querySelector( '.fy-vis-thumb' );
		var empty = card.querySelector( '.fy-vis-thumb-empty' );
		if ( ! input || ! img ) {
			return;
		}

		input.addEventListener( 'input', function () {
			var url = input.value.trim();
			if ( ! url ) {
				img.style.display = 'none';
				if ( empty ) { empty.style.display = ''; }
				return;
			}
			img.src = url;
			img.style.display = '';
			if ( empty ) { empty.style.display = 'none'; }
		} );

		img.addEventListener( 'error', function () {
			img.style.display = 'none';
			if ( empty ) {
				empty.style.display = '';
				empty.textContent = 'Image not found at that URL';
			}
		} );
	}

	/** Serialize the inline Hours & Pricing rows for a card. */
	function collectPricing( card ) {
		var rows = [];
		card.querySelectorAll( '.fy-vis-prow' ).forEach( function ( rowEl ) {
			var type = rowEl.getAttribute( 'data-row-type' ) || 'price';
			if ( 'heading' === type || 'note' === type ) {
				var textEl = rowEl.querySelector( '.fy-vis-prow-text' );
				rows.push( { type: type, text: textEl ? textEl.value : '' } );
			} else {
				var durEl   = rowEl.querySelector( '.fy-vis-prow-duration' );
				var priceEl = rowEl.querySelector( '.fy-vis-prow-price' );
				var freeEl  = rowEl.querySelector( '.fy-vis-prow-freecheck' );
				rows.push( {
					type: 'price',
					duration: durEl ? durEl.value : '',
					price: priceEl ? priceEl.value : 0,
					free: !! ( freeEl && freeEl.checked )
				} );
			}
		} );
		return rows;
	}

	function collectFields( card ) {
		var fields = {};
		card.querySelectorAll( '.fy-f' ).forEach( function ( input ) {
			var name = input.getAttribute( 'data-field' );
			if ( ! name ) {
				return;
			}
			fields[ name ] = ( 'checkbox' === input.type ) ? ( input.checked ? '1' : '' ) : input.value;
		} );
		return fields;
	}

	function setMessage( card, text, state ) {
		var msg = card.querySelector( '.fy-vis-msg' );
		if ( ! msg ) {
			return;
		}
		msg.textContent = text;
		msg.className = 'fy-vis-msg' + ( state ? ' is-' + state : '' );
	}

	function saveCard( card ) {
		var id = card.getAttribute( 'data-yacht-id' );
		if ( ! id ) {
			return;
		}

		var body = new FormData();
		body.append( 'action', fyVisualizer.action );
		body.append( 'nonce', fyVisualizer.nonce );
		body.append( 'post_id', id );

		var fields = collectFields( card );
		Object.keys( fields ).forEach( function ( key ) {
			body.append( 'fields[' + key + ']', fields[ key ] );
		} );
		body.append( 'pricing', JSON.stringify( collectPricing( card ) ) );

		card.classList.add( 'is-saving' );
		card.classList.remove( 'is-saved', 'is-error' );
		setMessage( card, fyVisualizer.i18n.saving, null );

		fetch( fyVisualizer.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: body
		} )
			.then( function ( response ) {
				return response.json().catch( function () {
					throw new Error( 'Bad response' );
				} );
			} )
			.then( function ( json ) {
				card.classList.remove( 'is-saving' );
				if ( json && json.success ) {
					card.classList.add( 'is-saved' );
					// A save can succeed but still have something worth
					// flagging — e.g. the image URL saved fine but the photo
					// itself failed to download. Show that instead of a
					// blanket "Saved" the visitor would otherwise have no
					// way to notice.
					var okDetail = ( json.data && json.data.message ) ? json.data.message : fyVisualizer.i18n.saved;
					setMessage( card, okDetail, 'ok' );
					setTimeout( function () {
						card.classList.remove( 'is-saved' );
						setMessage( card, '', null );
					}, 4000 );
				} else {
					card.classList.add( 'is-error' );
					var detail = ( json && json.data && json.data.message ) ? json.data.message : fyVisualizer.i18n.failed;
					setMessage( card, detail, 'error' );
				}
			} )
			.catch( function () {
				card.classList.remove( 'is-saving' );
				card.classList.add( 'is-error' );
				setMessage( card, fyVisualizer.i18n.failed, 'error' );
			} );
	}

	// Visualizer toolbar: live search + sort by size/price/name.
	function fyVisApply() {
		var grid   = document.querySelector( '.fy-vis-grid' );
		var search = document.getElementById( 'fy-vis-search' );
		var sortEl = document.getElementById( 'fy-vis-sort' );
		var count  = document.getElementById( 'fy-vis-count' );
		if ( ! grid ) {
			return;
		}

		var cards = Array.prototype.slice.call( grid.querySelectorAll( '.fy-vis-card' ) );
		var query = search ? search.value.trim().toLowerCase() : '';
		var mode  = sortEl ? sortEl.value : 'price-asc';

		cards.sort( function ( a, b ) {
			var sizeA = parseFloat( a.getAttribute( 'data-size' ) ) || 0;
			var sizeB = parseFloat( b.getAttribute( 'data-size' ) ) || 0;
			var priceA = parseFloat( a.getAttribute( 'data-price' ) ) || 0;
			var priceB = parseFloat( b.getAttribute( 'data-price' ) ) || 0;
			switch ( mode ) {
				case 'size-desc': return sizeB - sizeA;
				case 'price-asc':
				case 'price-desc':
					if ( ( priceA > 0 ) !== ( priceB > 0 ) ) { return priceA > 0 ? -1 : 1; }
					return mode === 'price-asc' ? priceA - priceB : priceB - priceA;
				case 'name': return ( a.getAttribute( 'data-title' ) || '' ).localeCompare( b.getAttribute( 'data-title' ) || '' );
				default: return sizeA - sizeB;
			}
		} );

		var shown = 0;
		cards.forEach( function ( card ) {
			grid.appendChild( card );
			var hit = ! query || ( card.getAttribute( 'data-title' ) || '' ).indexOf( query ) !== -1;
			card.style.display = hit ? '' : 'none';
			if ( hit ) { shown++; }
		} );

		if ( count ) {
			count.textContent = query ? shown + ' / ' + cards.length : cards.length + ' yachts';
		}
	}

	document.addEventListener( 'input', function ( e ) {
		if ( e.target && e.target.id === 'fy-vis-search' ) { fyVisApply(); }
	} );
	document.addEventListener( 'change', function ( e ) {
		if ( e.target && e.target.id === 'fy-vis-sort' ) { fyVisApply(); }
	} );
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', fyVisApply );
	} else {
		fyVisApply();
	}

	// Inline pricing rows: add / remove.
	document.addEventListener( 'click', function ( e ) {
		var addBtn = e.target.closest ? e.target.closest( '.fy-vis-add-row' ) : null;
		if ( addBtn ) {
			e.preventDefault();
			var tpl = document.getElementById( 'fy-vis-prow-' + ( addBtn.getAttribute( 'data-row-type' ) || 'price' ) );
			var box = addBtn.closest( '.fy-vis-pricing' );
			var rowsBox = box ? box.querySelector( '.fy-vis-rows' ) : null;
			if ( tpl && rowsBox ) {
				var wrap = document.createElement( 'div' );
				wrap.innerHTML = tpl.innerHTML.trim();
				var row = wrap.firstElementChild;
				if ( row ) {
					rowsBox.appendChild( row );
					var firstInput = row.querySelector( 'input[type="text"]' );
					if ( firstInput ) { firstInput.focus(); }
				}
			}
			return;
		}
		if ( e.target.classList && e.target.classList.contains( 'fy-vis-prow-remove' ) ) {
			e.preventDefault();
			var prow = e.target.closest( '.fy-vis-prow' );
			if ( prow ) { prow.parentNode.removeChild( prow ); }
		}
	} );

	// Desktop / tablet / mobile preview switcher.
	document.addEventListener( 'click', function ( e ) {
		var btn = e.target.closest ? e.target.closest( '.fy-device-btn' ) : null;
		if ( ! btn ) {
			return;
		}
		var frame = document.getElementById( 'fy-preview-frame' );
		if ( ! frame ) {
			return;
		}
		frame.setAttribute( 'data-device', btn.getAttribute( 'data-device' ) || 'desktop' );
		document.querySelectorAll( '.fy-device-btn' ).forEach( function ( b ) {
			b.classList.toggle( 'is-active', b === btn );
		} );
		syncPreviewHeight();
	} );

	/** Match the iframe height to its content so there is no inner scrollbar. */
	function syncPreviewHeight() {
		var iframe = document.getElementById( 'fy-preview-iframe' );
		if ( ! iframe ) {
			return;
		}
		window.setTimeout( function () {
			try {
				var doc = iframe.contentDocument || ( iframe.contentWindow && iframe.contentWindow.document );
				if ( doc && doc.body ) {
					iframe.style.height = Math.max( 700, doc.body.scrollHeight + 40 ) + 'px';
				}
			} catch ( err ) { /* srcdoc is same-origin; nothing to do */ }
		}, 350 );
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		var iframe = document.getElementById( 'fy-preview-iframe' );
		if ( iframe ) {
			iframe.addEventListener( 'load', syncPreviewHeight );
		}
	} );

	document.addEventListener( 'DOMContentLoaded', function () {
		var cards = document.querySelectorAll( '.fy-vis-card' );
		cards.forEach( function ( card ) {
			bindImagePreview( card );
			var button = card.querySelector( '.fy-vis-save' );
			if ( button ) {
				button.addEventListener( 'click', function () {
					saveCard( card );
				} );
			}
		} );
	} );

	/* ------------------------------------------------------------------
	 * Bulk select + remove — a checkbox per card, "Select all", and a
	 * "Remove Selected" button that trashes every checked yacht in one
	 * AJAX call (same effect as the single Remove link, just batched).
	 * ---------------------------------------------------------------- */

	function selectedCheckboxes() {
		return Array.prototype.slice.call( document.querySelectorAll( '.fy-vis-select-check:checked' ) );
	}

	function updateBulkBar() {
		var count   = selectedCheckboxes().length;
		var countEl = document.getElementById( 'fy-vis-bulk-count' );
		var btn     = document.getElementById( 'fy-vis-bulk-delete' );
		if ( countEl ) {
			countEl.textContent = count + ' selected';
		}
		if ( btn ) {
			btn.disabled = count === 0;
		}

		document.querySelectorAll( '.fy-vis-select-check' ).forEach( function ( box ) {
			var card = box.closest( '.fy-vis-card' );
			if ( card ) {
				card.classList.toggle( 'is-selected', box.checked );
			}
		} );

		var selectAll = document.getElementById( 'fy-vis-select-all' );
		var allBoxes  = document.querySelectorAll( '.fy-vis-select-check' );
		if ( selectAll ) {
			selectAll.checked = allBoxes.length > 0 && count === allBoxes.length;
		}
	}

	document.addEventListener( 'change', function ( e ) {
		if ( e.target && e.target.classList && e.target.classList.contains( 'fy-vis-select-check' ) ) {
			updateBulkBar();
			return;
		}
		if ( e.target && e.target.id === 'fy-vis-select-all' ) {
			var checked = e.target.checked;
			// Only the currently-visible (search/filtered) cards, matching
			// what the user can actually see when they click Select all.
			document.querySelectorAll( '.fy-vis-card' ).forEach( function ( card ) {
				if ( card.style.display === 'none' ) {
					return;
				}
				var box = card.querySelector( '.fy-vis-select-check' );
				if ( box ) {
					box.checked = checked;
				}
			} );
			updateBulkBar();
		}
	} );

	document.addEventListener( 'click', function ( e ) {
		if ( ! e.target || e.target.id !== 'fy-vis-bulk-delete' ) {
			return;
		}
		e.preventDefault();
		if ( typeof fyVisualizer === 'undefined' ) {
			return;
		}
		var boxes = selectedCheckboxes();
		if ( ! boxes.length ) {
			return;
		}
		var ids = boxes.map( function ( box ) { return box.value; } );
		var confirmMsg = ( fyVisualizer.i18n.confirmBulkDelete || 'Remove %d yacht(s)?' ).replace( '%d', ids.length );
		if ( ! window.confirm( confirmMsg ) ) {
			return;
		}

		var btn = e.target;
		btn.disabled = true;
		var originalText = btn.textContent;
		btn.textContent = fyVisualizer.i18n.deleting || 'Removing…';

		var body = new FormData();
		body.append( 'action', fyVisualizer.bulkDeleteAction );
		body.append( 'nonce', fyVisualizer.bulkDeleteNonce );
		ids.forEach( function ( id ) {
			body.append( 'ids[]', id );
		} );

		fetch( fyVisualizer.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: body
		} )
			.then( function ( response ) {
				return response.json().catch( function () {
					throw new Error( 'Bad response' );
				} );
			} )
			.then( function ( json ) {
				btn.disabled = false;
				btn.textContent = originalText;
				if ( ! json || ! json.success ) {
					window.alert( ( json && json.data && json.data.message ) ? json.data.message : 'Bulk remove failed.' );
					return;
				}
				var removed = ( json.data && json.data.removed ) || [];
				removed.forEach( function ( id ) {
					var card = document.querySelector( '.fy-vis-card[data-yacht-id="' + id + '"]' );
					if ( card ) {
						card.parentNode.removeChild( card );
					}
				} );
				updateBulkBar();
				fyVisApply();
			} )
			.catch( function () {
				btn.disabled = false;
				btn.textContent = originalText;
				window.alert( 'Bulk remove failed — check your connection and try again.' );
			} );
	} );
})();
