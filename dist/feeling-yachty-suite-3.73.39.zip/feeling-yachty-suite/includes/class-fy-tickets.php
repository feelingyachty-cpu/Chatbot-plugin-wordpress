<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ticket system: customer messages by department (Sales, Billing,
 * Cancellations, Support), threaded replies, and an admin Inbox.
 *
 * Storage: 'fy_ticket' posts; replies are comments of type 'fy_ticket_reply'.
 * Customers use the My Account → Support tab; staff use FY Command Center → Inbox.
 */
class FY_Fleet_Tickets {

	const POST_TYPE    = 'fy_ticket';
	const COMMENT_TYPE = 'fy_ticket_reply';

	public static function departments() {
		return array(
			'sales'         => __( '💼 Sales & Quotes', 'fy-fleet' ),
			'billing'       => __( '💳 Billing & Payments', 'fy-fleet' ),
			'cancellations' => __( '🔄 Cancellations & Changes', 'fy-fleet' ),
			'support'       => __( '🛟 General Support', 'fy-fleet' ),
		);
	}

	public static function statuses() {
		return array(
			'open'     => __( 'Open', 'fy-fleet' ),
			'answered' => __( 'Answered', 'fy-fleet' ),
			'closed'   => __( 'Closed', 'fy-fleet' ),
		);
	}

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		add_action( 'admin_post_fy_ticket_admin_reply', array( __CLASS__, 'handle_admin_reply' ) );

		// Front-end (My Account) actions.
		add_action( 'wp_loaded', array( __CLASS__, 'handle_front_actions' ) );

		// Keep customer reply comments out of blog comment feeds/counts.
		add_filter( 'comments_clauses', array( __CLASS__, 'exclude_from_queries' ), 10, 2 );
	}

	public static function register() {
		register_post_type(
			self::POST_TYPE,
			array(
				'public'          => false,
				'show_ui'         => false,
				'supports'        => array( 'title', 'comments' ),
				'capability_type' => 'post',
			)
		);
	}

	public static function exclude_from_queries( $clauses, $query ) {
		global $wpdb;
		// Only touch generic queries, not our own explicit ones.
		if ( empty( $query->query_vars['type'] ) || self::COMMENT_TYPE !== $query->query_vars['type'] ) {
			$clauses['where'] .= $wpdb->prepare( ' AND comment_type != %s', self::COMMENT_TYPE );
		}
		return $clauses;
	}

	/* ------------------------------------------------------------------
	 * Creating & replying
	 * ---------------------------------------------------------------- */

	/**
	 * @return int|WP_Error Ticket ID.
	 */
	public static function create( $args ) {
		$defaults = array(
			'subject'    => '',
			'message'    => '',
			'department' => 'support',
			'user_id'    => 0,
			'name'       => '',
			'email'      => '',
			'order_id'   => 0,
		);
		$args = wp_parse_args( $args, $defaults );

		if ( '' === trim( $args['subject'] ) || '' === trim( $args['message'] ) ) {
			return new WP_Error( 'fy_ticket_empty', __( 'Please add a subject and a message.', 'fy-fleet' ) );
		}
		if ( ! isset( self::departments()[ $args['department'] ] ) ) {
			$args['department'] = 'support';
		}

		$ticket_id = wp_insert_post(
			array(
				'post_type'   => self::POST_TYPE,
				'post_status' => 'publish',
				'post_title'  => wp_slash( sanitize_text_field( $args['subject'] ) ),
			),
			true
		);
		if ( is_wp_error( $ticket_id ) ) {
			return $ticket_id;
		}

		update_post_meta( $ticket_id, '_fy_department', $args['department'] );
		update_post_meta( $ticket_id, '_fy_status', 'open' );
		update_post_meta( $ticket_id, '_fy_user_id', (int) $args['user_id'] );
		update_post_meta( $ticket_id, '_fy_customer_name', sanitize_text_field( $args['name'] ) );
		update_post_meta( $ticket_id, '_fy_customer_email', sanitize_email( $args['email'] ) );
		if ( $args['order_id'] ) {
			update_post_meta( $ticket_id, '_fy_order_id', (int) $args['order_id'] );
		}

		self::add_reply( $ticket_id, $args['message'], false, $args['name'], $args['email'] );

		// Tell the team.
		wp_mail(
			get_option( 'admin_email' ),
			sprintf( '[%s] %s: %s', get_bloginfo( 'name' ), self::departments()[ $args['department'] ], $args['subject'] ),
			sprintf(
				"%s (%s) opened a ticket:\n\n%s\n\nReply here: %s",
				$args['name'],
				$args['email'],
				wp_strip_all_tags( $args['message'] ),
				admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-inbox&ticket=' . $ticket_id )
			)
		);

		// And tell n8n, so messages can flow straight into GoHighLevel.
		self::notify_webhook( 'ticket.created', $ticket_id, $args['message'] );

		return $ticket_id;
	}

	/**
	 * Push a customer message to the configured n8n webhook — the COMPLETE
	 * ticket record in the /fy/v1/tickets shape (full reply thread included)
	 * plus the customer's aggregate history.
	 */
	public static function notify_webhook( $event, $ticket_id, $message ) {
		if ( ! class_exists( 'FY_Fleet_Woo' ) ) {
			return;
		}

		$replies = array();
		foreach ( self::get_replies( $ticket_id ) as $reply ) {
			$replies[] = array(
				'from'     => '1' === get_comment_meta( $reply->comment_ID, '_fy_is_staff', true ) ? 'staff' : 'customer',
				'author'   => $reply->comment_author,
				'message'  => wp_strip_all_tags( $reply->comment_content ),
				'date_gmt' => $reply->comment_date_gmt,
			);
		}

		$customer_email = get_post_meta( $ticket_id, '_fy_customer_email', true );

		$delivered = FY_Fleet_Woo::post_webhook(
			array(
				'event'      => $event,
				'ticket_id'  => $ticket_id,
				'subject'    => get_the_title( $ticket_id ),
				'department' => get_post_meta( $ticket_id, '_fy_department', true ),
				'status'     => get_post_meta( $ticket_id, '_fy_status', true ),
				'created'    => get_post_field( 'post_date_gmt', $ticket_id ),
				'customer'   => array(
					'name'    => get_post_meta( $ticket_id, '_fy_customer_name', true ),
					'email'   => $customer_email,
					'user_id' => (int) get_post_meta( $ticket_id, '_fy_user_id', true ),
				),
				'customer_stats' => FY_Fleet_Woo::customer_stats( $customer_email ),
				'order_id'   => (int) get_post_meta( $ticket_id, '_fy_order_id', true ),
				'message'    => wp_strip_all_tags( $message ),
				'replies'    => $replies,
				'admin_url'  => admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-inbox&ticket=' . $ticket_id ),
				'sent_at'    => gmdate( 'c' ),
			)
		);

		if ( class_exists( 'FY_Fleet_Log' ) && FY_Fleet_Settings::get_booking()['webhook_url'] ) {
			FY_Fleet_Log::add(
				$delivered ? 'webhook.sent' : 'webhook.failed',
				sprintf( '%s for ticket #%d %s', $event, $ticket_id, $delivered ? 'delivered' : 'not delivered' ),
				array( 'ticket' => $ticket_id )
			);
		}
	}

	public static function add_reply( $ticket_id, $message, $is_staff, $name = '', $email = '' ) {
		$user = wp_get_current_user();
		return wp_insert_comment(
			array(
				'comment_post_ID'      => $ticket_id,
				'comment_content'      => wp_kses_post( $message ),
				'comment_type'         => self::COMMENT_TYPE,
				'user_id'              => $user ? (int) $user->ID : 0,
				'comment_author'       => $is_staff ? __( 'Feeling Yachty Team', 'fy-fleet' ) : $name,
				'comment_author_email' => $email,
				'comment_approved'     => 1,
				'comment_meta'         => array( '_fy_is_staff' => $is_staff ? '1' : '' ),
			)
		);
	}

	public static function get_replies( $ticket_id ) {
		return get_comments(
			array(
				'post_id' => $ticket_id,
				'type'    => self::COMMENT_TYPE,
				'orderby' => 'comment_date_gmt',
				'order'   => 'ASC',
				'status'  => 'approve',
			)
		);
	}

	/** Tickets a customer may see: matched by user ID, or by email for guest checkouts. */
	public static function for_user( $user ) {
		return get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 50,
				'meta_query'     => array(
					'relation' => 'OR',
					array( 'key' => '_fy_user_id', 'value' => (int) $user->ID ),
					array( 'key' => '_fy_customer_email', 'value' => $user->user_email ),
				),
			)
		);
	}

	public static function user_can_view( $ticket_id, $user ) {
		if ( ! $user || ! $user->ID ) {
			return false;
		}
		if ( user_can( $user, 'edit_shop_orders' ) ) {
			return true;
		}
		return (int) get_post_meta( $ticket_id, '_fy_user_id', true ) === (int) $user->ID
			|| get_post_meta( $ticket_id, '_fy_customer_email', true ) === $user->user_email;
	}

	public static function open_count() {
		$open = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 100,
				'fields'         => 'ids',
				'meta_key'       => '_fy_status',
				'meta_value'     => 'open',
			)
		);
		return count( $open );
	}

	/* ------------------------------------------------------------------
	 * Front-end actions (nonce-gated form posts from My Account)
	 * ---------------------------------------------------------------- */

	public static function handle_front_actions() {
		if ( ! is_user_logged_in() || empty( $_POST['fy_ticket_action'] ) ) {
			return;
		}
		$user   = wp_get_current_user();
		$action = sanitize_key( wp_unslash( $_POST['fy_ticket_action'] ) );

		if ( 'new' === $action && check_admin_referer( 'fy_ticket_new', 'fy_ticket_nonce' ) ) {
			$result = self::create(
				array(
					'subject'    => isset( $_POST['fy_subject'] ) ? sanitize_text_field( wp_unslash( $_POST['fy_subject'] ) ) : '',
					'message'    => isset( $_POST['fy_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['fy_message'] ) ) : '',
					'department' => isset( $_POST['fy_department'] ) ? sanitize_key( wp_unslash( $_POST['fy_department'] ) ) : 'support',
					'user_id'    => $user->ID,
					'name'       => trim( $user->first_name . ' ' . $user->last_name ) ? trim( $user->first_name . ' ' . $user->last_name ) : $user->display_name,
					'email'      => $user->user_email,
				)
			);
			if ( ! is_wp_error( $result ) ) {
				wp_safe_redirect( add_query_arg( 'ticket', $result, wc_get_account_endpoint_url( 'fy-support' ) ) );
				exit;
			}
		}

		if ( 'reply' === $action && check_admin_referer( 'fy_ticket_reply', 'fy_ticket_nonce' ) ) {
			$ticket_id = isset( $_POST['fy_ticket_id'] ) ? intval( $_POST['fy_ticket_id'] ) : 0;
			$message   = isset( $_POST['fy_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['fy_message'] ) ) : '';
			if ( $ticket_id && '' !== trim( $message ) && self::user_can_view( $ticket_id, $user ) ) {
				self::add_reply( $ticket_id, $message, false, $user->display_name, $user->user_email );
				update_post_meta( $ticket_id, '_fy_status', 'open' );
				self::notify_webhook( 'ticket.reply', $ticket_id, $message );
				wp_mail(
					get_option( 'admin_email' ),
					sprintf( '[%s] Ticket reply: %s', get_bloginfo( 'name' ), get_the_title( $ticket_id ) ),
					wp_strip_all_tags( $message ) . "\n\n" . admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-inbox&ticket=' . $ticket_id )
				);
			}
			wp_safe_redirect( add_query_arg( 'ticket', $ticket_id, wc_get_account_endpoint_url( 'fy-support' ) ) );
			exit;
		}
	}

	/* ------------------------------------------------------------------
	 * Admin Inbox
	 * ---------------------------------------------------------------- */

	public static function add_menu() {
		$open  = self::open_count();
		$badge = $open ? ' <span class="awaiting-mod count-' . $open . '"><span class="pending-count">' . $open . '</span></span>' : '';
		add_submenu_page(
			'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE,
			__( 'Inbox', 'fy-fleet' ),
			__( 'Inbox', 'fy-fleet' ) . $badge,
			'edit_shop_orders',
			'fy-fleet-inbox',
			array( __CLASS__, 'render_inbox' )
		);
	}

	public static function handle_admin_reply() {
		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'fy-fleet' ) );
		}
		check_admin_referer( 'fy_ticket_admin_reply' );

		$ticket_id = isset( $_POST['ticket_id'] ) ? intval( $_POST['ticket_id'] ) : 0;
		$message   = isset( $_POST['fy_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['fy_message'] ) ) : '';
		$status    = isset( $_POST['fy_status'] ) ? sanitize_key( wp_unslash( $_POST['fy_status'] ) ) : '';
		$dept      = isset( $_POST['fy_department'] ) ? sanitize_key( wp_unslash( $_POST['fy_department'] ) ) : '';

		if ( $ticket_id ) {
			if ( '' !== trim( $message ) ) {
				self::add_reply( $ticket_id, $message, true );
				if ( ! $status ) {
					$status = 'answered';
				}
				$customer_email = get_post_meta( $ticket_id, '_fy_customer_email', true );
				if ( $customer_email ) {
					wp_mail(
						$customer_email,
						sprintf( __( 'Re: %s — Feeling Yachty', 'fy-fleet' ), get_the_title( $ticket_id ) ),
						wp_strip_all_tags( $message ) . "\n\n" .
						__( 'View and reply in your account:', 'fy-fleet' ) . ' ' .
						add_query_arg( 'ticket', $ticket_id, wc_get_account_endpoint_url( 'fy-support' ) )
					);
				}
			}
			if ( $status && isset( self::statuses()[ $status ] ) ) {
				update_post_meta( $ticket_id, '_fy_status', $status );
			}
			if ( $dept && isset( self::departments()[ $dept ] ) ) {
				update_post_meta( $ticket_id, '_fy_department', $dept );
			}
		}

		wp_safe_redirect( admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-inbox&ticket=' . $ticket_id ) );
		exit;
	}

	public static function render_inbox() {
		$ticket_id = isset( $_GET['ticket'] ) ? intval( $_GET['ticket'] ) : 0;
		echo '<div class="wrap fy-inbox"><h1>📥 ' . esc_html__( 'Inbox', 'fy-fleet' ) . '</h1>';
		echo '<style>
			.fy-inbox .fy-inbox-tabs{margin:12px 0}
			.fy-inbox-list{background:#fff;border:1px solid #dcdcde;border-radius:8px;overflow:hidden}
			.fy-inbox-row{display:flex;gap:14px;align-items:center;padding:12px 16px;border-bottom:1px solid #f0f0f1;text-decoration:none;color:#1d2327}
			.fy-inbox-row:hover{background:#f6f7f7}
			.fy-inbox-row.is-open{border-left:4px solid #C7347B}
			.fy-inbox-dept{flex:none;font-size:11px;font-weight:700;padding:3px 9px;border-radius:999px;background:#f0f0f1}
			.fy-inbox-subject{font-weight:700;flex:1;min-width:0}
			.fy-inbox-meta{color:#787c82;font-size:12px;flex:none}
			.fy-thread{max-width:780px}
			.fy-msg{margin:10px 0;padding:13px 16px;border-radius:12px;background:#fff;border:1px solid #dcdcde}
			.fy-msg.is-staff{background:linear-gradient(160deg,#fff,#FDF2F8);border-color:#F4D6E5;margin-left:40px}
			.fy-msg-who{font-size:12px;font-weight:700;color:#C7347B;margin-bottom:4px}
			.fy-msg.is-staff .fy-msg-who{color:#5B21B6}
			.fy-msg-body{font-size:13.5px;line-height:1.6}
			.fy-msg-when{font-size:11px;color:#787c82;margin-top:6px}
		</style>';

		if ( $ticket_id && self::POST_TYPE === get_post_type( $ticket_id ) ) {
			self::render_admin_thread( $ticket_id );
		} else {
			self::render_admin_list();
		}
		echo '</div>';
	}

	private static function render_admin_list() {
		$dept_filter   = isset( $_GET['dept'] ) ? sanitize_key( $_GET['dept'] ) : '';
		$status_filter = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : '';
		$base          = admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-inbox' );

		echo '<div class="fy-inbox-tabs">';
		printf( '<a class="button %s" href="%s">%s</a> ', $status_filter || $dept_filter ? '' : 'button-primary', esc_url( $base ), esc_html__( 'All', 'fy-fleet' ) );
		foreach ( self::statuses() as $status_key => $status_label ) {
			printf( '<a class="button %s" href="%s">%s</a> ', $status_filter === $status_key ? 'button-primary' : '', esc_url( add_query_arg( 'status', $status_key, $base ) ), esc_html( $status_label ) );
		}
		echo ' &nbsp;|&nbsp; ';
		foreach ( self::departments() as $dept_key => $dept_label ) {
			printf( '<a class="button %s" href="%s">%s</a> ', $dept_filter === $dept_key ? 'button-primary' : '', esc_url( add_query_arg( 'dept', $dept_key, $base ) ), esc_html( $dept_label ) );
		}
		echo '</div>';

		$meta_query = array();
		if ( $dept_filter ) {
			$meta_query[] = array( 'key' => '_fy_department', 'value' => $dept_filter );
		}
		if ( $status_filter ) {
			$meta_query[] = array( 'key' => '_fy_status', 'value' => $status_filter );
		}
		$tickets = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 100,
				'meta_query'     => $meta_query, // phpcs:ignore
			)
		);

		echo '<div class="fy-inbox-list">';
		if ( empty( $tickets ) ) {
			echo '<p style="padding:20px">' . esc_html__( 'No messages here. 🎉', 'fy-fleet' ) . '</p>';
		}
		foreach ( $tickets as $ticket ) {
			$status = get_post_meta( $ticket->ID, '_fy_status', true );
			$dept   = get_post_meta( $ticket->ID, '_fy_department', true );
			$name   = get_post_meta( $ticket->ID, '_fy_customer_name', true );
			printf(
				'<a class="fy-inbox-row %s" href="%s"><span class="fy-inbox-dept">%s</span><span class="fy-inbox-subject">%s</span><span class="fy-inbox-meta">%s · %s · %s</span></a>',
				'open' === $status ? 'is-open' : '',
				esc_url( admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-inbox&ticket=' . $ticket->ID ) ),
				esc_html( isset( self::departments()[ $dept ] ) ? self::departments()[ $dept ] : $dept ),
				esc_html( $ticket->post_title ),
				esc_html( $name ),
				esc_html( isset( self::statuses()[ $status ] ) ? self::statuses()[ $status ] : $status ),
				esc_html( get_the_date( 'M j, g:i a', $ticket ) )
			);
		}
		echo '</div>';
	}

	private static function render_admin_thread( $ticket_id ) {
		$status = get_post_meta( $ticket_id, '_fy_status', true );
		$dept   = get_post_meta( $ticket_id, '_fy_department', true );
		$name   = get_post_meta( $ticket_id, '_fy_customer_name', true );
		$email  = get_post_meta( $ticket_id, '_fy_customer_email', true );
		$order  = (int) get_post_meta( $ticket_id, '_fy_order_id', true );

		echo '<p><a href="' . esc_url( admin_url( 'edit.php?post_type=' . FY_Fleet_CPT::POST_TYPE . '&page=fy-fleet-inbox' ) ) . '">&larr; ' . esc_html__( 'Back to Inbox', 'fy-fleet' ) . '</a></p>';
		echo '<div class="fy-thread">';
		echo '<h2>' . esc_html( get_the_title( $ticket_id ) ) . '</h2>';
		echo '<p>' . esc_html( $name ) . ' &lt;' . esc_html( $email ) . '&gt;';
		if ( $order ) {
			echo ' · <a href="' . esc_url( admin_url( 'post.php?post=' . $order . '&action=edit' ) ) . '">' . esc_html__( 'Order', 'fy-fleet' ) . ' #' . esc_html( $order ) . '</a>';
		}
		echo '</p>';

		foreach ( self::get_replies( $ticket_id ) as $reply ) {
			$is_staff = '1' === get_comment_meta( $reply->comment_ID, '_fy_is_staff', true );
			printf(
				'<div class="fy-msg %s"><div class="fy-msg-who">%s</div><div class="fy-msg-body">%s</div><div class="fy-msg-when">%s</div></div>',
				$is_staff ? 'is-staff' : '',
				esc_html( $is_staff ? __( 'Feeling Yachty Team', 'fy-fleet' ) : $reply->comment_author ),
				wp_kses_post( wpautop( $reply->comment_content ) ),
				esc_html( mysql2date( 'M j, Y g:i a', $reply->comment_date ) )
			);
		}
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:16px">
			<input type="hidden" name="action" value="fy_ticket_admin_reply">
			<input type="hidden" name="ticket_id" value="<?php echo esc_attr( $ticket_id ); ?>">
			<?php wp_nonce_field( 'fy_ticket_admin_reply' ); ?>
			<textarea name="fy_message" id="fy-admin-reply" rows="4" class="large-text" placeholder="<?php esc_attr_e( 'Reply to the customer… (emailed to them instantly)', 'fy-fleet' ); ?>"></textarea>
			<?php if ( class_exists( 'FY_Fleet_AI' ) && FY_Fleet_AI::configured() ) : ?>
				<p><button type="button" class="button" id="fy-ai-draft-btn">✨ <?php esc_html_e( 'Draft reply with AI', 'fy-fleet' ); ?></button>
				<span id="fy-ai-draft-status" style="margin-left:8px;color:#646970"></span></p>
				<script>
				(function(){
					var btn=document.getElementById('fy-ai-draft-btn');
					if(!btn)return;
					btn.addEventListener('click',function(){
						var status=document.getElementById('fy-ai-draft-status');
						var box=document.getElementById('fy-admin-reply');
						btn.disabled=true;status.textContent='<?php echo esc_js( __( 'Thinking…', 'fy-fleet' ) ); ?>';
						var body=new FormData();
						body.append('action','fy_ai_draft');
						body.append('nonce','<?php echo esc_js( wp_create_nonce( 'fy_ai_draft' ) ); ?>');
						body.append('ticket_id','<?php echo esc_js( $ticket_id ); ?>');
						fetch(ajaxurl,{method:'POST',credentials:'same-origin',body:body})
							.then(function(r){return r.json();})
							.then(function(j){
								btn.disabled=false;
								if(j&&j.success){box.value=j.data.draft;status.textContent='<?php echo esc_js( __( 'Draft ready — review before sending.', 'fy-fleet' ) ); ?>';}
								else{status.textContent=(j&&j.data&&j.data.message)?j.data.message:'Error';}
							})
							.catch(function(){btn.disabled=false;status.textContent='Network error';});
					});
				})();
				</script>
			<?php endif; ?>
			<p style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
				<label><?php esc_html_e( 'Status:', 'fy-fleet' ); ?>
					<select name="fy_status">
						<?php foreach ( self::statuses() as $status_key => $status_label ) : ?>
							<option value="<?php echo esc_attr( $status_key ); ?>" <?php selected( $status, $status_key ); ?>><?php echo esc_html( $status_label ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
				<label><?php esc_html_e( 'Department:', 'fy-fleet' ); ?>
					<select name="fy_department">
						<?php foreach ( self::departments() as $dept_key => $dept_label ) : ?>
							<option value="<?php echo esc_attr( $dept_key ); ?>" <?php selected( $dept, $dept_key ); ?>><?php echo esc_html( $dept_label ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
				<button class="button button-primary"><?php esc_html_e( 'Send Reply', 'fy-fleet' ); ?></button>
			</p>
		</form>
		</div>
		<?php
	}
}
