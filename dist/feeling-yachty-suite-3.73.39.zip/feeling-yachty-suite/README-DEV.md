# Feeling Yachty Command Center — developer notes

## Local test site (the missing execution step!)
Requires Node.js + Docker Desktop:

```bash
npm -g i @wordpress/env
wp-env start          # spins up WordPress + WooCommerce with this plugin active
# → http://localhost:8888  (admin / password)
```

Every change should be exercised here BEFORE uploading to the live site:
1. Activate plugin → starter fleet imports.
2. Fleet Visualizer → Live Preview renders, device buttons work.
3. Book a yacht end-to-end with Stripe test mode (card 4242 4242 4242 4242).
4. Bookings calendar shows the order; webhook fires (check Activity Log).

## Lint

```bash
composer install
composer lint      # PHP syntax across every file
composer phpcs     # WordPress coding standards
```

## Release
1. Bump `Version:` header and `FY_FLEET_VERSION` in `feeling-yachty-fleet.php` (cache-busts assets).
2. Commit, tag: `git tag v2.x.x`
3. Zip the folder (exclude `.git/`, `vendor/`) and upload via Plugins → Add New.

## Architecture map
- `includes/class-fy-cpt.php` — yacht post type, roles, permalinks
- `includes/class-fy-pricing.php` — the money engine; ALL prices computed server-side here
- `includes/class-fy-woo.php` — product sync, deposit charging, order meta, n8n webhook
- `includes/class-fy-booking.php` + `assets/booking.*` — customer booking UI
- `includes/class-fy-checkout.php` — bareboat form gate
- `includes/class-fy-rest.php` — /wp-json/fy/v1/* (yachts, fleets, customers, bookings, export/import)
- `assets/fleet.css|js` — the grid (extracted from inline; keep edits here, not in PHP)
