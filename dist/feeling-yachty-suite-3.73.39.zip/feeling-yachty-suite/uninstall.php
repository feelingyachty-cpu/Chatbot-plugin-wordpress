<?php
/**
 * Uninstall handler.
 *
 * By default NOTHING is deleted — your yachts, galleries, bookings and
 * settings survive an uninstall so an accidental "Delete" in the plugins
 * screen cannot destroy the fleet. To wipe everything on uninstall, add
 * this line to wp-config.php first:
 *
 *     define( 'FY_FLEET_ALLOW_ERASE', true );
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

if ( ! defined( 'FY_FLEET_ALLOW_ERASE' ) || ! FY_FLEET_ALLOW_ERASE ) {
	return; // Keep all data.
}

// Options.
foreach ( array( 'fy_fleet_settings', 'fy_fleet_booking_settings', 'fy_fleet_seo', 'fy_fleet_marinas', 'fy_fleet_seeded', 'fy_fleet_flush_needed' ) as $fy_option ) {
	delete_option( $fy_option );
}

// Posts of our types (yachts, galleries, logs) and their meta.
foreach ( array( 'fy_yacht', 'fy_gallery', 'fy_log' ) as $fy_type ) {
	$fy_ids = get_posts(
		array(
			'post_type'      => $fy_type,
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
		)
	);
	foreach ( $fy_ids as $fy_id ) {
		wp_delete_post( $fy_id, true );
	}
}

// Taxonomy terms.
foreach ( array( 'fy_yacht_cat', 'fy_yacht_tag' ) as $fy_tax ) {
	$fy_terms = get_terms( array( 'taxonomy' => $fy_tax, 'hide_empty' => false, 'fields' => 'ids' ) );
	if ( ! is_wp_error( $fy_terms ) ) {
		foreach ( $fy_terms as $fy_term_id ) {
			wp_delete_term( $fy_term_id, $fy_tax );
		}
	}
}
