<?php
/**
 * Fleet landing page: /yacht-category/{fleet}/
 * Editable H1 + intro copy above the live yacht grid for that fleet.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$fy_term  = get_queried_object();
$fy_h1    = get_term_meta( $fy_term->term_id, 'fy_page_h1', true );
$fy_h1    = $fy_h1 ? $fy_h1 : FY_Fleet_Pages::readable_term_name( $fy_term );
$fy_intro = term_description( $fy_term );

get_header();
?>

<main class="fy-fleet-landing">
	<style>
	.fy-fleet-landing{max-width:1240px;margin:0 auto;padding:24px 16px 40px}
	.fy-fleet-landing-head{max-width:900px;margin:0 auto 8px;text-align:center;
		font-family:ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif}
	.fy-fleet-landing-h1{
		margin:10px 0;font-size:clamp(28px,4.2vw,44px);font-weight:950;line-height:1.1;letter-spacing:-.03em;
		background:linear-gradient(90deg,#C94386,#7C3AED,#2563EB);
		-webkit-background-clip:text;background-clip:text;color:transparent;
	}
	.fy-fleet-landing-intro{color:#526079;font-size:clamp(14px,1.8vw,16.5px);line-height:1.7;font-weight:600}
	.fy-fleet-landing-intro p{margin:0 0 10px}
	</style>

	<header class="fy-fleet-landing-head">
		<?php
		// The site's own H1 is added by hand elsewhere on the page — a second
		// one here would leave two H1s competing for the same topic, which
		// undercuts exactly the semantic clarity on-page SEO depends on. This
		// headline stays, same size and weight, just one level down.
		?>
		<h2 class="fy-fleet-landing-h1"><?php echo esc_html( $fy_h1 ); ?></h2>
		<?php if ( $fy_intro ) : ?>
			<div class="fy-fleet-landing-intro"><?php echo wp_kses_post( $fy_intro ); ?></div>
		<?php endif; ?>
	</header>

	<?php
	echo FY_Fleet_Render::render( // phpcs:ignore -- render() escapes its own dynamic content
		array(
			'fleet'        => $fy_term->slug,
			'heading'      => $fy_h1,
			'hide_heading' => true, // the h2 above already carries this headline
		)
	);
	?>
</main>

<?php
get_footer();
