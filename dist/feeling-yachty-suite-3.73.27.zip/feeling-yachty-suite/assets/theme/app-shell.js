/* Feeling Yachty — app shell script. Two jobs, both about speed:
 *
 * 1. Hover/touch prefetch (instant.page-style): the moment a visitor's
 *    pointer settles on an internal link, the next page's HTML is
 *    prefetched — by the time they finish the click it's already in the
 *    browser cache, so navigation feels app-instant.
 * 2. Nothing else. The floating checkout pill is server-rendered and kept
 *    live by WooCommerce's own cart-fragments script; the press feedback
 *    and view transitions are pure CSS. No jQuery, loaded deferred.
 */
( function () {
	'use strict';

	if ( ! ( 'requestIdleCallback' in window ) && ! ( 'requestAnimationFrame' in window ) ) {
		return;
	}

	// Respect data-saver mode and very slow connections — prefetching
	// there costs the visitor real money/time for pages they may not open.
	var conn = navigator.connection || {};
	if ( conn.saveData || /(^|-)2g$/.test( conn.effectiveType || '' ) ) {
		return;
	}

	var prefetched = Object.create( null );
	var count = 0;
	var MAX_PREFETCH = 60;
	var HOVER_DELAY = 65; // ms — long enough to skip drive-by pointer moves.
	var timer = 0;

	function prefetchable( a ) {
		if ( ! a || ! a.href || count >= MAX_PREFETCH ) {
			return '';
		}
		if ( a.origin !== location.origin ) {
			return '';
		}
		if ( a.target && '_self' !== a.target ) {
			return '';
		}
		var url = a.href.split( '#' )[ 0 ];
		if ( ! url || url === location.href.split( '#' )[ 0 ] || prefetched[ url ] ) {
			return '';
		}
		var path = a.pathname || '';
		// Never prefetch state-changing or per-visitor URLs: cart/checkout
		// (nonces + totals), account, login/admin, or anything with an
		// action-looking query string.
		if ( /wp-admin|wp-login|logout|\/cart\b|\/checkout\b|\/my-account\b|\/login\b/i.test( path ) ) {
			return '';
		}
		if ( /(\?|&)(add-to-cart|remove_item|logout|_wpnonce)=/i.test( a.search || '' ) ) {
			return '';
		}
		// Skip obvious binaries.
		if ( /\.(pdf|zip|jpe?g|png|webp|gif|mp4|apk)$/i.test( path ) ) {
			return '';
		}
		return url;
	}

	function prefetch( url ) {
		prefetched[ url ] = true;
		count++;
		var link = document.createElement( 'link' );
		link.rel = 'prefetch';
		link.href = url;
		link.as = 'document';
		document.head.appendChild( link );
	}

	document.addEventListener(
		'mouseover',
		function ( e ) {
			var a = e.target && e.target.closest ? e.target.closest( 'a[href]' ) : null;
			var url = prefetchable( a );
			if ( ! url ) {
				return;
			}
			clearTimeout( timer );
			timer = setTimeout( function () {
				if ( ! prefetched[ url ] ) {
					prefetch( url );
				}
			}, HOVER_DELAY );
		},
		{ passive: true }
	);

	document.addEventListener(
		'mouseout',
		function () {
			clearTimeout( timer );
		},
		{ passive: true }
	);

	// On touch there is no hover — prefetch on first contact instead;
	// the ~100ms between touchstart and the click event is enough of a
	// head start to matter.
	document.addEventListener(
		'touchstart',
		function ( e ) {
			var a = e.target && e.target.closest ? e.target.closest( 'a[href]' ) : null;
			var url = prefetchable( a );
			if ( url ) {
				prefetch( url );
			}
		},
		{ passive: true }
	);
} )();
