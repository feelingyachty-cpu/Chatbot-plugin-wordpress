<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Per-yacht reviews, entered by staff (copied from Google/Instagram/WhatsApp).
 * Rendered on the yacht page and emitted as AggregateRating + Review schema —
 * the stars in search results.
 */
class FY_Fleet_Reviews {

	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_box' ) );
		add_action( 'save_post_' . FY_Fleet_CPT::POST_TYPE, array( __CLASS__, 'save' ), 10, 2 );
	}

	/**
	 * Has this specific booking already been reviewed? Checked by order +
	 * line item, not just order — a multi-yacht order shouldn't have one
	 * review block the others.
	 */
	public static function already_reviewed( $yacht_id, $order_id, $item_id ) {
		foreach ( self::get( $yacht_id ) as $review ) {
			if ( isset( $review['order_id'], $review['item_id'] )
				&& (int) $review['order_id'] === (int) $order_id
				&& (int) $review['item_id'] === (int) $item_id
			) {
				return true;
			}
		}
		return false;
	}

	/**
	 * A genuine, verified customer review — same _fy_reviews array staff
	 * reviews live in (same render, same AggregateRating schema), tagged so
	 * it's visually distinguishable and traceable back to the real booking
	 * that earned it. Auto-published: eligibility (claimed order + charter
	 * date already passed, checked by the caller before this is ever
	 * reachable) is already a strong anti-abuse gate on its own — this
	 * mirrors how cancellation requests and support tickets in this same
	 * codebase already skip a moderation queue.
	 */
	public static function submit_customer_review( $yacht_id, $user_id, $order_id, $item_id, $rating, $text ) {
		if ( self::already_reviewed( $yacht_id, $order_id, $item_id ) ) {
			return false;
		}
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return false;
		}
		$reviews   = self::get( $yacht_id );
		$reviews[] = array(
			'name'     => $user->display_name,
			'rating'   => max( 1, min( 5, intval( $rating ) ) ),
			'date'     => gmdate( 'Y-m-d' ),
			'text'     => sanitize_textarea_field( $text ),
			'source'   => 'customer',
			'user_id'  => (int) $user_id,
			'order_id' => (int) $order_id,
			'item_id'  => (int) $item_id,
		);
		update_post_meta( $yacht_id, '_fy_reviews', $reviews );
		return true;
	}

	/** @return array[] Each: name, rating (1–5), date (Y-m-d, optional), text. */
	public static function get( $yacht_id ) {
		$reviews = get_post_meta( $yacht_id, '_fy_reviews', true );
		return is_array( $reviews ) ? $reviews : array();
	}

	/** @return array{count:int,average:float} */
	public static function stats( $yacht_id ) {
		$reviews = self::get( $yacht_id );
		if ( empty( $reviews ) ) {
			return array( 'count' => 0, 'average' => 0.0 );
		}
		$sum = 0;
		foreach ( $reviews as $review ) {
			$sum += (float) $review['rating'];
		}
		return array(
			'count'   => count( $reviews ),
			'average' => round( $sum / count( $reviews ), 1 ),
		);
	}

	public static function add_meta_box() {
		add_meta_box( 'fy_reviews', __( 'Reviews (shown on page + Google stars)', 'fy-fleet' ), array( __CLASS__, 'render_meta_box' ), FY_Fleet_CPT::POST_TYPE, 'normal', 'default' );
	}

	public static function render_meta_box( $post ) {
		wp_nonce_field( 'fy_reviews_save', 'fy_reviews_nonce' );
		$reviews = self::get( $post->ID );
		?>
		<p class="description"><?php esc_html_e( 'Paste real reviews from Google, Instagram or WhatsApp. They appear on the yacht page and as star ratings in Google search results. Only publish genuine reviews.', 'fy-fleet' ); ?></p>
		<div id="fy-review-rows" class="fy-repeater">
			<?php foreach ( $reviews as $i => $review ) : ?>
				<?php self::row( $i, $review ); ?>
			<?php endforeach; ?>
		</div>
		<button type="button" class="button" id="fy-add-review"><?php esc_html_e( '+ Add Review', 'fy-fleet' ); ?></button>
		<script type="text/template" id="fy-review-template"><?php self::row( '__INDEX__', array() ); ?></script>
		<?php
	}

	private static function row( $i, $review ) {
		$name     = isset( $review['name'] ) ? $review['name'] : '';
		$rating   = isset( $review['rating'] ) ? $review['rating'] : 5;
		$date     = isset( $review['date'] ) ? $review['date'] : '';
		$text     = isset( $review['text'] ) ? $review['text'] : '';
		$source   = isset( $review['source'] ) ? $review['source'] : 'staff';
		$user_id  = isset( $review['user_id'] ) ? $review['user_id'] : '';
		$order_id = isset( $review['order_id'] ) ? $review['order_id'] : '';
		$item_id  = isset( $review['item_id'] ) ? $review['item_id'] : '';
		?>
		<div class="fy-repeater-row" style="flex-wrap:wrap">
			<?php if ( 'customer' === $source ) : ?>
				<span class="fy-row-tag" style="background:#E1F5EE;color:#085041" title="<?php esc_attr_e( 'Submitted by a real customer from a claimed, completed booking — not staff-entered.', 'fy-fleet' ); ?>">✓ <?php esc_html_e( 'Verified Guest', 'fy-fleet' ); ?></span>
				<?php // Round-trips through save() so a routine yacht-page save doesn't strip the verification trail off a real review. ?>
				<input type="hidden" name="fy_reviews[<?php echo esc_attr( $i ); ?>][source]" value="customer">
				<input type="hidden" name="fy_reviews[<?php echo esc_attr( $i ); ?>][user_id]" value="<?php echo esc_attr( $user_id ); ?>">
				<input type="hidden" name="fy_reviews[<?php echo esc_attr( $i ); ?>][order_id]" value="<?php echo esc_attr( $order_id ); ?>">
				<input type="hidden" name="fy_reviews[<?php echo esc_attr( $i ); ?>][item_id]" value="<?php echo esc_attr( $item_id ); ?>">
			<?php endif; ?>
			<input type="text" name="fy_reviews[<?php echo esc_attr( $i ); ?>][name]" value="<?php echo esc_attr( $name ); ?>" placeholder="<?php esc_attr_e( 'Guest name', 'fy-fleet' ); ?>" class="regular-text" style="width:160px">
			<select name="fy_reviews[<?php echo esc_attr( $i ); ?>][rating]">
				<?php for ( $star = 5; $star >= 1; $star-- ) : ?>
					<option value="<?php echo esc_attr( $star ); ?>" <?php selected( (int) $rating, $star ); ?>><?php echo esc_html( str_repeat( '★', $star ) . str_repeat( '☆', 5 - $star ) ); ?></option>
				<?php endfor; ?>
			</select>
			<input type="date" name="fy_reviews[<?php echo esc_attr( $i ); ?>][date]" value="<?php echo esc_attr( $date ); ?>">
			<input type="text" name="fy_reviews[<?php echo esc_attr( $i ); ?>][text]" value="<?php echo esc_attr( $text ); ?>" placeholder="<?php esc_attr_e( 'What they said…', 'fy-fleet' ); ?>" class="large-text" style="flex:1;min-width:220px">
			<button type="button" class="button-link-delete fy-remove-row"><?php esc_html_e( 'Remove', 'fy-fleet' ); ?></button>
		</div>
		<?php
	}

	public static function save( $post_id, $post ) {
		if ( ! isset( $_POST['fy_reviews_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fy_reviews_nonce'] ) ), 'fy_reviews_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$reviews = array();
		if ( isset( $_POST['fy_reviews'] ) && is_array( $_POST['fy_reviews'] ) ) {
			foreach ( wp_unslash( $_POST['fy_reviews'] ) as $review ) {
				$text = isset( $review['text'] ) ? sanitize_textarea_field( $review['text'] ) : '';
				$name = isset( $review['name'] ) ? sanitize_text_field( $review['name'] ) : '';
				if ( '' === $text && '' === $name ) {
					continue;
				}
				$date = isset( $review['date'] ) ? sanitize_text_field( $review['date'] ) : '';
				$row  = array(
					'name'   => $name,
					'rating' => max( 1, min( 5, intval( isset( $review['rating'] ) ? $review['rating'] : 5 ) ) ),
					'date'   => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ? $date : '',
					'text'   => $text,
				);
				// Preserve the verification trail on a real customer review
				// through a routine staff save — the repeater form round-trips
				// these as hidden fields specifically so this doesn't get lost.
				if ( isset( $review['source'] ) && 'customer' === $review['source'] ) {
					$row['source']   = 'customer';
					$row['user_id']  = isset( $review['user_id'] ) ? absint( $review['user_id'] ) : 0;
					$row['order_id'] = isset( $review['order_id'] ) ? absint( $review['order_id'] ) : 0;
					$row['item_id']  = isset( $review['item_id'] ) ? absint( $review['item_id'] ) : 0;
				}
				$reviews[] = $row;
			}
		}
		update_post_meta( $post_id, '_fy_reviews', $reviews );
	}

	/** AggregateRating + Review nodes for the Product schema. */
	public static function schema_parts( $yacht_id ) {
		$reviews = self::get( $yacht_id );
		if ( empty( $reviews ) ) {
			return array();
		}
		$stats = self::stats( $yacht_id );

		$nodes = array();
		foreach ( array_slice( $reviews, 0, 5 ) as $review ) {
			$node = array(
				'@type'        => 'Review',
				'author'       => array( '@type' => 'Person', 'name' => $review['name'] ? $review['name'] : __( 'Verified guest', 'fy-fleet' ) ),
				'reviewRating' => array( '@type' => 'Rating', 'ratingValue' => (int) $review['rating'], 'bestRating' => 5 ),
				'reviewBody'   => $review['text'],
			);
			if ( ! empty( $review['date'] ) ) {
				$node['datePublished'] = $review['date'];
			}
			$nodes[] = $node;
		}

		return array(
			'aggregateRating' => array(
				'@type'       => 'AggregateRating',
				'ratingValue' => $stats['average'],
				'reviewCount' => $stats['count'],
				'bestRating'  => 5,
			),
			'review'          => $nodes,
		);
	}

	/** Visible reviews block for the yacht page. */
	public static function render( $yacht_id ) {
		$reviews = self::get( $yacht_id );
		if ( empty( $reviews ) ) {
			return '';
		}
		$stats = self::stats( $yacht_id );

		ob_start();
		?>
		<section class="fy-reviews">
			<style>
			.fy-reviews{margin:22px 0;font-family:ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif}
			.fy-reviews-head{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px}
			.fy-reviews-title{
				margin:0;font-size:clamp(17px,2.4vw,22px);font-weight:950;letter-spacing:-.02em;
				background:linear-gradient(90deg,#C94386,#7C3AED,#2563EB);
				-webkit-background-clip:text;background-clip:text;color:transparent;
			}
			.fy-reviews-avg{
				display:inline-flex;align-items:center;gap:6px;padding:5px 11px;border-radius:999px;
				background:#FFF7E6;border:1px solid #F4C430;color:#7a5a00;font-size:12.5px;font-weight:900;
			}
			.fy-review{
				margin-bottom:9px;padding:13px 15px;border:1px solid rgba(124,58,237,.15);
				border-radius:14px;background:linear-gradient(180deg,#fff,#fffafd);
			}
			.fy-review-stars{color:#F4C430;font-size:14px;letter-spacing:1px}
			.fy-review-text{margin:5px 0;color:#172033;font-size:13.5px;font-weight:600;line-height:1.6}
			.fy-review-who{margin:0;color:#526079;font-size:11.5px;font-weight:800;display:flex;align-items:center;gap:7px}
			.fy-review-avatar{width:22px;height:22px;border-radius:50%;object-fit:cover;flex:none}
			.fy-review-verified{
				display:inline-flex;align-items:center;gap:3px;padding:1px 8px;border-radius:999px;
				background:#E1F5EE;color:#085041;font-size:10px;font-weight:900;letter-spacing:.02em;
			}
			</style>
			<div class="fy-reviews-head">
				<h3 class="fy-reviews-title">⭐ <?php esc_html_e( 'Guest reviews', 'fy-fleet' ); ?></h3>
				<span class="fy-reviews-avg">★ <?php echo esc_html( $stats['average'] ); ?> · <?php printf( esc_html( _n( '%d review', '%d reviews', $stats['count'], 'fy-fleet' ) ), (int) $stats['count'] ); ?></span>
			</div>
			<?php foreach ( $reviews as $review ) : ?>
				<?php $is_verified = isset( $review['source'] ) && 'customer' === $review['source']; ?>
				<div class="fy-review">
					<span class="fy-review-stars" aria-label="<?php echo esc_attr( $review['rating'] . '/5' ); ?>"><?php echo esc_html( str_repeat( '★', (int) $review['rating'] ) . str_repeat( '☆', 5 - (int) $review['rating'] ) ); ?></span>
					<p class="fy-review-text"><?php echo esc_html( $review['text'] ); ?></p>
					<p class="fy-review-who">
						<?php if ( $is_verified && ! empty( $review['user_id'] ) ) : ?>
							<img class="fy-review-avatar" src="<?php echo esc_url( get_avatar_url( (int) $review['user_id'], array( 'size' => 44 ) ) ); ?>" alt="" loading="lazy">
						<?php endif; ?>
						<span>— <?php echo esc_html( $review['name'] ? $review['name'] : __( 'Verified guest', 'fy-fleet' ) ); ?><?php echo $review['date'] ? esc_html( ' · ' . date_i18n( 'M Y', strtotime( $review['date'] ) ) ) : ''; ?></span>
						<?php if ( $is_verified ) : ?>
							<span class="fy-review-verified">✓ <?php esc_html_e( 'Verified Guest', 'fy-fleet' ); ?></span>
						<?php endif; ?>
					</p>
				</div>
			<?php endforeach; ?>
		</section>
		<?php
		return ob_get_clean();
	}
}
